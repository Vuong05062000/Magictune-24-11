package com.example.core.adb

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AdbPairingInputParserTest {

    @Test
    fun parsesPureSixDigitPin() {
        val parsed = AdbPairingInputParser.parse("482910")
        assertEquals("482910", parsed.pin)
        assertNull(parsed.port)
        assertNull(parsed.host)
    }

    @Test
    fun parsesSpacedAndDashedPin() {
        val spaced = AdbPairingInputParser.parse("482 910")
        assertEquals("482910", spaced.pin)
        assertNull(spaced.port)

        val dashed = AdbPairingInputParser.parse("482-910")
        assertEquals("482910", dashed.pin)
        assertNull(dashed.port)
    }

    @Test
    fun parsesPortAndPinWithSpaceOrColon() {
        val spaceSep = AdbPairingInputParser.parse("38475 123456")
        assertEquals(38475, spaceSep.port)
        assertEquals("123456", spaceSep.pin)

        val colonSep = AdbPairingInputParser.parse("41902:654321")
        assertEquals(41902, colonSep.port)
        assertEquals("654321", colonSep.pin)
    }

    @Test
    fun parsesHostPortAndPin() {
        val parsed = AdbPairingInputParser.parse("192.168.1.42:39125 908172")
        assertEquals("192.168.1.42", parsed.host)
        assertEquals(39125, parsed.port)
        assertEquals("908172", parsed.pin)
    }

    @Test
    fun parsesConcatenated11DigitPortAndPin() {
        val parsed = AdbPairingInputParser.parse("38475123456")
        assertEquals(38475, parsed.port)
        assertEquals("123456", parsed.pin)
    }

    @Test
    fun parsesPinBeforePort() {
        val parsed = AdbPairingInputParser.parse("123456 38475")
        assertEquals(38475, parsed.port)
        assertEquals("123456", parsed.pin)
    }

    @Test
    fun handlesShortOrEmptyInputGracefully() {
        val empty = AdbPairingInputParser.parse("   ")
        assertNull(empty.pin)
        assertNull(empty.port)

        val short = AdbPairingInputParser.parse("123")
        assertNull(short.pin)
        assertNull(short.port)
    }
}
