package com.example.core.service

import android.annotation.SuppressLint
import android.app.Activity
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.ComponentName
import android.content.Context
import android.content.BroadcastReceiver
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.widget.Toast
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.example.MainActivity
import com.example.core.shell.ShellEngine
import com.example.data.FloatingMiniWindowState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.delay
import kotlin.math.abs

/**
 * Quản lý 2 lớp phủ Hệ thống (TYPE_APPLICATION_OVERLAY - Hiển thị trên ứng dụng khác):
 * 1. Live Automation PiP HUD: Nổi trực tiếp TRÊN màn hình Cài đặt Android khi đang tự động gạt công tắc
 *    "Thông báo nhẹ nhàng" -> TẮT và "Biểu ngữ" -> BẬT tận mắt người dùng.
 *    Sử dụng FLAG_NOT_FOCUSABLE để không bao giờ cướp tiêu điểm (focus) của màn hình Cài đặt bên dưới,
 *    giúp uiautomator dump và input tap hoạt động chính xác 100%.
 * 2. Smart NavBar Google / Magic Live Bridge: Cầu nối cảm ứng thanh điều hướng đáy + Chặn YOYO chiếm quyền,
 *    đảm bảo nhấn giữ thanh điều hướng trên Honor MagicOS luôn gọi Khoanh tròn hỏi AI hoặc Trợ lý Magic
 *    kể cả khi hệ thống Honor khóa cứng cho YOYO hoặc khi đã tắt Gỡ lỗi / Tùy chọn nhà phát triển.
 */
object SystemFloatingHudOverlay {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val navBridgeSyncPending = java.util.concurrent.atomic.AtomicBoolean(false)
    @Volatile private var navScreenStateReceiver: BroadcastReceiver? = null
    @Volatile private var navScreenStateReceiverContext: Context? = null
    private val ioScope = CoroutineScope(
        kotlinx.coroutines.SupervisorJob() +
            Dispatchers.IO +
            com.example.MagicTuneApplication.globalCoroutineExceptionHandler
    )

    /**
     * V4.7.5: 2 nút điều hướng HUD (đặc biệt là nút Phải gọi Vẽ Chữ Mở App và nút Trái gọi Khoanh Tròn)
     * hoạt động ngay khi đã cấp quyền Hiển thị trên ứng dụng khác (canDrawSystemOverlay)
     * kể cả khi KHÔNG có kết nối gỡ lỗi WLAN!
     */
    private fun isNavBridgeUnlocked(context: Context): Boolean {
        val appCtx = context.applicationContext ?: context
        return canDrawSystemOverlay(appCtx)
    }

    fun isNavBridgeConfiguredActive(context: Context): Boolean {
        val appCtx = context.applicationContext ?: context
        val mode = getActiveNavModMode(appCtx)
        return (mode == "CIRCLE_TO_SEARCH" || mode == "MAGIC_LIVE") &&
            isNavBridgeUnlocked(appCtx) &&
            canDrawSystemOverlay(appCtx)
    }

    fun needsNavBridgeAttach(context: Context): Boolean {
        return isNavBridgeConfiguredActive(context) && (navLeftView == null || navRightView == null)
    }

    // --- 1. LIVE AUTOMATION FLOATING HUD STATE ---
    private var hudRootView: View? = null
    private var hudStepBadgeView: TextView? = null
    private var hudAppTitleView: TextView? = null
    private var hudActionDetailView: TextView? = null
    private var hudProgressBar: ProgressBar? = null
    private var hudLayoutParams: WindowManager.LayoutParams? = null
    private var onStopAutomationCallback: (() -> Unit)? = null

    // --- 2. DUAL SPLIT NAVBAR BUTTONS (LEFT: GOOGLE CIRCLE TO SEARCH, RIGHT: TRỢ LÝ MAGIC) ---
    private var navLeftView: View? = null
    private var navLeftParams: WindowManager.LayoutParams? = null
    private var navRightView: View? = null
    private var navRightParams: WindowManager.LayoutParams? = null
    private var leftPillView: View? = null
    private var rightPillView: View? = null
    private var isNavBridgeActiveAfterBoot: Boolean = false // Đảm bảo hiện ngay sau khi cài/boot
    @Volatile
    var isCurrentlyOnHome: Boolean = true
        private set
    const val KEY_TOP_LEFT_CARRIER_SWIPE_ENABLED = "magictune_top_left_carrier_swipe_enabled"
    const val KEY_NAV_BAR_LENGTH_PERCENT = "magictune_nav_bar_length_percent"
    private const val DEFAULT_NAV_BAR_LENGTH_PERCENT = 50

    @Volatile
    private var isNavBridgeSuppressedForCts: Boolean = false

    fun getNavBarLengthPercent(context: Context): Int {
        val appCtx = context.applicationContext ?: context
        val prefs = getNavBridgePrefs(appCtx)
        return prefs.getInt(KEY_NAV_BAR_LENGTH_PERCENT, DEFAULT_NAV_BAR_LENGTH_PERCENT).coerceIn(50, 100)
    }

    fun getNavBarLengthScale(context: Context): Float {
        return getNavBarLengthPercent(context) / 100f
    }

    fun setNavBarLengthPercent(context: Context, percent: Int) {
        val appCtx = context.applicationContext ?: context
        val p = percent.coerceIn(50, 100)
        try {
            appCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE).edit()
                .putInt(KEY_NAV_BAR_LENGTH_PERCENT, p)
                .apply()
            getNavBridgePrefs(appCtx).edit()
                .putInt(KEY_NAV_BAR_LENGTH_PERCENT, p)
                .apply()
        } catch (_: Throwable) {}
        updateNavBarLength(appCtx)
    }

    fun updateNavBarLength(context: Context) {
        val appCtx = context.applicationContext ?: context
        mainHandler.post {
            try {
                if (!isNavBridgeUnlocked(appCtx)) {
                    removeNavBridgeInternal(appCtx)
                    return@post
                }
                val scale = getNavBarLengthScale(appCtx)
                val pillW = dp((60f * scale).toInt(), appCtx)
                val containerW = pillW
                val hideLeft = isLeftPillEffectivelyHidden(appCtx)
                val hideRight = isRightPillEffectivelyHidden(appCtx)

                leftPillView?.let { v ->
                    val lp = (v.layoutParams as? FrameLayout.LayoutParams)
                        ?: FrameLayout.LayoutParams(pillW, dpF(7.2f, appCtx).toInt())
                    lp.width = pillW
                    lp.gravity = Gravity.START or Gravity.CENTER_VERTICAL
                    lp.leftMargin = 0
                    v.layoutParams = lp
                    v.requestLayout()
                }
                rightPillView?.let { v ->
                    val lp = (v.layoutParams as? FrameLayout.LayoutParams)
                        ?: FrameLayout.LayoutParams(pillW, dpF(7.2f, appCtx).toInt())
                    lp.width = pillW
                    lp.gravity = Gravity.END or Gravity.CENTER_VERTICAL
                    lp.rightMargin = 0
                    v.layoutParams = lp
                    v.requestLayout()
                }

                val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return@post
                val edgeOffset = computeNavPillEdgeOffsetPx(appCtx, containerW)
                navLeftView?.let { v ->
                    navLeftParams?.let { p ->
                        if (!hideLeft) {
                            p.width = containerW
                            p.height = dp(17, appCtx)
                            p.x = edgeOffset
                            p.alpha = 1f
                            p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                        } else {
                            p.width = 0
                            p.height = 0
                            p.x = 0
                            p.alpha = 0f
                            p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        }
                        p.gravity = Gravity.BOTTOM or Gravity.LEFT
                        p.y = 0
                        if (v.isAttachedToWindow) {
                            try { wm.updateViewLayout(v, p) } catch (_: Throwable) {}
                        }
                    }
                    v.requestLayout()
                }
                navRightView?.let { v ->
                    navRightParams?.let { p ->
                        if (!hideRight) {
                            p.width = containerW
                            p.height = dp(17, appCtx)
                            p.x = edgeOffset
                            p.alpha = 1f
                            p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                        } else {
                            p.width = 0
                            p.height = 0
                            p.x = 0
                            p.alpha = 0f
                            p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        }
                        p.gravity = Gravity.BOTTOM or Gravity.RIGHT
                        p.y = 0
                        if (v.isAttachedToWindow) {
                            try { wm.updateViewLayout(v, p) } catch (_: Throwable) {}
                        }
                    }
                    v.requestLayout()
                }
                refreshNavPillColors(appCtx)
            } catch (_: Throwable) {}
        }
    }

    @Volatile
    private var lastAssistantTriggerMs: Long = 0L
    @Volatile
    var lastAssistantTriggerMode: String = ""
    @Volatile
    private var lastUsmQueryMs: Long = 0L
    @Volatile
    private var cachedLatestPkg: String? = null
    @Volatile
    private var lastNavVisibilitySig: String? = null
    @Volatile
    private var lastNavColorUnlocked: Boolean? = null
    @Volatile
    private var lastNotifiedForegroundPkg: String? = null
    @Volatile
    private var lastKnownForegroundPkg: String? = null
    @Volatile
    private var isAutoHiddenForVideo: Boolean = false
    @Volatile
    private var isAudioCallbackRegistered: Boolean = false
    @Volatile
    private var audioPlaybackCallback: Any? = null
    @Volatile
    private var lastVideoAsyncCheckElapsedMs: Long = 0L
    private var pendingShowAfterVideoRunnable: Runnable? = null
    private var watcherAppContextRef: Context? = null

    private val alwaysVideoFeedPackages = setOf(
        "com.zhiliaoapp.musically",
        "com.ss.android.ugc.trill",
        "com.ss.android.ugc.aweme",
        "com.ss.android.ugc.aweme.lite",
        "com.kwai.video",
        "com.smile.gifmaker"
    )

    private val portraitFullscreenPlayerPackages = setOf(
        "com.hihonor.video",
        "com.huawei.himovie",
        "com.huawei.himovie.overseas",
        "com.mxtech.videoplayer.ad",
        "com.mxtech.videoplayer.pro",
        "org.videolan.vlc",
        "is.xyz.mpv",
        "org.xbmc.kodi",
        "org.courville.nova",
        "com.kmplayer",
        "video.player.videoplayer"
    )

    private val pureMusicAudioPackages = setOf(
        "com.spotify.music",
        "com.zing.mp3",
        "com.nct.android",
        "vn.nhaccuatui.player",
        "com.google.android.apps.youtube.music",
        "com.soundcloud.android",
        "com.hihonor.mediacenter",
        "com.huawei.music",
        "com.deezer.android.app",
        "com.aspiro.tidal"
    )

    private fun isPortraitFullscreenPlayerPackage(pkg: String?): Boolean {
        if (pkg.isNullOrBlank()) return false
        val p = pkg.lowercase()
        if (pureMusicAudioPackages.contains(p)) return false
        return portraitFullscreenPlayerPackages.contains(p) ||
            p.contains("videoplayer") ||
            p.contains("movieplayer")
    }

    private fun computeShouldAutoHideForVideo(context: Context, explicitFgPkg: String? = null): Boolean {
        val appCtx = context.applicationContext ?: context
        val fgPkg = (explicitFgPkg ?: lastKnownForegroundPkg ?: cachedLatestPkg).orEmpty().trim()
        val lowerFg = fgPkg.lowercase()
        val ownPkg = appCtx.packageName

        val isOwnApp = fgPkg.equals(ownPkg, ignoreCase = true)
        val isHome = fgPkg.isBlank() || isHomeScreenPackage(fgPkg, appCtx)
        val isSystemUiOrSettings = fgPkg == "com.android.systemui" ||
            MagicTuneCtsAccessibilityService.isSystemSettingsPackage(fgPkg)

        // Không bao giờ ẩn khi đang ở Màn hình chính hoặc trang Cài đặt hệ thống
        if (isHome || isSystemUiOrSettings) {
            return false
        }

        val am = appCtx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val isStreamMusicActive = try { am?.isMusicActive == true } catch (_: Throwable) { false }
        if (!isStreamMusicActive) {
            return false
        }

        var hasMovieAttr = false
        var hasMediaUsageAttr = false
        var hasGameUsageAttr = false

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val activeConfigs = AudioPlaybackCompatApi26.getActivePlaybackConfigurations(am)
            for (cfg in activeConfigs) {
                val attrs = cfg.audioAttributes ?: continue
                when (attrs.usage) {
                    AudioAttributes.USAGE_MEDIA -> {
                        hasMediaUsageAttr = true
                        if (attrs.contentType == AudioAttributes.CONTENT_TYPE_MOVIE) {
                            hasMovieAttr = true
                        }
                    }
                    AudioAttributes.USAGE_GAME -> hasGameUsageAttr = true
                }
            }
        }

        // Loại bỏ trường hợp đang chơi game (USAGE_GAME) hoặc ứng dụng chỉ nghe nhạc thuần túy
        val isOnlyGameAudio = hasGameUsageAttr && !hasMediaUsageAttr
        if (isOnlyGameAudio) {
            return false
        }

        val isLandscape = appCtx.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

        if (isOwnApp) {
            return isLandscape && hasMovieAttr
        }

        if (pureMusicAudioPackages.contains(lowerFg)) {
            return isLandscape && hasMovieAttr
        }

        // 1. Phát video toàn màn hình ngang (YouTube, Netflix, FPT Play, VieON, Chrome, Facebook, VLC...)
        if (isLandscape) {
            return true
        }

        // 2. Phát video toàn màn hình dọc (TikTok / Douyin đang thực sự phát video)
        if (alwaysVideoFeedPackages.contains(lowerFg)) {
            return true
        }

        // 3. Trình phát video nội bộ toàn màn hình dọc đang phát luồng video chuẩn MOVIE
        if (isPortraitFullscreenPlayerPackage(fgPkg) && hasMovieAttr) {
            return true
        }

        return false
    }

    private fun cancelPendingShowAfterVideo() {
        pendingShowAfterVideoRunnable?.let { mainHandler.removeCallbacks(it) }
        pendingShowAfterVideoRunnable = null
    }

    private fun applyVideoAutoHideDecision(context: Context, shouldHide: Boolean, immediateRestore: Boolean) {
        val appCtx = context.applicationContext ?: context
        if (shouldHide) {
            cancelPendingShowAfterVideo()
            if (!isAutoHiddenForVideo) {
                isAutoHiddenForVideo = true
                updateNavPillsVisibility(appCtx)
            }
            return
        }

        if (!isAutoHiddenForVideo) {
            cancelPendingShowAfterVideo()
            return
        }

        if (immediateRestore) {
            cancelPendingShowAfterVideo()
            isAutoHiddenForVideo = false
            updateNavPillsVisibility(appCtx)
        } else if (pendingShowAfterVideoRunnable == null) {
            val runnable = Runnable {
                pendingShowAfterVideoRunnable = null
                val recheckHide = computeShouldAutoHideForVideo(appCtx)
                if (recheckHide != isAutoHiddenForVideo) {
                    isAutoHiddenForVideo = recheckHide
                    updateNavPillsVisibility(appCtx)
                }
            }
            pendingShowAfterVideoRunnable = runnable
            mainHandler.postDelayed(runnable, 800L)
        }
    }

    private fun refreshVideoAutoHideState(context: Context, explicitFgPkg: String? = null, immediateRestore: Boolean = false) {
        val appCtx = context.applicationContext ?: context
        val shouldHide = computeShouldAutoHideForVideo(appCtx, explicitFgPkg)
        if (Looper.myLooper() == Looper.getMainLooper()) {
            applyVideoAutoHideDecision(appCtx, shouldHide, immediateRestore)
        } else {
            mainHandler.post {
                applyVideoAutoHideDecision(appCtx, shouldHide, immediateRestore)
            }
        }
    }

    private fun scheduleVideoAutoHideCheck(context: Context, immediate: Boolean = false) {
        val appCtx = context.applicationContext ?: context
        val pm = appCtx.getSystemService(Context.POWER_SERVICE) as? PowerManager
        if (pm?.isInteractive == false) return

        val fgLower = lastKnownForegroundPkg.orEmpty().lowercase()
        val fastHide = computeShouldAutoHideForVideo(appCtx)
        if (fastHide) {
            applyVideoAutoHideDecision(appCtx, true, immediateRestore = false)
        }

        val nowElapsed = SystemClock.elapsedRealtime()
        if (!immediate && nowElapsed - lastVideoAsyncCheckElapsedMs < 3_500L) {
            return
        }
        lastVideoAsyncCheckElapsedMs = nowElapsed

        ioScope.launch {
            try {
                val freshPkg = NoAccessibilityScreenEngine.getActiveForegroundPackage(appCtx)
                    ?: getLatestForegroundPackage(appCtx)
                if (!freshPkg.isNullOrBlank() && freshPkg != "com.android.systemui" && freshPkg != "android") {
                    if (freshPkg != lastKnownForegroundPkg) {
                        onForegroundAppChanged(appCtx, freshPkg)
                    }
                    lastKnownForegroundPkg = freshPkg
                } else if (freshPkg != null && isHomeScreenPackage(freshPkg, appCtx)) {
                    if (lastKnownForegroundPkg != freshPkg) {
                        onForegroundAppChanged(appCtx, freshPkg)
                    }
                }
                val isHomeOrNonVideo = freshPkg.isNullOrBlank() ||
                    isHomeScreenPackage(freshPkg, appCtx) ||
                    freshPkg.equals(appCtx.packageName, ignoreCase = true)
                val shouldHide = computeShouldAutoHideForVideo(appCtx, freshPkg)
                val immediateShow = isHomeOrNonVideo && !alwaysVideoFeedPackages.contains(fgLower)
                mainHandler.post {
                    applyVideoAutoHideDecision(appCtx, shouldHide, immediateRestore = immediateShow)
                }
            } catch (_: Throwable) {}
        }
    }

    private val delayedAudioRecheckRunnable = Runnable {
        val ctx = watcherAppContextRef ?: return@Runnable
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager
        if (pm?.isInteractive == false) return@Runnable
        if (navLeftView != null || navRightView != null) {
            scheduleVideoAutoHideCheck(ctx, immediate = false)
        }
    }

    @androidx.annotation.RequiresApi(Build.VERSION_CODES.O)
    private object AudioPlaybackCompatApi26 {
        fun getActivePlaybackConfigurations(am: AudioManager?): List<android.media.AudioPlaybackConfiguration> {
            return try {
                am?.activePlaybackConfigurations.orEmpty()
            } catch (_: Throwable) {
                emptyList()
            }
        }

        fun createAndRegister(
            am: AudioManager,
            handler: Handler,
            onChanged: () -> Unit
        ): Any {
            val cb = object : AudioManager.AudioPlaybackCallback() {
                override fun onPlaybackConfigChanged(configs: MutableList<android.media.AudioPlaybackConfiguration>?) {
                    onChanged()
                }
            }
            am.registerAudioPlaybackCallback(cb, handler)
            return cb
        }

        fun unregister(am: AudioManager?, cb: Any) {
            try {
                (cb as? AudioManager.AudioPlaybackCallback)?.let {
                    am?.unregisterAudioPlaybackCallback(it)
                }
            } catch (_: Throwable) {}
        }
    }

    private fun registerAudioPlaybackWatcher(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val appCtx = context.applicationContext ?: context
        watcherAppContextRef = appCtx
        if (isAudioCallbackRegistered) return
        try {
            val am = appCtx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            val cb = AudioPlaybackCompatApi26.createAndRegister(am, mainHandler) {
                val pm = appCtx.getSystemService(Context.POWER_SERVICE) as? PowerManager
                if (pm?.isInteractive == false) return@createAndRegister
                scheduleVideoAutoHideCheck(appCtx, immediate = false)
                // Nếu vừa dừng/chuyển bài ngắn, kiểm tra lại sau 950ms để khôi phục nút ngay khi audio thực sự ngắt
                mainHandler.removeCallbacks(delayedAudioRecheckRunnable)
                mainHandler.postDelayed(delayedAudioRecheckRunnable, 950L)
            }
            audioPlaybackCallback = cb
            isAudioCallbackRegistered = true
        } catch (_: Throwable) {}
    }

    private fun unregisterAudioPlaybackWatcher(context: Context) {
        val appCtx = context.applicationContext ?: watcherAppContextRef ?: return
        mainHandler.removeCallbacks(delayedAudioRecheckRunnable)
        cancelPendingShowAfterVideo()
        isAutoHiddenForVideo = false
        val cb = audioPlaybackCallback ?: return
        audioPlaybackCallback = null
        isAudioCallbackRegistered = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val am = appCtx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                AudioPlaybackCompatApi26.unregister(am, cb)
            } catch (_: Throwable) {}
        }
    }

    // --- 3. POST-FACE-UNLOCK HANDS-FREE TRỢ LÝ MAGIC WAKE LISTENER ---
    private var unlockSpeechRecognizer: android.speech.SpeechRecognizer? = null
    @Volatile
    private var isUnlockVoiceListening: Boolean = false
    @Volatile
    private var magicLiveSessionActiveUntilMs: Long = 0L
    private val stopUnlockListenRunnable = Runnable {
        stopUnlockVoiceWakeListener()
    }

    private fun showPillsTemporarily() {
        // Luôn luôn hiển thị rực rỡ vĩnh viễn ở alpha 0.99f khi ở màn hình chính
    }

    private fun updatePillsAlpha() {
        val targetAlpha = if (isAutoHiddenForVideo) 0f else 0.92f
        mainHandler.post {
            leftPillView?.let { v ->
                if (kotlin.math.abs(v.alpha - targetAlpha) > 0.02f) {
                    v.animate()?.alpha(targetAlpha)?.setDuration(250)?.start()
                }
            }
            rightPillView?.let { v ->
                if (kotlin.math.abs(v.alpha - targetAlpha) > 0.02f) {
                    v.animate()?.alpha(targetAlpha)?.setDuration(250)?.start()
                }
            }
        }
    }

    val yoyoPackages = setOf(
        "com.hihonor.magicvoice",
        "com.hihonor.yoyo",
        "com.hihonor.assistant",
        "com.hihonor.ai.agent",
        "com.hihonor.aiagent",
        "com.hihonor.vassistant",
        "com.huawei.vassistant",
        "com.hihonor.voiceassistant",
        "com.hihonor.hiaction",
        "com.hihonor.hiaye"
    )

    fun dismissActiveYoyoSession(context: Context) {
        val appCtx = context.applicationContext ?: context
        try {
            val shell = ShellEngine.getInstance(appCtx)
            if (shell.state.value.isAdbReady) {
                ioScope.launch {
                    try {
                        val allYoyoPkgs = yoyoPackages.plus(listOf(
                            "com.hihonor.magicvoice",
                            "com.hihonor.yoyo",
                            "com.hihonor.assistant",
                            "com.hihonor.ai.agent",
                            "com.hihonor.aiagent",
                            "com.hihonor.hiaye",
                            "com.hihonor.hiaction"
                        )).distinct()
                        val cmds = allYoyoPkgs.joinToString("; ") { "am force-stop $it >/dev/null 2>&1" }
                        shell.execute(cmds)
                    } catch (_: Throwable) {}
                }
            }
        } catch (_: Throwable) {}
    }

    private val magicLiveAndGoogleVoicePackages = setOf(
        "com.google.android.apps.bard",
        "com.google.android.googlequicksearchbox"
    )

    fun canDrawSystemOverlay(context: Context): Boolean {
        return try {
            Settings.canDrawOverlays(context)
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Cập nhật hoặc hiển thị cửa sổ PiP HUD nổi trực tiếp trên các ứng dụng khác (như Cài đặt Android)
     * trong suốt quá trình tự động mở trang thông báo và gạt công tắc.
     */
    private var lastHudCtx: Context? = null
    private val hudSafetyAutoHideRunnable = Runnable {
        lastHudCtx?.let { removeHudInternal(it) }
    }

    fun updateAutomationHud(
        context: Context,
        state: FloatingMiniWindowState,
        onStopClick: () -> Unit
    ) {
        val appCtx = context.applicationContext
        lastHudCtx = appCtx
        onStopAutomationCallback = onStopClick
        mainHandler.post {
            try {
                if (!state.isVisible || !canDrawSystemOverlay(appCtx)) {
                    removeHudInternal(appCtx)
                    return@post
                }
                // Chỉ hiển thị System Overlay HUD khi đang chạy tự động hóa (vì lúc đó Cài đặt Android đè lên MagicTune)
                // Khi đã quay về màn hình MagicTune và kết thúc, Compose FloatingAutomationOverlay sẽ hiển thị kết quả.
                if (!state.isRunningAutomation) {
                    removeHudInternal(appCtx)
                    return@post
                }

                ensureHudViewCreated(appCtx)
                mainHandler.removeCallbacks(hudSafetyAutoHideRunnable)
                mainHandler.postDelayed(hudSafetyAutoHideRunnable, 30_000L)
                val pct = if (state.totalSteps > 0) {
                    ((state.currentStep.toFloat() / state.totalSteps.toFloat()) * 100f).toInt().coerceIn(5, 100)
                } else 0

                hudStepBadgeView?.text = "⚡ AUTO-CLICKER • Bước ${state.currentStep}/${state.totalSteps} ($pct%)"
                hudAppTitleView?.text = "🎯 ${state.currentAppName.ifBlank { "Đang xử lý..." }}"
                hudActionDetailView?.text = state.currentActionDetail.ifBlank { "Đang tự động gạt công tắc..." }
                hudProgressBar?.progress = pct
            } catch (_: Exception) {}
        }
    }

    fun hideAutomationHud(context: Context) {
        val appCtx = context.applicationContext
        mainHandler.post {
            removeHudInternal(appCtx)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun ensureHudViewCreated(context: Context) {
        if (hudRootView != null) return
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return

        val density = context.resources.displayMetrics.density
        fun dp(v: Int): Int = (v * density).toInt()

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(14).toFloat()
                setColor(Color.parseColor("#F20F172A"))
                setStroke(dp(2), Color.parseColor("#06B6D4"))
            }
            elevation = dp(10).toFloat()
        }

        // Top row: Badge + Stop Button
        val topRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val stepBadge = TextView(context).apply {
            text = "⚡ AUTO-CLICKER ĐANG GẠT CÔNG TẮC"
            setTextColor(Color.parseColor("#22D3EE"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        hudStepBadgeView = stepBadge

        val stopBtn = TextView(context).apply {
            text = "⏹ DỪNG"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor("#EF4444"))
            }
            setOnClickListener {
                onStopAutomationCallback?.invoke()
                removeHudInternal(context)
            }
        }

        topRow.addView(stepBadge)
        topRow.addView(stopBtn)
        container.addView(topRow)

        // App Title
        val appTitle = TextView(context).apply {
            text = "Đang mở Cài đặt thông báo..."
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, dp(4), 0, dp(2))
        }
        hudAppTitleView = appTitle
        container.addView(appTitle)

        // Action Detail
        val detailTv = TextView(context).apply {
            text = "Tự động tắt Báo nhẹ nhàng & bật Biểu ngữ..."
            setTextColor(Color.parseColor("#A7F3D0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        hudActionDetailView = detailTv
        container.addView(detailTv)

        // Progress Bar
        val progress = ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 15
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(5)
            ).apply {
                topMargin = dp(6)
            }
        }
        hudProgressBar = progress
        container.addView(progress)

        val screenWidth = context.resources.displayMetrics.widthPixels
        val hudWidth = (screenWidth - dp(24)).coerceAtMost(dp(420))

        val overlayType = com.example.core.compat.DeviceCompatProfile.overlayWindowType()

        val params = WindowManager.LayoutParams(
            hudWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(32)
        }

        // Cho phép kéo thanh HUD lên/xuống nếu người dùng muốn đổi vị trí
        var initialY = 0
        var touchStartY = 0f
        container.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialY = params.y
                    touchStartY = event.rawY
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = (event.rawY - touchStartY).toInt()
                    if (abs(dy) > dp(6)) {
                        params.y = (initialY + dy).coerceIn(dp(16), dp(500))
                        if (container.isAttachedToWindow) {
                            try {
                                wm.updateViewLayout(container, params)
                            } catch (_: Throwable) {}
                        }
                        true
                    } else false
                }
                else -> false
            }
        }

        try {
            wm.addView(container, params)
            hudRootView = container
            hudLayoutParams = params
        } catch (_: Throwable) {}
    }

    private fun removeHudInternal(context: Context) {
        mainHandler.removeCallbacks(hudSafetyAutoHideRunnable)
        val view = hudRootView ?: return
        hudRootView = null
        hudStepBadgeView = null
        hudAppTitleView = null
        hudActionDetailView = null
        hudProgressBar = null
        hudLayoutParams = null
        try {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            if (view.isAttachedToWindow) {
                wm?.removeViewImmediate(view)
            }
        } catch (_: Throwable) {
            try {
                val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
                wm?.removeView(view)
            } catch (_: Throwable) {}
        }
    }

    // ========================================================================================
    // 2. SMART NAVBAR GOOGLE / GEMINI BRIDGE (VƯỢT KHÓA CỨNG YOYO TRÊN HONOR MAGICOS)
    // ========================================================================================

    private const val PREFS_NAV_BRIDGE = "magictune_nav_bridge_forever_prefs"
    private const val KEY_NAV_MOD_MODE = "magictune_nav_mod_mode"
    private const val KEY_NAV_EXPLICIT_DISABLED = "magictune_nav_explicit_disabled"
    private const val KEY_TRIGGER_GESTURE_TYPE = "magictune_trigger_gesture_type"
    private const val KEY_YOYO_COEXIST_MODE = "magictune_yoyo_coexist_mode"
    private const val KEY_HIDE_LEFT_PILL = "magictune_hide_left_pill"
    private const val KEY_HIDE_RIGHT_PILL = "magictune_hide_right_pill"
    private const val KEY_HIDE_BOTH_PILLS = "magictune_hide_both_pills"
    private const val KEY_NAV_PILLS_CENTERED = "magictune_nav_pills_centered"

    /**
     * V4.9: Kiểm tra trạng thái đẩy 2 nút điều hướng vào giữa màn hình (thay thế YOYO)
     * hay đặt ở 2 mép màn hình (dùng song song với YOYO).
     */
    fun isNavPillsCentered(context: Context): Boolean {
        val appCtx = context.applicationContext ?: context
        return try {
            val stdPrefs = appCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE)
            if (stdPrefs.contains(KEY_NAV_PILLS_CENTERED)) {
                return stdPrefs.getBoolean(KEY_NAV_PILLS_CENTERED, false)
            }
            getNavBridgePrefs(appCtx).getBoolean(KEY_NAV_PILLS_CENTERED, false)
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * V4.9: Bật/tắt chế độ đẩy 2 nút điều hướng vào giữa màn hình.
     * - centered = true: Đẩy 2 nút vào chính giữa cạnh đáy màn hình (kèm tắt YOYO).
     * - centered = false: Trả 2 nút về 2 mép trái/phải màn hình (kèm khôi phục YOYO ở giữa).
     */
    fun setNavPillsCentered(context: Context, centered: Boolean) {
        val appCtx = context.applicationContext ?: context
        try {
            appCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_NAV_PILLS_CENTERED, centered)
                .apply()
            getNavBridgePrefs(appCtx).edit()
                .putBoolean(KEY_NAV_PILLS_CENTERED, centered)
                .apply()
        } catch (_: Throwable) {}
        setYoyoCoexistModeEnabled(appCtx, !centered)
        savePersistentNavModMode(appCtx, "CIRCLE_TO_SEARCH", explicitlyDisabled = false)
        mainHandler.post {
            if (navLeftView == null || navRightView == null) {
                syncNavBarBridge(appCtx)
            } else {
                updateNavBarLength(appCtx)
                updateNavPillsVisibility(appCtx)
            }
        }
    }

    private fun computeNavPillEdgeOffsetPx(context: Context, pillWidthPx: Int): Int {
        val appCtx = context.applicationContext ?: context
        if (!isNavPillsCentered(appCtx)) return 0
        val screenW = appCtx.resources.displayMetrics.widthPixels
        val halfGap = dp(6, appCtx)
        return ((screenW / 2) - pillWidthPx - halfGap).coerceAtLeast(0)
    }

    private fun getNavBridgePrefs(context: Context): android.content.SharedPreferences {
        val appCtx = context.applicationContext ?: context
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                val dpCtx = appCtx.createDeviceProtectedStorageContext()
                dpCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE)
            } else {
                appCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE)
            }
        } catch (_: Throwable) {
            appCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE)
        }
    }

    @Volatile
    private var cachedActiveNavModMode: String? = null

    @Volatile
    private var cachedMagicLiveMicWake: Boolean? = null

    fun invalidateMicWakeCache(enabled: Boolean? = null) {
        cachedMagicLiveMicWake = enabled
    }

    /**
     * Lưu chế độ Mod Phím Điều Hướng bền vững qua Khởi động lại máy (Direct Boot + SharedPreferences + Settings.Secure + ShellEngine)
     * để tính năng Khoanh tròn hỏi AI & Trò Chuyện Magic Live luôn hoạt động ngay cả khi tắt Gỡ lỗi WLAN / ADB hoặc khởi động lại điện thoại,
     * chỉ ẩn đi khi người dùng gỡ cài đặt ứng dụng chính hoặc chủ động bấm Khôi phục YOYO gốc.
     */
    fun savePersistentNavModMode(context: Context, mode: String, explicitlyDisabled: Boolean = false) {
        val appCtx = context.applicationContext ?: context
        cachedActiveNavModMode = if (explicitlyDisabled) "DEFAULT" else mode
        if (mode != "MAGIC_LIVE" || explicitlyDisabled) {
            cachedMagicLiveMicWake = false
        }
        try {
            getNavBridgePrefs(appCtx).edit()
                .putString(KEY_NAV_MOD_MODE, mode)
                .putBoolean(KEY_NAV_EXPLICIT_DISABLED, explicitlyDisabled)
                .apply()
        } catch (_: Throwable) {}
        try {
            appCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE).edit()
                .putString(KEY_NAV_MOD_MODE, mode)
                .putBoolean(KEY_NAV_EXPLICIT_DISABLED, explicitlyDisabled)
                .apply()
        } catch (_: Throwable) {}
        try {
            val shell = ShellEngine.getInstance(appCtx)
            if (shell.getPersistedSetting("secure", KEY_NAV_MOD_MODE) != mode) {
                shell.setPersistedSetting("secure", KEY_NAV_MOD_MODE, mode)
            }
        } catch (_: Throwable) {}
        try {
            val cr = appCtx.contentResolver
            if (Settings.Secure.getString(cr, KEY_NAV_MOD_MODE) != mode) {
                Settings.Secure.putString(cr, KEY_NAV_MOD_MODE, mode)
            }
        } catch (_: Throwable) {}
    }

    /**
     * Đọc chế độ Mod Phím Điều Hướng hiện tại ("CIRCLE_TO_SEARCH", "MAGIC_LIVE", hoặc "DEFAULT").
     * Mặc định luôn duy trì "CIRCLE_TO_SEARCH" (cho phép đồng thời cả Khoanh tròn Google & Trò chuyện Trợ lý Magic)
     * kể cả sau khi khởi động lại máy hay tắt WLAN/ADB, trừ khi người dùng chủ động tắt.
     */
    fun getActiveNavModMode(context: Context): String {
        cachedActiveNavModMode?.let { return it }
        val appCtx = context.applicationContext ?: context
        try {
            val dpPrefs = getNavBridgePrefs(appCtx)
            if (dpPrefs.getBoolean(KEY_NAV_EXPLICIT_DISABLED, false)) {
                cachedActiveNavModMode = "DEFAULT"
                return "DEFAULT"
            }
            val savedDp = dpPrefs.getString(KEY_NAV_MOD_MODE, null)
            if (savedDp == "CIRCLE_TO_SEARCH" || savedDp == "MAGIC_LIVE") {
                cachedActiveNavModMode = savedDp
                return savedDp
            }
        } catch (_: Throwable) {}

        try {
            val stdPrefs = appCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE)
            if (stdPrefs.getBoolean(KEY_NAV_EXPLICIT_DISABLED, false)) {
                cachedActiveNavModMode = "DEFAULT"
                return "DEFAULT"
            }
            val savedStd = stdPrefs.getString(KEY_NAV_MOD_MODE, null)
            if (savedStd == "CIRCLE_TO_SEARCH" || savedStd == "MAGIC_LIVE") {
                cachedActiveNavModMode = savedStd
                return savedStd
            }
        } catch (_: Throwable) {}

        try {
            val shell = ShellEngine.getInstance(appCtx)
            val persisted = shell.getPersistedSetting("secure", KEY_NAV_MOD_MODE)
            if (persisted == "CIRCLE_TO_SEARCH" || persisted == "MAGIC_LIVE") {
                savePersistentNavModMode(appCtx, persisted, explicitlyDisabled = false)
                return persisted
            }
        } catch (_: Throwable) {}

        val secureMode = try {
            Settings.Secure.getString(appCtx.contentResolver, KEY_NAV_MOD_MODE)
        } catch (_: Exception) {
            null
        }
        if (secureMode == "CIRCLE_TO_SEARCH" || secureMode == "MAGIC_LIVE") {
            savePersistentNavModMode(appCtx, secureMode, explicitlyDisabled = false)
            return secureMode
        }

        // Mặc định luôn bật CIRCLE_TO_SEARCH (hỗ trợ cả Khoanh Tròn & Trợ lý Magic) khi app còn cài trên máy
        savePersistentNavModMode(appCtx, "CIRCLE_TO_SEARCH", explicitlyDisabled = false)
        return "CIRCLE_TO_SEARCH"
    }

    /**
     * Kiểm tra công tắc cho phép lắng nghe giọng nói mở khóa gọi Magic Live hay không.
     * Khi người dùng TẮT tính năng gọi Magic Live để tiết kiệm pin, Micro sẽ ngắt hoàn toàn 100%.
     */
    fun isMagicLiveMicWakeEnabled(context: Context): Boolean {
        val mode = getActiveNavModMode(context)
        if (mode != "MAGIC_LIVE") {
            cachedMagicLiveMicWake = false
            return false
        }
        cachedMagicLiveMicWake?.let { return it }
        val shell = ShellEngine.getInstance(context.applicationContext)
        val micWakeFlag = shell.getPersistedSetting("secure", "magictune_magic_live_mic_wake")
        val enabled = micWakeFlag == "1"
        cachedMagicLiveMicWake = enabled
        return enabled
    }

    /**
     * Chế độ Chung Sống & Tự Động Nhường Nhau 3 Trợ Lý (YOYO + Khoanh tròn hỏi AI + Trợ lý Magic):
     * Mặc định BẬT (`true`) để người dùng vừa giữ nguyên được YOYO gốc của Honor (bấm ở giữa thanh đáy / nút nguồn / giọng nói),
     * vừa dùng được Khoanh tròn hỏi AI (bấm thanh sát cạnh Trái) và Trợ lý Magic (bấm thanh sát cạnh Phải), cả 3 tự động nhường màn hình & Micro cho nhau!
     */
    fun isYoyoCoexistModeEnabled(context: Context): Boolean {
        val appCtx = context.applicationContext ?: context
        return try {
            val stdPrefs = appCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE)
            if (stdPrefs.contains(KEY_YOYO_COEXIST_MODE)) {
                return stdPrefs.getBoolean(KEY_YOYO_COEXIST_MODE, true)
            }
            if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
                return true
            }
            getNavBridgePrefs(appCtx).getBoolean(KEY_YOYO_COEXIST_MODE, true)
        } catch (_: Throwable) {
            true
        }
    }

    fun setYoyoCoexistModeEnabled(context: Context, enabled: Boolean) {
        val appCtx = context.applicationContext ?: context
        try {
            appCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_YOYO_COEXIST_MODE, enabled).apply()
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                try {
                    getNavBridgePrefs(appCtx).edit().putBoolean(KEY_YOYO_COEXIST_MODE, enabled).apply()
                } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    const val GESTURE_TYPE_BOTH = "BOTH"
    const val GESTURE_TYPE_NAV_HOLD = "NAV_HOLD"
    const val GESTURE_TYPE_CORNER_SWIPE = "CORNER_SWIPE"

    /**
     * Đọc kiểu cử chỉ kích hoạt Trợ lý ("BOTH" - Cả hai, "NAV_HOLD" - Nhấn thanh đáy, "CORNER_SWIPE" - Vuốt góc dưới màn hình).
     */
    fun getTriggerGestureType(context: Context): String {
        val appCtx = context.applicationContext ?: context
        try {
            val saved = getNavBridgePrefs(appCtx).getString(KEY_TRIGGER_GESTURE_TYPE, null)
            if (!saved.isNullOrBlank()) return saved
        } catch (_: Throwable) {}
        return try {
            val shell = ShellEngine.getInstance(appCtx)
            val persisted = shell.getPersistedSetting("secure", KEY_TRIGGER_GESTURE_TYPE)
            if (!persisted.isNullOrBlank()) return persisted
            Settings.Secure.getString(appCtx.contentResolver, KEY_TRIGGER_GESTURE_TYPE) ?: GESTURE_TYPE_NAV_HOLD
        } catch (_: Exception) {
            GESTURE_TYPE_NAV_HOLD
        }
    }

    /**
     * Lưu kiểu cử chỉ kích hoạt theo sở thích người dùng ("BOTH", "NAV_HOLD", hoặc "CORNER_SWIPE").
     */
    fun isTopLeftCarrierSwipeEnabled(context: Context): Boolean {
        val appCtx = context.applicationContext ?: context
        return try {
            getNavBridgePrefs(appCtx).getBoolean(KEY_TOP_LEFT_CARRIER_SWIPE_ENABLED, false)
        } catch (_: Throwable) {
            false
        }
    }

    fun setTopLeftCarrierSwipeEnabled(context: Context, enabled: Boolean) {
        val appCtx = context.applicationContext ?: context
        try {
            getNavBridgePrefs(appCtx).edit().putBoolean(KEY_TOP_LEFT_CARRIER_SWIPE_ENABLED, enabled).apply()
            appCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_TOP_LEFT_CARRIER_SWIPE_ENABLED, enabled).apply()
        } catch (_: Throwable) {}
        try {
            val shell = ShellEngine.getInstance(appCtx)
            shell.setPersistedSetting("secure", KEY_TOP_LEFT_CARRIER_SWIPE_ENABLED, if (enabled) "1" else "0")
        } catch (_: Throwable) {}
        mainHandler.post {
            removeNavBridgeInternal(appCtx)
            syncNavBarBridge(appCtx)
        }
    }

    /**
     * V3.9 & V4.0: Kiểm tra trạng thái ẩn nút điều hướng Trái (Circle to Search).
     * Chỉ khi thiết bị đã được kích hoạt vĩnh viễn quyền ADB & chạy ngầm thì mới được hiện!
     */
    fun isLeftPillHidden(context: Context): Boolean {
        val appCtx = context.applicationContext ?: context
        if (!isNavBridgeUnlocked(appCtx)) return true
        val prefs = getNavBridgePrefs(appCtx)
        return prefs.getBoolean(KEY_HIDE_BOTH_PILLS, false) || prefs.getBoolean(KEY_HIDE_LEFT_PILL, false)
    }

    /**
     * V3.9 & V4.0: Kiểm tra trạng thái ẩn nút điều hướng Phải (Magic Live AI).
     * Chỉ khi thiết bị đã được kích hoạt vĩnh viễn quyền ADB & chạy ngầm thì mới được hiện!
     */
    fun isRightPillHidden(context: Context): Boolean {
        val appCtx = context.applicationContext ?: context
        if (!isNavBridgeUnlocked(appCtx)) return true
        val prefs = getNavBridgePrefs(appCtx)
        return prefs.getBoolean(KEY_HIDE_BOTH_PILLS, false) || prefs.getBoolean(KEY_HIDE_RIGHT_PILL, false)
    }

    /**
     * V3.9 & V4.0: Kiểm tra trạng thái ẩn CẢ 2 NÚT điều hướng.
     */
    fun isBothPillsHidden(context: Context): Boolean {
        val appCtx = context.applicationContext ?: context
        if (!isNavBridgeUnlocked(appCtx)) return true
        val prefs = getNavBridgePrefs(appCtx)
        return prefs.getBoolean(KEY_HIDE_BOTH_PILLS, false) || (isLeftPillHidden(appCtx) && isRightPillHidden(appCtx))
    }

    private fun isLeftPillEffectivelyHidden(context: Context): Boolean {
        return isLeftPillHidden(context) || isAutoHiddenForVideo
    }

    private fun isRightPillEffectivelyHidden(context: Context): Boolean {
        return isRightPillHidden(context) || isAutoHiddenForVideo
    }

    /**
     * V3.9 & V4.0: Cập nhật hiển thị ẩn / hiện tức thì trên WindowManager cho cả 2 nút.
     * Khi ẩn (hoặc tự động tàng hình khi phát video/xem phim): Thu gọn Window size về 0x0, alpha = 0f và bật FLAG_NOT_TOUCHABLE để triệt tiêu 100% hình ảnh lẫn cảm ứng.
     * Khi hiện: Khôi phục kích thước chuẩn theo thanh trượt độ dài và cho phép chạm bình thường.
     * Nếu thiết bị chưa kích hoạt vĩnh viễn qua ADB -> Gỡ view triệt để khỏi WindowManager!
     */
    fun updateNavPillsVisibility(context: Context) {
        val appCtx = context.applicationContext ?: context
        mainHandler.post {
            try {
                if (!isNavBridgeUnlocked(appCtx)) {
                    removeNavBridgeInternal(appCtx)
                    return@post
                }
                val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return@post
                val hideLeft = isLeftPillEffectivelyHidden(appCtx)
                val hideRight = isRightPillEffectivelyHidden(appCtx)
                val scale = getNavBarLengthScale(appCtx)
                val currentContainerW = dp((60f * scale).toInt(), appCtx)
                val edgeOffset = computeNavPillEdgeOffsetPx(appCtx, currentContainerW)
                val sig = "${hideLeft}_${hideRight}_${currentContainerW}_${edgeOffset}"
                if (sig == lastNavVisibilitySig && navLeftView != null && navRightView != null) {
                    refreshNavPillColors(appCtx)
                    return@post
                }
                lastNavVisibilitySig = sig

                navLeftView?.let { v ->
                    v.visibility = if (hideLeft) View.GONE else View.VISIBLE
                    v.isClickable = !hideLeft
                    leftPillView?.let { pill ->
                        pill.animate()?.cancel()
                        pill.visibility = if (hideLeft) View.GONE else View.VISIBLE
                        pill.alpha = if (hideLeft) 0f else 0.92f
                    }
                    navLeftParams?.let { p ->
                        p.gravity = Gravity.BOTTOM or Gravity.LEFT
                        if (hideLeft) {
                            p.width = 0
                            p.height = 0
                            p.x = 0
                            p.alpha = 0f
                            p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        } else {
                            p.width = currentContainerW
                            p.height = dp(17, appCtx)
                            p.x = edgeOffset
                            p.alpha = 1f
                            p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                        }
                        try { wm.updateViewLayout(v, p) } catch (_: Throwable) {}
                    }
                    v.requestLayout()
                }

                navRightView?.let { v ->
                    v.visibility = if (hideRight) View.GONE else View.VISIBLE
                    v.isClickable = !hideRight
                    rightPillView?.let { pill ->
                        pill.animate()?.cancel()
                        pill.visibility = if (hideRight) View.GONE else View.VISIBLE
                        pill.alpha = if (hideRight) 0f else 0.92f
                    }
                    navRightParams?.let { p ->
                        p.gravity = Gravity.BOTTOM or Gravity.RIGHT
                        if (hideRight) {
                            p.width = 0
                            p.height = 0
                            p.x = 0
                            p.alpha = 0f
                            p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        } else {
                            p.width = currentContainerW
                            p.height = dp(17, appCtx)
                            p.x = edgeOffset
                            p.alpha = 1f
                            p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                        }
                        try { wm.updateViewLayout(v, p) } catch (_: Throwable) {}
                    }
                    v.requestLayout()
                }
                refreshNavPillColors(appCtx)
            } catch (_: Exception) {}
        }
    }

    /**
     * V4.0: Cập nhật màu sắc 2 thanh điều hướng đáy HUD:
     * - Chỉ khi ĐÃ KÍCH HOẠT WLAN / ADB VĨNH VIỄN: Hiển thị màu kính lỏng (#50FFFFFF) viền phản quang (#80FFFFFF).
     * - Khi CHƯA KÍCH HOẠT: Ẩn triệt để khỏi WindowManager, không hiển thị bất kỳ phím nào.
     */
    fun refreshNavPillColors(context: Context) {
        val appCtx = context.applicationContext ?: context
        mainHandler.post {
            try {
                val isWlanActive = isNavBridgeUnlocked(appCtx)
                if (!isWlanActive) {
                    removeNavBridgeInternal(appCtx)
                    return@post
                }
                val isWlanUnlocked = com.example.core.permission.AppPermissionChecker.isFirstTimeWlanActivated(appCtx)
                if (lastNavColorUnlocked == isWlanUnlocked &&
                    leftPillView?.background != null &&
                    rightPillView?.background != null
                ) {
                    return@post
                }
                lastNavColorUnlocked = isWlanUnlocked

                val density = appCtx.resources.displayMetrics.density
                fun dp(v: Float): Int = (v * density).toInt()
                fun dpF(v: Float): Float = v * density

                leftPillView?.let { pill ->
                    pill.background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = dpF(4.5f)
                        if (isWlanUnlocked) {
                            setColor(Color.parseColor("#50FFFFFF"))
                            setStroke(dp(1.0f), Color.parseColor("#80FFFFFF"))
                        } else {
                            setColor(Color.parseColor("#75DC2626"))
                            setStroke(dp(1.4f), Color.parseColor("#EF4444"))
                        }
                    }
                }
                rightPillView?.let { pill ->
                    pill.background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = dpF(4.5f)
                        // Nút Phải (Vẽ Chữ / Chat AI) không cần ADB, luôn hiển thị kính lỏng sang trọng
                        setColor(Color.parseColor("#50FFFFFF"))
                        setStroke(dp(1.0f), Color.parseColor("#80FFFFFF"))
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    /**
     * V3.9: Công tắc ẩn / hiện nút điều hướng Trái
     */
    fun setLeftPillHidden(context: Context, hidden: Boolean) {
        val appCtx = context.applicationContext ?: context
        val both = hidden && isRightPillHidden(appCtx)
        try {
            appCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_HIDE_LEFT_PILL, hidden)
                .putBoolean(KEY_HIDE_BOTH_PILLS, both)
                .apply()
            getNavBridgePrefs(appCtx).edit()
                .putBoolean(KEY_HIDE_LEFT_PILL, hidden)
                .putBoolean(KEY_HIDE_BOTH_PILLS, both)
                .apply()
        } catch (_: Throwable) {}
        updateNavPillsVisibility(appCtx)
    }

    /**
     * V3.9: Công tắc ẩn / hiện nút điều hướng Phải
     */
    fun setRightPillHidden(context: Context, hidden: Boolean) {
        val appCtx = context.applicationContext ?: context
        val both = hidden && isLeftPillHidden(appCtx)
        try {
            appCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_HIDE_RIGHT_PILL, hidden)
                .putBoolean(KEY_HIDE_BOTH_PILLS, both)
                .apply()
            getNavBridgePrefs(appCtx).edit()
                .putBoolean(KEY_HIDE_RIGHT_PILL, hidden)
                .putBoolean(KEY_HIDE_BOTH_PILLS, both)
                .apply()
        } catch (_: Throwable) {}
        updateNavPillsVisibility(appCtx)
    }

    /**
     * V3.9: Công tắc ẩn / hiện CẢ 2 NÚT điều hướng (1 Chạm)
     */
    fun setBothPillsHidden(context: Context, hidden: Boolean) {
        val appCtx = context.applicationContext ?: context
        try {
            appCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_HIDE_BOTH_PILLS, hidden)
                .putBoolean(KEY_HIDE_LEFT_PILL, hidden)
                .putBoolean(KEY_HIDE_RIGHT_PILL, hidden)
                .apply()
            getNavBridgePrefs(appCtx).edit()
                .putBoolean(KEY_HIDE_BOTH_PILLS, hidden)
                .putBoolean(KEY_HIDE_LEFT_PILL, hidden)
                .putBoolean(KEY_HIDE_RIGHT_PILL, hidden)
                .apply()
        } catch (_: Throwable) {}
        updateNavPillsVisibility(appCtx)
    }

    /**
     * Keep the lightweight screen receiver only while the navigation bridge is configured.
     * The overlay windows and audio callback are removed while the display is off, then
     * attached again on SCREEN_ON without a polling loop or a wake lock.
     */
    private fun registerNavScreenStateReceiver(context: Context) {
        if (navScreenStateReceiver != null) return
        val appCtx = context.applicationContext ?: context
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_SCREEN_OFF -> mainHandler.post {
                        try {
                            stopUnlockVoiceWakeListener()
                            removeNavBridgeInternal(appCtx, keepScreenStateReceiver = true)
                        } catch (_: Throwable) {}
                    }
                    Intent.ACTION_SCREEN_ON -> {
                        com.example.core.widget.MagicTuneAppSearchWidgetProvider.refreshAllWidgets(appCtx)
                        if (isNavBridgeConfiguredActive(appCtx)) {
                            syncNavBarBridge(appCtx)
                        } else {
                            unregisterNavScreenStateReceiver()
                        }
                    }
                }
            }
        }
        try {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                appCtx.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                appCtx.registerReceiver(receiver, filter)
            }
            navScreenStateReceiverContext = appCtx
            navScreenStateReceiver = receiver
        } catch (_: Throwable) {}
    }

    private fun unregisterNavScreenStateReceiver() {
        val receiver = navScreenStateReceiver ?: return
        val context = navScreenStateReceiverContext
        navScreenStateReceiver = null
        navScreenStateReceiverContext = null
        try {
            if (context != null) context.unregisterReceiver(receiver)
        } catch (_: Throwable) {}
    }

    fun setTriggerGestureType(context: Context, type: String) {
        val appCtx = context.applicationContext
        try {
            getNavBridgePrefs(appCtx).edit().putString(KEY_TRIGGER_GESTURE_TYPE, type).apply()
            appCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE)
                .edit().putString(KEY_TRIGGER_GESTURE_TYPE, type).apply()
        } catch (_: Throwable) {}
        try {
            val shell = ShellEngine.getInstance(appCtx)
            shell.setPersistedSetting("secure", KEY_TRIGGER_GESTURE_TYPE, type)
        } catch (_: Throwable) {}
        if (appCtx.checkCallingOrSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED) {
            try {
                Settings.Secure.putString(appCtx.contentResolver, KEY_TRIGGER_GESTURE_TYPE, type)
            } catch (_: Exception) {}
        }
        mainHandler.post {
            removeNavBridgeInternal(appCtx)
            syncNavBarBridge(appCtx)
        }
    }

    /**
     * Mở trực tiếp màn hình Cài Đặt Điều Hướng Hệ Thống của Honor MagicOS để người dùng tắt thanh cử chỉ gốc của YOYO
     */
    fun openSystemNavigationSettings(context: Context) {
        val appCtx = context.applicationContext ?: context
        val intents = listOf(
            Intent("com.android.settings.GESTURE_NAVIGATION_SETTINGS"),
            Intent("android.settings.SYSTEM_NAVIGATION_SETTINGS"),
            Intent().setComponent(ComponentName("com.android.settings", "com.android.settings.Settings\$SystemNavigationActivity")),
            Intent().setComponent(ComponentName("com.android.settings", "com.android.settings.navigation.NaviSettingsActivity")),
            Intent().setComponent(ComponentName("com.huawei.android.launcher", "com.huawei.android.launcher.settings.SystemNaviActivity")),
            Intent(Settings.ACTION_SETTINGS)
        )
        for (intent in intents) {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                appCtx.startActivity(intent)
                return
            } catch (_: Throwable) {}
        }
    }

    /**
     * Tự động ẩn / thu nhỏ và thụt xuống dưới nút điều hướng ảo khi màn hình Khoanh tròn hỏi AI
     * (`CircleToSearchOverlayActivity`) hoặc Magic Live Nổi đang hiển thị, giúp người dùng bấm hàng nút chức năng
     * ở đáy màn hình chính xác 100% mà không bao giờ bị ấn nhầm.
     */
    fun setNavBridgeSuppressedForOverlay(context: Context, @Suppress("UNUSED_PARAMETER") suppressed: Boolean) {
        // Luôn giữ 2 nút điều hướng sát góc Trái & Phải hoạt động 100% (KHÔNG bao giờ ẩn hay khóa cảm ứng)
        // để người dùng có thể nhấn gọi bảng Magic Live hoặc Khoanh tròn hỏi AI TỨC THÌ bất cứ lúc nào
        // mà không phải đợi các lớp phủ khác đóng hết!
        isNavBridgeSuppressedForCts = false
        val appCtx = context.applicationContext
        mainHandler.post {
            try {
                if (!isNavBridgeUnlocked(appCtx)) {
                    removeNavBridgeInternal(appCtx)
                    return@post
                }
                val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return@post
                val density = appCtx.resources.displayMetrics.density
                fun dp(v: Int): Int = (v * density).toInt()

                val scale = getNavBarLengthScale(appCtx)
                val targetW = dp((60f * scale).toInt())
                val edgeOffset = computeNavPillEdgeOffsetPx(appCtx, targetW)

                listOf(
                    Triple(navLeftView, navLeftParams, Gravity.BOTTOM or Gravity.LEFT),
                    Triple(navRightView, navRightParams, Gravity.BOTTOM or Gravity.RIGHT)
                ).forEach { (navView, navParams, edgeGravity) ->
                    if (navView != null && navParams != null) {
                        val isHiddenPill = if (navView == navLeftView) isLeftPillEffectivelyHidden(appCtx) else isRightPillEffectivelyHidden(appCtx)
                        val targetVisible = if (isHiddenPill) View.GONE else View.VISIBLE
                        val targetClickable = !isHiddenPill
                        val resolvedW = if (isHiddenPill) 0 else targetW
                        val targetH = if (isHiddenPill) 0 else dp(17) // V3.9: Giảm thêm 20% độ cao (21dp -> 17dp)
                        val targetAlpha = if (isHiddenPill) 0f else 1f
                        val targetX = if (isHiddenPill) 0 else edgeOffset
                        var targetFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
                        if (isHiddenPill) {
                            targetFlags = targetFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        }
                        val needsLayoutUpdate = navParams.gravity != edgeGravity ||
                            navParams.x != targetX ||
                            navParams.y != 0 ||
                            navParams.width != resolvedW ||
                            navParams.height != targetH ||
                            navParams.alpha != targetAlpha ||
                            navParams.flags != targetFlags ||
                            navView.visibility != targetVisible ||
                            navView.isClickable != targetClickable
                        if (needsLayoutUpdate) {
                            navParams.gravity = edgeGravity
                            navParams.x = targetX
                            navView.visibility = targetVisible
                            navView.isClickable = targetClickable
                            navParams.width = resolvedW
                            navParams.height = targetH
                            navParams.alpha = targetAlpha
                            navParams.y = 0
                            navParams.flags = targetFlags
                            if (navView.isAttachedToWindow) {
                                try {
                                    wm.updateViewLayout(navView, navParams)
                                } catch (_: Throwable) {}
                            }
                            updatePillsAlpha()
                        }
                    }
                }
                leftPillView?.let { v ->
                    val curLp = v.layoutParams as? FrameLayout.LayoutParams
                    if (curLp == null || curLp.width != targetW) {
                        val lp = curLp ?: FrameLayout.LayoutParams(targetW, dp(7))
                        lp.width = targetW
                        lp.gravity = Gravity.START or Gravity.CENTER_VERTICAL
                        lp.leftMargin = 0
                        v.layoutParams = lp
                    }
                }
                rightPillView?.let { v ->
                    val curLp = v.layoutParams as? FrameLayout.LayoutParams
                    if (curLp == null || curLp.width != targetW) {
                        val lp = curLp ?: FrameLayout.LayoutParams(targetW, dp(7))
                        lp.width = targetW
                        lp.gravity = Gravity.END or Gravity.CENTER_VERTICAL
                        lp.rightMargin = 0
                        v.layoutParams = lp
                    }
                }
            } catch (_: Exception) {}
        }
    }

    /**
     * Kiểm tra định kỳ (Watchdog) đảm bảo cầu nối Thanh điều hướng đáy & 2 góc vuốt luôn gắn trên WindowManager
     * kể cả khi xoay màn hình, đổi độ phân giải, khởi động lại SystemUI hoặc tắt Gỡ lỗi WLAN / ADB.
     */
    fun ensureNavBridgeHealthy(context: Context) {
        val appCtx = context.applicationContext ?: context
        mainHandler.post {
            try {
                if (!isNavBridgeUnlocked(appCtx)) {
                    removeNavBridgeInternal(appCtx)
                    return@post
                }
                val mode = getActiveNavModMode(appCtx)
                if ((mode == "CIRCLE_TO_SEARCH" || mode == "MAGIC_LIVE") && canDrawSystemOverlay(appCtx)) {
                    // V4.0 FIX TRIỆT ĐỂ: Chỉ coi là cần tạo lại khi view thực sự bằng null!
                    // Tuyệt đối không kiểm tra !isAttachedToWindow vì trong các pha transition/layout tạm thời của Android
                    // flag này có thể tạm thời là false, dẫn đến việc xóa nhầm tham chiếu và add đè thành 4 phím điều hướng!
                    val needInit = navLeftView == null || navRightView == null
                    if (needInit) {
                        removeNavBridgeInternal(appCtx)
                        syncNavBarBridge(appCtx)
                    } else {
                        updateNavPillsVisibility(appCtx)
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    /**
     * Đồng bộ Cầu nối cảm ứng Thanh điều hướng đáy sát cạnh Trái & cạnh Phải màn hình:
     * - Chỉ khi ĐÃ ĐƯỢC CẤP QUYỀN ADB & CHẠY NGẦM VĨNH VIỄN thì mới được hiển thị 2 phím điều hướng!
     * - Nút Sát Cạnh Trái: Nhấn giữ gọi Khoanh tròn hỏi AI & Dịch Màn Hình; Nhấp 1 lần tự đẩy cảm ứng xuyên qua xuống nút bên dưới.
     * - Nút Sát Cạnh Phải: Nhấn giữ gọi Magic Live Voice AI; Nhấp 1 lần tự đẩy cảm ứng xuyên qua xuống nút bên dưới.
     * - Toàn bộ vùng giữa màn hình để trống 100% cho thanh điều hướng YOYO gốc của Honor, không bao giờ ấn nhầm!
     */
    @SuppressLint("ClickableViewAccessibility")
    fun syncNavBarBridge(context: Context) {
        if (!navBridgeSyncPending.compareAndSet(false, true)) return
        val appCtx = context.applicationContext
        if (!mainHandler.post {
            try {
                val isWlanActive = isNavBridgeUnlocked(appCtx)
                val mode = getActiveNavModMode(appCtx)
                val shouldEnable = isWlanActive && (mode == "CIRCLE_TO_SEARCH" || mode == "MAGIC_LIVE") && canDrawSystemOverlay(appCtx)
                if (!shouldEnable) {
                    removeNavBridgeInternal(appCtx)
                    if (mode != "MAGIC_LIVE") {
                        stopUnlockVoiceWakeListener()
                    }
                    return@post
                }

                registerNavScreenStateReceiver(appCtx)
                val powerManager = appCtx.getSystemService(Context.POWER_SERVICE) as? PowerManager
                if (powerManager?.isInteractive == false) {
                    stopUnlockVoiceWakeListener()
                    removeNavBridgeInternal(appCtx, keepScreenStateReceiver = true)
                    return@post
                }

                // V4.0 FIX: Fast-path nếu cả 2 thanh điều hướng đã tồn tại thì CHỈ CẦN cập nhật trạng thái hiển thị ẩn/hiện & độ dài
                // Tuyệt đối không tạo thêm view mới đè lên, giải quyết triệt để vấn đề bị trùng 4 phím điều hướng!
                if (navLeftView != null && navRightView != null) {
                    updateNavPillsVisibility(appCtx)
                    updateNavBarLength(appCtx)
                    refreshNavPillColors(appCtx)
                    return@post
                }

                val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return@post
                val density = appCtx.resources.displayMetrics.density
                fun dp(v: Int): Int = (v * density).toInt()
                fun dp(v: Float): Int = (v * density).toInt()
                fun dpF(v: Float): Float = v * density

                val overlayType = com.example.core.compat.DeviceCompatProfile.overlayWindowType()

                val suppressedInitially = false

                // =========================================================================
                // 2 NÚT ĐIỀU HƯỚNG NẰM SÁT HẲN VÀO CẠNH TRÁI & CẠNH PHẢI MÀN HÌNH (x = 0):
                // 1. SÁT CẠNH TRÁI (Gravity.BOTTOM or Gravity.LEFT, x = 0): NHẤN GIỮ GỌI MAGIC KHOANH TRÒN
                // 2. SÁT CẠNH PHẢI (Gravity.BOTTOM or Gravity.RIGHT, x = 0): NHẤN GIỮ GỌI TRỢ LÝ MAGIC LIVE AI
                // => Vùng chính giữa màn hình rộng rãi tuyệt đối cho YOYO của Honor, không bao giờ dí nhầm!
                // =========================================================================

                val scale = getNavBarLengthScale(appCtx)
                val currentPillW = dp(60f * scale)
                val currentContainerW = currentPillW

                registerAudioPlaybackWatcher(appCtx)
                isAutoHiddenForVideo = computeShouldAutoHideForVideo(appCtx)

                // --- 1. NÚT SÁT CẠNH TRÁI -> MAGIC KHOANH TRÒN & DỊCH MÀN HÌNH (THANH CYAN) ---
                if (navLeftView != null) {
                    try {
                        wm.removeViewImmediate(navLeftView)
                    } catch (_: Throwable) {
                        try { wm.removeView(navLeftView) } catch (_: Throwable) {}
                    }
                    navLeftView = null
                    navLeftParams = null
                    leftPillView = null
                }
                run {
                    val hideLeft = isLeftPillEffectivelyHidden(appCtx)
                    val leftContainer = object : FrameLayout(appCtx) {
                        override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
                            super.onLayout(changed, left, top, right, bottom)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && right > left && bottom > top) {
                                try {
                                    systemGestureExclusionRects = listOf(android.graphics.Rect(0, 0, right - left, bottom - top))
                                } catch (_: Throwable) {}
                            }
                        }

                        override fun onConfigurationChanged(newConfig: Configuration?) {
                            super.onConfigurationChanged(newConfig)
                            updateNavBarLength(appCtx)
                            scheduleVideoAutoHideCheck(appCtx, immediate = true)
                        }
                    }.apply {
                        clipChildren = false
                        clipToPadding = false
                    }
                    val leftPillIndicator = View(appCtx).apply {
                        layoutParams = FrameLayout.LayoutParams(
                            currentPillW,
                            dp(7.2f), // V3.9: Giảm thêm 20% độ cao (9dp -> 7.2dp)
                            Gravity.START or Gravity.CENTER_VERTICAL
                        ).apply {
                            leftMargin = 0
                        }
                        val isWlanActiveLeft = com.example.core.permission.AppPermissionChecker.isFirstTimeWlanActivated(appCtx)
                        visibility = if (hideLeft) View.GONE else View.VISIBLE
                        alpha = if (hideLeft) 0f else 0.92f
                        background = GradientDrawable().apply {
                            shape = GradientDrawable.RECTANGLE
                            cornerRadius = dpF(4.5f)
                            if (!isWlanActiveLeft) {
                                setColor(Color.parseColor("#75DC2626")) // Đỏ cảnh báo nổi bật
                                setStroke(dp(1.4f), Color.parseColor("#EF4444")) // Viền đỏ tươi báo hiệu ĐANG KHÓA ĐỎ
                            } else {
                                setColor(Color.parseColor("#50FFFFFF")) // Kính lỏng trong suốt sang trọng
                                setStroke(dp(1.0f), Color.parseColor("#80FFFFFF")) // Viền phản quang kính lỏng
                            }
                        }
                    }
                    leftPillView = leftPillIndicator
                    leftContainer.addView(leftPillIndicator)

                    val leftParams = WindowManager.LayoutParams(
                        if (suppressedInitially) 1 else if (hideLeft) 0 else currentContainerW,
                        if (suppressedInitially) 1 else if (hideLeft) 0 else dp(17), // V3.9: Giảm thêm 20% độ cao (21dp -> 17dp)
                        overlayType,
                        (WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED) or
                            (if (hideLeft) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0),
                        PixelFormat.TRANSLUCENT
                    ).apply {
                        gravity = Gravity.BOTTOM or Gravity.LEFT
                        x = if (hideLeft) 0 else computeNavPillEdgeOffsetPx(appCtx, currentContainerW)
                        y = 0 // Sát hẳn xuống dưới mép màn hình theo yêu cầu người dùng
                        alpha = if (hideLeft) 0f else 1f
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                            layoutInDisplayCutoutMode =
                                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                        }
                    }

                    leftContainer.visibility = if (hideLeft) View.GONE else View.VISIBLE
                    leftContainer.isClickable = !hideLeft
                    var downX = 0f
                    var downY = 0f
                    var lastMoveX = 0f
                    var lastMoveY = 0f
                    var downTime = 0L
                    var longPressTriggered = false
                    var swipeTriggered = false

                    fun flashLeftPillFeedback() {
                        triggerHapticFeedback(appCtx, leftContainer)
                        leftPillIndicator.background = GradientDrawable().apply {
                            shape = GradientDrawable.RECTANGLE
                            cornerRadius = dpF(4.5f)
                            setColor(Color.parseColor("#99FFFFFF"))
                            setStroke(dp(1.5f), Color.WHITE)
                        }
                        mainHandler.postDelayed({
                            refreshNavPillColors(appCtx)
                        }, 200L)
                    }

                    val leftLongPressRunnable = Runnable {
                        if (!swipeTriggered && !longPressTriggered) {
                            longPressTriggered = true
                            flashLeftPillFeedback()
                            triggerConfiguredAssistantNow(appCtx, explicitMode = "CIRCLE_TO_SEARCH")
                        }
                    }

                    leftContainer.setOnTouchListener { _, event ->
                        when (event.actionMasked) {
                            MotionEvent.ACTION_DOWN -> {
                                downX = event.rawX
                                downY = event.rawY
                                lastMoveX = downX
                                lastMoveY = downY
                                downTime = System.currentTimeMillis()
                                longPressTriggered = false
                                swipeTriggered = false
                                mainHandler.removeCallbacks(leftLongPressRunnable)
                                mainHandler.postDelayed(leftLongPressRunnable, 240L) // Phản hồi cực nhạy 240ms trên MagicOS 10 / Android 17
                                true
                            }
                            MotionEvent.ACTION_MOVE -> {
                                lastMoveX = event.rawX
                                lastMoveY = event.rawY
                                val dx = lastMoveX - downX
                                val dy = lastMoveY - downY
                                if (!longPressTriggered && !swipeTriggered) {
                                    if (Math.abs(dx) > dp(36) || Math.abs(dy) > dp(36)) {
                                        swipeTriggered = true
                                        mainHandler.removeCallbacks(leftLongPressRunnable)
                                    }
                                }
                                true
                            }
                            MotionEvent.ACTION_UP -> {
                                mainHandler.removeCallbacks(leftLongPressRunnable)
                                if (!longPressTriggered && !swipeTriggered) {
                                    longPressTriggered = true
                                    flashLeftPillFeedback()
                                    triggerConfiguredAssistantNow(appCtx, explicitMode = "CIRCLE_TO_SEARCH")
                                }
                                true
                            }
                            MotionEvent.ACTION_CANCEL -> {
                                mainHandler.removeCallbacks(leftLongPressRunnable)
                                // Trên Honor MagicOS 10 / Android 17, SystemUI Gesture Detector ở mép đáy (y=0) đôi khi
                                // cướp luồng cảm ứng (pilferPointers) và gửi ACTION_CANCEL khi người dùng chạm vào thanh đáy.
                                // Nếu ngón tay không vuốt đi chỗ khác (< 28dp), lập tức kích hoạt Khoanh Tròn để không bao giờ bị hụt cảm ứng!
                                val dx = Math.abs(lastMoveX - downX)
                                val dy = Math.abs(lastMoveY - downY)
                                val heldMs = System.currentTimeMillis() - downTime
                                if (!longPressTriggered && !swipeTriggered && dx < dp(28) && dy < dp(28) && heldMs >= 45L) {
                                    longPressTriggered = true
                                    flashLeftPillFeedback()
                                    triggerConfiguredAssistantNow(appCtx, explicitMode = "CIRCLE_TO_SEARCH")
                                }
                                true
                            }
                            else -> true
                        }
                    }

                    wm.addView(leftContainer, leftParams)
                    navLeftView = leftContainer
                    navLeftParams = leftParams
                }

                // --- 2. NÚT SÁT CẠNH PHẢI -> TRỢ LÝ MAGIC LIVE AI (THANH TÍM) ---
                if (navRightView != null) {
                    try {
                        wm.removeViewImmediate(navRightView)
                    } catch (_: Throwable) {
                        try { wm.removeView(navRightView) } catch (_: Throwable) {}
                    }
                    navRightView = null
                    navRightParams = null
                    rightPillView = null
                }
                run {
                    val hideRight = isRightPillEffectivelyHidden(appCtx)
                    val rightContainer = object : FrameLayout(appCtx) {
                        override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
                            super.onLayout(changed, left, top, right, bottom)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && right > left && bottom > top) {
                                try {
                                    systemGestureExclusionRects = listOf(android.graphics.Rect(0, 0, right - left, bottom - top))
                                } catch (_: Throwable) {}
                            }
                        }
                    }.apply {
                        clipChildren = false
                        clipToPadding = false
                    }
                    val rightPillIndicator = View(appCtx).apply {
                        layoutParams = FrameLayout.LayoutParams(
                            currentPillW,
                            dp(7.2f), // V3.9: Giảm thêm 20% độ cao (9dp -> 7.2dp)
                            Gravity.END or Gravity.CENTER_VERTICAL
                        ).apply {
                            rightMargin = 0
                        }
                        visibility = if (hideRight) View.GONE else View.VISIBLE
                        alpha = if (hideRight) 0f else 0.92f
                        background = GradientDrawable().apply {
                            shape = GradientDrawable.RECTANGLE
                            cornerRadius = dpF(4.5f)
                            // Nút Phải (Vẽ Chữ / Chat AI) không cần ADB, luôn mở sẵn kính lỏng
                            setColor(Color.parseColor("#50FFFFFF"))
                            setStroke(dp(1.0f), Color.parseColor("#80FFFFFF"))
                        }
                    }
                    rightPillView = rightPillIndicator
                    rightContainer.addView(rightPillIndicator)

                    val rightParams = WindowManager.LayoutParams(
                        if (suppressedInitially) 1 else if (hideRight) 0 else currentContainerW,
                        if (suppressedInitially) 1 else if (hideRight) 0 else dp(17), // V3.9: Giảm thêm 20% độ cao (21dp -> 17dp)
                        overlayType,
                        (WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED) or
                            (if (hideRight) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0),
                        PixelFormat.TRANSLUCENT
                    ).apply {
                        gravity = Gravity.BOTTOM or Gravity.RIGHT
                        x = if (hideRight) 0 else computeNavPillEdgeOffsetPx(appCtx, currentContainerW)
                        y = 0 // Sát hẳn xuống dưới mép màn hình theo yêu cầu người dùng
                        alpha = if (hideRight) 0f else 1f
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                            layoutInDisplayCutoutMode =
                                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                        }
                    }

                    rightContainer.visibility = if (hideRight) View.GONE else View.VISIBLE
                    rightContainer.isClickable = !hideRight
                    var downX = 0f
                    var downY = 0f
                    var lastMoveX = 0f
                    var lastMoveY = 0f
                    var downTime = 0L
                    var longPressTriggered = false
                    var swipeTriggered = false

                    fun flashRightPillFeedback() {
                        triggerHapticFeedback(appCtx, rightContainer)
                        rightPillIndicator.background = GradientDrawable().apply {
                            shape = GradientDrawable.RECTANGLE
                            cornerRadius = dpF(4.5f)
                            setColor(Color.parseColor("#99FFFFFF"))
                            setStroke(dp(1.5f), Color.WHITE)
                        }
                        mainHandler.postDelayed({
                            refreshNavPillColors(appCtx)
                        }, 200L)
                    }

                    val rightLongPressRunnable = Runnable {
                        if (!swipeTriggered && !longPressTriggered) {
                            longPressTriggered = true
                            flashRightPillFeedback()
                            triggerRightGestureLauncherNow(appCtx)
                        }
                    }

                    rightContainer.setOnTouchListener { _, event ->
                        when (event.actionMasked) {
                            MotionEvent.ACTION_DOWN -> {
                                downX = event.rawX
                                downY = event.rawY
                                lastMoveX = downX
                                lastMoveY = downY
                                downTime = System.currentTimeMillis()
                                longPressTriggered = false
                                swipeTriggered = false
                                mainHandler.removeCallbacks(rightLongPressRunnable)
                                mainHandler.postDelayed(rightLongPressRunnable, 150L) // Phản hồi tức thì 150ms trên MagicOS / Android
                                true
                            }
                            MotionEvent.ACTION_MOVE -> {
                                lastMoveX = event.rawX
                                lastMoveY = event.rawY
                                val dx = lastMoveX - downX
                                val dy = lastMoveY - downY
                                if (!longPressTriggered && !swipeTriggered) {
                                    if (Math.abs(dx) > dp(36) || Math.abs(dy) > dp(36)) {
                                        swipeTriggered = true
                                        mainHandler.removeCallbacks(rightLongPressRunnable)
                                    }
                                }
                                true
                            }
                            MotionEvent.ACTION_UP -> {
                                mainHandler.removeCallbacks(rightLongPressRunnable)
                                if (!longPressTriggered && !swipeTriggered) {
                                    longPressTriggered = true
                                    flashRightPillFeedback()
                                    triggerRightGestureLauncherNow(appCtx)
                                }
                                true
                            }
                            MotionEvent.ACTION_CANCEL -> {
                                mainHandler.removeCallbacks(rightLongPressRunnable)
                                val dx = Math.abs(lastMoveX - downX)
                                val dy = Math.abs(lastMoveY - downY)
                                val heldMs = System.currentTimeMillis() - downTime
                                if (!longPressTriggered && !swipeTriggered && dx < dp(28) && dy < dp(28) && heldMs >= 45L) {
                                    longPressTriggered = true
                                    flashRightPillFeedback()
                                    triggerRightGestureLauncherNow(appCtx)
                                }
                                true
                            }
                            else -> true
                        }
                    }

                    wm.addView(rightContainer, rightParams)
                    navRightView = rightContainer
                    navRightParams = rightParams
                }
            } catch (_: Exception) {
            } finally {
                navBridgeSyncPending.set(false)
            }
        }) {
            navBridgeSyncPending.set(false)
        }
    }




    private fun updateNavPillsTouchable(context: Context, touchable: Boolean) {
        try {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
            val left = navLeftView
            val leftP = navLeftParams
            if (left != null && leftP != null) {
                val hideLeft = isLeftPillEffectivelyHidden(context)
                val newLeftFlags = if (touchable && !hideLeft) {
                    leftP.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                } else {
                    leftP.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                }
                if (newLeftFlags != leftP.flags) {
                    leftP.flags = newLeftFlags
                    try { wm.updateViewLayout(left, leftP) } catch (_: Throwable) {}
                }
            }
            val right = navRightView
            val rightP = navRightParams
            if (right != null && rightP != null) {
                val hideRight = isRightPillEffectivelyHidden(context)
                val newRightFlags = if (touchable && !hideRight) {
                    rightP.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                } else {
                    rightP.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                }
                if (newRightFlags != rightP.flags) {
                    rightP.flags = newRightFlags
                    try { wm.updateViewLayout(right, rightP) } catch (_: Throwable) {}
                }
            }
        } catch (_: Exception) {}
    }

    private fun removeNavBridgeInternal(context: Context, keepScreenStateReceiver: Boolean = false) {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val retainReceiverForScreenOn = keepScreenStateReceiver ||
            (powerManager?.isInteractive == false && isNavBridgeConfiguredActive(context))
        if (!retainReceiverForScreenOn) unregisterNavScreenStateReceiver()
        unregisterAudioPlaybackWatcher(context)
        lastNavVisibilitySig = null
        lastNavColorUnlocked = null
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
        leftPillView = null
        rightPillView = null
        navLeftView?.let { v ->
            try { 
                wm?.removeViewImmediate(v) 
            } catch (_: Throwable) {
                try { wm?.removeView(v) } catch (_: Throwable) {}
            }
        }
        navLeftView = null
        navLeftParams = null

        navRightView?.let { v ->
            try { 
                wm?.removeViewImmediate(v) 
            } catch (_: Throwable) {
                try { wm?.removeView(v) } catch (_: Throwable) {}
            }
        }
        navRightView = null
        navRightParams = null
    }

    /**
     * Kiểm tra xem package có phải là màn hình chính (Launcher/Home Screen) hay không.
     */
    fun isHomeScreenPackage(pkg: String?, context: Context): Boolean {
        if (pkg.isNullOrEmpty()) return false
        if (pkg == "home") return true

        val lowerPkg = pkg.lowercase()

        val knownLaunchers = setOf(
            "com.hihonor.android.launcher",
            "com.hihonor.desktop",
            "com.hihonor.launcher",
            "com.hihonor.launcher3",
            "com.huawei.android.launcher",
            "com.huawei.desktop",
            "com.google.android.apps.nexuslauncher",
            "com.android.launcher3",
            "com.android.launcher",
            "com.sec.android.app.launcher",
            "com.miui.home",
            "com.oppo.launcher",
            "com.oneplus.launcher",
            "com.teslacoilsw.launcher"
        )
        if (knownLaunchers.contains(lowerPkg)) return true

        if (lowerPkg.contains("hihonor.android.launcher") ||
            lowerPkg.contains("hihonor.desktop") ||
            lowerPkg.contains("huawei.android.launcher") ||
            lowerPkg.contains("huawei.desktop")
        ) {
            return true
        }

        return try {
            val pm = context.packageManager
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
            }
            val resolveInfo = pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            val defaultHome = resolveInfo?.activityInfo?.packageName
            !defaultHome.isNullOrEmpty() && defaultHome.equals(pkg, ignoreCase = true)
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Nhường quyền màn hình & Micro ngay lập tức (<5ms) cho YOYO gốc của Honor khi người dùng gọi YOYO
     * (qua vùng giữa thanh điều hướng đáy, nút nguồn hoặc giọng nói).
     */
    fun yieldToYoyoImmediately(context: Context) {
        try {
            val appCtx = context.applicationContext ?: context
            // 1. Giải phóng 100% quyền Micro & AudioFocus để YOYO nghe giọng nói không bị tranh chấp
            releaseMicrophoneForMagicLiveImmediately(appCtx)
            // 2. Tự động đóng lớp phủ Trợ lý Magic nếu đang mở để nhường cho YOYO
            if (com.example.core.widget.MagicLiveFloatingOverlay.isShowing) {
                com.example.core.widget.MagicLiveFloatingOverlay.yieldMicrophoneAndDismissForExternalAi(appCtx)
            }
            // 3. Tự động đóng lớp phủ Khoanh tròn hỏi AI & Dịch Cuộn nếu đang mở để nhường cho YOYO
            com.example.core.widget.CircleToSearchOverlayActivity.dismissIfActiveForMagicLive()
            if (com.example.core.widget.GoogleLiveTranslateOverlay.isRunning) {
                com.example.core.widget.GoogleLiveTranslateOverlay.stop(appCtx)
            }
        } catch (_: Throwable) {}
    }

    /**
     * Cập nhật trạng thái hiển thị của 2 thanh điều hướng:
     * - Ở Màn hình chính (Launcher/Home): Hiện rõ ràng (alpha = 1.0f).
     * - Khi mở ứng dụng bất kỳ (Zalo, Facebook, 1688, Chrome...): TÀNG HÌNH (alpha = 0.0f)
     *   để không che khuất bất kỳ nội dung nào trong ứng dụng, nhưng vẫn giữ 100% diện tích
     *   chạm nhận diện cử chỉ Circle to Search & Trợ lý Magic!
     * - Khi phát hiện YOYO được mở lên ở chế độ Chung sống 3 Trợ lý: Tự động nhường Micro & màn hình cho YOYO!
     */
    fun onForegroundAppChanged(context: Context, packageName: String?) {
        try {
            if (!packageName.isNullOrEmpty() && yoyoPackages.contains(packageName)) {
                if (isYoyoCoexistModeEnabled(context)) {
                    yieldToYoyoImmediately(context)
                    return
                }
            }
            val validPkg = !packageName.isNullOrBlank() && packageName != "com.android.systemui" && packageName != "android"
            val pkgChanged = validPkg && packageName != lastKnownForegroundPkg
            if (validPkg) {
                lastKnownForegroundPkg = packageName
            }
            refreshVideoAutoHideState(context, if (validPkg) packageName else null, immediateRestore = pkgChanged)

            if (packageName == lastNotifiedForegroundPkg) return
            lastNotifiedForegroundPkg = packageName

            val isHome = isHomeScreenPackage(packageName, context) || packageName == "home"
            isCurrentlyOnHome = isHome
            updatePillsAlpha()
            if (isHome) {
                com.example.core.widget.MagicTuneAppSearchWidgetProvider.refreshAllWidgets(context)
            } else if (validPkg && packageName != context.packageName) {
                com.example.core.widget.MagicTuneAppSearchWidgetProvider.recordAppLaunch(context, packageName)
            }
        } catch (_: Exception) {}
    }

    private fun getLatestForegroundPackage(context: Context): String? {
        val now = System.currentTimeMillis()
        if (now - lastUsmQueryMs < 1200L && cachedLatestPkg != null) {
            return cachedLatestPkg
        }
        return try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return null
            lastUsmQueryMs = now
            val events = usm.queryEvents(now - 2500L, now) ?: return cachedLatestPkg
            val event = UsageEvents.Event()
            var latestPkg: String? = null
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED ||
                    @Suppress("DEPRECATION") (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND)
                ) {
                    latestPkg = event.packageName
                }
            }
            if (latestPkg != null) {
                cachedLatestPkg = latestPkg
            }
            cachedLatestPkg
        } catch (_: Exception) {
            cachedLatestPkg
        }
    }

    /**
     * Polling fallback được gọi định kỳ từ KeepAliveService để đảm bảo thanh nav bar
     * luôn đúng trạng thái tàng hình / hiển thị ngay cả khi AccessibilityEvent bị trễ.
     */
    fun checkAndUpdateNavBarVisibility(context: Context, explicitPkg: String? = null) {
        try {
            val latestPkg = explicitPkg ?: getLatestForegroundPackage(context)
            if (latestPkg != null && latestPkg != "com.android.systemui" && latestPkg != "android") {
                onForegroundAppChanged(context, latestPkg)
            } else {
                refreshVideoAutoHideState(context, null, immediateRestore = false)
            }
        } catch (_: Exception) {}
    }

    /**
     * Kiểm tra tiến trình tiền cảnh:
     * 1. Nếu biểu tượng trò chuyện của Magic Live / Google Assistant (`com.google.android.apps.bard` hoặc `com.google.android.googlequicksearchbox`)
     *    xuất hiện -> LẬP TỨC trả lại 100% quyền Micro của thiết bị cho Magic Live ngay lập tức!
     * 2. Nếu tiến trình YOYO bật lên:
     *    - Ở chế độ Chung sống 3 Trợ lý (mặc định BẬT): Lập tức nhường Micro & đóng lớp phủ MagicTune để YOYO hoạt động mượt mà!
     *    - Chỉ khi người dùng tắt chế độ chung sống (chọn khóa hẳn YOYO): mới đè Google/Trợ lý Magic lên.
     */
    fun interceptYoyoIfForeground(context: Context, explicitPkg: String? = null) {
        try {
            val latestForegroundPkg = explicitPkg ?: getLatestForegroundPackage(context)
            val now = System.currentTimeMillis()

            if (latestForegroundPkg != null && magicLiveAndGoogleVoicePackages.contains(latestForegroundPkg)) {
                // Ngay khi biểu tượng trò chuyện của Magic Live / Google xuất hiện -> Trả lại quyền Micro tức khắc cho MagicLive!
                releaseMicrophoneForMagicLiveImmediately(context)
                if (latestForegroundPkg == "com.google.android.apps.bard") {
                    com.example.core.widget.MagicLiveFloatingOverlay.yieldMicrophoneAndDismissForExternalAi(context)
                }
                return
            }

            if (latestForegroundPkg != null && yoyoPackages.contains(latestForegroundPkg)) {
                if (isYoyoCoexistModeEnabled(context)) {
                    // Chế độ Chung sống 3 Trợ lý: Tự động nhường quyền Micro & màn hình cho YOYO!
                    yieldToYoyoImmediately(context)
                    return
                }
                val mode = getActiveNavModMode(context)
                if ((mode == "CIRCLE_TO_SEARCH" || mode == "MAGIC_LIVE") && now - lastAssistantTriggerMs > 1200L) {
                    triggerConfiguredAssistantNow(context, mode)
                }
            }
        } catch (_: Exception) {}
    }

    fun performHomeGesture(context: Context) {
        try {
            onForegroundAppChanged(context, "home")
            val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivityAllowingBackground(context, homeIntent)
        } catch (_: Exception) {}
    }

    private fun startActivityAllowingBackground(
        context: Context,
        intent: Intent,
        @Suppress("UNUSED_PARAMETER") preferFloatingWindow: Boolean = false
    ): Boolean {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            val options = android.app.ActivityOptions.makeBasic().apply {
                if (Build.VERSION.SDK_INT >= 34) {
                    setPendingIntentBackgroundActivityStartMode(
                        @Suppress("DEPRECATION") android.app.ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                    )
                }
            }
            context.startActivity(intent, options.toBundle())
            true
        } catch (_: Exception) {
            try {
                if (Build.VERSION.SDK_INT >= 34) {
                    @Suppress("DEPRECATION")
                    val fallbackOpts = android.app.ActivityOptions.makeBasic()
                        .setPendingIntentBackgroundActivityStartMode(
                            android.app.ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                        )
                    context.startActivity(intent, fallbackOpts.toBundle())
                } else {
                    context.startActivity(intent)
                }
                true
            } catch (_: Exception) {
                try {
                    context.startActivity(intent)
                    true
                } catch (_: Exception) {
                    false
                }
            }
        }
    }

    private fun triggerHapticFeedback(context: Context, view: View?) {
        try {
            view?.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(35L, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(35L)
            }
        } catch (_: Exception) {}
    }

    /**
     * Giải phóng và trả lại 100% quyền Micro + Audio Focus cho Magic Live / YOYO ngay tức khắc (<5ms).
     * Đảm bảo ứng dụng MagicTune không bao giờ giữ kênh thu âm làm mất tiếng của Magic Live hoặc YOYO.
     */
    fun releaseMicrophoneForMagicLiveImmediately(context: Context? = null) {
        // Khóa không cho bộ lắng nghe mở khóa chiếm lại Micro trong suốt 120 giây khi Magic Live / YOYO đang hội thoại
        magicLiveSessionActiveUntilMs = System.currentTimeMillis() + 120_000L
        stopUnlockVoiceWakeListener()
        if (context != null) {
            val appCtx = context.applicationContext
            try {
                val am = appCtx.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
                @Suppress("DEPRECATION")
                am?.abandonAudioFocus(null)
            } catch (_: Throwable) {}

            val hasMicPerm = androidx.core.content.ContextCompat.checkSelfPermission(
                appCtx,
                android.Manifest.permission.RECORD_AUDIO
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
            val shell = ShellEngine.getInstance(appCtx)
            if (!hasMicPerm && shell.state.value.isAdbReady) {
                ioScope.launch {
                    try {
                        val pkg = appCtx.packageName
                        shell.execute(
                            "pm grant -u 0 $pkg android.permission.RECORD_AUDIO >/dev/null 2>&1 || pm grant --user 0 $pkg android.permission.RECORD_AUDIO >/dev/null 2>&1 || pm grant $pkg android.permission.RECORD_AUDIO >/dev/null 2>&1 || true; " +
                            "cmd appops set $pkg RECORD_AUDIO allow >/dev/null 2>&1 || cmd appops set --user 0 $pkg RECORD_AUDIO allow >/dev/null 2>&1 || true"
                        )
                    } catch (_: Throwable) {}
                }
            }
        }
    }

    fun triggerRightGestureLauncherNow(context: Context) {
        val appCtx = context.applicationContext ?: context
        // Vẽ chữ mở app / khay tìm app hoạt động độc lập, không cần trợ năng ngầm hay ADB
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            com.example.core.widget.GestureLauncherOverlay.show(appCtx)
        } else {
            mainHandler.post {
                com.example.core.widget.GestureLauncherOverlay.show(appCtx)
            }
        }
    }

    /**
     * Kích hoạt tính năng Khoanh tròn hỏi AI (Ép hoạt động trên Honor) / Tìm Kiếm Giọng Nói Google / Magic Live Nổi:
     * Tự động nhường quyền qua lại giữa 3 Trợ lý (Khoanh tròn hỏi AI ↔ Trợ lý Magic ↔ YOYO).
     */
    fun triggerConfiguredAssistantNow(context: Context, explicitMode: String? = null): Boolean {
        val appCtx = context.applicationContext
        val mode = explicitMode ?: getActiveNavModMode(appCtx)
        val requiresAdb = mode == "CIRCLE_TO_SEARCH" || mode == "LIVE_SCROLL"
        if (requiresAdb && (!isNavBridgeUnlocked(appCtx) || !com.example.core.permission.AppPermissionChecker.isFirstTimeWlanActivated(appCtx))) {
            triggerHapticFeedback(appCtx, navLeftView ?: navRightView)
            mainHandler.post {
                try {
                    Toast.makeText(
                        appCtx,
                        "🔒 TÍNH NĂNG ĐỌC MÀN HÌNH CẦN KẾT NỐI ADB LẦN ĐẦU!\nVui lòng kết nối Gỡ lỗi Wi-Fi 1 lần trong MagicTune để kích hoạt Dịch Cuộn / Khoanh Màn Hình!",
                        Toast.LENGTH_LONG
                    ).show()
                } catch (_: Throwable) {}
            }
            try {
                val intent = Intent(appCtx, com.example.MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra("TARGET_TAB", "SHIZUKU")
                }
                appCtx.startActivity(intent)
            } catch (_: Throwable) {}
            return false
        }
        val now = System.currentTimeMillis()
        if (mode == lastAssistantTriggerMode && now - lastAssistantTriggerMs < 180L) return true
        lastAssistantTriggerMs = now
        lastAssistantTriggerMode = mode

        val shell = ShellEngine.getInstance(appCtx)
        val isAdbReady = shell.state.value.isAdbReady
        val coexistYoyo = isYoyoCoexistModeEnabled(appCtx)

        // 0. Chỉ giải phóng Micro & Assist Settings khi thực sự gọi Trợ lý giọng nói (MAGIC_LIVE / GOOGLE_VOICE_DIRECT),
        // tránh chạy ADB grant RECORD_AUDIO hay Settings.Secure IPC vô ích khi chỉ mở mặt kính Khoanh tròn hỏi AI!
        if (mode == "MAGIC_LIVE" || mode == "GOOGLE_VOICE_DIRECT") {
            releaseMicrophoneForMagicLiveImmediately(appCtx)
            ioScope.launch {
                MagicTuneCtsAccessibilityService.ensureAssistSettingsEnabledIfNeeded(appCtx)
            }
        } else {
            stopUnlockVoiceWakeListener()
        }
        hideSecurityPill(appCtx)

        val magicTuneComponent = "${appCtx.packageName}/com.example.core.assistant.MagicTuneVoiceInteractionService"

        if (mode == "MAGIC_LIVE") {
            try {
                val cr = appCtx.contentResolver
                Settings.Secure.putString(cr, "assistant", magicTuneComponent)
                Settings.Secure.putString(cr, "voice_interaction_service", magicTuneComponent)
            } catch (_: Throwable) {}
        }

        // BƯỚC 2: Đóng lớp phủ đối ứng (nếu đang mở)
        setNavBridgeSuppressedForOverlay(appCtx, true)
        if (mode == "MAGIC_LIVE") {
            com.example.core.widget.CircleToSearchOverlayActivity.dismissIfActiveForMagicLive()
            if (com.example.core.widget.GoogleLiveTranslateOverlay.isRunning) {
                com.example.core.widget.GoogleLiveTranslateOverlay.stop(appCtx)
            }
        } else {
            com.example.core.widget.MagicLiveFloatingOverlay.dismiss(appCtx)
            if (com.example.core.widget.MagicLiveFloatingOverlay.isShowing) {
                com.example.core.widget.MagicLiveFloatingOverlay.yieldMicrophoneAndDismissForExternalAi(appCtx)
            }
        }

        // BƯỚC 3: HIỂN THỊ TỨC THÌ 0MS TRÊN MAIN THREAD (không delay, không đợi ShellEngine mutex!)
        val launchTask = Runnable {
            when (mode) {
                "MAGIC_LIVE" -> {
                    dismissActiveYoyoSession(appCtx)
                    launchMagicLiveDirect(context)
                }
                "GOOGLE_VOICE_DIRECT" -> {
                    launchGoogleVoiceSearchDirect(context)
                }
                else -> {
                    MagicTuneCtsAccessibilityService.resetAutoHiddenFlagIfSafe(context)
                    com.example.core.widget.CircleToSearchOverlayActivity.launch(context)
                }
            }
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            launchTask.run()
        } else {
            mainHandler.postAtFrontOfQueue(launchTask)
        }

        // BƯỚC 4: Không am force-stop YOYO liên tục khi mở Circle to Search (tránh MagicOS tự khởi động lại YOYO gây nóng & ngốn pin);
        // chỉ dọn tiến trình YOYO khi người dùng mở MAGIC_LIVE với chế độ không chung sống.
        if (isAdbReady && mode == "MAGIC_LIVE" && !coexistYoyo) {
            ioScope.launch {
                try {
                    shell.execute("am force-stop com.hihonor.magicvoice >/dev/null 2>&1; am force-stop com.hihonor.yoyo >/dev/null 2>&1; cmd statusbar collapse >/dev/null 2>&1 || true")
                } catch (_: Throwable) {}
            }
        }

        return true
    }

    /**
     * Mở TRỰC TIẾP tính năng Tìm Kiếm Giọng Nói của App Google (VoiceSearchActivity) trên màn hình,
     * KHÔNG mở trang chủ tin tức của App Google và KHÔNG gọi sang Trợ lý Magic.
     */
    private fun launchGoogleVoiceSearchDirect(context: Context): Boolean {
        releaseMicrophoneForMagicLiveImmediately(context)
        val pm = context.packageManager
        val candidates = listOf(
            // 1. Gọi trực tiếp VoiceSearchActivity chính gốc của App Google với ACTION_WEB_SEARCH
            Intent(android.speech.RecognizerIntent.ACTION_WEB_SEARCH).apply {
                setClassName(
                    "com.google.android.googlequicksearchbox",
                    "com.google.android.googlequicksearchbox.VoiceSearchActivity"
                )
                putExtra(
                    android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    android.speech.RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH
                )
                putExtra("com.google.android.voicesearch.extra.CALLED_FROM_SEARCH_PLATE", true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            // 2. Gọi trực tiếp component VoiceSearchActivity của App Google
            Intent().apply {
                setClassName(
                    "com.google.android.googlequicksearchbox",
                    "com.google.android.googlequicksearchbox.VoiceSearchActivity"
                )
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            // 3. Action SEARCH_LONG_PRESS chuẩn của App Google (mở hộp thoại tìm kiếm nổi của Google)
            Intent(Intent.ACTION_SEARCH_LONG_PRESS).apply {
                setPackage("com.google.android.googlequicksearchbox")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            // 4. Action WEB_SEARCH đóng gói riêng cho App Google
            Intent(android.speech.RecognizerIntent.ACTION_WEB_SEARCH).apply {
                setPackage("com.google.android.googlequicksearchbox")
                putExtra(
                    android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    android.speech.RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH
                )
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
        )

        for (intent in candidates) {
            if (pm.resolveActivity(intent, 0) != null && startActivityAllowingBackground(context, intent)) {
                return true
            }
        }

        // Nếu thiết bị chưa cài hoặc vô hiệu hóa ứng dụng Google tìm kiếm giọng nói:
        // Thông báo rõ ràng và tự động mở CH Play (Google Play Store) để tải
        val appCtx = context.applicationContext ?: context
        val voiceHint = "⚠️ Đang mở CH Play để cài đặt ứng dụng Google tìm kiếm giọng nói..."
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            try { android.widget.Toast.makeText(appCtx, voiceHint, android.widget.Toast.LENGTH_SHORT).show() } catch (_: Throwable) {}
        } else {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                try { android.widget.Toast.makeText(appCtx, voiceHint, android.widget.Toast.LENGTH_SHORT).show() } catch (_: Throwable) {}
            }
        }
        try {
            val playIntent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("market://details?id=com.google.android.googlequicksearchbox")).apply {
                setPackage("com.android.vending")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivityAllowingBackground(context, playIntent)
            return true
        } catch (_: Throwable) {
            try {
                val webIntent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.googlequicksearchbox")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivityAllowingBackground(context, webIntent)
                return true
            } catch (_: Throwable) {}
        }

        return false
    }

    fun launchMagicLiveAssistantFromForeground(activity: Activity): Boolean {
        releaseMicrophoneForMagicLiveImmediately(activity)
        com.example.core.widget.CircleToSearchOverlayActivity.dismissIfActiveForMagicLive()
        val shown = com.example.core.widget.MagicLiveFloatingOverlay.showAndStartListening(activity)
        if (shown) return true
        return launchMagicLiveDirect(activity)
    }

    private fun isPackageInstalled(context: Context, pkg: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(pkg, 0)
            true
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Kích hoạt Hộp Thoại Giọng Nói NỔI (`MagicLiveFloatingOverlay`) trực tiếp trên màn hình hiện tại
     * ở bất kỳ đâu trên Honor MagicOS 11 / Android 17 để người dùng trò chuyện bằng âm thanh ngay ngoài màn hình
     * mà KHÔNG chuyển hướng vào bên trong full app MagicLive.
     */
    fun launchMagicLiveDirect(context: Context): Boolean {
        dismissActiveYoyoSession(context)
        releaseMicrophoneForMagicLiveImmediately(context)
        com.example.core.widget.CircleToSearchOverlayActivity.dismissIfActiveForMagicLive()

        // 1. Ưu tiên số 1: Hiển thị trực tiếp Hộp Thoại Giọng Nói Nổi MagicLiveFloatingOverlay ngay trên màn hình hiện tại (0ms)
        if (com.example.core.widget.MagicLiveFloatingOverlay.showAndStartListening(context)) {
            return true
        }

        // 2. Nếu chưa cấp quyền vẽ trên ứng dụng khác hoặc cần xin quyền Micro qua Activity trong suốt:
        if (com.example.core.widget.MagicLiveLockscreenActivity.launchFromOverlay(context)) {
            return true
        }

        // 3. Dự phòng mở App Magic Live chính thức nếu chưa cấp quyền lớp phủ
        return com.example.core.widget.MagicLiveFloatingOverlay.openOfficialMagicLiveAppAndYieldMic(context)
    }

    // ========================================================================================
    // 3. TIẾP NHẬN MICRO & GỌI GEMINI NỔI BẰNG GIỌNG ĐỌC NGAY SAU KHI MỞ KHÓA KHUÔN MẶT
    // ========================================================================================

    /**
     * Tự động kích hoạt phiên lắng nghe giọng đọc rảnh tay (6 giây) ngay sau khi màn hình khóa
     * vừa được mở khóa bằng khuôn mặt / vân tay (`Intent.ACTION_USER_PRESENT`), CHỈ KHI tính năng
     * gọi Magic Live đang được BẬT và Magic Live chưa mở trên màn hình.
     *
     * Ngay khi người dùng đọc từ khóa hoặc biểu tượng Magic Live xuất hiện -> Ứng dụng lập tức nhả Micro
     * trong <5ms (`releaseMicrophoneForMagicLiveImmediately`) để trả lại quyền Micro 100% cho MagicLive!
     */
    fun onDeviceUnlockedByUser(context: Context) {
        val appCtx = context.applicationContext
        refreshNavPillColors(appCtx)
        updateNavPillsVisibility(appCtx)
        // Nếu người dùng đã TẮT tính năng gọi Magic Live để tiết kiệm pin -> Không bật Micro!
        if (!isMagicLiveMicWakeEnabled(appCtx)) {
            stopUnlockVoiceWakeListener()
            return
        }
        // Nếu Magic Live vừa được kích hoạt hoặc đang hội thoại -> Tuyệt đối không chạm vào Micro để tránh cướp Micro của MagicLive!
        if (System.currentTimeMillis() < magicLiveSessionActiveUntilMs) {
            stopUnlockVoiceWakeListener()
            return
        }

        val hasMicPerm = androidx.core.content.ContextCompat.checkSelfPermission(
            appCtx,
            android.Manifest.permission.RECORD_AUDIO
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

        if (!hasMicPerm) {
            val shell = ShellEngine.getInstance(appCtx)
            if (shell.state.value.isAdbReady) {
                ioScope.launch {
                    try {
                        val pkg = appCtx.packageName
                        shell.execute("pm grant $pkg android.permission.RECORD_AUDIO >/dev/null 2>&1; appops set $pkg RECORD_AUDIO allow >/dev/null 2>&1")
                    } catch (_: Throwable) {}
                }
            }
            return
        }

        mainHandler.post {
            try {
                if (isUnlockVoiceListening || System.currentTimeMillis() < magicLiveSessionActiveUntilMs) return@post
                if (!isMagicLiveMicWakeEnabled(appCtx)) return@post
                if (!android.speech.SpeechRecognizer.isRecognitionAvailable(appCtx)) return@post

                stopUnlockVoiceWakeListener()
                val recognizer = android.speech.SpeechRecognizer.createSpeechRecognizer(appCtx)
                unlockSpeechRecognizer = recognizer
                isUnlockVoiceListening = true

                val recognizerIntent = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(
                        android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                    )
                    putExtra(android.speech.RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(android.speech.RecognizerIntent.EXTRA_CALLING_PACKAGE, appCtx.packageName)
                }

                recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
                    override fun onReadyForSpeech(params: android.os.Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}

                    override fun onError(error: Int) {
                        stopUnlockVoiceWakeListener()
                    }

                    override fun onResults(results: android.os.Bundle?) {
                        val matches = results?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)
                        if (checkWakeWordsAndTriggerMagicLive(appCtx, matches)) return
                        stopUnlockVoiceWakeListener()
                    }

                    override fun onPartialResults(partialResults: android.os.Bundle?) {
                        val matches = partialResults?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)
                        checkWakeWordsAndTriggerMagicLive(appCtx, matches)
                    }

                    override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
                })

                recognizer.startListening(recognizerIntent)
                // Tự động đóng phiên lắng nghe sau 6 giây nếu người dùng không gọi Magic Live để tiết kiệm pin và giải phóng Micro
                mainHandler.removeCallbacks(stopUnlockListenRunnable)
                mainHandler.postDelayed(stopUnlockListenRunnable, 6000L)
            } catch (_: Throwable) {
                stopUnlockVoiceWakeListener()
            }
        }
    }

    private fun checkWakeWordsAndTriggerMagicLive(context: Context, phrases: List<String>?): Boolean {
        if (phrases.isNullOrEmpty()) return false
        val wakeKeywords = listOf(
            "magic live",
            "magic_live",
            "alo magic live",
            "alo magic_live",
            "mở magic live",
            "mở magic_live",
            "gọi magic live",
            "gọi magic_live",
            "ge mi ni",
            "ok google",
            "okay google",
            "hey google",
            "trợ lý",
            "tro ly"
        )
        for (raw in phrases) {
            val normalized = raw.lowercase().trim()
            if (wakeKeywords.any { normalized.contains(it) }) {
                // Trả lại Micro ngay tức khắc (<5ms) trước khi bật hộp thoại Magic Live Nổi
                releaseMicrophoneForMagicLiveImmediately(context)
                triggerConfiguredAssistantNow(context, explicitMode = "MAGIC_LIVE")
                return true
            }
        }
        return false
    }

    fun showSecurityPill(context: Context, pkg: String) {
        val appCtx = context.applicationContext
        mainHandler.post {
            if (securityPillView != null) return@post
            val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return@post
            
            val density = appCtx.resources.displayMetrics.density
            fun dp(v: Int): Int = (v * density).toInt()

            val container = LinearLayout(appCtx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(8), dp(14), dp(8))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(24).toFloat()
                    setColor(Color.parseColor("#F2111827"))
                    setStroke(dp(1), Color.parseColor("#10B981"))
                }
                elevation = dp(6).toFloat()
                
                // Allow dragging
                var downY = 0f
                var initialY = 0
                setOnTouchListener { _, event ->
                    when (event.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            downY = event.rawY
                            initialY = (layoutParams as? WindowManager.LayoutParams)?.y ?: 0
                            false
                        }
                        MotionEvent.ACTION_MOVE -> {
                            val dy = (event.rawY - downY).toInt()
                            if (abs(dy) > dp(5)) {
                                val params = layoutParams as? WindowManager.LayoutParams ?: return@setOnTouchListener false
                                params.y = (initialY + dy).coerceIn(0, dp(400))
                                try { wm.updateViewLayout(this, params) } catch (_: Throwable) {}
                                true
                            } else false
                        }
                        else -> false
                    }
                }
            }

            val icon = TextView(appCtx).apply {
                text = "🛡️"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            }
            container.addView(icon)

            val statusTv = TextView(appCtx).apply {
                text = "🛡️ Phát hiện ứng dụng Ngân hàng (Đã tạm ngưng đọc màn hình)"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(10), 0, dp(10), 0)
            }
            container.addView(statusTv)

            val closeBtn = TextView(appCtx).apply {
                text = "✕"
                setTextColor(Color.parseColor("#9CA3AF"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setPadding(dp(6), dp(2), dp(6), dp(2))
                setOnClickListener { hideSecurityPill(appCtx) }
            }
            container.addView(closeBtn)

            val overlayType = com.example.core.compat.DeviceCompatProfile.overlayWindowType()
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = dp(14)
                windowAnimations = android.R.style.Animation_Toast
            }

            try {
                wm.addView(container, params)
                securityPillView = container
                securityPillParams = params
                // Tự động ẩn sau đúng 3 giây theo yêu cầu người dùng, không che màn hình
                mainHandler.removeCallbacks(autoDismissSecurityPillRunnable)
                mainHandler.postDelayed(autoDismissSecurityPillRunnable, 3000L)
            } catch (_: Throwable) {}
        }
    }

    private val autoDismissSecurityPillRunnable = Runnable {
        dismissSecurityPillInternal()
    }

    fun hideSecurityPill(context: Context? = null) {
        mainHandler.post {
            dismissSecurityPillInternal()
        }
    }

    private fun dismissSecurityPillInternal() {
        mainHandler.removeCallbacks(autoDismissSecurityPillRunnable)
        val view = securityPillView ?: return
        securityPillView = null
        securityPillParams = null
        try {
            val wm = view.context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            wm?.removeViewImmediate(view)
        } catch (_: Throwable) {}
    }

    private var securityPillView: View? = null
    private var securityPillParams: WindowManager.LayoutParams? = null

    private fun dpF(v: Float, context: Context): Float = v * context.resources.displayMetrics.density
    private fun dp(v: Int, context: Context): Int = dpF(v.toFloat(), context).toInt()

    fun stopUnlockVoiceWakeListener() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { stopUnlockVoiceWakeListener() }
            return
        }
        mainHandler.removeCallbacks(stopUnlockListenRunnable)
        isUnlockVoiceListening = false
        val rec = unlockSpeechRecognizer ?: return
        unlockSpeechRecognizer = null
        try {
            rec.stopListening()
        } catch (_: Throwable) {}
        try {
            rec.cancel()
        } catch (_: Throwable) {}
        try {
            rec.destroy()
        } catch (_: Throwable) {}
    }
}
