package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DeviceInfo
import com.example.ui.theme.*

import androidx.activity.compose.BackHandler

data class OemBrandCardInfo(
    val brandKey: String,
    val name: String,
    val romName: String,
    val description: String,
    val killerMechanism: String,
    val accentColor: Color,
    val features: List<String>
)

@Composable
fun UniversalOemFixScreen(
    deviceInfo: DeviceInfo = DeviceInfo(),
    isBusy: Boolean,
    onBack: () -> Unit,
    onFixUniversalAll: () -> Unit,
    onFixXiaomi: () -> Unit,
    onFixOppo: () -> Unit,
    onFixVivo: () -> Unit,
    onFixHuawei: () -> Unit,
    onFixSamsung: () -> Unit = {},
    onFixMeizu: () -> Unit = {},
    onFixAsusRog: () -> Unit = {},
    onRevertOemOptimization: () -> Unit = {}
) {
    // Luôn xử lý phím Back vật lý / cử chỉ vuốt cạnh để quay lại tab trước đó, không văng app
    BackHandler {
        onBack()
    }

    val scrollState = rememberScrollState()

    // Tự động nhận diện hãng của máy hiện tại
    val currentManufacturer = (deviceInfo.manufacturer.ifBlank { android.os.Build.MANUFACTURER.orEmpty() }).uppercase()
    val detectedBrand = remember(currentManufacturer) {
        when {
            currentManufacturer.contains("XIAOMI") || currentManufacturer.contains("REDMI") || currentManufacturer.contains("POCO") -> "XIAOMI"
            currentManufacturer.contains("OPPO") || currentManufacturer.contains("REALME") || currentManufacturer.contains("ONEPLUS") -> "OPPO"
            currentManufacturer.contains("VIVO") || currentManufacturer.contains("IQOO") -> "VIVO"
            currentManufacturer.contains("HUAWEI") || currentManufacturer.contains("HONOR") -> "HUAWEI"
            currentManufacturer.contains("SAMSUNG") -> "SAMSUNG"
            currentManufacturer.contains("MEIZU") -> "MEIZU"
            currentManufacturer.contains("ASUS") || currentManufacturer.contains("SONY") -> "ASUS"
            else -> "OTHER"
        }
    }

    var selectedTabFilter by remember { mutableStateOf("ALL") }

    val brandList = remember {
        listOf(
            OemBrandCardInfo(
                brandKey = "XIAOMI",
                name = "Xiaomi / Redmi / POCO",
                romName = "HyperOS & MIUI 12-14",
                description = "Chế ngự Joyose & PowerKeeper, vô hiệu hóa đóng băng RAM ngầm và bật AutoStart cho mọi ứng dụng chat.",
                killerMechanism = "Joyose + PowerKeeper (Ép Sleep sau 3-5 phút)",
                accentColor = Color(0xFFFF6900),
                features = listOf(
                    "Tắt giới hạn nền PowerKeeper & Joyose",
                    "Cấp đặc quyền AutoStart (Tự khởi chạy)",
                    "Vô hiệu hóa MIUI Battery Saver thông minh",
                    "Khóa Doze Mode & Standby Buckets về Active"
                )
            ),
            OemBrandCardInfo(
                brandKey = "OPPO",
                name = "OPPO / Realme / OnePlus",
                romName = "ColorOS 11-15 & OxygenOS",
                description = "Vô hiệu hóa trình quản lý pin Athena, tắt chế độ Deep Sleep ban đêm và giải phóng RAM đa nhiệm mượt mà.",
                killerMechanism = "com.coloros.athena + Deep Sleep (Chặn socket ngầm)",
                accentColor = MagicEmerald,
                features = listOf(
                    "Vô hiệu hóa dịch vụ ngầm Athena Battery",
                    "Tắt Deep Sleep và Night Freeze liên tục",
                    "Cấp RUN_IN_BACKGROUND cho toàn bộ app tin nhắn",
                    "Bật Speed Mode tối ưu thông báo thời gian thực"
                )
            ),
            OemBrandCardInfo(
                brandKey = "VIVO",
                name = "Vivo / iQOO",
                romName = "OriginOS 3-5 & Funtouch OS",
                description = "Ngắt rào cản iManager đóng băng, vô hiệu hóa Night Idle Sleep và mở khóa kết nối FCM Google.",
                killerMechanism = "iManager Freeze + Night Idle Sleep",
                accentColor = MagicCyan,
                features = listOf(
                    "Dỡ bỏ rào cản iManager đóng băng ngầm",
                    "Tắt vivo_night_idle_sleep & vivo_freeze",
                    "Đưa Standby Bucket của app chat về Active",
                    "Cấp quyền đánh thức màn hình khi có tin nhắn"
                )
            ),
            OemBrandCardInfo(
                brandKey = "HUAWEI",
                name = "Huawei / Honor",
                romName = "HarmonyOS 2-4 & EMUI / MagicOS",
                description = "Ngắt dịch vụ ngầm PowerGenie diệt app, tắt chế độ tiết kiệm pin thông minh và tối ưu hóa đẩy tin nhắn.",
                killerMechanism = "PowerGenie + iAware diệt tiến trình nền",
                accentColor = Color(0xFFFF4D4F),
                features = listOf(
                    "Vô hiệu hóa hoặc kiềm chế PowerGenie nền",
                    "Bỏ chế độ gentle_notification câm thông báo",
                    "Whitelist Doze Mode 24/7 cho Zalo, Messenger, Gmail",
                    "Phá gom cụm thông báo 0s tức thì"
                )
            ),
            OemBrandCardInfo(
                brandKey = "SAMSUNG",
                name = "Samsung Galaxy",
                romName = "One UI 4-7 (Android 12-15)",
                description = "Tắt Device Care tự động đưa app vào Deep Sleeping, vô hiệu hóa RAM Plus gây lag và tối ưu kết nối Doze.",
                killerMechanism = "Device Care Sleeping Apps + RAM Plus ảo gây chậm",
                accentColor = Color(0xFF2B6CB0),
                features = listOf(
                    "Vô hiệu hóa Device Care (com.samsung.android.lool)",
                    "Tắt tính năng đưa app không dùng vào ngủ đông",
                    "Tắt RAM Plus ảo để giải phóng chip nhớ và CPU",
                    "Giữ kết nối socket Doze Mode liên tục"
                )
            ),
            OemBrandCardInfo(
                brandKey = "MEIZU",
                name = "Meizu / Flyme",
                romName = "Flyme OS 9-11 (Android 11-14)",
                description = "Gỡ bỏ cơ chế OneMind AI ép ngủ đông, cấp quyền chạy ngầm không giới hạn và bảo đảm thông báo đến ngay lập tức.",
                killerMechanism = "OneMind AI Engine ngủ đông cực đoan",
                accentColor = MagicPurple,
                features = listOf(
                    "Tắt OneMind AI Background Freeze",
                    "Cấp AutoStart và Standby Bucket vĩnh viễn",
                    "Mở khóa màn hình khi có thông báo tài chính quan trọng",
                    "Bỏ giới hạn Doze Mode trên Flyme"
                )
            ),
            OemBrandCardInfo(
                brandKey = "ASUS",
                name = "Asus / ROG Phone / Sony Xperia",
                romName = "ROG UI & Xperia Android",
                description = "Vô hiệu hóa Asus PowerMaster, tắt Stamina Mode của Sony và mở Doze Mode để nhận thông báo game & mạng xã hội siêu tốc.",
                killerMechanism = "Asus PowerMaster & Sony Stamina diệt socket",
                accentColor = MagicRose,
                features = listOf(
                    "Vô hiệu hóa Asus PowerMaster Powersaver",
                    "Tắt Sony Stamina Mode ngắt kết nối nền",
                    "Giữ nhịp kết nối mạng kể cả khi tắt màn hình",
                    "Tối ưu cho cả app game và mạng xã hội"
                )
            )
        )
    }

    val filteredBrands = remember(selectedTabFilter, brandList) {
        if (selectedTabFilter == "ALL") brandList
        else brandList.filter { it.brandKey == selectedTabFilter }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Tiêu đề & Nút Quay lại
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onBack() }
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại", tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text("TỐI ƯU ĐA HÃNG OEM CHUYÊN SÂU", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black)
                Text("Đặc trị trễ thông báo, diệt ngầm & đóng băng socket trên mọi ROM Android", color = MagicCyanLight, fontSize = 11.sp)
            }
        }

        // Ô #48: BẢNG NHẬN DIỆN THIẾT BỊ THỜI GIAN THỰC & TỔNG QUAN CÔNG NGHỆ
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
            border = BorderStroke(1.5.dp, Brush.horizontalGradient(listOf(MagicCyan, MagicEmerald)))
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicCyan.copy(alpha = 0.22f))
                            .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Ô #48",
                            color = MagicCyanLight,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Text(
                        text = "Tương thích 100% Android 11 đến Android 17",
                        color = MagicEmeraldLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Text(
                    text = "🌐 TRẠM ĐIỀU PHỐI TỐI ƯU ĐA HÃNG OEM",
                    color = Color.White,
                    fontSize = 14.5.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )

                // Banner Nhận diện máy hiện tại
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0F172A))
                        .border(1.dp, MagicBorder, RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MagicCyan.copy(alpha = 0.18f))
                            .border(1.dp, MagicCyan, RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(22.dp))
                    }
                    Column(
                        modifier = Modifier.fillMaxHeight().weight(1f),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        if (detectedBrand != "OTHER") {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(MagicEmerald.copy(alpha = 0.2f))
                                    .padding(horizontal = 6.dp, vertical = 1.5.dp)
                            ) {
                                Text("Khớp $detectedBrand", color = MagicEmeraldLight, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text(
                            text = "Thiết bị hiện tại: ${deviceInfo.model}",
                            color = Color.White,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            text = "Hãng: ${deviceInfo.manufacturer} • Android: ${deviceInfo.version} (SDK ${deviceInfo.sdkInt}) • Giao diện: ${deviceInfo.magicOS}",
                            color = TextSecondary,
                            fontSize = 10.5.sp,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Text(
                    text = "Các dòng máy Android nội địa (Xiaomi, Oppo, Realme, Vivo, Huawei, Samsung...) thường có cơ chế tiết kiệm pin cực đoan (Joyose, Athena, iManager, PowerGenie, OneMind), tự ngắt kết nối ngầm khiến thông báo Zalo, Messenger, Gmail, ứng dụng tài chính bị trễ hoặc câm. Trang này can thiệp trực tiếp vào từng lõi hệ thống để khắc phục 100%.",
                    color = TextSecondary,
                    fontSize = 11.5.sp,
                    lineHeight = 16.sp
                )

                // 2 Nút Tổng lực: 1-Tap Tối ưu tất cả & Khôi phục
                Row(
                    modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onFixUniversalAll,
                        enabled = !isBusy,
                        modifier = Modifier
                            .fillMaxHeight().weight(1.4f)
                            .defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicCyan,
                            contentColor = Color(0xFF020617)
                        )
                    ) {
                        Icon(imageVector = Icons.Default.FlashOn, contentDescription = null, modifier = Modifier.size(19.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("⚡ TỐI ƯU TOÀN DIỆN TẤT CẢ HÃNG", fontSize = 11.5.sp, fontWeight = FontWeight.Black)
                            Text("(Universal 1-Tap Cho Mọi Máy)", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    OutlinedButton(
                        onClick = onRevertOemOptimization,
                        enabled = !isBusy,
                        modifier = Modifier
                            .fillMaxHeight().weight(0.85f)
                            .defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.6f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicAmber)
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Khôi Phục", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Ô #49: BỘ LỌC HÃNG & DANH SÁCH CHI TIẾT TỪNG DÒNG MÁY
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicCyan.copy(alpha = 0.22f))
                            .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Ô #49",
                            color = MagicCyanLight,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
                Text(
                    text = "CHỌN GÓI TỐI ƯU RIÊNG CHO HÃNG ĐIỆN THOẠI",
                    color = Color.White,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Đặc trị riêng theo từng ROM hệ điều hành của hãng đó",
                    color = TextSecondary,
                    fontSize = 10.5.sp,
                    modifier = Modifier.fillMaxWidth()
                )

                // Thanh chọn nhanh hãng (Chips)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val filterChips = listOf(
                        "ALL" to "Tất cả (${brandList.size})",
                        "XIAOMI" to "Xiaomi",
                        "OPPO" to "OPPO / Realme",
                        "VIVO" to "Vivo / iQOO",
                        "HUAWEI" to "Huawei / Honor",
                        "SAMSUNG" to "Samsung",
                        "MEIZU" to "Meizu",
                        "ASUS" to "Asus / Sony"
                    )
                    filterChips.forEach { (key, label) ->
                        val isSelected = selectedTabFilter == key
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isSelected) MagicCyan
                                    else MagicSurfaceCard
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) Color.White else MagicBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { selectedTabFilter = key }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                color = if (isSelected) Color(0xFF020617) else Color.White,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold
                            )
                        }
                    }
                }

                // Danh sách từng hãng với chi tiết cơ chế diệt ngầm & nút thực thi
                filteredBrands.forEach { brand ->
                    var isExpanded by remember { mutableStateOf(brand.brandKey == detectedBrand) }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                        border = BorderStroke(
                            1.2.dp,
                            if (brand.brandKey == detectedBrand) MagicEmerald else brand.accentColor.copy(alpha = 0.5f)
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { isExpanded = !isExpanded },
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(34.dp)
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(brand.accentColor.copy(alpha = 0.18f))
                                                .border(1.dp, brand.accentColor, RoundedCornerShape(10.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.PhoneAndroid,
                                                contentDescription = null,
                                                tint = brand.accentColor,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                        Text(
                                            text = brand.romName,
                                            color = brand.accentColor,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (brand.brandKey == detectedBrand) {
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(MagicEmerald)
                                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                                            ) {
                                                Text(
                                                    text = "Máy bạn",
                                                    color = Color(0xFF020617),
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Black
                                                )
                                            }
                                        }
                                    }

                                    Icon(
                                        imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                        contentDescription = null,
                                        tint = TextSecondary
                                    )
                                }
                                Text(
                                    text = brand.name,
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            Text(
                                text = brand.description,
                                color = TextSecondary,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )

                            // Thẻ cảnh báo cơ chế diệt ngầm
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF0F172A))
                                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 5.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(Icons.Default.Warning, contentDescription = null, tint = MagicAmber, modifier = Modifier.size(13.dp))
                                    Text(
                                        text = "Cơ chế cản trở: ${brand.killerMechanism}",
                                        color = Color(0xFFFEF08A),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }

                            AnimatedVisibility(visible = isExpanded) {
                                Column(
                                    modifier = Modifier.padding(top = 4.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "Hạng mục can thiệp tự động:",
                                        color = Color.White,
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    brand.features.forEach { feat ->
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(Icons.Default.Check, contentDescription = null, tint = brand.accentColor, modifier = Modifier.size(12.dp))
                                            Text(text = feat, color = TextSecondary, fontSize = 10.5.sp)
                                        }
                                    }
                                }
                            }

                            // Nút hành động cho từng hãng
                            Button(
                                onClick = {
                                    when (brand.brandKey) {
                                        "XIAOMI" -> onFixXiaomi()
                                        "OPPO" -> onFixOppo()
                                        "VIVO" -> onFixVivo()
                                        "HUAWEI" -> onFixHuawei()
                                        "SAMSUNG" -> onFixSamsung()
                                        "MEIZU" -> onFixMeizu()
                                        "ASUS" -> onFixAsusRog()
                                        else -> onFixUniversalAll()
                                    }
                                },
                                enabled = !isBusy,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .defaultMinSize(minHeight = 36.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = brand.accentColor,
                                    contentColor = if (brand.accentColor == MagicEmerald || brand.accentColor == MagicCyan) Color(0xFF020617) else Color.White
                                )
                            ) {
                                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Áp Dụng Tối Ưu Cho ${brand.name.split("/").first().trim()}",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
