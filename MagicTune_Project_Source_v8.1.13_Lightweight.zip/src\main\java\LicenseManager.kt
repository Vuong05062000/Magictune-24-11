package com.example.core.license

import android.content.Context
import android.os.Build
import android.provider.Settings
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import android.util.Base64
import java.util.UUID
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.isActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * LicenseManager: Quản lý kích hoạt bản PRO bảo mật cao (SHA-256 + Cloud Firestore Sync + Real-time Admin Revocation)
 * Đảm bảo không thể giả mạo SMS hay dùng chùa vượt quá số lượt dùng thử do Admin quy định.
 */
object LicenseManager {

    const val PREF_NAME = "magictune_pro_prefs"
    const val KEY_PRO_ACTIVATED = "is_pro_activated"
    const val KEY_ACCOUNT_PRO_ACTIVATED = "is_account_pro_activated"
    const val KEY_UPGRADED_TO_ACCOUNT_PRO = "is_upgraded_to_account_pro"
    const val KEY_PENDING_ACCOUNT_PRO_BIND = "pending_account_pro_bind"
    const val KEY_ACTIVE_SESSION_TOKEN = "active_account_session_token"
    const val KEY_ACTIVATED_LICENSE = "activated_license_key"
    const val KEY_REVOKED_BY_ADMIN = "is_revoked_by_admin"
    const val KEY_AUTO_APPROVE_NOTIFICATION_PAYMENT = "is_auto_approve_notification_payment_enabled"
    const val KEY_BORROWED_ACCOUNT_PRO_SESSION = "is_borrowed_account_pro_session"
    const val CHANNEL_PRO_APPROVED_ID = "magictune_user_pro_approved_channel"
    const val KEY_LAST_NOTIFIED_PRO_APPROVED_TIER = "last_notified_pro_approved_tier"

    val ADMIN_EMAIL: String
        get() = runCatching { com.example.BuildConfig.ADMIN_EMAIL }.getOrNull()?.ifBlank { null } ?: "vuongdhkmhn@gmail.com"
    val ADMIN_PHONE: String
        get() = runCatching { com.example.BuildConfig.ADMIN_PHONE }.getOrNull()?.ifBlank { null } ?: "0393368007"

    // 🚀 Reactive Pro State for UI
    private val _isProFlow = kotlinx.coroutines.flow.MutableStateFlow(false)
    val isProFlow: kotlinx.coroutines.flow.StateFlow<Boolean> = _isProFlow

    /**
     * Khởi tạo trạng thái Pro ban đầu từ cache cục bộ (0ms)
     */
    fun initProFlowFromCache(context: Context) {
        _isProFlow.value = isProActivated(context)
    }

    fun isAutoApproveNotificationPaymentEnabled(context: Context): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_AUTO_APPROVE_NOTIFICATION_PAYMENT, true)
    }

    fun setAutoApproveNotificationPaymentEnabled(context: Context, enabled: Boolean) {
        val appCtx = context.applicationContext
        val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_AUTO_APPROVE_NOTIFICATION_PAYMENT, enabled).apply()
        putSecureConfigString(appCtx, KEY_AUTO_APPROVE_NOTIFICATION_PAYMENT, enabled.toString())
        syncCloudGlobalConfigMap(appCtx, mapOf(KEY_AUTO_APPROVE_NOTIFICATION_PAYMENT to enabled))
        notifyProAndConfigStateChanged(appCtx)
    }

    private const val KEY_ADMIN_SIMULATE_FREE_MODE = "admin_simulate_free_mode"

    @Volatile
    private var cachedAdminSimulateFreeMode: Boolean? = null

    fun isAdminSimulateFreeMode(context: Context): Boolean {
        cachedAdminSimulateFreeMode?.let { return it }
        val prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val value = prefs.getBoolean(KEY_ADMIN_SIMULATE_FREE_MODE, false)
        cachedAdminSimulateFreeMode = value
        return value
    }

    fun setAdminSimulateFreeMode(context: Context, simulateFree: Boolean) {
        val appCtx = context.applicationContext
        cachedAdminSimulateFreeMode = simulateFree
        val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_ADMIN_SIMULATE_FREE_MODE, simulateFree).apply()
        _isProFlow.value = isProActivated(appCtx)
        notifyProAndConfigStateChanged(appCtx)
    }

    // Secret Salt bảo mật chống giải ngược (Chỉ Admin mới tạo được Key hợp lệ)
    private val SECRET_SALT: String
        get() = runCatching { com.example.BuildConfig.PRO_SECRET_SALT }.getOrNull()?.ifBlank { null } ?: "MagicTunePro_SecretSalt_2026_VVuong_0393368007"
    private val ACCOUNT_PRO_SALT: String
        get() = runCatching { com.example.BuildConfig.PRO_ACCOUNT_SALT }.getOrNull()?.ifBlank { null } ?: "MagicTuneAccountPro_Salt_2026_VVuong_0393368007"

    // Endpoint Kill-Switch công khai
    private const val KILL_SWITCH_URL = "https://raw.githubusercontent.com/vuongdhkmhn/magictune/main/killswitch.txt"
    private const val PAID_DEVICES_URL = "https://raw.githubusercontent.com/vuongdhkmhn/magictune/main/paid_devices.txt"

    const val ACTION_PRO_ACTIVATED = "com.example.core.license.ACTION_PRO_ACTIVATED"
    const val ACTION_CONFIG_UPDATED = "com.example.core.license.ACTION_CONFIG_UPDATED"
    const val ACTION_GLOBAL_BROADCAST = "com.example.core.license.ACTION_GLOBAL_BROADCAST"

    const val KEY_PAYMENT_BANK_NAME = "payment_bank_name"
    const val KEY_PAYMENT_BANK_CODE = "payment_bank_code"
    const val KEY_PAYMENT_ACCOUNT_NUMBER = "payment_account_number"
    const val KEY_PAYMENT_ACCOUNT_HOLDER = "payment_account_holder"
    const val KEY_CUSTOM_APP_NAME = "custom_app_name"
    const val KEY_CUSTOM_APP_VERSION = "custom_app_version"
    const val KEY_CUSTOM_APP_FONT_SIZE = "custom_app_font_size"
    const val KEY_SHOW_FB_HEADER_ICON = "show_fb_header_icon"
    const val KEY_SHOW_YT_HEADER_ICON = "show_yt_header_icon"

    fun isFacebookHeaderIconVisible(context: Context?): Boolean {
        if (context == null) return true
        val appCtx = context.applicationContext ?: context
        val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        if (prefs.contains(KEY_SHOW_FB_HEADER_ICON)) {
            return prefs.getBoolean(KEY_SHOW_FB_HEADER_ICON, true)
        }
        val sec = getSecureConfigString(appCtx, KEY_SHOW_FB_HEADER_ICON)?.trim()
        if (sec != null && (sec.equals("true", true) || sec.equals("false", true))) {
            val v = sec.toBoolean()
            prefs.edit().putBoolean(KEY_SHOW_FB_HEADER_ICON, v).apply()
            return v
        }
        return true
    }

    fun setFacebookHeaderIconVisible(context: Context, visible: Boolean) {
        val appCtx = context.applicationContext ?: context
        val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_SHOW_FB_HEADER_ICON, visible).apply()
        putSecureConfigString(appCtx, KEY_SHOW_FB_HEADER_ICON, visible.toString())
        syncCloudGlobalConfigMap(appCtx, mapOf(KEY_SHOW_FB_HEADER_ICON to visible))
        notifyProAndConfigStateChanged(appCtx)
    }

    fun isYouTubeHeaderIconVisible(context: Context?): Boolean {
        if (context == null) return true
        val appCtx = context.applicationContext ?: context
        val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        if (prefs.contains(KEY_SHOW_YT_HEADER_ICON)) {
            return prefs.getBoolean(KEY_SHOW_YT_HEADER_ICON, true)
        }
        val sec = getSecureConfigString(appCtx, KEY_SHOW_YT_HEADER_ICON)?.trim()
        if (sec != null && (sec.equals("true", true) || sec.equals("false", true))) {
            val v = sec.toBoolean()
            prefs.edit().putBoolean(KEY_SHOW_YT_HEADER_ICON, v).apply()
            return v
        }
        return true
    }

    fun setYouTubeHeaderIconVisible(context: Context, visible: Boolean) {
        val appCtx = context.applicationContext ?: context
        val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_SHOW_YT_HEADER_ICON, visible).apply()
        putSecureConfigString(appCtx, KEY_SHOW_YT_HEADER_ICON, visible.toString())
        syncCloudGlobalConfigMap(appCtx, mapOf(KEY_SHOW_YT_HEADER_ICON to visible))
        notifyProAndConfigStateChanged(appCtx)
    }
    private const val KEY_GROQ_API_KEY_POOL = "groq_api_key_pool"
    private const val KEY_GEMINI_API_KEY_POOL = "magic_live_api_key_pool"
    private const val KEY_COMMUNITY_GEMINI_POOL = "community_gemini_key_pool"
    private const val KEY_COMMUNITY_GROQ_POOL = "community_groq_key_pool"
    private const val KEY_INVALID_DEAD_AI_KEYS = "invalid_dead_ai_keys_v1"
    private const val KEY_USER_CUSTOM_GEMINI_KEY = "user_custom_magic_live_key"
    private const val KEY_USER_CUSTOM_GEMINI_ONLY = "user_custom_gemini_only_key"
    private const val KEY_USER_CUSTOM_GROQ_ONLY = "user_custom_groq_only_key"

    private val verifiedValidAiKeysRam = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private val invalidDeadAiKeysRam = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    @Volatile
    private var invalidDeadKeysLoaded = false

    private fun ensureInvalidDeadKeysLoaded(context: Context?) {
        if (invalidDeadKeysLoaded || context == null) return
        synchronized(invalidDeadAiKeysRam) {
            if (invalidDeadKeysLoaded) return
            try {
                val prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                prefs.getStringSet(KEY_INVALID_DEAD_AI_KEYS, emptySet())?.forEach { k ->
                    if (k.isNotBlank()) invalidDeadAiKeysRam.add(k.trim())
                }
                invalidDeadKeysLoaded = true
            } catch (_: Throwable) {}
        }
    }

    fun isAiKeyInvalidOrDead(context: Context?, key: String): Boolean {
        val clean = key.trim()
        if (clean.isBlank()) return true
        ensureInvalidDeadKeysLoaded(context)
        return invalidDeadAiKeysRam.contains(clean)
    }

    /**
     * Kiểm tra định dạng & độ phức tạp ký tự chuẩn của Key Gemini (`AIza...`) để chặn ngay các chuỗi gõ bừa kiểu `AIza111111...`
     */
    fun isPlausibleGeminiKeyFormat(key: String): Boolean {
        val clean = key.trim()
        if (!clean.matches(Regex("^AIza[0-9A-Za-z_\\-]{31,48}$"))) return false
        val body = clean.removePrefix("AIza")
        val uniqueChars = body.toSet().size
        if (uniqueChars < 8) return false
        if (body.contains("12345678") || body.contains("abcdefgh", ignoreCase = true)) return false
        return !invalidDeadAiKeysRam.contains(clean)
    }

    /**
     * Kiểm tra định dạng & độ phức tạp ký tự chuẩn của Key Groq (`gsk_...`) để chặn ngay các chuỗi gõ bừa kiểu `gsk_111111...`
     */
    fun isPlausibleGroqKeyFormat(key: String): Boolean {
        val clean = key.trim()
        if (!clean.matches(Regex("^gsk_[0-9A-Za-z_\\-]{36,72}$"))) return false
        val body = clean.removePrefix("gsk_")
        val uniqueChars = body.toSet().size
        if (uniqueChars < 10) return false
        if (body.contains("12345678") || body.contains("abcdefgh", ignoreCase = true)) return false
        return !invalidDeadAiKeysRam.contains(clean)
    }

    /**
     * Xác thực TRỰC TIẾP (Live Ping 0-token) Key Gemini với máy chủ Google AI Studio:
     * - Chặn đứng 100% các mã Key giả, gõ bừa, hết hạn hoặc đã bị thu hồi trước khi cho phép lưu vào Kho Cộng Đồng.
     */
    fun verifySingleGeminiKeyLive(context: Context?, apiKey: String): Pair<Boolean, String> {
        val clean = apiKey.trim()
        ensureInvalidDeadKeysLoaded(context)
        if (!isPlausibleGeminiKeyFormat(clean)) {
            return false to "Key Gemini (${clean.take(10)}...) sai định dạng chuẩn (cần 39 ký tự bắt đầu bằng AIza...)"
        }
        if (verifiedValidAiKeysRam.contains(clean)) {
            return true to "Key Gemini hợp lệ"
        }
        var conn: java.net.HttpURLConnection? = null
        return try {
            val url = java.net.URL("https://generativelanguage.googleapis.com/v1beta/models?key=$clean&pageSize=3")
            conn = (url.openConnection() as java.net.HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 6000
                readTimeout = 6000
                setRequestProperty("Accept", "application/json")
            }
            val code = conn.responseCode
            if (code in 200..299) {
                val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText().take(600) }
                if (body.contains("\"models\"")) {
                    verifiedValidAiKeysRam.add(clean)
                    invalidDeadAiKeysRam.remove(clean)
                    true to "Key Gemini hợp lệ & hoạt động tốt"
                } else {
                    false to "Key Gemini (${clean.take(10)}...) phản hồi không hợp lệ từ Google"
                }
            } else if (code == 429) {
                // Mã 429 nghĩa là Key hoàn toàn có thật và hợp lệ trên Google, chỉ đang tạm chạm giới hạn phút
                verifiedValidAiKeysRam.add(clean)
                invalidDeadAiKeysRam.remove(clean)
                true to "Key Gemini hợp lệ (đang chạm giới hạn phút tạm thời)"
            } else if (code == 400 || code == 401 || code == 403) {
                false to "Key Gemini (${clean.take(10)}...) KHÔNG TỒN TẠI hoặc đã bị khóa/thu hồi trên Google AI Studio!"
            } else {
                false to "Máy chủ Google trả mã HTTP $code khi kiểm tra Key (${clean.take(10)}...)"
            }
        } catch (e: Throwable) {
            false to "Không thể kết nối Internet để kiểm tra Key Gemini (${clean.take(10)}...). Vui lòng kiểm tra mạng!"
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }

    /**
     * Xác thực TRỰC TIẾP (Live Ping 0-token) Key Groq với máy chủ Groq Cloud:
     * - Chặn đứng 100% các mã Key giả, gõ bừa, hết hạn hoặc đã bị xóa trước khi cho phép lưu vào Kho Cộng Đồng.
     */
    fun verifySingleGroqKeyLive(context: Context?, apiKey: String): Pair<Boolean, String> {
        val clean = apiKey.trim()
        ensureInvalidDeadKeysLoaded(context)
        if (!isPlausibleGroqKeyFormat(clean)) {
            return false to "Key Groq (${clean.take(10)}...) sai định dạng chuẩn (cần ~56 ký tự bắt đầu bằng gsk_...)"
        }
        if (verifiedValidAiKeysRam.contains(clean)) {
            return true to "Key Groq hợp lệ"
        }
        var conn: java.net.HttpURLConnection? = null
        return try {
            val url = java.net.URL("https://api.groq.com/openai/v1/models")
            conn = (url.openConnection() as java.net.HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 6000
                readTimeout = 6000
                setRequestProperty("Authorization", "Bearer $clean")
                setRequestProperty("Accept", "application/json")
            }
            val code = conn.responseCode
            if (code in 200..299) {
                val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText().take(600) }
                if (body.contains("\"data\"")) {
                    verifiedValidAiKeysRam.add(clean)
                    invalidDeadAiKeysRam.remove(clean)
                    true to "Key Groq hợp lệ & hoạt động tốt"
                } else {
                    false to "Key Groq (${clean.take(10)}...) phản hồi không hợp lệ từ Groq"
                }
            } else if (code == 429) {
                verifiedValidAiKeysRam.add(clean)
                invalidDeadAiKeysRam.remove(clean)
                true to "Key Groq hợp lệ (đang chạm giới hạn phút tạm thời)"
            } else if (code == 400 || code == 401 || code == 403) {
                false to "Key Groq (${clean.take(10)}...) KHÔNG TỒN TẠI hoặc đã bị xóa/thu hồi trên Groq Console!"
            } else {
                false to "Máy chủ Groq trả mã HTTP $code khi kiểm tra Key (${clean.take(10)}...)"
            }
        } catch (e: Throwable) {
            false to "Không thể kết nối Internet để kiểm tra Key Groq (${clean.take(10)}...). Vui lòng kiểm tra mạng!"
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }

    /**
     * Tự động cách ly & loại bỏ ngay lập tức bất kỳ Key nào bị phát hiện chết / thu hồi / không hợp lệ (`401`, `API_KEY_INVALID`)
     * trong quá trình sử dụng thực tế để không bao giờ làm gián đoạn hoặc hỏng AI của cộng đồng.
     */
    fun markAiKeyInvalidOrDead(context: Context?, badKey: String, isGemini: Boolean) {
        val clean = badKey.trim()
        if (clean.isBlank() || clean == "FIREBASE_AI_LOGIC_FREE_POOL") return
        ensureInvalidDeadKeysLoaded(context)
        invalidDeadAiKeysRam.add(clean)
        verifiedValidAiKeysRam.remove(clean)
        if (isGemini) {
            magic_liveKeyCooldownMap[clean] = System.currentTimeMillis() + 365L * 24 * 3600_000L
            currentMagicLiveKeyIndex = (currentMagicLiveKeyIndex + 1).coerceAtLeast(0)
        } else {
            keyCooldownMap[clean] = System.currentTimeMillis() + 365L * 24 * 3600_000L
            currentApiKeyIndex = (currentApiKeyIndex + 1).coerceAtLeast(0)
        }
        if (context != null) {
            val appCtx = context.applicationContext
            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                try {
                    val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    val savedDead = LinkedHashSet<String>(prefs.getStringSet(KEY_INVALID_DEAD_AI_KEYS, emptySet()) ?: emptySet())
                    savedDead.add(clean)
                    val editor = prefs.edit().putStringSet(KEY_INVALID_DEAD_AI_KEYS, savedDead)

                    // Gỡ key hỏng khỏi danh sách cá nhân & kho cộng đồng trên máy
                    val currCustom = getUserCustomMagicLiveKey(appCtx)
                    if (currCustom.contains(clean)) {
                        val filteredCustom = currCustom.split(Regex("[\\s,;]+"))
                            .map { it.trim() }
                            .filter { it.isNotBlank() && it != clean }
                            .joinToString(" ")
                        editor.putString(KEY_USER_CUSTOM_GEMINI_KEY, filteredCustom)
                        putSecureConfigString(appCtx, KEY_USER_CUSTOM_GEMINI_KEY, filteredCustom)
                    }
                    val commGem = getCommunityGeminiKeyPool(appCtx)
                    if (commGem.contains(clean)) {
                        val filteredGem = commGem.split(Regex("[\\s,;]+"))
                            .map { it.trim() }
                            .filter { it.isNotBlank() && it != clean }
                            .joinToString(" ")
                        editor.putString(KEY_COMMUNITY_GEMINI_POOL, filteredGem)
                        putSecureConfigString(appCtx, KEY_COMMUNITY_GEMINI_POOL, filteredGem)
                    }
                    val commGroq = getCommunityGroqKeyPool(appCtx)
                    if (commGroq.contains(clean)) {
                        val filteredGroq = commGroq.split(Regex("[\\s,;]+"))
                            .map { it.trim() }
                            .filter { it.isNotBlank() && it != clean }
                            .joinToString(" ")
                        editor.putString(KEY_COMMUNITY_GROQ_POOL, filteredGroq)
                        putSecureConfigString(appCtx, KEY_COMMUNITY_GROQ_POOL, filteredGroq)
                    }
                    editor.apply()
                } catch (_: Throwable) {}
            }
        }
    }

    fun getCommunityGeminiKeyPool(context: Context): String {
        ensureInvalidDeadKeysLoaded(context)
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val local = prefs.getString(KEY_COMMUNITY_GEMINI_POOL, "")?.trim().orEmpty()
        val sec = getSecureConfigString(context, KEY_COMMUNITY_GEMINI_POOL)?.trim().orEmpty()
        val combined = "$local $sec"
            .split(Regex("[\\s,;]+"))
            .map { it.trim() }
            .filter { isPlausibleGeminiKeyFormat(it) }
            .distinct()
            .joinToString(" ")
        if (combined.isNotBlank() && combined != local) {
            prefs.edit().putString(KEY_COMMUNITY_GEMINI_POOL, combined).apply()
        }
        return combined
    }

    fun getCommunityGroqKeyPool(context: Context): String {
        ensureInvalidDeadKeysLoaded(context)
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val local = prefs.getString(KEY_COMMUNITY_GROQ_POOL, "")?.trim().orEmpty()
        val sec = getSecureConfigString(context, KEY_COMMUNITY_GROQ_POOL)?.trim().orEmpty()
        val combined = "$local $sec"
            .split(Regex("[\\s,;]+"))
            .map { it.trim() }
            .filter { isPlausibleGroqKeyFormat(it) }
            .distinct()
            .joinToString(" ")
        if (combined.isNotBlank() && combined != local) {
            prefs.edit().putString(KEY_COMMUNITY_GROQ_POOL, combined).apply()
        }
        return combined
    }

    /**
     * Đóng góp các Key đã xác thực sống (Verified Live) của người dùng vào Kho Key Cộng Đồng Toàn Cầu
     * để tất cả người dùng khác trong ứng dụng cùng được chia sẻ xoay vòng hoàn toàn miễn phí (Admin tốn 0đ).
     */
    fun contributeVerifiedKeysToCommunityPool(
        context: Context,
        verifiedGeminiKeys: List<String>,
        verifiedGroqKeys: List<String>
    ) {
        val cleanGem = verifiedGeminiKeys.map { it.trim() }.filter { isPlausibleGeminiKeyFormat(it) }.distinct()
        val cleanGroq = verifiedGroqKeys.map { it.trim() }.filter { isPlausibleGroqKeyFormat(it) }.distinct()
        if (cleanGem.isEmpty() && cleanGroq.isEmpty()) return

        val appCtx = context.applicationContext
        val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val editor = prefs.edit()
        val cloudUpdates = mutableMapOf<String, Any>()

        if (cleanGem.isNotEmpty()) {
            val mergedCommGem = (cleanGem + getCommunityGeminiKeyPool(appCtx).split(Regex("[\\s,;]+")))
                .map { it.trim() }
                .filter { isPlausibleGeminiKeyFormat(it) }
                .distinct()
                .joinToString(" ")
            val mergedAdminGem = (cleanGem + getMagicLiveApiKeyPool(appCtx).split(Regex("[\\s,;]+")))
                .map { it.trim() }
                .filter { isPlausibleGeminiKeyFormat(it) }
                .distinct()
                .joinToString(" ")
            editor.putString(KEY_COMMUNITY_GEMINI_POOL, mergedCommGem)
            editor.putString(KEY_GEMINI_API_KEY_POOL, mergedAdminGem)
            putSecureConfigString(appCtx, KEY_COMMUNITY_GEMINI_POOL, mergedCommGem)
            putSecureConfigString(appCtx, KEY_GEMINI_API_KEY_POOL, mergedAdminGem)
            cloudUpdates[KEY_COMMUNITY_GEMINI_POOL] = mergedCommGem
            cloudUpdates[KEY_GEMINI_API_KEY_POOL] = mergedAdminGem
        }

        if (cleanGroq.isNotEmpty()) {
            val mergedCommGroq = (cleanGroq + getCommunityGroqKeyPool(appCtx).split(Regex("[\\s,;]+")))
                .map { it.trim() }
                .filter { isPlausibleGroqKeyFormat(it) }
                .distinct()
                .joinToString(" ")
            val mergedAdminGroq = (cleanGroq + getGroqApiKeyPool(appCtx).split(Regex("[\\s,;]+")))
                .map { it.trim() }
                .filter { isPlausibleGroqKeyFormat(it) }
                .distinct()
                .joinToString(" ")
            editor.putString(KEY_COMMUNITY_GROQ_POOL, mergedCommGroq)
            editor.putString(KEY_GROQ_API_KEY_POOL, mergedAdminGroq)
            putSecureConfigString(appCtx, KEY_COMMUNITY_GROQ_POOL, mergedCommGroq)
            putSecureConfigString(appCtx, KEY_GROQ_API_KEY_POOL, mergedAdminGroq)
            cloudUpdates[KEY_COMMUNITY_GROQ_POOL] = mergedCommGroq
            cloudUpdates[KEY_GROQ_API_KEY_POOL] = mergedAdminGroq
        }

        editor.apply()
        if (cloudUpdates.isNotEmpty()) {
            syncCloudGlobalConfigMap(appCtx, cloudUpdates)
        }
    }

    data class LiveKeyValidationReport(
        val validGeminiKeys: List<String>,
        val validGroqKeys: List<String>,
        val invalidReasons: List<String>,
        val savedAnyValidKey: Boolean
    )

    /**
     * Xác thực trực tiếp trên máy chủ Google/Groq toàn bộ các Key người dùng vừa nhập/dán:
     * - Chỉ lưu những Key THẬT và ĐANG HOẠT ĐỘNG.
     * - Từ chối thẳng thừng các mã giả / gõ bừa để bảo vệ Kho Key Cộng Đồng.
     * - Tự động đóng góp Key hợp lệ vào Kho Key Cộng Đồng cho mọi người dùng khác cùng hưởng lợi.
     */
    fun validateAndSaveUserAiKeysLive(context: Context, rawText: String): LiveKeyValidationReport {
        val appCtx = context.applicationContext ?: context
        ensureInvalidDeadKeysLoaded(appCtx)
        val candidateGemini = Regex("AIza[0-9A-Za-z_\\-]{10,}").findAll(rawText).map { it.value.trim() }.distinct().toList()
        val candidateGroq = Regex("gsk_[0-9A-Za-z_\\-]{10,}").findAll(rawText).map { it.value.trim() }.distinct().toList()

        val validGemini = mutableListOf<String>()
        val validGroq = mutableListOf<String>()
        val invalidReasons = mutableListOf<String>()

        for (gKey in candidateGemini) {
            val (ok, msg) = verifySingleGeminiKeyLive(appCtx, gKey)
            if (ok) {
                validGemini.add(gKey)
            } else {
                invalidReasons.add(msg)
            }
        }
        for (kKey in candidateGroq) {
            val (ok, msg) = verifySingleGroqKeyLive(appCtx, kKey)
            if (ok) {
                validGroq.add(kKey)
            } else {
                invalidReasons.add(msg)
            }
        }

        val savedAny = validGemini.isNotEmpty() || validGroq.isNotEmpty()
        if (savedAny) {
            // Giữ lại các key hợp lệ đã lưu trước đó của người dùng (ví dụ đã lưu Gemini trước đó, nay thêm Groq)
            val prevGemini = getUserPersonalGeminiKey(appCtx)
                .split(Regex("[\\s,;]+"))
                .map { it.trim() }
                .filter { isPlausibleGeminiKeyFormat(it) }
            val prevGroq = getUserPersonalGroqKey(appCtx)
                .split(Regex("[\\s,;]+"))
                .map { it.trim() }
                .filter { isPlausibleGroqKeyFormat(it) }

            val finalPersonalGemini = (validGemini + prevGemini).distinct()
            val finalPersonalGroq = (validGroq + prevGroq).distinct()
            val combinedValid = (finalPersonalGemini + finalPersonalGroq).joinToString(" ")

            setUserCustomMagicLiveKey(appCtx, combinedValid, syncToCloud = true)
            contributeVerifiedKeysToCommunityPool(appCtx, validGemini, validGroq)
        }

        return LiveKeyValidationReport(
            validGeminiKeys = validGemini,
            validGroqKeys = validGroq,
            invalidReasons = invalidReasons,
            savedAnyValidKey = savedAny
        )
    }

    fun getUserCustomMagicLiveKey(context: Context): String {
        ensureInvalidDeadKeysLoaded(context)
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_USER_CUSTOM_GEMINI_KEY, "")?.trim().orEmpty()
        if (raw.isNotBlank()) return raw
        val sec = getSecureConfigString(context, KEY_USER_CUSTOM_GEMINI_KEY)?.trim().orEmpty()
        if (sec.isNotBlank()) {
            prefs.edit().putString(KEY_USER_CUSTOM_GEMINI_KEY, sec).apply()
            return sec
        }
        return ""
    }

    fun getUserPersonalGeminiKey(context: Context): String {
        val raw = getUserCustomMagicLiveKey(context)
        return raw.split(Regex("[\\s,;]+"))
            .map { it.trim() }
            .filter { isPlausibleGeminiKeyFormat(it) }
            .distinct()
            .joinToString(" ")
    }

    fun getUserPersonalGroqKey(context: Context): String {
        val raw = getUserCustomMagicLiveKey(context)
        return raw.split(Regex("[\\s,;]+"))
            .map { it.trim() }
            .filter { isPlausibleGroqKeyFormat(it) }
            .distinct()
            .joinToString(" ")
    }

    fun hasUserPersonalGeminiKey(context: Context): Boolean = getUserPersonalGeminiKey(context).isNotBlank()

    fun hasUserPersonalGroqKey(context: Context): Boolean = getUserPersonalGroqKey(context).isNotBlank()

    fun hasUserAddedBothPersonalAiKeys(context: Context): Boolean {
        return hasUserPersonalGeminiKey(context) && hasUserPersonalGroqKey(context)
    }

    fun hasUserAddedAnyPersonalAiKey(context: Context): Boolean {
        return hasUserPersonalGeminiKey(context) || hasUserPersonalGroqKey(context)
    }

    /**
     * Kiểm tra quyền sử dụng các tính năng AI của MagicLive theo cơ chế Kho Key Cộng Đồng Dùng Chung (100% Free Tier):
     * 1. Tài khoản PRO hoặc ADMIN: Luôn được phép sử dụng.
     * 2. Người dùng đã đóng góp đủ Key Gemini (AIza...) + Key Groq (gsk_...) hợp lệ: Được sử dụng thoải mái và chia sẻ xoay vòng cùng Kho Cộng Đồng.
     * 3. Nếu Kho Key Cộng Đồng đang có sẵn cả Key Gemini + Key Groq hợp lệ do những người dùng khác đóng góp (và còn trong hạn mức miễn phí):
     *    Cho phép tất cả người dùng khác cùng sử dụng chung Kho Key Cộng Đồng ngay lập tức (Admin tốn 0đ)!
     * 4. Nếu chưa có Key cá nhân và Kho Cộng Đồng chưa đủ Key (hoặc đang chạm trần phút): Nhắc người dùng thêm Key hợp lệ của họ để đóng góp cho cộng đồng hoặc nâng cấp PRO.
     */
    fun checkMagicLiveAiKeyRequirement(context: Context): Pair<Boolean, String> {
        val isSimFree = isAdminSimulateFreeMode(context)
        val isPro = isProActivated(context) && !isSimFree
        val isAdmin = isCurrentUserAdmin(context) && !isSimFree
        if (isPro || isAdmin) {
            return true to ""
        }
        val hasPersonalGemini = hasUserPersonalGeminiKey(context)
        val hasPersonalGroq = hasUserPersonalGroqKey(context)
        if (hasPersonalGemini && hasPersonalGroq) {
            return true to "🤝 Đang dùng Key cá nhân & Kho Key Cộng Đồng (Miễn phí 100%)"
        }

        // Kiểm tra xem Kho Key Cộng Đồng (do người dùng khác đóng góp) có đang sẵn sàng cả Gemini & Groq trong hạn mức Free-Tier không
        val communityGeminiAvailable = getAllAdminAndPersonalGeminiKeysRaw(context)
            .any { isAiKeyWithinFreeTierLimit(context, it, isGemini = true) }
        val communityGroqAvailable = getAllAdminAndPersonalGroqKeysRaw(context)
            .any { isAiKeyWithinFreeTierLimit(context, it, isGemini = false) }
        val hasCommunityContributedKeys = getCommunityGeminiKeyPool(context).isNotBlank() ||
            getCommunityGroqKeyPool(context).isNotBlank() ||
            getMagicLiveApiKeyPool(context).isNotBlank() ||
            getGroqApiKeyPool(context).isNotBlank()

        if (hasCommunityContributedKeys && communityGeminiAvailable && communityGroqAvailable) {
            return true to "🤝 Đang dùng chung Kho Key Cộng Đồng miễn phí (Hãy bấm '🔑 Key' để đóng góp thêm Key của bạn cho cộng đồng nhé!)"
        }

        val missingDesc = when {
            !hasPersonalGemini && !hasPersonalGroq -> "Cả 2 Key Gemini (AIza...) & Key Groq (gsk_...)"
            !hasPersonalGemini -> "Key Gemini (bắt đầu bằng AIza...)"
            else -> "Key Groq (bắt đầu bằng gsk_...)"
        }
        val reminderMsg = "🔑 ĐÓNG GÓP KEY AI CỘNG ĐỒNG HOẶC NÂNG CẤP PRO:\n" +
            "• Để mọi người dùng chung miễn phí 100% (Admin không mất phí duy trì), khi 1 người dùng thêm Key hợp lệ thì toàn bộ cộng đồng sẽ được dùng chung xoay vòng.\n" +
            "• Hiện tại Kho Cộng Đồng đang cần thêm Key hoặc máy bạn còn thiếu: $missingDesc.\n" +
            "👉 Hãy bấm nút '🔑 Thêm Key' trên bảng MagicLive để dán Key Gemini (AIza...) + Groq (gsk_...) hợp lệ (hệ thống sẽ kiểm tra Key sống trước khi lưu) hoặc nâng cấp PRO Vĩnh Viễn!"
        return false to reminderMsg
    }

    fun saveUserPersonalAiKeys(
        context: Context,
        geminiKeyInput: String,
        groqKeyInput: String,
        syncToCloud: Boolean = true
    ) {
        val combinedTokens = "$geminiKeyInput $groqKeyInput"
            .split(Regex("[\\s,;]+"))
            .map { it.trim() }
            .filter { it.isNotBlank() && it != "null" }
            .distinct()
        setUserCustomMagicLiveKey(context, combinedTokens.joinToString(" "), syncToCloud = syncToCloud)
    }

    fun setUserCustomMagicLiveKey(context: Context, key: String, syncToCloud: Boolean = true) {
        ensureInvalidDeadKeysLoaded(context)
        val tokens = key.split(Regex("[\\s,;]+"))
            .map { it.trim() }
            .filter { it.isNotBlank() && it != "null" && it != "GROQ_API_KEY_DEFAULT_VALUE" }
            .distinct()
        val geminiTokens = tokens.filter { isPlausibleGeminiKeyFormat(it) }
        val groqTokens = tokens.filter { isPlausibleGroqKeyFormat(it) }
        val cleanCombined = (geminiTokens + groqTokens).distinct().joinToString(" ")
        val cleanGemini = geminiTokens.joinToString(" ")
        val cleanGroq = groqTokens.joinToString(" ")

        // Xóa trạng thái cooldown cho các key hợp lệ vừa nhập mới
        for (tk in geminiTokens) magic_liveKeyCooldownMap.remove(tk)
        for (tk in groqTokens) keyCooldownMap.remove(tk)

        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_USER_CUSTOM_GEMINI_KEY, cleanCombined)
            .putString(KEY_USER_CUSTOM_GEMINI_ONLY, cleanGemini)
            .putString(KEY_USER_CUSTOM_GROQ_ONLY, cleanGroq)
            .putLong("user_custom_ai_key_updated_ms", System.currentTimeMillis())
            .apply()
        putSecureConfigString(context, KEY_USER_CUSTOM_GEMINI_KEY, cleanCombined)
        if (syncToCloud) {
            syncUserPersonalAiKeysToCloud(context, cleanGemini, cleanGroq, cleanCombined)
            if (geminiTokens.isNotEmpty() || groqTokens.isNotEmpty()) {
                contributeVerifiedKeysToCommunityPool(context, geminiTokens, groqTokens)
            }
        }
        notifyProAndConfigStateChanged(context)
    }

    fun syncUserPersonalAiKeysToCloud(
        context: Context,
        geminiKey: String = getUserPersonalGeminiKey(context),
        groqKey: String = getUserPersonalGroqKey(context),
        combinedRaw: String = getUserCustomMagicLiveKey(context)
    ) {
        val appCtx = context.applicationContext
        val nowMs = System.currentTimeMillis()
        val hasAny = geminiKey.isNotBlank() || groqKey.isNotBlank() || combinedRaw.isNotBlank()

        // Cập nhật ngay bộ nhớ đệm RAM của trang Quản Trị (nếu đang mở) để Admin thấy tức thì 0ms
        val deviceId = getDeviceId(appCtx).trim().uppercase()
        val normDevId = normalizeDeviceIdForMatch(deviceId)
        val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
        val savedEmail = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString("current_user_email", "")?.trim().orEmpty()
        val effectiveEmail = (user?.email ?: savedEmail).trim()

        val ramFields = mapOf<String, Any>(
            "customGeminiKey" to geminiKey,
            "customGroqKey" to groqKey,
            "customAiKeyRaw" to combinedRaw,
            "userCustomAiKeys" to combinedRaw,
            "hasCustomAiKey" to hasAny,
            "customAiKeyUpdatedMs" to nowMs
        )
        adminRestCollectionCache["devices"]?.let { (ts, list) ->
            val updated = list.map { m ->
                val dId = normalizeDeviceIdForMatch((m["deviceId"] as? String) ?: (m["__id"] as? String).orEmpty())
                if (normDevId.isNotBlank() && dId == normDevId) m + ramFields else m
            }
            adminRestCollectionCache["devices"] = ts to updated
        }
        adminRestCollectionCache["users"]?.let { (ts, list) ->
            val updated = list.map { m ->
                val uId = (m["userId"] as? String) ?: (m["__id"] as? String).orEmpty()
                val uDev = normalizeDeviceIdForMatch((m["deviceId"] as? String).orEmpty())
                val uActDev = normalizeDeviceIdForMatch((m["activeDeviceId"] as? String).orEmpty())
                val uEm = ((m["email"] as? String).orEmpty()).trim()
                val matched = (user != null && uId == user.uid) ||
                    (effectiveEmail.isNotBlank() && uEm.equals(effectiveEmail, ignoreCase = true)) ||
                    (normDevId.isNotBlank() && (uDev == normDevId || uActDev == normDevId))
                if (matched) m + ramFields else m
            }
            adminRestCollectionCache["users"] = ts to updated
        }

        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = FirebaseFirestore.getInstance()
                val payload = mutableMapOf<String, Any>(
                    "customGeminiKey" to geminiKey,
                    "customGroqKey" to groqKey,
                    "customAiKeyRaw" to combinedRaw,
                    "userCustomAiKeys" to combinedRaw,
                    "hasCustomAiKey" to hasAny,
                    "customAiKeyUpdatedMs" to nowMs,
                    "customAiKeyUpdatedAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                val devPayload = payload + mapOf(
                    "deviceId" to deviceId,
                    "model" to "${Build.MANUFACTURER} ${Build.MODEL}"
                ) + (if (effectiveEmail.isNotBlank()) mapOf("ownerEmail" to effectiveEmail) else emptyMap()) +
                    (if (user != null && user.uid.isNotBlank()) mapOf("ownerUid" to user.uid) else emptyMap())

                val devTargetIds = listOf(deviceId, normDevId, if (normDevId.isNotBlank()) "MT-$normDevId" else "")
                    .map { it.trim() }
                    .filter { it.isNotBlank() }
                    .distinct()

                for (dId in devTargetIds) {
                    val dMap = devPayload + ("deviceId" to dId)
                    kotlin.runCatching { db.collection("devices").document(dId).set(dMap, SetOptions.merge()) }
                    FirestoreRestTokenBridge.patchDocViaRest(appCtx, "devices", dId, dMap)
                }

                if (user != null && user.uid.isNotBlank()) {
                    val uMap = payload + mapOf(
                        "userId" to user.uid,
                        "deviceId" to deviceId,
                        "activeDeviceId" to deviceId,
                        "activeDeviceModel" to "${Build.MANUFACTURER} ${Build.MODEL}"
                    ) + (if (effectiveEmail.isNotBlank()) mapOf("email" to effectiveEmail) else emptyMap())
                    kotlin.runCatching { db.collection("users").document(user.uid).set(uMap, SetOptions.merge()) }
                    FirestoreRestTokenBridge.patchDocViaRest(appCtx, "users", user.uid, uMap)
                } else if (effectiveEmail.contains("@")) {
                    val matchedUsers = FirestoreRestTokenBridge.queryCollectionByFieldInViaRest(
                        appCtx,
                        "users",
                        "email",
                        listOf(effectiveEmail, effectiveEmail.lowercase()),
                        limit = 5
                    )
                    for (uDoc in matchedUsers) {
                        val docId = (uDoc["__id"] as? String).orEmpty()
                        if (docId.isNotBlank()) {
                            FirestoreRestTokenBridge.patchDocViaRest(appCtx, "users", docId, payload)
                            kotlin.runCatching { db.collection("users").document(docId).set(payload, SetOptions.merge()) }
                        }
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    private fun getApkBrandingScopeSuffix(): String {
        val vc = try { com.example.BuildConfig.VERSION_CODE } catch (_: Throwable) { 1 }
        val vn = try { com.example.BuildConfig.VERSION_NAME } catch (_: Throwable) { com.example.data.APP_VERSION_NAME }
            .replace(Regex("[^a-zA-Z0-9]"), "_")
            .trim('_')
            .ifBlank { "default" }
        return "vc${vc}_$vn"
    }

    private fun scopedAppNameKey(): String = "${KEY_CUSTOM_APP_NAME}_${getApkBrandingScopeSuffix()}"
    private fun scopedAppVersionKey(): String = "${KEY_CUSTOM_APP_VERSION}_${getApkBrandingScopeSuffix()}"
    private fun scopedAppFontSizeKey(): String = "${KEY_CUSTOM_APP_FONT_SIZE}_${getApkBrandingScopeSuffix()}"

    fun getAppName(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val key = scopedAppNameKey()
        val local = prefs.getString(key, null)
        if (!local.isNullOrBlank()) return local
        val sec = getSecureConfigString(context, key)
        if (!sec.isNullOrBlank()) {
            prefs.edit().putString(key, sec).apply()
            return sec
        }
        return "Magictune_Tool"
    }

    fun setAppName(context: Context, name: String) {
        val clean = name.trim().ifBlank { "Magictune_Tool" }
        val key = scopedAppNameKey()
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(key, clean).apply()
        putSecureConfigString(context, key, clean)
        syncCloudGlobalConfigMap(context, mapOf(key to clean))
        notifyProAndConfigStateChanged(context)
    }

    fun getAppVersionLabel(context: Context): String {
        val currentDefault = com.example.data.APP_VERSION_NAME.lowercase()
        val key = scopedAppVersionKey()
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val local = prefs.getString(key, null)
        if (local != null) return local
        val sec = getSecureConfigString(context, key)
        if (sec != null) {
            prefs.edit().putString(key, sec).apply()
            return sec
        }
        return currentDefault
    }

    fun setAppVersionLabel(context: Context, versionLabel: String) {
        val clean = versionLabel.trim()
        val key = scopedAppVersionKey()
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(key, clean).apply()
        putSecureConfigString(context, key, clean)
        syncCloudGlobalConfigMap(context, mapOf(key to clean))
        notifyProAndConfigStateChanged(context)
    }

    fun getAppNameFontSizeSp(context: Context): Float {
        val key = scopedAppFontSizeKey()
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val local = prefs.getFloat(key, -1f)
        if (local in 7f..26f) return local
        val sec = getSecureConfigString(context, key)?.toFloatOrNull()
        if (sec != null && sec in 7f..26f) {
            prefs.edit().putFloat(key, sec).apply()
            return sec
        }
        return 11.5f
    }

    fun setAppNameFontSizeSp(context: Context, sizeSp: Float) {
        val cleanSize = sizeSp.coerceIn(7.5f, 24f)
        val key = scopedAppFontSizeKey()
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putFloat(key, cleanSize).apply()
        putSecureConfigString(context, key, cleanSize.toString())
        syncCloudGlobalConfigMap(context, mapOf(key to cleanSize.toDouble()))
        notifyProAndConfigStateChanged(context)
    }

    fun setHeaderBrandingConfig(
        context: Context,
        appName: String,
        versionLabel: String,
        fontSizeSp: Float
    ) {
        val cleanName = appName.trim().ifBlank { "Magictune_Tool" }
        val cleanVer = versionLabel.trim()
        val cleanSize = fontSizeSp.coerceIn(7.5f, 24f)
        val nameKey = scopedAppNameKey()
        val verKey = scopedAppVersionKey()
        val fontKey = scopedAppFontSizeKey()
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(nameKey, cleanName)
            .putString(verKey, cleanVer)
            .putFloat(fontKey, cleanSize)
            .apply()
        putSecureConfigString(context, nameKey, cleanName)
        putSecureConfigString(context, verKey, cleanVer)
        putSecureConfigString(context, fontKey, cleanSize.toString())
        syncCloudGlobalConfigMap(
            context,
            mapOf(
                nameKey to cleanName,
                verKey to cleanVer,
                fontKey to cleanSize.toDouble()
            )
        )
        notifyProAndConfigStateChanged(context)
    }

    const val KEY_APP_UI_SCALE = "app_ui_scale_ratio"
    const val KEY_APP_UI_SCALE_UPDATED_AT = "app_ui_scale_updated_at"
    private val _appUiScaleFlow = kotlinx.coroutines.flow.MutableStateFlow(0.85f)
    val appUiScaleFlow: kotlinx.coroutines.flow.StateFlow<Float> = _appUiScaleFlow

    fun getAppUiScale(context: Context): Float {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val local = prefs.getFloat(KEY_APP_UI_SCALE, -1f)
        val sec = getSecureConfigString(context, KEY_APP_UI_SCALE)?.toFloatOrNull()
        val localTs = prefs.getLong(KEY_APP_UI_SCALE_UPDATED_AT, 0L)
        val secTs = getSecureConfigString(context, KEY_APP_UI_SCALE_UPDATED_AT)?.toLongOrNull() ?: 0L

        if (sec != null && sec in 0.80f..1.00f && (secTs > localTs || local !in 0.80f..1.00f)) {
            val cleanSec = (kotlin.math.round(sec * 100f) / 100f).coerceIn(0.80f, 1.00f)
            prefs.edit()
                .putFloat(KEY_APP_UI_SCALE, cleanSec)
                .putLong(KEY_APP_UI_SCALE_UPDATED_AT, maxOf(localTs, secTs))
                .apply()
            _appUiScaleFlow.value = cleanSec
            return cleanSec
        }
        if (local in 0.80f..1.00f) {
            val cleanLocal = (kotlin.math.round(local * 100f) / 100f).coerceIn(0.80f, 1.00f)
            _appUiScaleFlow.value = cleanLocal
            return cleanLocal
        }
        _appUiScaleFlow.value = 0.85f
        return 0.85f
    }

    fun setAppUiScale(context: Context, scale: Float, syncCloud: Boolean = true) {
        val cleanScale = (kotlin.math.round(scale * 100f) / 100f).coerceIn(0.80f, 1.00f)
        val nowMs = System.currentTimeMillis()
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putFloat(KEY_APP_UI_SCALE, cleanScale)
            .putLong(KEY_APP_UI_SCALE_UPDATED_AT, nowMs)
            .apply()
        putSecureConfigString(context, KEY_APP_UI_SCALE, cleanScale.toString())
        putSecureConfigString(context, KEY_APP_UI_SCALE_UPDATED_AT, nowMs.toString())
        _appUiScaleFlow.value = cleanScale
        if (syncCloud) {
            syncCloudGlobalConfigMap(
                context,
                mapOf(
                    KEY_APP_UI_SCALE to cleanScale.toDouble(),
                    KEY_APP_UI_SCALE_UPDATED_AT to nowMs
                )
            )
            notifyProAndConfigStateChanged(context)
        }
    }

    fun getMagicLiveApiKeyPool(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val local = prefs.getString(KEY_GEMINI_API_KEY_POOL, null)
        if (!local.isNullOrBlank()) return local
        val sec = getSecureConfigString(context, KEY_GEMINI_API_KEY_POOL)
        if (!sec.isNullOrBlank()) {
            prefs.edit().putString(KEY_GEMINI_API_KEY_POOL, sec).apply()
            return sec
        }
        return ""
    }

    fun setMagicLiveApiKeyPool(context: Context, pool: String) {
        val cleanPool = pool.trim()
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_GEMINI_API_KEY_POOL, cleanPool).apply()
        putSecureConfigString(context, KEY_GEMINI_API_KEY_POOL, cleanPool)
        syncCloudGlobalConfigMap(context, mapOf(KEY_GEMINI_API_KEY_POOL to cleanPool))
        notifyProAndConfigStateChanged(context)
    }

    fun countClassifiedAiKeys(rawInput: String): Pair<Int, Int> {
        val tokens = rawInput.split(Regex("[\\s,;]+")).map { it.trim() }.filter { it.length >= 12 && it != "null" && it != "GROQ_API_KEY_DEFAULT_VALUE" }.distinct()
        val groqCount = tokens.count { it.startsWith("gsk_") || (!it.startsWith("AIza") && it.length >= 20) }
        val magic_liveCount = tokens.count { it.startsWith("AIza") }
        return groqCount to magic_liveCount
    }

    // =========================================================================
    // CƠ CHẾ BẢO VỆ TUYỆT ĐỐI HẠN MỨC MIỄN PHÍ (100% FREE TIER QUOTA GUARD)
    // & TỰ ĐỘNG XOAY VÒNG NHIỀU KEY (GEMINI + GROQ) ĐỂ ADMIN TỐN 0 ĐỒNG DUY TRÌ
    // =========================================================================
    private const val MAX_FREE_GEMINI_RPM = 12 // Giới hạn miễn phí Google: 15 RPM -> Chặn ở 12 RPM để an toàn 100%
    private const val MAX_FREE_GEMINI_RPD = 1400 // Giới hạn miễn phí Google: 1,500 RPD -> Chặn ở 1,400 RPD
    private const val MAX_FREE_GROQ_RPM = 25 // Giới hạn miễn phí Groq: 30 RPM -> Chặn ở 25 RPM
    private const val MAX_FREE_GROQ_RPD = 1400 // Giới hạn miễn phí Groq: 1,400 RPD/key

    private val keyMinuteTimestampsMap = java.util.concurrent.ConcurrentHashMap<String, MutableList<Long>>()
    private val keyDailyCountMap = java.util.concurrent.ConcurrentHashMap<String, Int>()
    @Volatile
    private var activeQuotaDayKey: String = ""

    private fun currentQuotaDayString(): String {
        return java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
    }

    private fun ensureQuotaDayFresh(context: Context?) {
        val today = currentQuotaDayString()
        if (activeQuotaDayKey != today) {
            synchronized(keyDailyCountMap) {
                if (activeQuotaDayKey != today) {
                    activeQuotaDayKey = today
                    keyDailyCountMap.clear()
                    if (context != null) {
                        try {
                            val prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                            val savedDay = prefs.getString("ai_quota_day_str", "") ?: ""
                            if (savedDay != today) {
                                prefs.edit().putString("ai_quota_day_str", today).putString("ai_quota_counts_json", "{}").apply()
                            } else {
                                val rawJson = prefs.getString("ai_quota_counts_json", "{}") ?: "{}"
                                val obj = org.json.JSONObject(rawJson)
                                val keys = obj.keys()
                                while (keys.hasNext()) {
                                    val k = keys.next()
                                    keyDailyCountMap[k] = obj.optInt(k, 0)
                                }
                            }
                        } catch (_: Throwable) {}
                    }
                }
            }
        }
    }

    fun isAiKeyWithinFreeTierLimit(
        context: Context?,
        apiKey: String,
        isGemini: Boolean
    ): Boolean {
        val clean = apiKey.trim()
        if (clean.isBlank()) return false
        ensureQuotaDayFresh(context)
        val now = System.currentTimeMillis()
        val cooldownUntil = if (isGemini) {
            magic_liveKeyCooldownMap[clean] ?: 0L
        } else {
            keyCooldownMap[clean] ?: 0L
        }
        if (cooldownUntil > now) return false

        val maxRpm = if (isGemini) MAX_FREE_GEMINI_RPM else MAX_FREE_GROQ_RPM
        val maxRpd = if (isGemini) MAX_FREE_GEMINI_RPD else MAX_FREE_GROQ_RPD

        val dailyUsed = keyDailyCountMap[clean] ?: 0
        if (dailyUsed >= maxRpd) {
            // Đã chạm trần miễn phí trong ngày của Key này -> khóa Key đến hết ngày và đổi sang Key tiếp theo
            if (isGemini) {
                markMagicLiveApiKeyCooldown(clean, cooldownMs = 6 * 3600_000L)
            } else {
                markGroqApiKeyCooldown(clean, cooldownMs = 6 * 3600_000L)
            }
            return false
        }

        val list = keyMinuteTimestampsMap.getOrPut(clean) { java.util.Collections.synchronizedList(mutableListOf()) }
        synchronized(list) {
            list.removeAll { now - it > 60_000L }
            if (list.size >= maxRpm) {
                // Đã chạm trần miễn phí theo phút (RPM) của Key này -> tạm nghỉ 45s và tự động xoay sang Key khác
                if (isGemini) {
                    markMagicLiveApiKeyCooldown(clean, cooldownMs = 45_000L)
                } else {
                    markGroqApiKeyCooldown(clean, cooldownMs = 45_000L)
                }
                return false
            }
        }
        return true
    }

    fun tryConsumeAiKeyFreeTierQuota(
        context: Context?,
        apiKey: String,
        isGemini: Boolean
    ): Boolean {
        val clean = apiKey.trim()
        if (!isAiKeyWithinFreeTierLimit(context, clean, isGemini)) return false
        val now = System.currentTimeMillis()
        val list = keyMinuteTimestampsMap.getOrPut(clean) { java.util.Collections.synchronizedList(mutableListOf()) }
        synchronized(list) {
            list.add(now)
        }
        val newDaily = (keyDailyCountMap[clean] ?: 0) + 1
        keyDailyCountMap[clean] = newDaily
        if (isGemini) {
            currentMagicLiveKeyIndex = (currentMagicLiveKeyIndex + 1).coerceAtLeast(0)
        } else {
            currentApiKeyIndex = (currentApiKeyIndex + 1).coerceAtLeast(0)
        }
        // Lưu nhẹ mỗi 5 lượt để tiết kiệm tài nguyên đọc/ghi
        if (context != null && (newDaily % 5 == 1)) {
            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                try {
                    val prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    val obj = org.json.JSONObject()
                    for ((k, v) in keyDailyCountMap) {
                        obj.put(k, v)
                    }
                    prefs.edit()
                        .putString("ai_quota_day_str", currentQuotaDayString())
                        .putString("ai_quota_counts_json", obj.toString())
                        .apply()
                } catch (_: Throwable) {}
            }
        }
        return true
    }

    data class AiKeyPoolStatusSummary(
        val totalGroqKeys: Int,
        val activeGroqKeys: Int,
        val cooldownGroqKeys: Int,
        val totalGeminiKeys: Int,
        val activeGeminiKeys: Int,
        val cooldownGeminiKeys: Int,
        val hasPersonalGemini: Boolean,
        val hasPersonalGroq: Boolean,
        val totalCallsTodayInFreeTier: Int
    )

    fun getAiKeyPoolStatusSummary(context: Context): AiKeyPoolStatusSummary {
        ensureQuotaDayFresh(context)
        val allGroq = getAllAdminAndPersonalGroqKeysRaw(context)
        val allGemini = getAllAdminAndPersonalGeminiKeysRaw(context)
        val activeGroq = allGroq.count { isAiKeyWithinFreeTierLimit(context, it, isGemini = false) }
        val activeGemini = allGemini.count { isAiKeyWithinFreeTierLimit(context, it, isGemini = true) }
        val totalToday = keyDailyCountMap.values.sum()
        return AiKeyPoolStatusSummary(
            totalGroqKeys = allGroq.size,
            activeGroqKeys = activeGroq,
            cooldownGroqKeys = (allGroq.size - activeGroq).coerceAtLeast(0),
            totalGeminiKeys = allGemini.size,
            activeGeminiKeys = activeGemini,
            cooldownGeminiKeys = (allGemini.size - activeGemini).coerceAtLeast(0),
            hasPersonalGemini = hasUserPersonalGeminiKey(context),
            hasPersonalGroq = hasUserPersonalGroqKey(context),
            totalCallsTodayInFreeTier = totalToday
        )
    }

    private fun getAllAdminAndPersonalGeminiKeysRaw(context: Context): List<String> {
        ensureInvalidDeadKeysLoaded(context)
        val combined = mutableListOf<String>()
        val sources = listOf(
            getUserPersonalGeminiKey(context),
            getCommunityGeminiKeyPool(context),
            getMagicLiveApiKeyPool(context),
            getGroqApiKeyPool(context)
        )
        for (src in sources) {
            if (src.isNotBlank()) {
                src.split(Regex("[\\s,;]+"))
                    .map { it.trim() }
                    .filter { isPlausibleGeminiKeyFormat(it) && !isAiKeyInvalidOrDead(context, it) }
                    .forEach { if (!combined.contains(it)) combined.add(it) }
            }
        }
        val buildKey = try {
            val field = com.example.BuildConfig::class.java.getField("GEMINI_API_KEY")
            field.get(null)?.toString()?.trim().orEmpty()
        } catch (_: Throwable) { "" }
        if (isPlausibleGeminiKeyFormat(buildKey) && buildKey != "MY_GEMINI_API_KEY" && !isAiKeyInvalidOrDead(context, buildKey) && !combined.contains(buildKey)) {
            combined.add(buildKey)
        }
        return combined
    }

    private fun getAllAdminAndPersonalGroqKeysRaw(context: Context): List<String> {
        ensureInvalidDeadKeysLoaded(context)
        val combined = mutableListOf<String>()
        val sources = listOf(
            getUserPersonalGroqKey(context),
            getCommunityGroqKeyPool(context),
            getGroqApiKeyPool(context),
            getMagicLiveApiKeyPool(context)
        )
        for (src in sources) {
            if (src.isNotBlank()) {
                src.split(Regex("[\\s,;]+"))
                    .map { it.trim() }
                    .filter { isPlausibleGroqKeyFormat(it) && !isAiKeyInvalidOrDead(context, it) }
                    .forEach { if (!combined.contains(it)) combined.add(it) }
            }
        }
        val buildKey = try { com.example.BuildConfig.GROQ_API_KEY.trim() } catch (_: Throwable) { "" }
        if (isPlausibleGroqKeyFormat(buildKey) && buildKey != "GROQ_API_KEY_DEFAULT_VALUE" && !isAiKeyInvalidOrDead(context, buildKey) && !combined.contains(buildKey)) {
            combined.add(buildKey)
        }
        return combined
    }

    /**
     * Lấy danh sách Key Gemini khả dụng (nằm trong hạn mức Miễn Phí & tự động xoay vòng Kho Key Cộng Đồng):
     * - Khi 1 người dùng thêm Key hợp lệ của họ, tất cả người dùng khác đều được chia sẻ dùng chung xoay vòng trong Kho Cộng Đồng.
     * - Mọi Key đều được bảo vệ nghiêm ngặt trong hạn mức Free-Tier (<= 12 RPM, <= 1.400 RPD) và loại bỏ ngay nếu bị thu hồi.
     */
    fun getAllMagicLiveApiKeys(context: Context, forMagicLiveFeature: Boolean = false): List<String> {
        ensureQuotaDayFresh(context)
        ensureInvalidDeadKeysLoaded(context)
        val allVerifiedKeys = getAllAdminAndPersonalGeminiKeysRaw(context)
        if (allVerifiedKeys.isEmpty()) return emptyList()

        val candidatePool = if (allVerifiedKeys.size > 1) {
            val start = (currentMagicLiveKeyIndex.coerceAtLeast(0)) % allVerifiedKeys.size
            allVerifiedKeys.drop(start) + allVerifiedKeys.take(start)
        } else {
            allVerifiedKeys
        }

        val withinFreeQuota = candidatePool.filter { isAiKeyWithinFreeTierLimit(context, it, isGemini = true) }
        return if (withinFreeQuota.isNotEmpty()) {
            withinFreeQuota
        } else {
            val maxRpd = MAX_FREE_GEMINI_RPD
            candidatePool
                .filter { (keyDailyCountMap[it] ?: 0) < maxRpd && !isAiKeyInvalidOrDead(context, it) }
                .sortedBy { magic_liveKeyCooldownMap[it] ?: 0L }
        }
    }

    private var currentMagicLiveKeyIndex = 0
    private val magic_liveKeyCooldownMap = java.util.concurrent.ConcurrentHashMap<String, Long>()

    fun getLoadBalancedMagicLiveApiKey(context: Context, forMagicLiveFeature: Boolean = false): String {
        val keys = getAllMagicLiveApiKeys(context, forMagicLiveFeature = forMagicLiveFeature)
        val firstKey = keys.firstOrNull() ?: return ""
        currentMagicLiveKeyIndex = (currentMagicLiveKeyIndex + 1).coerceAtLeast(0)
        return firstKey
    }

    fun markMagicLiveApiKeyCooldown(key: String, cooldownMs: Long = 75_000L) {
        val clean = key.trim()
        if (clean.isNotBlank()) {
            magic_liveKeyCooldownMap[clean] = System.currentTimeMillis() + cooldownMs
            currentMagicLiveKeyIndex = (currentMagicLiveKeyIndex + 1).coerceAtLeast(0)
        }
    }

    private val secureConfigRamCache = java.util.concurrent.ConcurrentHashMap<String, String>()

    private fun putSecureConfigString(context: Context, key: String, value: String) {
        secureConfigRamCache[key] = value
        val appCtx = context.applicationContext
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                try {
                    Settings.Secure.putString(appCtx.contentResolver, "magictune_cfg_$key", value)
                } catch (_: Throwable) {}
            }
        } else {
            try {
                Settings.Secure.putString(appCtx.contentResolver, "magictune_cfg_$key", value)
            } catch (_: Throwable) {}
        }
    }

    private fun getSecureConfigString(context: Context, key: String): String? {
        secureConfigRamCache[key]?.let { cached ->
            return cached.takeIf { it.isNotBlank() }
        }
        val appCtx = context.applicationContext
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            secureConfigRamCache[key] = ""
            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                try {
                    val loaded = Settings.Secure.getString(appCtx.contentResolver, "magictune_cfg_$key")?.trim().orEmpty()
                    secureConfigRamCache[key] = loaded
                } catch (_: Throwable) {
                    secureConfigRamCache[key] = ""
                }
            }
            return null
        }
        return try {
            val loaded = Settings.Secure.getString(appCtx.contentResolver, "magictune_cfg_$key")?.trim().orEmpty()
            secureConfigRamCache[key] = loaded
            loaded.takeIf { it.isNotBlank() }
        } catch (_: Throwable) {
            secureConfigRamCache[key] = ""
            null
        }
    }

    fun getGroqApiKeyPool(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val local = prefs.getString(KEY_GROQ_API_KEY_POOL, null)
        if (!local.isNullOrBlank()) return local
        val sec = getSecureConfigString(context, KEY_GROQ_API_KEY_POOL)
        if (!sec.isNullOrBlank()) {
            prefs.edit().putString(KEY_GROQ_API_KEY_POOL, sec).apply()
            return sec
        }
        return ""
    }

    fun setGroqApiKeyPool(context: Context, pool: String) {
        val cleanPool = pool.trim()
        val tokens = cleanPool.split(Regex("[\\s,;]+"))
            .map { it.trim() }
            .filter { it.isNotBlank() && it != "null" && it != "GROQ_API_KEY_DEFAULT_VALUE" }
            .distinct()
        val magic_liveTokens = tokens.filter { it.startsWith("AIza") && it.length >= 16 }
        val groqTokens = tokens.filter { !it.startsWith("AIza") && it.length >= 16 }

        val cleanGroqPool = groqTokens.joinToString(" ")
        val cleanGeminiPool = magic_liveTokens.joinToString(" ")

        // Làm mới trạng thái cooldown để các key Admin vừa gán hoạt động ngay lập tức
        magic_liveKeyCooldownMap.clear()
        keyCooldownMap.clear()

        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val editor = prefs.edit()
            .putString(KEY_GROQ_API_KEY_POOL, cleanGroqPool)
            .putString(KEY_GEMINI_API_KEY_POOL, cleanGeminiPool)
        editor.apply()

        putSecureConfigString(context, KEY_GROQ_API_KEY_POOL, cleanGroqPool)
        putSecureConfigString(context, KEY_GEMINI_API_KEY_POOL, cleanGeminiPool)

        val cloudMap = mapOf<String, Any>(
            KEY_GROQ_API_KEY_POOL to cleanGroqPool,
            KEY_GEMINI_API_KEY_POOL to cleanGeminiPool
        )
        syncCloudGlobalConfigMap(context, cloudMap)
        notifyProAndConfigStateChanged(context)
    }

    fun appendKeysToAdminSharedPool(context: Context, rawKeysToAppend: String): Pair<Int, Int> {
        val existingCombined = getCombinedAdminAiKeyPool(context)
        val merged = "$existingCombined $rawKeysToAppend"
            .split(Regex("[\\s,;]+"))
            .map { it.trim() }
            .filter { it.isNotBlank() && it != "null" && it != "GROQ_API_KEY_DEFAULT_VALUE" }
            .distinct()
            .joinToString(" ")
        setGroqApiKeyPool(context, merged)
        return countClassifiedAiKeys(merged)
    }

    private var currentApiKeyIndex = 0
    private val keyCooldownMap = java.util.concurrent.ConcurrentHashMap<String, Long>()

    fun getAllGroqApiKeys(context: Context, forMagicLiveFeature: Boolean = false): List<String> {
        ensureQuotaDayFresh(context)
        ensureInvalidDeadKeysLoaded(context)
        val allVerifiedKeys = getAllAdminAndPersonalGroqKeysRaw(context)
        if (allVerifiedKeys.isEmpty()) return emptyList()

        val candidatePool = if (allVerifiedKeys.size > 1) {
            val start = (currentApiKeyIndex.coerceAtLeast(0)) % allVerifiedKeys.size
            allVerifiedKeys.drop(start) + allVerifiedKeys.take(start)
        } else {
            allVerifiedKeys
        }

        val withinFreeQuota = candidatePool.filter { isAiKeyWithinFreeTierLimit(context, it, isGemini = false) }
        return if (withinFreeQuota.isNotEmpty()) {
            withinFreeQuota
        } else {
            val maxRpd = MAX_FREE_GROQ_RPD
            candidatePool
                .filter { (keyDailyCountMap[it] ?: 0) < maxRpd && !isAiKeyInvalidOrDead(context, it) }
                .sortedBy { keyCooldownMap[it] ?: 0L }
        }
    }

    fun getCombinedAdminAiKeyPool(context: Context): String {
        val groq = getGroqApiKeyPool(context)
        val magic_live = getMagicLiveApiKeyPool(context)
        val all = (groq.split(Regex("[\\s,;]+")) + magic_live.split(Regex("[\\s,;]+")))
            .map { it.trim() }
            .filter { it.isNotBlank() && it != "GROQ_API_KEY_DEFAULT_VALUE" && it != "null" }
            .distinct()
        return all.joinToString(" ")
    }

    fun getCombinedAiApiKeyPool(context: Context): String {
        val adminPool = getCombinedAdminAiKeyPool(context)
        val custom = getUserCustomMagicLiveKey(context)
        val all = (adminPool.split(Regex("[\\s,;]+")) + custom.split(Regex("[\\s,;]+")))
            .map { it.trim() }
            .filter { it.isNotBlank() && it != "GROQ_API_KEY_DEFAULT_VALUE" && it != "null" }
            .distinct()
        return all.joinToString(" ")
    }

    fun getActiveGroqApiKey(context: Context, forMagicLiveFeature: Boolean = false): String {
        val keys = getAllGroqApiKeys(context, forMagicLiveFeature = forMagicLiveFeature)
        if (keys.isNotEmpty()) {
            val idx = (currentApiKeyIndex.coerceAtLeast(0)) % keys.size
            return keys[idx]
        }
        return ""
    }

    fun getLoadBalancedGroqApiKey(context: Context, forMagicLiveFeature: Boolean = false): String {
        val keys = getAllGroqApiKeys(context, forMagicLiveFeature = forMagicLiveFeature)
        val chosen = keys.firstOrNull() ?: return ""
        currentApiKeyIndex = (currentApiKeyIndex + 1).coerceAtLeast(0)
        return chosen
    }

    fun markGroqApiKeyCooldown(key: String, cooldownMs: Long = 65_000L) {
        val clean = key.trim()
        if (clean.isNotBlank()) {
            keyCooldownMap[clean] = System.currentTimeMillis() + cooldownMs
            currentApiKeyIndex = (currentApiKeyIndex + 1).coerceAtLeast(0)
        }
    }

    fun rotateGroqApiKey(context: Context) {
        val keys = getAllGroqApiKeys(context)
        if (keys.size > 1) {
            currentApiKeyIndex = (currentApiKeyIndex + 1) % keys.size
        }
    }

    data class ProRecoveryRecord(
        val id: String = "",
        val deviceId: String = "",
        val deviceModel: String = "",
        val ownerEmail: String = "",
        val ownerName: String = "",
        val note: String = "",
        val createdAt: Any? = null,
        val status: String = "PENDING", // "PENDING" | "RESTORED"
        val previousProVerified: Boolean = true
    )

    @Volatile
    var lastCloudLookupDiag: String = ""

    fun sendProRecoveryRequest(context: Context, note: String, onComplete: (Boolean, String) -> Unit) {
        val appCtx = context.applicationContext
        try {
            val deviceId = getDeviceId(appCtx).uppercase()
            val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
            val db = FirebaseFirestore.getInstance()
            val recordId = "recovery_${deviceId}"
            val record = mapOf(
                "id" to recordId,
                "deviceId" to deviceId,
                "deviceModel" to "${Build.MANUFACTURER} ${Build.MODEL}",
                "ownerEmail" to (user?.email ?: "Khách vãng lai"),
                "ownerName" to (user?.displayName ?: "Người dùng"),
                "note" to note.ifBlank { "Khôi phục quyền Pro cho thiết bị $deviceId" },
                "createdAt" to FieldValue.serverTimestamp(),
                "status" to "PENDING",
                "previousProVerified" to true
            )
            if (user == null) {
                kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                    val ok = FirestoreRestTokenBridge.patchDocViaRest(appCtx, "pro_recovery_requests", recordId, record)
                    withContext(Dispatchers.Main) {
                        if (ok) {
                            onComplete(true, "Đã gửi yêu cầu khôi phục Pro thành công tới Admin! Admin sẽ kiểm tra và cấp lại ngay.")
                        } else {
                            onComplete(false, "Không thể kết nối máy chủ đám mây, vui lòng kiểm tra mạng Internet.")
                        }
                    }
                }
                return
            }
            db.collection("pro_recovery_requests").document(recordId).set(record, SetOptions.merge())
                .addOnSuccessListener {
                    onComplete(true, "Đã gửi yêu cầu khôi phục Pro thành công tới Admin! Admin sẽ kiểm tra và cấp lại ngay.")
                }
                .addOnFailureListener { e ->
                    kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                        val ok = FirestoreRestTokenBridge.patchDocViaRest(appCtx, "pro_recovery_requests", recordId, record)
                        withContext(Dispatchers.Main) {
                            if (ok) {
                                onComplete(true, "Đã gửi yêu cầu khôi phục Pro thành công tới Admin! Admin sẽ kiểm tra và cấp lại ngay.")
                            } else {
                                onComplete(false, "Không thể gửi yêu cầu: ${e.localizedMessage}")
                            }
                        }
                    }
                }
        } catch (e: Exception) {
            onComplete(false, "Lỗi: ${e.localizedMessage}")
        }
    }

    private val tlIsoUtcSeconds = ThreadLocal.withInitial {
        java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }
    }

    fun extractTimestampMillis(raw: Any?): Long {
        return when (raw) {
            is com.google.firebase.Timestamp -> raw.toDate().time
            is Number -> {
                val v = raw.toLong()
                if (v in 1..9_999_999_999L) v * 1000L else v
            }
            is java.util.Date -> raw.time
            is String -> {
                val clean = raw.trim()
                clean.toLongOrNull()?.let { v ->
                    return if (v in 1..9_999_999_999L) v * 1000L else v
                }
                if (clean.contains("T")) {
                    val normalized = if (clean.contains(".")) {
                        clean.substringBefore(".") + if (clean.endsWith("Z")) "Z" else ""
                    } else clean
                    try {
                        tlIsoUtcSeconds.get()?.parse(normalized)?.time ?: 0L
                    } catch (_: Throwable) {
                        0L
                    }
                } else if (clean.length == 10 && clean[4] == '-' && clean[7] == '-') {
                    try {
                        tlYmdFormat.get()?.parse(clean)?.time ?: 0L
                    } catch (_: Throwable) {
                        0L
                    }
                } else {
                    0L
                }
            }
            else -> 0L
        }
    }

    suspend fun refreshProStatus(context: Context): Boolean = withContext(Dispatchers.IO) {
        kotlinx.coroutines.withTimeoutOrNull(15_000L) {
            if (isAdminSimulateFreeMode(context)) {
                _isProFlow.value = false
                return@withTimeoutOrNull false
            }
            val stopped = checkKillSwitchRemote()
            if (stopped) return@withTimeoutOrNull false

            val isKnownDevicePro = checkDeviceRecognizedProInCloud(context)
            if (isKnownDevicePro) return@withTimeoutOrNull isProActivated(context)
            
            val isPaidOnline = checkOnlinePaymentStatusRemote(context)
            isPaidOnline && isProActivated(context)
        } ?: isProActivated(context)
    }

    fun adminRestoreProForDevice(
        deviceId: String,
        context: Context? = null,
        requestDocId: String = "",
        ownerEmail: String = "",
        isAccountProHint: Boolean? = null,
        onComplete: (Boolean) -> Unit
    ) {
        val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
        fun finishOnMain(result: Boolean) {
            if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
                onComplete(result)
            } else {
                mainHandler.post { onComplete(result) }
            }
        }

        val cleanId = deviceId.trim().uppercase()
        val normId = normalizeDeviceIdForMatch(cleanId)
        val cleanReqId = requestDocId.trim()
        val cleanEmail = ownerEmail.trim().lowercase().substringBefore(" (").trim()
        if (cleanId.isBlank() && normId.isBlank() && cleanReqId.isBlank()) {
            finishOnMain(false)
            return
        }

        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            try {
                val appCtx = context?.applicationContext
                val db = FirebaseFirestore.getInstance()
                val targetDevIds = listOf(
                    cleanId,
                    normId,
                    if (normId.isNotBlank()) "MT-$normId" else ""
                ).map { it.trim() }.filter { it.isNotBlank() }.distinct()

                // 1. Xác định hạng Pro (ưu tiên isAccountProHint truyền từ UI để phản hồi tức thì)
                var isAccPro = isAccountProHint == true
                if (isAccountProHint == null && appCtx != null) {
                    val cachedDevs = adminRestCollectionCache["devices"]?.second.orEmpty()
                    for (m in cachedDevs) {
                        val dId = normalizeDeviceIdForMatch((m["deviceId"] as? String) ?: (m["__id"] as? String).orEmpty())
                        if (normId.isNotBlank() && dId == normId) {
                            if ((m["isAccountPro"] as? Boolean) == true ||
                                (m["upgradedToAccountPro"] as? Boolean) == true ||
                                (m["proTier"] as? String)?.equals("ACCOUNT_PRO", ignoreCase = true) == true
                            ) {
                                isAccPro = true
                                break
                            }
                        }
                    }
                }

                val tier = if (isAccPro) "ACCOUNT_PRO" else "DEVICE_PRO"
                val keyBaseId = cleanId.ifBlank { if (normId.isNotBlank()) "MT-$normId" else cleanReqId }
                val licenseKey = if (isAccPro) {
                    generateAccountProLicenseKeyForDevice(keyBaseId)
                } else {
                    generateLicenseKeyForDevice(keyBaseId)
                }

                val updates = mutableMapOf<String, Any>(
                    "deviceId" to keyBaseId,
                    "appId" to "magictune",
                    "product" to "MAGICTUNE_PRO",
                    "magictunePro" to true,
                    "isPro" to true,
                    "isAccountPro" to isAccPro,
                    "upgradedToAccountPro" to isAccPro,
                    "proTier" to tier,
                    "revokedByAdmin" to false,
                    "licenseKey" to licenseKey,
                    "approvedByAiReason" to "ADMIN_RESTORE_PRO_$tier",
                    "proActivatedSource" to "ADMIN_RESTORE_PRO_$tier",
                    "proActivatedAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (cleanEmail.contains("@")) {
                    updates["ownerEmail"] = cleanEmail
                }

                // 2. Tập hợp đầy đủ các Document ID có thể tồn tại của yêu cầu khôi phục này
                val recoveryIdsToUpdate = linkedSetOf<String>()
                if (cleanReqId.isNotBlank()) recoveryIdsToUpdate.add(cleanReqId)
                if (cleanId.isNotBlank()) {
                    recoveryIdsToUpdate.add(cleanId)
                    recoveryIdsToUpdate.add("recovery_$cleanId")
                }
                if (normId.isNotBlank()) {
                    recoveryIdsToUpdate.add("MT-$normId")
                    recoveryIdsToUpdate.add("recovery_MT-$normId")
                    recoveryIdsToUpdate.add(normId)
                    recoveryIdsToUpdate.add("recovery_$normId")
                }
                adminRestCollectionCache["pro_recovery_requests"]?.second?.forEach { recMap ->
                    val docId = (recMap["__id"] as? String).orEmpty()
                    val recDev = (recMap["deviceId"] as? String).orEmpty()
                    val recIdField = (recMap["id"] as? String).orEmpty()
                    val matchesReqId = cleanReqId.isNotBlank() && (docId == cleanReqId || recIdField == cleanReqId)
                    val matchesDev = normId.isNotBlank() && normalizeDeviceIdForMatch(recDev.ifBlank { docId }) == normId
                    if ((matchesReqId || matchesDev) && docId.isNotBlank()) {
                        recoveryIdsToUpdate.add(docId)
                    }
                }

                // Cập nhật ngay bộ nhớ đệm REST trong RAM để không bao giờ bị ghi đè lại trạng thái PENDING cũ
                adminRestCollectionCache["pro_recovery_requests"]?.let { (ts, list) ->
                    val updatedList = list.map { recMap ->
                        val docId = (recMap["__id"] as? String).orEmpty()
                        val recDev = (recMap["deviceId"] as? String).orEmpty()
                        val recIdField = (recMap["id"] as? String).orEmpty()
                        val matchesReqId = cleanReqId.isNotBlank() && (docId == cleanReqId || recIdField == cleanReqId)
                        val matchesDev = normId.isNotBlank() && normalizeDeviceIdForMatch(recDev.ifBlank { docId }) == normId
                        if (matchesReqId || matchesDev || recoveryIdsToUpdate.contains(docId)) {
                            recMap + mapOf("status" to "RESTORED")
                        } else recMap
                    }
                    adminRestCollectionCache["pro_recovery_requests"] = ts to updatedList
                }

                val restoredPayload = mapOf<String, Any>(
                    "status" to "RESTORED",
                    "restoredKey" to licenseKey,
                    "restoredAt" to FieldValue.serverTimestamp(),
                    "resolvedAt" to FieldValue.serverTimestamp()
                )

                // 3. Nếu chính thiết bị hiện tại được khôi phục, mở khóa Pro ngay tại chỗ
                if (appCtx != null) {
                    val currDev = getDeviceId(appCtx).trim().uppercase()
                    val currNorm = normalizeDeviceIdForMatch(currDev)
                    if (normId.isNotBlank() && (cleanId == currDev || normId == currNorm)) {
                        val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                        prefs.edit()
                            .putBoolean(KEY_REVOKED_BY_ADMIN, false)
                            .putBoolean(KEY_PRO_ACTIVATED, true)
                            .putBoolean(KEY_ACCOUNT_PRO_ACTIVATED, isAccPro)
                            .putBoolean(KEY_UPGRADED_TO_ACCOUNT_PRO, isAccPro)
                            .putString(KEY_ACTIVATED_LICENSE, licenseKey)
                            .apply()
                        writeProIntegritySeal(appCtx, isPro = true, isAccPro = isAccPro)
                        persistHardwareProSignatureIfNeeded(appCtx, true)
                        notifyProAndConfigStateChanged(appCtx)
                    }
                }

                // 4. Thực thi song song (parallel) các lệnh REST tới `devices` và `pro_recovery_requests` để hoàn tất trong ~300ms
                var anyWriteSuccess = false
                if (appCtx != null) {
                    kotlinx.coroutines.coroutineScope {
                        val devJobs = targetDevIds.map { dId ->
                            val payload = updates + ("deviceId" to dId)
                            async(Dispatchers.IO) {
                                FirestoreRestTokenBridge.patchDocViaRest(appCtx, "devices", dId, payload)
                            }
                        }
                        val recJobs = recoveryIdsToUpdate.map { rId ->
                            async(Dispatchers.IO) {
                                FirestoreRestTokenBridge.patchDocViaRest(appCtx, "pro_recovery_requests", rId, restoredPayload)
                            }
                        }
                        val results = devJobs.map { it.await() } + recJobs.map { it.await() }
                        if (results.any { it }) {
                            anyWriteSuccess = true
                        }
                    }
                }

                // 5. Ghi đồng bộ qua Firestore SDK ở chế độ bất đồng bộ (không chờ timeout gây đơ nút)
                for (dId in targetDevIds) {
                    val payload = updates + ("deviceId" to dId)
                    kotlin.runCatching {
                        db.collection("devices").document(dId).set(payload, SetOptions.merge())
                        anyWriteSuccess = true
                    }
                }
                for (rId in recoveryIdsToUpdate) {
                    kotlin.runCatching {
                        db.collection("pro_recovery_requests").document(rId).set(restoredPayload, SetOptions.merge())
                        anyWriteSuccess = true
                    }
                }

                // 6. Phản hồi ngay cho giao diện Admin
                finishOnMain(anyWriteSuccess)

                // 7. Quét hậu kiểm ngầm (background) trên `users` và `pro_recovery_requests` để đồng bộ sạch sẽ 100%
                if (appCtx != null) {
                    if (cleanEmail.contains("@")) {
                        val userPatch = mapOf(
                            "isPro" to true,
                            "magictunePro" to true,
                            "isAccountPro" to isAccPro,
                            "proTier" to tier,
                            "magictuneTier" to tier,
                            "licenseKey" to licenseKey,
                            "revokedByAdmin" to false,
                            "proActivatedSource" to "ADMIN_RESTORE_PRO_$tier",
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                        val matchedUsers = FirestoreRestTokenBridge.queryCollectionByFieldInViaRest(
                            appCtx,
                            "users",
                            "email",
                            listOf(cleanEmail, cleanEmail.lowercase()),
                            limit = 10
                        )
                        for (uMap in matchedUsers) {
                            val uId = (uMap["__id"] as? String).orEmpty()
                            if (uId.isNotBlank()) {
                                FirestoreRestTokenBridge.patchDocViaRest(appCtx, "users", uId, userPatch)
                                kotlin.runCatching {
                                    db.collection("users").document(uId).set(userPatch, SetOptions.merge())
                                }
                            }
                        }
                    }
                    val allRecMaps = fetchAdminCollectionMapsViaRest(appCtx, "pro_recovery_requests", 200, forceRefresh = true)
                    for (recMap in allRecMaps) {
                        val docId = (recMap["__id"] as? String).orEmpty()
                        val recDev = (recMap["deviceId"] as? String).orEmpty()
                        val recStatus = (recMap["status"] as? String).orEmpty()
                        if (docId.isNotBlank() && recStatus == "PENDING" &&
                            normId.isNotBlank() && normalizeDeviceIdForMatch(recDev.ifBlank { docId }) == normId
                        ) {
                            FirestoreRestTokenBridge.patchDocViaRest(appCtx, "pro_recovery_requests", docId, restoredPayload)
                            kotlin.runCatching {
                                db.collection("pro_recovery_requests").document(docId).set(restoredPayload, SetOptions.merge())
                            }
                        }
                    }
                }
            } catch (_: Throwable) {
                finishOnMain(false)
            }
        }
    }

    fun adminDeleteRecoveryRequest(
        context: Context,
        requestDocId: String,
        deviceId: String = "",
        onComplete: (Boolean) -> Unit
    ) {
        val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
        val cleanReqId = requestDocId.trim()
        val cleanId = deviceId.trim().uppercase()
        val normId = normalizeDeviceIdForMatch(cleanId)
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            var deletedAny = false
            try {
                val appCtx = context.applicationContext
                val db = FirebaseFirestore.getInstance()
                val idsToDelete = linkedSetOf<String>()
                if (cleanReqId.isNotBlank()) idsToDelete.add(cleanReqId)
                if (cleanId.isNotBlank()) {
                    idsToDelete.add(cleanId)
                    idsToDelete.add("recovery_$cleanId")
                }
                if (normId.isNotBlank()) {
                    idsToDelete.add("MT-$normId")
                    idsToDelete.add("recovery_MT-$normId")
                    idsToDelete.add(normId)
                    idsToDelete.add("recovery_$normId")
                }

                adminRestCollectionCache["pro_recovery_requests"]?.second?.forEach { recMap ->
                    val docId = (recMap["__id"] as? String).orEmpty()
                    val recDev = (recMap["deviceId"] as? String).orEmpty()
                    val recIdField = (recMap["id"] as? String).orEmpty()
                    val matchesReq = cleanReqId.isNotBlank() && (docId == cleanReqId || recIdField == cleanReqId)
                    val matchesDev = normId.isNotBlank() && normalizeDeviceIdForMatch(recDev.ifBlank { docId }) == normId
                    if ((matchesReq || matchesDev) && docId.isNotBlank()) {
                        idsToDelete.add(docId)
                    }
                }

                adminRestCollectionCache["pro_recovery_requests"]?.let { (ts, list) ->
                    val filtered = list.filterNot { recMap ->
                        val docId = (recMap["__id"] as? String).orEmpty()
                        val recDev = (recMap["deviceId"] as? String).orEmpty()
                        val recIdField = (recMap["id"] as? String).orEmpty()
                        val matchesReq = cleanReqId.isNotBlank() && (docId == cleanReqId || recIdField == cleanReqId)
                        val matchesDev = normId.isNotBlank() && normalizeDeviceIdForMatch(recDev.ifBlank { docId }) == normId
                        matchesReq || matchesDev || idsToDelete.contains(docId)
                    }
                    adminRestCollectionCache["pro_recovery_requests"] = ts to filtered
                }

                kotlinx.coroutines.coroutineScope {
                    val jobs = idsToDelete.map { id ->
                        async(Dispatchers.IO) {
                            FirestoreRestTokenBridge.deleteDocViaRest(appCtx, "pro_recovery_requests", id)
                        }
                    }
                    if (jobs.map { it.await() }.any { it }) {
                        deletedAny = true
                    }
                }

                for (id in idsToDelete) {
                    kotlin.runCatching {
                        db.collection("pro_recovery_requests").document(id).delete()
                        deletedAny = true
                    }
                }
            } catch (_: Throwable) {
            } finally {
                mainHandler.post { onComplete(deletedAny) }
            }
        }
    }

    private val adminRestCollectionCache = java.util.concurrent.ConcurrentHashMap<String, Pair<Long, List<Map<String, Any>>>>()
    private const val ADMIN_REST_CACHE_TTL_MS = 60_000L
    private const val KEY_DELETED_AI_CHAT_LOG_IDS = "deleted_ai_chat_log_ids_v1"
    private const val KEY_DELETED_ADB_ERROR_LOG_IDS = "deleted_adb_error_log_ids_v1"
    private val deletedAiChatLogIdsMemory = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private val deletedAdbErrorLogIdsMemory = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    @Volatile
    private var deletedTombstonesLoaded = false

    private fun ensureDeletedTombstonesLoaded(context: Context?) {
        if (deletedTombstonesLoaded || context == null) return
        synchronized(this) {
            if (deletedTombstonesLoaded) return
            try {
                val prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                prefs.getStringSet(KEY_DELETED_AI_CHAT_LOG_IDS, emptySet())?.forEach {
                    if (it.isNotBlank()) deletedAiChatLogIdsMemory.add(it.trim())
                }
                prefs.getStringSet(KEY_DELETED_ADB_ERROR_LOG_IDS, emptySet())?.forEach {
                    if (it.isNotBlank()) deletedAdbErrorLogIdsMemory.add(it.trim())
                }
                deletedTombstonesLoaded = true
            } catch (_: Throwable) {}
        }
    }

    private fun markAiChatLogIdsDeleted(context: Context?, ids: Collection<String>) {
        ensureDeletedTombstonesLoaded(context)
        val clean = ids.map { it.trim() }.filter { it.isNotBlank() }
        if (clean.isEmpty()) return
        deletedAiChatLogIdsMemory.addAll(clean)
        // Evict immediately from in-memory REST collection cache
        adminRestCollectionCache["ai_pro_chat_logs"]?.let { (ts, list) ->
            val filtered = list.filterNot { m ->
                val dId = (m["__id"] as? String).orEmpty().trim()
                val fId = (m["id"] as? String).orEmpty().trim()
                (dId.isNotBlank() && deletedAiChatLogIdsMemory.contains(dId)) ||
                    (fId.isNotBlank() && deletedAiChatLogIdsMemory.contains(fId))
            }
            adminRestCollectionCache["ai_pro_chat_logs"] = ts to filtered
        }
        if (context != null) {
            try {
                val prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                val persisted = LinkedHashSet<String>(prefs.getStringSet(KEY_DELETED_AI_CHAT_LOG_IDS, emptySet()) ?: emptySet())
                persisted.addAll(clean)
                val trimmed = if (persisted.size > 600) persisted.toList().takeLast(600).toSet() else persisted
                prefs.edit().putStringSet(KEY_DELETED_AI_CHAT_LOG_IDS, trimmed).apply()
            } catch (_: Throwable) {}
        }
    }

    private fun isAiChatLogDeleted(context: Context?, vararg candidateIds: String): Boolean {
        ensureDeletedTombstonesLoaded(context)
        return candidateIds.any { id ->
            val c = id.trim()
            c.isNotBlank() && deletedAiChatLogIdsMemory.contains(c)
        }
    }

    private fun markAdbErrorLogIdsDeleted(context: Context?, ids: Collection<String>) {
        ensureDeletedTombstonesLoaded(context)
        val clean = ids.map { it.trim() }.filter { it.isNotBlank() }
        if (clean.isEmpty()) return
        deletedAdbErrorLogIdsMemory.addAll(clean)
        adminRestCollectionCache["admin_logs"]?.let { (ts, list) ->
            val filtered = list.filterNot { m ->
                val dId = (m["__id"] as? String).orEmpty().trim()
                val fId = (m["id"] as? String).orEmpty().trim()
                (dId.isNotBlank() && deletedAdbErrorLogIdsMemory.contains(dId)) ||
                    (fId.isNotBlank() && deletedAdbErrorLogIdsMemory.contains(fId))
            }
            adminRestCollectionCache["admin_logs"] = ts to filtered
        }
        if (context != null) {
            try {
                val prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                val persisted = LinkedHashSet<String>(prefs.getStringSet(KEY_DELETED_ADB_ERROR_LOG_IDS, emptySet()) ?: emptySet())
                persisted.addAll(clean)
                val trimmed = if (persisted.size > 600) persisted.toList().takeLast(600).toSet() else persisted
                prefs.edit().putStringSet(KEY_DELETED_ADB_ERROR_LOG_IDS, trimmed).apply()
            } catch (_: Throwable) {}
        }
    }

    private fun isAdbErrorLogDeleted(context: Context?, vararg candidateIds: String): Boolean {
        ensureDeletedTombstonesLoaded(context)
        return candidateIds.any { id ->
            val c = id.trim()
            c.isNotBlank() && deletedAdbErrorLogIdsMemory.contains(c)
        }
    }

    private const val LEGACY_PREF_ADMIN_DISK_CACHE = "magictune_admin_rest_disk_cache"
    private const val ADMIN_OFFLINE_CACHE_DIR = "admin_offline_cache"
    private val adminDiskCollectionLocks = java.util.concurrent.ConcurrentHashMap<String, Any>()
    @Volatile
    private var legacyDiskCacheCleaned = false

    private fun getAdminOfflineCacheDir(context: Context): java.io.File {
        val dir = java.io.File(context.applicationContext.filesDir, ADMIN_OFFLINE_CACHE_DIR)
        if (!dir.exists()) {
            try { dir.mkdirs() } catch (_: Throwable) {}
        }
        if (!legacyDiskCacheCleaned) {
            legacyDiskCacheCleaned = true
            try {
                context.applicationContext.deleteSharedPreferences(LEGACY_PREF_ADMIN_DISK_CACHE)
            } catch (_: Throwable) {}
        }
        return dir
    }

    private fun safeCollectionFileName(collection: String): String {
        return collection.replace(Regex("[^a-zA-Z0-9_-]"), "_") + ".json"
    }

    fun saveAdminLastGlobalSyncMs(context: Context, tsMs: Long) {
        try {
            val file = java.io.File(getAdminOfflineCacheDir(context), "last_sync_ms.txt")
            file.writeText(tsMs.toString(), Charsets.UTF_8)
        } catch (_: Throwable) {}
    }

    fun getAdminLastGlobalSyncMs(context: Context): Long {
        return try {
            val file = java.io.File(getAdminOfflineCacheDir(context), "last_sync_ms.txt")
            if (!file.exists()) return 0L
            file.readText(Charsets.UTF_8).trim().toLongOrNull() ?: 0L
        } catch (_: Throwable) {
            0L
        }
    }

    private fun writeAdminCollectionMapsToFileSync(context: Context, collection: String, list: List<Map<String, Any>>) {
        val lock = adminDiskCollectionLocks.getOrPut(collection) { Any() }
        synchronized(lock) {
            try {
                val arr = org.json.JSONArray()
                for (m in list.take(220)) {
                    val obj = org.json.JSONObject()
                    for ((k, v) in m) {
                        when (v) {
                            is String -> {
                                val trimmed = if (v.length > 1200) v.take(1200) + "..." else v
                                obj.put(k, trimmed)
                            }
                            is Boolean, is Int, is Long, is Double -> obj.put(k, v)
                            else -> {
                                val s = v.toString()
                                obj.put(k, if (s.length > 1200) s.take(1200) + "..." else s)
                            }
                        }
                    }
                    arr.put(obj)
                }
                val dir = getAdminOfflineCacheDir(context)
                val target = java.io.File(dir, safeCollectionFileName(collection))
                val tmp = java.io.File(dir, safeCollectionFileName(collection) + ".tmp")
                tmp.writeText(arr.toString(), Charsets.UTF_8)
                if (!tmp.renameTo(target)) {
                    target.writeText(arr.toString(), Charsets.UTF_8)
                    try { tmp.delete() } catch (_: Throwable) {}
                }
            } catch (_: Throwable) {}
        }
    }

    private fun saveAdminCollectionMapsToDisk(context: Context, collection: String, list: List<Map<String, Any>>) {
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            val appCtx = context.applicationContext
            val snapshot = list.toList()
            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                writeAdminCollectionMapsToFileSync(appCtx, collection, snapshot)
            }
            return
        }
        writeAdminCollectionMapsToFileSync(context, collection, list)
    }

    fun getCachedAdminCollectionMapsInstant(context: Context, collection: String): List<Map<String, Any>> {
        adminRestCollectionCache[collection]?.second?.takeIf { it.isNotEmpty() }?.let { return it }
        // Không đọc & parse file JSON lớn trực tiếp trên Main UI Thread để giữ 120fps tuyệt đối
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            return emptyList()
        }
        val lock = adminDiskCollectionLocks.getOrPut(collection) { Any() }
        return synchronized(lock) {
            adminRestCollectionCache[collection]?.second?.takeIf { it.isNotEmpty() }?.let { return@synchronized it }
            try {
                val file = java.io.File(getAdminOfflineCacheDir(context), safeCollectionFileName(collection))
                if (!file.exists() || file.length() <= 2L) return@synchronized emptyList()
                val raw = file.readText(Charsets.UTF_8)
                val ts = file.lastModified().takeIf { it > 0L } ?: System.currentTimeMillis()
                val arr = org.json.JSONArray(raw)
                val parsed = ArrayList<Map<String, Any>>(arr.length())
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val map = HashMap<String, Any>(o.length() + 2)
                    val keys = o.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        val v = o.opt(k)
                        if (v != null && v !== org.json.JSONObject.NULL) {
                            map[k] = v
                        }
                    }
                    if (map.isNotEmpty()) parsed.add(map)
                }
                if (parsed.isNotEmpty()) {
                    val capped = if (collection == "ai_pro_chat_logs" || collection == "admin_logs") {
                        parsed.take(60).map { map ->
                            map.mapValues { (_, v) ->
                                if (v is String && v.length > 4000) v.take(4000) + "... [trimmed]" else v
                            }
                        }
                    } else {
                        parsed.take(250)
                    }
                    adminRestCollectionCache[collection] = ts to capped
                }
                parsed
            } catch (_: Throwable) {
                emptyList()
            }
        }
    }

    fun fetchAdminCollectionMapsViaRest(
        context: Context,
        collection: String,
        pageSize: Int = 150,
        forceRefresh: Boolean = false,
        maxPages: Int = 1
    ): List<Map<String, Any>> {
        val now = System.currentTimeMillis()
        if (!forceRefresh) {
            adminRestCollectionCache[collection]?.let { (ts, cached) ->
                if (now - ts < ADMIN_REST_CACHE_TTL_MS && cached.isNotEmpty()) {
                    return cached
                }
            }
        }
        // Bảo vệ tuyệt đối: không bao giờ thực thi HTTP đồng bộ trên Main UI Thread
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            return getCachedAdminCollectionMapsInstant(context, collection)
        }
        return try {
            val effectiveMaxPages = maxPages.coerceIn(1, 4)
            val fresh = FirestoreRestTokenBridge.fetchCollectionMapsViaRest(
                context.applicationContext,
                collection,
                pageSize.coerceIn(1, 200),
                maxPages = effectiveMaxPages
            )
            if (fresh.isNotEmpty()) {
                val capped = if (collection == "ai_pro_chat_logs" || collection == "admin_logs") {
                    fresh.take(60).map { map ->
                        map.mapValues { (_, v) ->
                            if (v is String && v.length > 4000) v.take(4000) + "... [trimmed]" else v
                        }
                    }
                } else {
                    fresh.take(250)
                }
                adminRestCollectionCache[collection] = now to capped
                saveAdminCollectionMapsToDisk(context, collection, capped)
                capped
            } else {
                getCachedAdminCollectionMapsInstant(context, collection)
            }
        } catch (_: Throwable) {
            getCachedAdminCollectionMapsInstant(context, collection)
        }
    }

    fun parseProRecoveryRecordsFromMaps(rawList: List<Map<String, Any>>): List<ProRecoveryRecord> {
        return try {
            rawList.mapNotNull { m ->
                try {
                    val docId = (m["__id"] as? String).orEmpty()
                    val createdRaw = m["createdAt"] ?: m["resolvedAt"] ?: m["restoredAt"]
                    ProRecoveryRecord(
                        id = (m["id"] as? String)?.takeIf { it.isNotBlank() } ?: docId,
                        deviceId = (m["deviceId"] as? String)?.takeIf { it.isNotBlank() }
                            ?: docId.removePrefix("recovery_").substringBefore("_"),
                        deviceModel = (m["deviceModel"] as? String)?.takeIf { it.isNotBlank() } ?: "Thiết bị Android",
                        ownerEmail = (m["ownerEmail"] as? String)?.takeIf { it.isNotBlank() } ?: "Khách vãng lai",
                        ownerName = (m["ownerName"] as? String)?.takeIf { it.isNotBlank() } ?: "Người dùng",
                        note = (m["note"] as? String)?.takeIf { it.isNotBlank() } ?: "Khôi phục quyền Pro theo ID máy",
                        createdAt = createdRaw,
                        status = (m["status"] as? String)?.takeIf { it.isNotBlank() } ?: "PENDING",
                        previousProVerified = (m["previousProVerified"] as? Boolean) ?: true
                    )
                } catch (_: Throwable) {
                    null
                }
            }.sortedByDescending { extractTimestampMillis(it.createdAt) }
                .groupBy { normalizeDeviceIdForMatch(it.deviceId).ifBlank { it.id } }
                .mapNotNull { (_, items) -> items.firstOrNull() }
                .toList()
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun getOfflineProRecoveryRequestsCached(context: Context): List<ProRecoveryRecord> {
        return parseProRecoveryRecordsFromMaps(getCachedAdminCollectionMapsInstant(context, "pro_recovery_requests"))
    }

    fun fetchProRecoveryRequestsViaRest(
        context: Context,
        forceRefresh: Boolean = false
    ): List<ProRecoveryRecord> {
        val rawList = fetchAdminCollectionMapsViaRest(context, "pro_recovery_requests", 120, forceRefresh = forceRefresh)
        return parseProRecoveryRecordsFromMaps(rawList)
    }

    fun observeProRecoveryRequests(
        context: Context? = null,
        onUpdate: (List<ProRecoveryRecord>) -> Unit
    ): com.google.firebase.firestore.ListenerRegistration? {
        return try {
            val db = FirebaseFirestore.getInstance()
            val listenerScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + Dispatchers.Default)
            var currentJob: kotlinx.coroutines.Job? = null
            var lastEmitted: List<ProRecoveryRecord>? = null
            // Chỉ lắng nghe tối đa 100 bản ghi và chỉ gọi REST khi SDK báo lỗi để tiết kiệm tối đa lượt đọc Firestore cho Admin
            val rawReg = db.collection("pro_recovery_requests")
                .limit(50)
                .addSnapshotListener(com.example.core.auth.FirebaseAuthManager.adminSnapshotExecutor) { snap, error ->
                    if (error != null && context != null) {
                        val appCtx = context.applicationContext
                        currentJob?.cancel()
                        currentJob = listenerScope.launch(Dispatchers.IO) {
                            val restList = fetchProRecoveryRequestsViaRest(appCtx)
                            if (restList != lastEmitted) {
                                lastEmitted = restList
                                withContext(Dispatchers.Main) {
                                    onUpdate(restList)
                                }
                            }
                        }
                        return@addSnapshotListener
                    }
                    if (snap != null) {
                        val docs = snap.documents
                        currentJob?.cancel()
                        currentJob = listenerScope.launch {
                            val list = docs.mapNotNull { doc ->
                                try {
                                    val createdRaw = doc.get("createdAt") ?: doc.get("resolvedAt") ?: doc.get("restoredAt")
                                    ProRecoveryRecord(
                                        id = doc.getString("id") ?: doc.id,
                                        deviceId = doc.getString("deviceId") ?: doc.id.removePrefix("recovery_").substringBefore("_"),
                                        deviceModel = doc.getString("deviceModel") ?: "Thiết bị Android",
                                        ownerEmail = doc.getString("ownerEmail") ?: "Khách vãng lai",
                                        ownerName = doc.getString("ownerName") ?: "Người dùng",
                                        note = doc.getString("note") ?: "Khôi phục quyền Pro theo ID máy",
                                        createdAt = createdRaw,
                                        status = doc.getString("status") ?: "PENDING",
                                        previousProVerified = doc.getBoolean("previousProVerified") ?: true
                                    )
                                } catch (_: Exception) {
                                    null
                                }
                            }.sortedByDescending { extractTimestampMillis(it.createdAt) }
                                .groupBy { normalizeDeviceIdForMatch(it.deviceId).ifBlank { it.id } }
                                .mapNotNull { (_, items) -> items.firstOrNull() }
                                .toList()
                            if (list != lastEmitted) {
                                lastEmitted = list
                                withContext(Dispatchers.Main) {
                                    onUpdate(list)
                                }
                            }
                        }
                    }
                }
            com.google.firebase.firestore.ListenerRegistration {
                currentJob?.cancel()
                listenerScope.cancel()
                rawReg.remove()
            }
        } catch (_: Exception) {
            null
        }
    }

    private const val KEY_BROADCAST_ID = "global_broadcast_id"
    private const val KEY_BROADCAST_TITLE = "global_broadcast_title"
    private const val KEY_BROADCAST_MESSAGE = "global_broadcast_message"
    private const val KEY_BROADCAST_TYPE = "global_broadcast_type" // "UPDATE" or "ANNOUNCEMENT"
    private const val KEY_BROADCAST_ACTIVE = "global_broadcast_active"
    private const val KEY_BROADCAST_URL = "global_broadcast_url"
    private const val KEY_BROADCAST_SENT_AT = "global_broadcast_sent_at"
    private const val KEY_DISMISSED_BROADCAST_ID = "dismissed_broadcast_id"
    private const val KEY_NOTIFIED_BROADCAST_ID = "notified_system_broadcast_id"

    private const val KEY_LATEST_APK_URL = "latest_apk_url"
    private const val KEY_LATEST_APK_VERSION_CODE = "latest_apk_version_code"
    private const val KEY_LATEST_APK_VERSION_NAME = "latest_apk_version_name"
    private const val KEY_LATEST_APK_SIZE_BYTES = "latest_apk_size_bytes"
    private const val KEY_LATEST_APK_NOTES = "latest_apk_notes"
    private const val KEY_LATEST_APK_HOST = "latest_apk_host"
    private const val KEY_LATEST_APK_UPLOADED_AT = "latest_apk_uploaded_at"
    private const val KEY_LATEST_APK_AUTO_UPDATE = "latest_apk_auto_update"
    private const val KEY_DISMISSED_RELEASE_ID = "dismissed_apk_release_id"

    @androidx.compose.runtime.Immutable
    data class LatestApkRelease(
        val versionCode: Long = 0L,
        val versionName: String = "",
        val downloadUrl: String = "",
        val sizeBytes: Long = 0L,
        val releaseNotes: String = "",
        val hostLabel: String = "",
        val uploadedAtMs: Long = 0L,
        val autoUpdateEnabled: Boolean = true
    ) {
        val releaseId: String
            get() = "${versionCode}_${uploadedAtMs}"
    }

    private val _latestApkReleaseFlow = kotlinx.coroutines.flow.MutableStateFlow<LatestApkRelease?>(null)
    val latestApkReleaseFlow: kotlinx.coroutines.flow.StateFlow<LatestApkRelease?> = _latestApkReleaseFlow

    @androidx.compose.runtime.Immutable
    data class GlobalBroadcastMessage(
        val id: String = "",
        val title: String = "",
        val message: String = "",
        val type: String = "UPDATE", // "UPDATE" | "ANNOUNCEMENT"
        val isActive: Boolean = false,
        val actionUrl: String = "",
        val sentAtMs: Long = 0L
    )

    private val _globalBroadcastFlow = kotlinx.coroutines.flow.MutableStateFlow<GlobalBroadcastMessage?>(null)
    val globalBroadcastFlow: kotlinx.coroutines.flow.StateFlow<GlobalBroadcastMessage?> = _globalBroadcastFlow

    private val _proStateVersionFlow = kotlinx.coroutines.flow.MutableStateFlow(0L)
    val proStateVersionFlow: kotlinx.coroutines.flow.StateFlow<Long> = _proStateVersionFlow

    @Volatile
    private var lastNotifyBroadcastMs: Long = 0L

    fun notifyProAndConfigStateChanged(context: Context) {
        val now = System.currentTimeMillis()
        _isProFlow.value = isProActivated(context) // Cập nhật Flow phản ứng UI
        if (now - lastNotifyBroadcastMs < 60L) return
        lastNotifyBroadcastMs = now
        _proStateVersionFlow.value = now
        try {
            val pkg = context.packageName
            context.sendBroadcast(android.content.Intent(ACTION_PRO_ACTIVATED).setPackage(pkg))
            context.sendBroadcast(android.content.Intent(ACTION_CONFIG_UPDATED).setPackage(pkg))
        } catch (_: Exception) {}
    }



    // Chống trừ 2 lần liên tiếp trong cùng 1 thao tác (ViewModel -> Repository)
    @Volatile
    private var lastTrialConsumedTimestampMs: Long = 0L

    data class AiProChatLogRecord(
        val id: String = "",
        val deviceId: String = "",
        val deviceModel: String = "",
        val ownerEmail: String = "",
        val ownerName: String = "",
        val userMessage: String = "",
        val aiReply: String = "",
        val eventType: String = "PRO_INQUIRY", // "BILL_VERIFIED_PRO" | "BILL_REJECTED" | "FAKE_BILL_DETECTED" | "REUSED_BILL_BLOCKED" | "KEY_VERIFIED_PRO" | "CLOUD_FAMILIAR_RESTORED" | "UNPAID_PRO_REQUEST_BLOCKED" | "PRO_INQUIRY"
        val proGranted: Boolean = false,
        val grantedTier: String = "NONE", // "ACCOUNT_PRO" | "DEVICE_PRO" | "NONE"
        val generatedKey: String = "",
        val billImageHash: String = "",
        val bankTransCode: String = "",
        val forensicVerdict: String = "",
        val timestampMs: Long = 0L,
        val createdAt: Any? = null
    ) {
        fun getFormattedTime(): String {
            val ms = if (timestampMs > 0L) {
                timestampMs
            } else {
                (createdAt as? com.google.firebase.Timestamp)?.toDate()?.time ?: 0L
            }
            if (ms <= 0L) return "Vừa xong"
            return try {
                (tlAiLogTimeFormat.get() ?: java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss", java.util.Locale.getDefault())).format(java.util.Date(ms))
            } catch (_: Exception) {
                "Vừa xong"
            }
        }
    }

    private val tlAiLogTimeFormat = ThreadLocal.withInitial {
        java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss", java.util.Locale.getDefault())
    }
    private val tlYmdFormat = ThreadLocal.withInitial {
        java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
    }

    fun computeByteArraySha256(bytes: ByteArray): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hashBytes = digest.digest(bytes)
            val sb = StringBuilder()
            for (b in hashBytes) {
                val hex = Integer.toHexString(0xff and b.toInt())
                if (hex.length == 1) sb.append('0')
                sb.append(hex)
            }
            sb.toString().uppercase()
        } catch (_: Exception) {
            ""
        }
    }

    /**
     * Tính mã băm thị giác (Perceptual dHash 64-bit) của ảnh biên lai để phát hiện ảnh bị cắt cúp,
     * chụp lại màn hình, nén lại hoặc chỉnh sửa nhẹ nhằm lách bộ lọc SHA-256.
     */
    fun computeBitmapPerceptualHash(bitmap: android.graphics.Bitmap): String {
        return try {
            val scaled = android.graphics.Bitmap.createScaledBitmap(bitmap, 9, 8, true)
            var hash = 0UL
            var bitIndex = 0
            for (y in 0 until 8) {
                for (x in 0 until 8) {
                    val p1 = scaled.getPixel(x, y)
                    val p2 = scaled.getPixel(x + 1, y)
                    val lum1 = ((p1 shr 16 and 0xFF) * 299 + (p1 shr 8 and 0xFF) * 587 + (p1 and 0xFF) * 114)
                    val lum2 = ((p2 shr 16 and 0xFF) * 299 + (p2 shr 8 and 0xFF) * 587 + (p2 and 0xFF) * 114)
                    if (lum1 > lum2) {
                        hash = hash or (1UL shl bitIndex)
                    }
                    bitIndex++
                }
            }
            hash.toString(16).uppercase().padStart(16, '0')
        } catch (_: Exception) {
            ""
        }
    }

    fun arePerceptualHashesSimilar(h1: String, h2: String, maxHammingDistance: Int = 5): Boolean {
        val clean1 = h1.trim().uppercase()
        val clean2 = h2.trim().uppercase()
        if (clean1.length != 16 || clean2.length != 16) return false
        return try {
            val v1 = clean1.toULong(16)
            val v2 = clean2.toULong(16)
            val xorVal = v1 xor v2
            xorVal.countOneBits() <= maxHammingDistance
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Kiểm tra Chống Gian Lận Dùng Lại Bill Cũ / Bill Trùng Lặp (Anti-Replay Attack):
     * Kiểm tra đồng thời chữ ký SHA-256, chữ ký thị giác Perceptual Hash (chống cắt ảnh/nén lại),
     * và Mã giao dịch ngân hàng (FT / Reference Code) trên toàn bộ lịch sử `ai_pro_chat_logs` & `devices`.
     */
    suspend fun checkBillReplayOrDuplicateInCloud(
        billSha256: String,
        bankTransCode: String,
        currentDeviceId: String,
        isRequestingAccountUpgrade: Boolean,
        billPerceptualHash: String = "",
        context: Context? = null
    ): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        try {
            val db = FirebaseFirestore.getInstance()
            val normCurrentId = normalizeDeviceIdForMatch(currentDeviceId)
            val cleanHash = billSha256.trim().uppercase()
            val cleanPerceptual = billPerceptualHash.trim().uppercase()
            val cleanTrans = bankTransCode.trim().uppercase()
                .replace(" ", "")
                .takeIf { it.length >= 6 && it != "NONE" && it != "UNKNOWN" && it != "KHONGCO" && it != "NULL" }
                .orEmpty()

            val matchedDocs = mutableListOf<com.google.firebase.firestore.DocumentSnapshot>()
            val seenDocIds = mutableSetOf<String>()
            if (cleanHash.isNotBlank()) {
                try {
                    val hashSnap = db.collection("ai_pro_chat_logs")
                        .whereEqualTo("billImageHash", cleanHash)
                        .limit(10)
                        .get()
                        .await()
                    for (d in hashSnap.documents) {
                        if (seenDocIds.add(d.id)) matchedDocs.add(d)
                    }
                } catch (_: Exception) {}
            }
            if (cleanTrans.isNotBlank()) {
                try {
                    val transSnap = db.collection("ai_pro_chat_logs")
                        .whereEqualTo("bankTransCode", cleanTrans)
                        .limit(10)
                        .get()
                        .await()
                    for (d in transSnap.documents) {
                        if (seenDocIds.add(d.id)) matchedDocs.add(d)
                    }
                } catch (_: Exception) {}
            }
            // Quét thêm các bản ghi gần nhất để đối chiếu Perceptual Hash & chống sửa mã GD
            try {
                val recentSnap = db.collection("ai_pro_chat_logs")
                    .limit(150)
                    .get()
                    .await()
                for (d in recentSnap.documents) {
                    if (seenDocIds.add(d.id)) matchedDocs.add(d)
                }
            } catch (_: Exception) {}

            for (doc in matchedDocs) {
                val wasGranted = doc.getBoolean("proGranted") == true ||
                    (doc.getString("eventType") ?: "") == "REVOKED_BY_ADMIN"
                if (!wasGranted) continue

                val existingHash = (doc.getString("billImageHash") ?: "").trim().uppercase()
                val existingPerceptual = (doc.getString("billPerceptualHash") ?: "").trim().uppercase()
                val existingTrans = (doc.getString("bankTransCode") ?: "").trim().uppercase().replace(" ", "")
                val existingDevId = (doc.getString("deviceId") ?: "").trim().uppercase()
                val existingTier = (doc.getString("grantedTier") ?: "").trim().uppercase()
                val normExistingDev = normalizeDeviceIdForMatch(existingDevId)

                // 1. Trùng khớp 100% chữ ký ảnh SHA-256
                if (cleanHash.isNotBlank() && existingHash.isNotBlank() && cleanHash == existingHash) {
                    if (normExistingDev != normCurrentId) {
                        return@withContext true to "Ảnh biên lai này đã từng được sử dụng để kích hoạt cho thiết bị $existingDevId. Hệ thống chống gian lận nghiêm cấm dùng 1 ảnh bill cho nhiều máy!"
                    }
                    if (isRequestingAccountUpgrade && existingTier == "DEVICE_PRO") {
                        return@withContext true to "Ảnh biên lai này là hóa đơn cũ khi bạn mua gói Pro Thiết Bị trước đây. Để nâng cấp lên Pro Tài Khoản, bạn cần thực hiện giao dịch chuyển khoản mới!"
                    }
                    return@withContext true to "Ảnh biên lai này đã được sử dụng trước đó trên hệ thống. Vui lòng không gửi lại hóa đơn cũ!"
                }

                // 2. Trùng khớp Chữ ký Thị giác Perceptual Hash (Phát hiện cắt cúp / chụp lại ảnh bill cũ)
                if (cleanPerceptual.length == 16 && existingPerceptual.length == 16 &&
                    arePerceptualHashesSimilar(cleanPerceptual, existingPerceptual, maxHammingDistance = 4)
                ) {
                    if (normExistingDev != normCurrentId) {
                        return@withContext true to "Hệ thống phát hiện ảnh biên lai này trùng khớp hình ảnh với hóa đơn đã dùng cho thiết bị $existingDevId (dù đã cắt cúp/chỉnh sửa). Không thể dùng lại biên lai của máy khác!"
                    }
                    if (isRequestingAccountUpgrade && existingTier == "DEVICE_PRO") {
                        return@withContext true to "Hệ thống nhận diện đây là ảnh biên lai cũ của gói Pro Thiết Bị. Vui lòng dùng ảnh biên lai chuyển khoản mới để nâng cấp lên Pro Tài Khoản!"
                    }
                }

                // 3. Trùng khớp Mã giao dịch ngân hàng (FT / Mã tham chiếu)
                if (cleanTrans.isNotBlank() && existingTrans.isNotBlank() && cleanTrans == existingTrans) {
                    if (normExistingDev != normCurrentId) {
                        return@withContext true to "Mã giao dịch ngân hàng ($cleanTrans) trên biên lai này đã được sử dụng cho thiết bị $existingDevId trước đó. Không thể dùng lại biên lai cũ!"
                    }
                    if (isRequestingAccountUpgrade && existingTier == "DEVICE_PRO") {
                        return@withContext true to "Mã giao dịch ($cleanTrans) này thuộc lần kích hoạt Pro Thiết Bị trước đây. Vui lòng thực hiện giao dịch mới để nâng cấp lên Pro Tài Khoản!"
                    }
                    return@withContext true to "Mã giao dịch ngân hàng ($cleanTrans) này đã được hệ thống duyệt sử dụng trước đó. Không thể dùng lại mã giao dịch cũ!"
                }
            }

            // 4. Fallback kiểm tra qua REST nếu máy khách chưa đăng nhập Google
            if (context != null) {
                try {
                    val restLogs = FirestoreRestTokenBridge.fetchCollectionMapsViaRest(context.applicationContext, "ai_pro_chat_logs")
                    for (m in restLogs) {
                        val wasGranted = (m["proGranted"] as? Boolean) == true ||
                            ((m["eventType"] as? String) == "REVOKED_BY_ADMIN")
                        if (!wasGranted) continue
                        val existingHash = (m["billImageHash"] as? String).orEmpty().trim().uppercase()
                        val existingPerceptual = (m["billPerceptualHash"] as? String).orEmpty().trim().uppercase()
                        val existingTrans = (m["bankTransCode"] as? String).orEmpty().trim().uppercase().replace(" ", "")
                        val existingDevId = (m["deviceId"] as? String).orEmpty().trim().uppercase()
                        val existingTier = (m["grantedTier"] as? String).orEmpty().trim().uppercase()
                        val normExistingDev = normalizeDeviceIdForMatch(existingDevId)

                        if (cleanHash.isNotBlank() && existingHash.isNotBlank() && cleanHash == existingHash) {
                            if (normExistingDev != normCurrentId) {
                                return@withContext true to "Ảnh biên lai này đã từng được sử dụng cho thiết bị $existingDevId. Nghiêm cấm dùng 1 ảnh bill cho nhiều máy!"
                            }
                            if (isRequestingAccountUpgrade && existingTier == "DEVICE_PRO") {
                                return@withContext true to "Ảnh biên lai này là hóa đơn cũ của gói Pro Thiết Bị. Vui lòng quét QR chuyển khoản mới để nâng cấp Pro Tài Khoản!"
                            }
                            return@withContext true to "Ảnh biên lai này đã được sử dụng trước đó!"
                        }
                        if (cleanPerceptual.length == 16 && existingPerceptual.length == 16 &&
                            arePerceptualHashesSimilar(cleanPerceptual, existingPerceptual, maxHammingDistance = 4) &&
                            normExistingDev != normCurrentId
                        ) {
                            return@withContext true to "Phát hiện ảnh biên lai trùng khớp với hóa đơn đã dùng cho thiết bị $existingDevId!"
                        }
                        if (cleanTrans.isNotBlank() && existingTrans.isNotBlank() && cleanTrans == existingTrans) {
                            if (normExistingDev != normCurrentId) {
                                return@withContext true to "Mã giao dịch ngân hàng ($cleanTrans) đã được sử dụng cho thiết bị $existingDevId trước đó!"
                            }
                            return@withContext true to "Mã giao dịch ngân hàng ($cleanTrans) đã được sử dụng trước đó!"
                        }
                    }
                } catch (_: Exception) {}
            }

            false to ""
        } catch (_: Exception) {
            false to ""
        }
    }

    fun logAiProChatInteraction(
        context: Context,
        userMessage: String,
        aiReply: String,
        eventType: String,
        proGranted: Boolean,
        grantedTier: String = "NONE",
        generatedKey: String = "",
        targetDeviceId: String = "",
        billImageHash: String = "",
        bankTransCode: String = "",
        forensicVerdict: String = "",
        billPerceptualHash: String = ""
    ) {
        try {
            val deviceId = targetDeviceId.trim().uppercase().ifBlank { getDeviceId(context).uppercase() }
            val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val savedEmail = prefs.getString("current_user_email", "")?.trim().orEmpty()
            val familiarEmail = prefs.getString("last_familiar_email", "")?.trim().orEmpty()
            val effectiveEmail = when {
                !user?.email.isNullOrBlank() -> user?.email ?: ""
                savedEmail.isNotBlank() -> savedEmail
                familiarEmail.isNotBlank() -> "$familiarEmail (Máy quen)"
                else -> "👤 Khách vãng lai (Chưa đăng nhập)"
            }
            val effectiveName = when {
                !user?.displayName.isNullOrBlank() -> user?.displayName ?: ""
                effectiveEmail.contains("@") -> effectiveEmail.substringBefore("@")
                else -> "Khách vãng lai"
            }

            val now = System.currentTimeMillis()
            val logId = "ailog_${deviceId}_$now"
            val db = FirebaseFirestore.getInstance()
            val data = mapOf(
                "id" to logId,
                "appId" to "magictune",
                "deviceId" to deviceId,
                "deviceModel" to "${Build.MANUFACTURER} ${Build.MODEL}",
                "ownerEmail" to effectiveEmail,
                "ownerName" to effectiveName,
                "userMessage" to userMessage.take(1500),
                "aiReply" to aiReply.take(2500),
                "eventType" to eventType,
                "proGranted" to proGranted,
                "grantedTier" to grantedTier,
                "generatedKey" to generatedKey,
                "billImageHash" to billImageHash,
                "billPerceptualHash" to billPerceptualHash,
                "bankTransCode" to bankTransCode,
                "forensicVerdict" to forensicVerdict.take(500),
                "timestampMs" to now,
                "createdAt" to FieldValue.serverTimestamp()
            )
            if (user == null) {
                FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "ai_pro_chat_logs", logId, data)
            } else {
                db.collection("ai_pro_chat_logs").document(logId).set(data, SetOptions.merge())
            }
        } catch (_: Exception) {}
    }

    fun parseAiProChatLogsFromMaps(context: Context, rawList: List<Map<String, Any>>): List<AiProChatLogRecord> {
        return try {
            ensureDeletedTombstonesLoaded(context)
            rawList.mapNotNull { m ->
                try {
                    val docId = (m["__id"] as? String).orEmpty().trim()
                    val fieldId = (m["id"] as? String).orEmpty().trim()
                    val evType = ((m["eventType"] as? String)?.takeIf { it.isNotBlank() }
                        ?: (m["securityEvent"] as? String)?.takeIf { it.isNotBlank() }
                        ?: "PRO_INQUIRY").trim()
                    val isSoftDeleted = (m["deletedByAdmin"] as? Boolean) == true ||
                        evType.equals("DELETED_BY_ADMIN", ignoreCase = true)
                    if (isSoftDeleted) return@mapNotNull null

                    val tsMs = (m["timestampMs"] as? Number)?.toLong()
                        ?: extractTimestampMillis(m["createdAt"])
                    val devId = (m["deviceId"] as? String).orEmpty().trim()
                    val sigKey = if (devId.isNotBlank() && tsMs > 0L) "${devId}_$tsMs" else ""
                    if (isAiChatLogDeleted(context, docId, fieldId, sigKey)) {
                        return@mapNotNull null
                    }
                    val recordId = docId.ifBlank { fieldId }

                    AiProChatLogRecord(
                        id = recordId,
                        deviceId = devId,
                        deviceModel = (m["deviceModel"] as? String).orEmpty(),
                        ownerEmail = ((m["ownerEmail"] as? String)?.takeIf { it.isNotBlank() }
                            ?: (m["userEmail"] as? String).orEmpty()),
                        ownerName = ((m["ownerName"] as? String)?.takeIf { it.isNotBlank() }
                            ?: (m["userName"] as? String).orEmpty()),
                        userMessage = (m["userMessage"] as? String).orEmpty(),
                        aiReply = (m["aiReply"] as? String).orEmpty(),
                        eventType = evType,
                        proGranted = (m["proGranted"] as? Boolean) ?: false,
                        grantedTier = (m["grantedTier"] as? String)?.takeIf { it.isNotBlank() } ?: "NONE",
                        generatedKey = (m["generatedKey"] as? String).orEmpty(),
                        billImageHash = (m["billImageHash"] as? String).orEmpty(),
                        bankTransCode = (m["bankTransCode"] as? String).orEmpty(),
                        forensicVerdict = (m["forensicVerdict"] as? String).orEmpty(),
                        timestampMs = tsMs,
                        createdAt = m["createdAt"]
                    )
                } catch (_: Throwable) {
                    null
                }
            }.sortedByDescending { it.timestampMs }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun getOfflineAiProChatLogsCached(context: Context): List<AiProChatLogRecord> {
        return parseAiProChatLogsFromMaps(context, getCachedAdminCollectionMapsInstant(context, "ai_pro_chat_logs"))
    }

    fun fetchAiProChatLogsViaRest(
        context: Context,
        forceRefresh: Boolean = false
    ): List<AiProChatLogRecord> {
        ensureDeletedTombstonesLoaded(context)
        val rawList = fetchAdminCollectionMapsViaRest(context, "ai_pro_chat_logs", 150, forceRefresh = forceRefresh)
        return parseAiProChatLogsFromMaps(context, rawList)
    }

    fun observeAiProChatLogs(
        context: Context? = null,
        onUpdate: (List<AiProChatLogRecord>) -> Unit
    ): com.google.firebase.firestore.ListenerRegistration? {
        return try {
            ensureDeletedTombstonesLoaded(context)
            val db = FirebaseFirestore.getInstance()
            val listenerScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + Dispatchers.Default)
            var currentJob: kotlinx.coroutines.Job? = null
            var lastEmitted: List<AiProChatLogRecord>? = null
            val rawReg = db.collection("ai_pro_chat_logs")
                .limit(50)
                .addSnapshotListener(com.example.core.auth.FirebaseAuthManager.adminSnapshotExecutor) { snap, error ->
                    if (error != null && context != null) {
                        val appCtx = context.applicationContext
                        currentJob?.cancel()
                        currentJob = listenerScope.launch(Dispatchers.IO) {
                            val restList = fetchAiProChatLogsViaRest(appCtx)
                            if (restList != lastEmitted) {
                                lastEmitted = restList
                                withContext(Dispatchers.Main) {
                                    onUpdate(restList)
                                }
                            }
                        }
                        return@addSnapshotListener
                    }
                    if (snap != null) {
                        val docs = snap.documents
                        currentJob?.cancel()
                        currentJob = listenerScope.launch {
                            val list = docs.mapNotNull { doc ->
                                try {
                                    val evType = (doc.getString("eventType")
                                        ?: doc.getString("securityEvent")
                                        ?: "PRO_INQUIRY").trim()
                                    if (doc.getBoolean("deletedByAdmin") == true ||
                                        evType.equals("DELETED_BY_ADMIN", ignoreCase = true)
                                    ) {
                                        return@mapNotNull null
                                    }
                                    val tsMs = (doc.get("timestampMs") as? Number)?.toLong()
                                        ?: (doc.get("createdAt") as? com.google.firebase.Timestamp)?.toDate()?.time
                                        ?: 0L
                                    val devId = (doc.getString("deviceId") ?: "").trim()
                                    val fieldId = (doc.getString("id") ?: "").trim()
                                    val sigKey = if (devId.isNotBlank() && tsMs > 0L) "${devId}_$tsMs" else ""
                                    if (isAiChatLogDeleted(context, doc.id, fieldId, sigKey)) {
                                        return@mapNotNull null
                                    }

                                    AiProChatLogRecord(
                                        id = doc.id,
                                        deviceId = devId,
                                        deviceModel = doc.getString("deviceModel") ?: "",
                                        ownerEmail = doc.getString("ownerEmail") ?: doc.getString("userEmail") ?: "",
                                        ownerName = doc.getString("ownerName") ?: doc.getString("userName") ?: "",
                                        userMessage = doc.getString("userMessage") ?: "",
                                        aiReply = doc.getString("aiReply") ?: "",
                                        eventType = evType,
                                        proGranted = doc.getBoolean("proGranted") ?: false,
                                        grantedTier = doc.getString("grantedTier") ?: "NONE",
                                        generatedKey = doc.getString("generatedKey") ?: "",
                                        billImageHash = doc.getString("billImageHash") ?: "",
                                        bankTransCode = doc.getString("bankTransCode") ?: "",
                                        forensicVerdict = doc.getString("forensicVerdict") ?: "",
                                        timestampMs = tsMs,
                                        createdAt = doc.get("createdAt")
                                    )
                                } catch (_: Exception) {
                                    null
                                }
                            }.sortedByDescending { it.timestampMs }

                            if (list != lastEmitted) {
                                lastEmitted = list
                                withContext(Dispatchers.Main) {
                                    onUpdate(list)
                                }
                            }
                        }
                    }
                }
            com.google.firebase.firestore.ListenerRegistration {
                currentJob?.cancel()
                listenerScope.cancel()
                rawReg.remove()
            }
        } catch (_: Exception) {
            null
        }
    }

    fun deleteAiProChatLog(
        logId: String,
        context: Context? = null,
        deviceId: String = "",
        timestampMs: Long = 0L,
        onResult: ((Boolean) -> Unit)? = null
    ) {
        val cleanId = logId.trim()
        if (cleanId.isBlank() && deviceId.isBlank()) {
            onResult?.invoke(false)
            return
        }
        val appCtx = context?.applicationContext
        val candidateDocIds = LinkedHashSet<String>()
        val tombstoneKeys = LinkedHashSet<String>()
        if (cleanId.isNotBlank()) {
            candidateDocIds.add(cleanId)
            tombstoneKeys.add(cleanId)
        }
        val cleanDev = deviceId.trim()
        if (cleanDev.isNotBlank() && timestampMs > 0L) {
            tombstoneKeys.add("${cleanDev}_$timestampMs")
            candidateDocIds.add("ailog_${cleanDev}_$timestampMs")
            candidateDocIds.add("sec_${cleanDev}_$timestampMs")
        }

        // Tìm thêm mọi document ID thực tế (__id và id) khớp trong bộ đệm REST hiện tại
        adminRestCollectionCache["ai_pro_chat_logs"]?.second?.forEach { m ->
            val dId = (m["__id"] as? String).orEmpty().trim()
            val fId = (m["id"] as? String).orEmpty().trim()
            val mDev = (m["deviceId"] as? String).orEmpty().trim()
            val mTs = (m["timestampMs"] as? Number)?.toLong() ?: extractTimestampMillis(m["createdAt"])
            val matched = (cleanId.isNotBlank() && (dId == cleanId || fId == cleanId)) ||
                (cleanDev.isNotBlank() && timestampMs > 0L && mDev.equals(cleanDev, ignoreCase = true) && mTs == timestampMs)
            if (matched) {
                if (dId.isNotBlank()) {
                    candidateDocIds.add(dId)
                    tombstoneKeys.add(dId)
                }
                if (fId.isNotBlank()) {
                    candidateDocIds.add(fId)
                    tombstoneKeys.add(fId)
                }
                if (mDev.isNotBlank() && mTs > 0L) {
                    tombstoneKeys.add("${mDev}_$mTs")
                }
            }
        }

        // 1. Ghi nhận ngay vào Tombstone cục bộ & loại khỏi bộ đệm REST tức thì để dù bấm Làm mới ngay cũng không hiện lại
        markAiChatLogIdsDeleted(appCtx, tombstoneKeys)

        // 2. Xóa qua SDK (nếu SDK có quyền)
        try {
            val db = FirebaseFirestore.getInstance()
            candidateDocIds.forEach { id ->
                db.collection("ai_pro_chat_logs").document(id).delete()
            }
        } catch (_: Exception) {}

        // 3. Xóa vĩnh viễn trên Cloud qua cầu nối REST + Fallback đánh dấu deletedByAdmin nếu Firestore Rules chặn lệnh DELETE
        if (appCtx != null) {
            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                var anySuccess = false
                val softDeletePayload = mapOf(
                    "deletedByAdmin" to true,
                    "eventType" to "DELETED_BY_ADMIN",
                    "proGranted" to false
                )
                for (docId in candidateDocIds) {
                    val hardDeleted = try {
                        FirestoreRestTokenBridge.deleteDocViaRest(appCtx, "ai_pro_chat_logs", docId)
                    } catch (_: Throwable) {
                        false
                    }
                    if (hardDeleted) {
                        anySuccess = true
                    } else {
                        val softDeleted = try {
                            FirestoreRestTokenBridge.patchDocViaRest(appCtx, "ai_pro_chat_logs", docId, softDeletePayload)
                        } catch (_: Throwable) {
                            false
                        }
                        if (softDeleted) anySuccess = true
                    }
                }
                if (onResult != null) {
                    withContext(Dispatchers.Main) {
                        onResult(anySuccess || candidateDocIds.isNotEmpty())
                    }
                }
            }
        } else {
            onResult?.invoke(true)
        }
    }

    data class AdminAdbErrorLogRecord(
        val id: String = "",
        val date: String = "", // Định dạng yyyy-MM-dd, ví dụ "2026-11-01"
        val deviceId: String = "",
        val deviceModel: String = "",
        val commercialName: String = "",
        val manufacturer: String = "",
        val soc: String = "",
        val androidVersion: String = "",
        val magicOsVersion: String = "",
        val command: String = "",
        val exitCode: Int = 1,
        val errorOutput: String = "",
        val occurrenceCount: Long = 1L,
        val affectedDevices: List<String> = emptyList(),
        val connectionMode: String = "",
        val userEmail: String = "",
        val userName: String = "",
        val featureSource: String = "ADB_COMMAND",
        val firstSeenTimestamp: Long = 0L,
        val lastSeenTimestamp: Long = 0L,
        val timestampMs: Long = 0L,
        val createdAt: Any? = null
    ) {
        val displayDate: String
            get() = if (date.isNotBlank()) date else {
                if (timestampMs > 0) {
                    java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date(timestampMs))
                } else "Unknown"
            }

        val dedupKey: String
            get() = "${displayDate}|${command.trim()}|$exitCode"
    }

    private val recentErrorSignatures = java.util.concurrent.ConcurrentHashMap<String, Long>()

    private fun md5Hash(input: String): String {
        return try {
            val md = java.security.MessageDigest.getInstance("MD5")
            val digest = md.digest(input.toByteArray(Charsets.UTF_8))
            digest.joinToString("") { "%02x".format(it) }.take(12)
        } catch (_: Throwable) {
            input.hashCode().toString().replace("-", "n")
        }
    }

    /**
     * Kiểm tra xem một lệnh hoặc thông báo lỗi có phải là lỗi liên quan đến KẾT NỐI (ADB / Shizuku / Pairing / Socket / Binder) hay không.
     * Yêu cầu của Admin: Ô #8 ở trang quản trị KHÔNG hiển thị các lệnh lỗi liên quan đến kết nối,
     * CHỈ đẩy và hiển thị các lệnh lỗi phát sinh trong quá trình thực thi các chức năng khác của ứng dụng.
     */
    fun isConnectionRelatedAdbError(
        command: String,
        errorOutput: String,
        featureSource: String = ""
    ): Boolean {
        val cmdLower = command.trim().lowercase()
        val errLower = errorOutput.trim().lowercase()
        val srcLower = featureSource.trim().lowercase()

        if (cmdLower.isBlank()) return true
        if (srcLower == "user_pro_report") return false

        // 1. Nguồn phát sinh từ việc ghép nối / kết nối hoặc log terminal chung
        if (srcLower == "terminal_log" ||
            srcLower.contains("connect") ||
            srcLower.contains("pair") ||
            srcLower.contains("kết nối") ||
            srcLower.contains("ket noi") ||
            srcLower.contains("handshake") ||
            srcLower.contains("shizuku_init") ||
            srcLower.contains("wireless_adb")
        ) {
            return true
        }

        // 2. Bản thân câu lệnh là lệnh kết nối / ghép đôi / kiểm tra kết nối ADB hoặc khởi tạo
        if (cmdLower.startsWith("adb connect") ||
            cmdLower.startsWith("adb pair") ||
            cmdLower.startsWith("adb disconnect") ||
            cmdLower.startsWith("adb devices") ||
            cmdLower.startsWith("adb kill-server") ||
            cmdLower.startsWith("adb start-server") ||
            cmdLower.startsWith("adb wait-for-device") ||
            cmdLower.startsWith("adb tcpip") ||
            cmdLower.startsWith("connect ") ||
            cmdLower.startsWith("pair ") ||
            cmdLower == "echo" ||
            cmdLower.startsWith("echo ")
        ) {
            return true
        }

        // 3. Nội dung lỗi trả về là lỗi mất kết nối, chưa kết nối, đóng socket, hết thời gian chờ kết nối hoặc Shizuku binder ngắt
        val connectionErrorKeywords = listOf(
            "lỗi kết nối",
            "chưa kết nối",
            "không thể kết nối",
            "mất kết nối",
            "ngắt kết nối",
            "chưa bật gỡ lỗi",
            "chưa cấp quyền shizuku",
            "shizuku chưa chạy",
            "shizuku binder",
            "binder không phản hồi",
            "binder dead",
            "binder is null",
            "deadobjectexception",
            "remoteexception",
            "shizuku not running",
            "shizuku is not available",
            "shizuku server bị treo",
            "lỗi tiến trình shizuku",
            "shizuku.newprocess",
            "received error from binder",
            "connection refused",
            "connection reset",
            "connection timed out",
            "connect timed out",
            "failed to connect",
            "unable to connect",
            "cannot connect",
            "can't connect",
            "could not connect",
            "no devices/emulators found",
            "no devices found",
            "device offline",
            "device not found",
            "device unauthorized",
            "device still authorizing",
            "error: closed",
            "socket closed",
            "socket is closed",
            "broken pipe",
            "eofexception",
            "handshake",
            "pairing",
            "pair code",
            "wireless debugging",
            "gỡ lỗi không dây",
            "no route to host",
            "network is unreachable",
            "port 5555",
            "127.0.0.1:",
            "localhost:"
        )
        if (connectionErrorKeywords.any { kw -> errLower.contains(kw) || cmdLower.contains(kw) }) {
            return true
        }

        return false
    }

    fun saveAdminAdbErrorLog(
        context: Context,
        command: String,
        exitCode: Int,
        errorOutput: String,
        connectionMode: String,
        featureSource: String
    ) {
        // Disabled and removed to lighten app and admin panel
    }

    fun pushUserReportedAdbErrorsToAdmin(
        context: Context,
        errorEntries: List<Pair<String, String>>,
        onResult: (Boolean, String) -> Unit
    ) {
        onResult(false, "Tính năng báo cáo lỗi ADB đã được gỡ bỏ.")
    }

    fun fetchAdminAdbErrorLogsViaRest(
        context: Context,
        forceRefresh: Boolean = false
    ): List<AdminAdbErrorLogRecord> {
        return try {
            ensureDeletedTombstonesLoaded(context)
            val rawList = fetchAdminCollectionMapsViaRest(context, "admin_logs", 150, forceRefresh = forceRefresh)
            rawList.mapNotNull { m ->
                try {
                    if ((m["deletedByAdmin"] as? Boolean) == true) return@mapNotNull null
                    val docId = (m["__id"] as? String).orEmpty().trim()
                    val fieldId = (m["id"] as? String).orEmpty().trim()
                    val logDate = (m["date"] as? String).orEmpty()
                    val recordId = docId.ifBlank { fieldId }

                    val tsMs = (m["timestampMs"] as? Number)?.toLong()
                        ?: extractTimestampMillis(m["createdAt"])
                    val cmd = (m["command"] as? String).orEmpty()
                    if (cmd.isBlank()) return@mapNotNull null
                    val exitCodeVal = (m["exitCode"] as? Number)?.toInt() ?: 1
                    val dedupKey = "${logDate}_${cmd.trim().lowercase()}_$exitCodeVal"
                    if (isAdbErrorLogDeleted(context, docId, fieldId, dedupKey)) {
                        return@mapNotNull null
                    }
                    val errOut = (m["errorOutput"] as? String).orEmpty()
                    val featSrc = (m["featureSource"] as? String)?.takeIf { it.isNotBlank() } ?: "ADB_COMMAND"
                    if (isConnectionRelatedAdbError(cmd, errOut, featSrc)) {
                        return@mapNotNull null
                    }
                    AdminAdbErrorLogRecord(
                        id = recordId,
                        date = logDate,
                        deviceId = (m["deviceId"] as? String).orEmpty(),
                        deviceModel = (m["deviceModel"] as? String).orEmpty(),
                        commercialName = (m["commercialName"] as? String).orEmpty(),
                        manufacturer = (m["manufacturer"] as? String).orEmpty(),
                        soc = (m["soc"] as? String).orEmpty(),
                        androidVersion = (m["androidVersion"] as? String).orEmpty(),
                        magicOsVersion = (m["magicOsVersion"] as? String).orEmpty(),
                        command = cmd,
                        exitCode = exitCodeVal,
                        errorOutput = errOut,
                        occurrenceCount = (m["occurrenceCount"] as? Number)?.toLong() ?: 1L,
                        affectedDevices = (m["affectedDevices"] as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
                        connectionMode = (m["connectionMode"] as? String).orEmpty(),
                        userEmail = (m["userEmail"] as? String).orEmpty(),
                        userName = (m["userName"] as? String).orEmpty(),
                        featureSource = featSrc,
                        firstSeenTimestamp = (m["firstSeenTimestamp"] as? Number)?.toLong() ?: 0L,
                        lastSeenTimestamp = (m["lastSeenTimestamp"] as? Number)?.toLong() ?: 0L,
                        timestampMs = tsMs,
                        createdAt = m["createdAt"]
                    )
                } catch (_: Throwable) {
                    null
                }
            }.sortedByDescending { it.timestampMs }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun observeAdminAdbErrorLogs(
        context: Context? = null,
        onUpdate: (List<AdminAdbErrorLogRecord>) -> Unit
    ): com.google.firebase.firestore.ListenerRegistration? {
        return try {
            ensureDeletedTombstonesLoaded(context)
            val db = FirebaseFirestore.getInstance()
            val listenerScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + Dispatchers.Default)
            var currentJob: kotlinx.coroutines.Job? = null
            var lastEmitted: List<AdminAdbErrorLogRecord>? = null
            val rawReg = db.collection("admin_logs")
                .limit(100)
                .addSnapshotListener(com.example.core.auth.FirebaseAuthManager.adminSnapshotExecutor) { snap, error ->
                    if (error != null && context != null) {
                        val appCtx = context.applicationContext
                        currentJob?.cancel()
                        currentJob = listenerScope.launch(Dispatchers.IO) {
                            val restList = fetchAdminAdbErrorLogsViaRest(appCtx)
                            if (restList != lastEmitted) {
                                lastEmitted = restList
                                withContext(Dispatchers.Main) {
                                    onUpdate(restList)
                                }
                            }
                        }
                        return@addSnapshotListener
                    }
                    if (snap != null) {
                        val docs = snap.documents
                        currentJob?.cancel()
                        currentJob = listenerScope.launch {
                            val list = docs.mapNotNull { doc ->
                                try {
                                    if (doc.getBoolean("deletedByAdmin") == true) return@mapNotNull null
                                    val logDate = (doc.getString("date") ?: "").trim()
                                    val cmd = (doc.getString("command") ?: "").trim()
                                    if (cmd.isBlank()) return@mapNotNull null
                                    val exitCodeVal = doc.getLong("exitCode")?.toInt() ?: 1
                                    val dedupKey = "${logDate}_${cmd.lowercase()}_$exitCodeVal"
                                    val fieldId = (doc.getString("id") ?: "").trim()
                                    if (isAdbErrorLogDeleted(context, doc.id, fieldId, dedupKey)) {
                                        return@mapNotNull null
                                    }
                                    val errOut = (doc.getString("errorOutput") ?: "").trim()
                                    val featSrc = (doc.getString("featureSource") ?: "ADB_COMMAND").trim()
                                    if (isConnectionRelatedAdbError(cmd, errOut, featSrc)) {
                                        return@mapNotNull null
                                    }
                                    AdminAdbErrorLogRecord(
                                        id = doc.id,
                                        date = logDate,
                                        deviceId = (doc.getString("deviceId") ?: "").trim(),
                                        deviceModel = (doc.getString("deviceModel") ?: "").trim(),
                                        commercialName = (doc.getString("commercialName") ?: "").trim(),
                                        manufacturer = (doc.getString("manufacturer") ?: "").trim(),
                                        soc = (doc.getString("soc") ?: "").trim(),
                                        androidVersion = (doc.getString("androidVersion") ?: "").trim(),
                                        magicOsVersion = (doc.getString("magicOsVersion") ?: "").trim(),
                                        command = cmd,
                                        exitCode = exitCodeVal,
                                        errorOutput = errOut,
                                        occurrenceCount = doc.getLong("occurrenceCount") ?: 1L,
                                        affectedDevices = (doc.get("affectedDevices") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
                                        connectionMode = (doc.getString("connectionMode") ?: "").trim(),
                                        userEmail = (doc.getString("userEmail") ?: "").trim(),
                                        userName = (doc.getString("userName") ?: "").trim(),
                                        featureSource = featSrc,
                                        firstSeenTimestamp = doc.getLong("firstSeenTimestamp") ?: 0L,
                                        lastSeenTimestamp = doc.getLong("lastSeenTimestamp") ?: 0L,
                                        timestampMs = doc.getLong("timestampMs") ?: doc.getTimestamp("createdAt")?.toDate()?.time ?: 0L,
                                        createdAt = doc.get("createdAt")
                                    )
                                } catch (_: Exception) {
                                    null
                                }
                            }.sortedByDescending { it.timestampMs }

                            if (list != lastEmitted) {
                                lastEmitted = list
                                withContext(Dispatchers.Main) {
                                    onUpdate(list)
                                }
                            }
                        }
                    }
                }
            com.google.firebase.firestore.ListenerRegistration {
                currentJob?.cancel()
                listenerScope.cancel()
                rawReg.remove()
            }
        } catch (_: Exception) {
            null
        }
    }

    fun deleteAdminAdbErrorLog(
        logId: String,
        context: Context? = null,
        dedupKey: String = ""
    ) {
        val cleanId = logId.trim()
        if (cleanId.isBlank() && dedupKey.isBlank()) return
        val appCtx = context?.applicationContext
        val candidateDocIds = LinkedHashSet<String>()
        val tombstoneKeys = LinkedHashSet<String>()
        if (cleanId.isNotBlank()) {
            candidateDocIds.add(cleanId)
            tombstoneKeys.add(cleanId)
        }
        if (dedupKey.isNotBlank()) {
            tombstoneKeys.add(dedupKey.trim())
        }
        adminRestCollectionCache["admin_logs"]?.second?.forEach { m ->
            val dId = (m["__id"] as? String).orEmpty().trim()
            val fId = (m["id"] as? String).orEmpty().trim()
            val mDate = (m["date"] as? String).orEmpty().trim()
            val mCmd = (m["command"] as? String).orEmpty().trim()
            val mExit = (m["exitCode"] as? Number)?.toInt() ?: 1
            val mDedup = "${mDate}_${mCmd.lowercase()}_$mExit"
            if ((cleanId.isNotBlank() && (dId == cleanId || fId == cleanId)) ||
                (dedupKey.isNotBlank() && mDedup == dedupKey.trim())
            ) {
                if (dId.isNotBlank()) {
                    candidateDocIds.add(dId)
                    tombstoneKeys.add(dId)
                }
                if (fId.isNotBlank()) {
                    candidateDocIds.add(fId)
                    tombstoneKeys.add(fId)
                }
            }
        }
        markAdbErrorLogIdsDeleted(appCtx, tombstoneKeys)
        try {
            val db = FirebaseFirestore.getInstance()
            candidateDocIds.forEach { id ->
                db.collection("admin_logs").document(id).delete()
            }
        } catch (_: Exception) {}
        if (appCtx != null) {
            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                val softDeletePayload = mapOf("deletedByAdmin" to true, "command" to "")
                for (docId in candidateDocIds) {
                    val hardOk = try {
                        FirestoreRestTokenBridge.deleteDocViaRest(appCtx, "admin_logs", docId)
                    } catch (_: Throwable) {
                        false
                    }
                    if (!hardOk) {
                        try {
                            FirestoreRestTokenBridge.patchDocViaRest(appCtx, "admin_logs", docId, softDeletePayload)
                        } catch (_: Throwable) {}
                    }
                }
            }
        }
    }

    fun clearAllAdminAdbErrorLogs(context: Context) {
        val appCtx = context.applicationContext
        val cachedIds = adminRestCollectionCache["admin_logs"]?.second?.mapNotNull {
            (it["__id"] as? String)?.trim()?.takeIf { s -> s.isNotBlank() }
        }.orEmpty()
        markAdbErrorLogIdsDeleted(appCtx, cachedIds)
        adminRestCollectionCache.remove("admin_logs")
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            try {
                if (cachedIds.isNotEmpty()) {
                    FirestoreRestTokenBridge.batchDeleteDocsViaRest(appCtx, "admin_logs", cachedIds)
                }
                val db = FirebaseFirestore.getInstance()
                val snap = withTimeoutOrNull(10_000L) { db.collection("admin_logs").limit(500).get().await() }
                if (snap != null) {
                    val ownDocs = snap.documents.filter { doc ->
                        isOwnedByMagicTuneApp("admin_logs", doc.id, doc.data ?: emptyMap())
                    }
                    for (chunk in ownDocs.chunked(350)) {
                        val batch = db.batch()
                        chunk.forEach { batch.delete(it.reference) }
                        withTimeoutOrNull(10_000L) { batch.commit().await() }
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    data class OldDataCleanupResult(
        val success: Boolean,
        val deletedActivityLogs: Int = 0,
        val deletedAdbErrors: Int = 0,
        val deletedQrSessions: Int = 0,
        val errorMessage: String? = null
    ) {
        val totalDeleted: Int get() = deletedActivityLogs + deletedAdbErrors + deletedQrSessions
    }

    data class OldDataCleanupProgress(
        val isRunning: Boolean = false,
        val currentStage: String = "",
        val scannedDocs: Int = 0,
        val deletedDocs: Int = 0,
        val lastCompletedResult: OldDataCleanupResult? = null,
        val lastFinishedAtMs: Long = 0L
    )

    private val _cleanupProgressFlow = kotlinx.coroutines.flow.MutableStateFlow(OldDataCleanupProgress())
    val cleanupProgressFlow: kotlinx.coroutines.flow.StateFlow<OldDataCleanupProgress> = _cleanupProgressFlow
    private val cleanupScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + Dispatchers.IO)

    /**
     * Kiểm tra CHẶT CHẼ tài liệu có thực sự thuộc về ứng dụng MagicTune hay không.
     * Tuyệt đối KHÔNG chạm vào tài liệu của các app hoặc website khác dùng chung dự án Firebase.
     */
    private fun isOwnedByMagicTuneApp(
        collection: String,
        docId: String,
        map: Map<String, Any?>
    ): Boolean {
        val rawAppId = (
            (map["appId"] as? String)
                ?: (map["app_id"] as? String)
                ?: (map["projectApp"] as? String)
                ?: (map["sourceApp"] as? String)
                ?: ""
            ).trim()
        if (rawAppId.isNotBlank() &&
            !rawAppId.equals("magictune", ignoreCase = true) &&
            !rawAppId.equals("magictune_honor", ignoreCase = true)
        ) {
            return false
        }

        val isTaggedMagicTune = rawAppId.equals("magictune", ignoreCase = true) ||
            rawAppId.equals("magictune_honor", ignoreCase = true)

        return when (collection) {
            "ai_pro_chat_logs" -> {
                if (isTaggedMagicTune) return true
                val devId = (map["deviceId"] as? String).orEmpty().trim()
                val secEvent = (map["securityEvent"] as? String).orEmpty().trim()
                docId.startsWith("ailog_") ||
                    docId.startsWith("sec_") ||
                    devId.startsWith("MT-", ignoreCase = true) ||
                    secEvent == "SECURITY_MOD_TAMPER_BLOCKED" ||
                    (map.containsKey("forensicVerdict") && map.containsKey("billImageHash"))
            }
            "admin_logs" -> {
                if (isTaggedMagicTune) return true
                docId.startsWith("adb_err_") &&
                    (map.containsKey("command") || map.containsKey("errorOutput") || map.containsKey("magicOsVersion"))
            }
            "payment_intents" -> {
                // Giữ nguyên mọi bản ghi đã duyệt Pro để bảo toàn dữ liệu khôi phục bản quyền
                val isProApproved = (map["isPro"] as? Boolean) == true ||
                    (map["status"] as? String)?.equals("APPROVED", ignoreCase = true) == true
                if (isProApproved) return false
                if (isTaggedMagicTune) return true
                val intentId = (map["intentId"] as? String).orEmpty().trim()
                val devId = (map["deviceId"] as? String).orEmpty().trim()
                (docId.startsWith("MT-", ignoreCase = true) ||
                    intentId.startsWith("MT-", ignoreCase = true) ||
                    devId.startsWith("MT-", ignoreCase = true)) && map.containsKey("actionType")
            }
            else -> false
        }
    }

    /**
     * DỌN SẠCH DỮ LIỆU NGÀY CŨ TIẾT KIỆM CHI PHÍ FIRESTORE (CHẠY DƯỚI NỀN, PHÂN TRANG, CÓ TIMEOUT):
     * - Chỉ xóa các bản ghi của các ngày trước hôm nay thuộc ĐÚNG ỨNG DỤNG MAGICTUNE trong 3 bảng:
     *   1) `ai_pro_chat_logs` (Nhật ký hoạt động / trò chuyện AI của MagicTune)
     *   2) `admin_logs` (Báo cáo lỗi ADB `adb_err_*` của MagicTune)
     *   3) `payment_intents` (Các phiên mở QR / thanh toán chưa duyệt ngày cũ của MagicTune)
     * - Không bao giờ xóa dữ liệu của app hoặc website khác dùng chung Firebase.
     * - Giữ nguyên 100% dữ liệu hôm nay, tài khoản (`users`), thiết bị (`devices`, `pro_devices`), khôi phục (`pro_recovery_requests`), kho app (`honor_apps`) và cấu hình (`app_config`).
     */
    fun cleanupOldLogsAndQrSessionsKeepToday(
        context: Context,
        onComplete: ((OldDataCleanupResult) -> Unit)? = null
    ) {
        if (_cleanupProgressFlow.value.isRunning) {
            val appCtx = context.applicationContext ?: context
            val msg = "⏳ Đang dọn dữ liệu ngày cũ dưới nền (${_cleanupProgressFlow.value.deletedDocs} mục đã xóa)..."
            if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
                try { android.widget.Toast.makeText(appCtx, msg, android.widget.Toast.LENGTH_SHORT).show() } catch (_: Throwable) {}
            } else {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    try { android.widget.Toast.makeText(appCtx, msg, android.widget.Toast.LENGTH_SHORT).show() } catch (_: Throwable) {}
                }
            }
            return
        }

        val appCtx = context.applicationContext
        _cleanupProgressFlow.value = OldDataCleanupProgress(
            isRunning = true,
            currentStage = "Khởi tạo dọn dẹp dữ liệu MagicTune...",
            scannedDocs = 0,
            deletedDocs = 0,
            lastCompletedResult = _cleanupProgressFlow.value.lastCompletedResult,
            lastFinishedAtMs = _cleanupProgressFlow.value.lastFinishedAtMs
        )

        cleanupScope.launch {
            var finalResult = OldDataCleanupResult(success = false, errorMessage = "Chưa hoàn tất")
            var totalScanned = 0
            var totalDeleted = 0
            try {
                val cal = java.util.Calendar.getInstance().apply {
                    set(java.util.Calendar.HOUR_OF_DAY, 0)
                    set(java.util.Calendar.MINUTE, 0)
                    set(java.util.Calendar.SECOND, 0)
                    set(java.util.Calendar.MILLISECOND, 0)
                }
                val startOfTodayMs = cal.timeInMillis
                val todayYmd = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date(startOfTodayMs))
                val db = FirebaseFirestore.getInstance()

                fun parseEpochFromDocId(docId: String): Long {
                    val m13 = Regex("_(\\d{13})$").find(docId)
                    return m13?.groupValues?.getOrNull(1)?.toLongOrNull() ?: 0L
                }

                fun parseYmdFromAdbDocId(docId: String): String {
                    val m = Regex("^adb_err_(\\d{4})(\\d{2})(\\d{2})_").find(docId)
                    return if (m != null) "${m.groupValues[1]}-${m.groupValues[2]}-${m.groupValues[3]}" else ""
                }

                fun isOldRecordFromMap(collection: String, docId: String, map: Map<String, Any?>): Boolean {
                    if (collection == "admin_logs") {
                        val dateStr = ((map["date"] as? String)?.trim().orEmpty())
                            .ifBlank { parseYmdFromAdbDocId(docId) }
                        if (dateStr.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) {
                            return dateStr < todayYmd
                        }
                    }
                    val candidates = listOf(
                        extractTimestampMillis(map["lastSeenTimestamp"]),
                        extractTimestampMillis(map["timestampMs"]),
                        extractTimestampMillis(map["timestamp"]),
                        extractTimestampMillis(map["updatedAt"]),
                        extractTimestampMillis(map["createdAt"]),
                        parseEpochFromDocId(docId)
                    )
                    val bestTs = candidates.maxOrNull() ?: 0L
                    return bestTs in 1L until startOfTodayMs
                }

                fun updateProgress(stage: String) {
                    _cleanupProgressFlow.value = _cleanupProgressFlow.value.copy(
                        isRunning = true,
                        currentStage = stage,
                        scannedDocs = totalScanned,
                        deletedDocs = totalDeleted
                    )
                }

                suspend fun deleteOldDocsInCollection(collection: String, stageLabel: String): Int {
                    updateProgress(stageLabel)
                    var deletedInCol = 0
                    val pageSize = 300
                    val maxPages = 40
                    var useRestFallback = false

                    // 1. Phân trang SDK có timeout rõ ràng để không bao giờ bị treo vô hạn
                    try {
                        var lastDoc: com.google.firebase.firestore.DocumentSnapshot? = null
                        for (page in 0 until maxPages) {
                            val baseQuery = db.collection(collection)
                                .orderBy(com.google.firebase.firestore.FieldPath.documentId())
                                .limit(pageSize.toLong())
                            val pagedQuery = if (lastDoc != null) baseQuery.startAfter(lastDoc) else baseQuery
                            val snap = withTimeoutOrNull(10_000L) {
                                pagedQuery.get(com.google.firebase.firestore.Source.SERVER).await()
                            }
                            if (snap == null) {
                                useRestFallback = true
                                break
                            }
                            val docs = snap.documents
                            if (docs.isEmpty()) break

                            totalScanned += docs.size
                            lastDoc = docs.last()

                            val toDelete = docs.filter { doc ->
                                val dataMap = doc.data ?: emptyMap()
                                isOwnedByMagicTuneApp(collection, doc.id, dataMap) &&
                                    isOldRecordFromMap(collection, doc.id, dataMap)
                            }
                            if (toDelete.isNotEmpty()) {
                                val batch = db.batch()
                                toDelete.forEach { batch.delete(it.reference) }
                                val commitOk = withTimeoutOrNull(10_000L) {
                                    batch.commit().await()
                                    true
                                } == true
                                if (commitOk) {
                                    deletedInCol += toDelete.size
                                    totalDeleted += toDelete.size
                                } else {
                                    // Fallback sang REST Batch Commit nếu SDK commit timeout/lỗi quyền
                                    val restDel = FirestoreRestTokenBridge.batchDeleteDocsViaRest(
                                        appCtx,
                                        collection,
                                        toDelete.map { it.id }
                                    )
                                    deletedInCol += restDel
                                    totalDeleted += restDel
                                }
                            }
                            updateProgress(stageLabel)
                            if (docs.size < pageSize) break
                        }
                    } catch (_: Throwable) {
                        useRestFallback = true
                    }

                    // 2. Fallback phân trang REST + Xóa hàng loạt bằng Firestore REST `:commit` (không còn xóa tuần tự từng doc)
                    if (useRestFallback) {
                        var pageToken = ""
                        val seenDocIds = HashSet<String>()
                        for (page in 0 until maxPages) {
                            val (items, nextToken) = FirestoreRestTokenBridge.fetchCollectionPageViaRest(
                                context = appCtx,
                                collection = collection,
                                pageSize = pageSize,
                                pageToken = pageToken
                            )
                            if (items.isEmpty()) break
                            totalScanned += items.size

                            val idsToDelete = items.mapNotNull { item ->
                                val docId = (item["__id"] as? String).orEmpty()
                                if (docId.isBlank() || !seenDocIds.add(docId)) return@mapNotNull null
                                if (isOwnedByMagicTuneApp(collection, docId, item) &&
                                    isOldRecordFromMap(collection, docId, item)
                                ) {
                                    docId
                                } else {
                                    null
                                }
                            }
                            if (idsToDelete.isNotEmpty()) {
                                val restDeleted = FirestoreRestTokenBridge.batchDeleteDocsViaRest(appCtx, collection, idsToDelete)
                                deletedInCol += restDeleted
                                totalDeleted += restDeleted
                            }
                            updateProgress(stageLabel)
                            if (nextToken.isBlank() || items.size < pageSize) break
                            pageToken = nextToken
                        }
                    }

                    adminRestCollectionCache.remove(collection)
                    return deletedInCol
                }

                val deletedActivity = deleteOldDocsInCollection("ai_pro_chat_logs", "Đang dọn Nhật ký MagicTune...")
                val deletedAdbErr = deleteOldDocsInCollection("admin_logs", "Đang dọn Lỗi ADB MagicTune...")
                val deletedQr = deleteOldDocsInCollection("payment_intents", "Đang dọn Phiên QR ngày cũ...")

                finalResult = OldDataCleanupResult(
                    success = true,
                    deletedActivityLogs = deletedActivity,
                    deletedAdbErrors = deletedAdbErr,
                    deletedQrSessions = deletedQr
                )
            } catch (e: Throwable) {
                finalResult = OldDataCleanupResult(
                    success = false,
                    errorMessage = e.localizedMessage ?: e.message ?: "Lỗi không xác định khi dọn dẹp"
                )
            } finally {
                val finishedAt = System.currentTimeMillis()
                _cleanupProgressFlow.value = OldDataCleanupProgress(
                    isRunning = false,
                    currentStage = if (finalResult.success) "Hoàn tất dọn dẹp" else "Dọn dẹp gặp lỗi",
                    scannedDocs = totalScanned,
                    deletedDocs = totalDeleted,
                    lastCompletedResult = finalResult,
                    lastFinishedAtMs = finishedAt
                )
                withContext(Dispatchers.Main) {
                    val toastMsg = if (finalResult.success) {
                        if (finalResult.totalDeleted > 0) {
                            "✅ Đã dọn xong dưới nền ${finalResult.totalDeleted} bản ghi ngày cũ của MagicTune (Nhật ký: ${finalResult.deletedActivityLogs}, Lỗi ADB: ${finalResult.deletedAdbErrors}, Phiên QR: ${finalResult.deletedQrSessions})."
                        } else {
                            "✨ Đã kiểm tra xong dưới nền: Không có bản ghi ngày cũ nào của MagicTune cần xóa!"
                        }
                    } else {
                        "⚠️ Dọn dẹp dưới nền chưa hoàn tất: ${finalResult.errorMessage ?: "Vui lòng thử lại"}"
                    }
                    try {
                        android.widget.Toast.makeText(appCtx, toastMsg, android.widget.Toast.LENGTH_LONG).show()
                    } catch (_: Throwable) {}
                    onComplete?.invoke(finalResult)
                }
            }
        }
    }

    /**
     * Sinh Mã Kích Hoạt PRO TÀI KHOẢN chuẩn SHA-256 theo Email khách hàng (Không bao giờ dùng hashCode() âm).
     */
    fun generateAccountProKeyForEmail(email: String): String {
        val cleanEmail = email.trim().lowercase()
        if (!cleanEmail.contains("@")) return "TKPR-9999-8888-7777"
        return try {
            val combinedInput = "EMAIL:$cleanEmail:$ACCOUNT_PRO_SALT"
            val digest = MessageDigest.getInstance("SHA-256")
            val hashBytes = digest.digest(combinedInput.toByteArray(Charsets.UTF_8))
            val hexString = StringBuilder()
            for (b in hashBytes) {
                val hex = Integer.toHexString(0xff and b.toInt())
                if (hex.length == 1) hexString.append('0')
                hexString.append(hex)
            }
            val sub = hexString.toString().uppercase().take(12)
            "TKPR-${sub.substring(0, 4)}-${sub.substring(4, 8)}-${sub.substring(8, 12)}"
        } catch (_: Exception) {
            "TKPR-9999-8888-7777"
        }
    }

    /**
     * Tự động ghi nhận ngay Device ID / Email + Mã Key lên Cloud (`devices`, `pro_devices`, `users`) qua kênh kép SDK + REST.
     */
    fun registerAdminGeneratedKeyToCloud(
        rawDeviceId: String,
        generatedKey: String,
        isAccountPro: Boolean,
        context: Context? = null,
        ownerEmailHint: String = "",
        onComplete: ((Boolean, String) -> Unit)? = null
    ) {
        val cleanInput = rawDeviceId.trim()
        if (cleanInput.isBlank()) {
            onComplete?.invoke(false, "Thiếu Device ID hoặc Email mục tiêu.")
            return
        }
        val isEmailTarget = cleanInput.contains("@")
        val cleanEmail = when {
            isEmailTarget -> cleanInput.lowercase()
            ownerEmailHint.contains("@") -> ownerEmailHint.trim().lowercase()
            else -> ""
        }
        val cleanDevId = if (isEmailTarget) "" else cleanInput.uppercase()
        val normDevId = normalizeDeviceIdForMatch(cleanDevId)
        val tier = if (isAccountPro) "ACCOUNT_PRO" else "DEVICE_PRO"
        val appCtx = context?.applicationContext

        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            var anySuccess = false
            try {
                val db = FirebaseFirestore.getInstance()
                val hwId = getHardwareId()
                val devBase = mutableMapOf<String, Any>(
                    "hardwareId" to hwId,
                    "appId" to "magictune",
                    "product" to "MAGICTUNE_PRO",
                    "magictunePro" to true,
                    "isPro" to true,
                    "isAccountPro" to isAccountPro,
                    "upgradedToAccountPro" to isAccountPro,
                    "proTier" to tier,
                    "licenseKey" to generatedKey,
                    "revokedByAdmin" to false,
                    "approvedByAiReason" to "ADMIN_KEY_GENERATED_$tier",
                    "proActivatedSource" to "ADMIN_KEY_GENERATED_$tier",
                    "proActivatedMs" to System.currentTimeMillis(),
                    "proActivatedAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (cleanEmail.contains("@")) {
                    devBase["ownerEmail"] = cleanEmail
                }

                if (cleanDevId.isNotBlank()) {
                    val devIds = listOf(cleanDevId, normDevId, if (normDevId.isNotBlank()) "MT-$normDevId" else "")
                        .filter { it.isNotBlank() }.distinct()
                    for (dId in devIds) {
                        val payload = devBase + ("deviceId" to dId) + ("normalizedDeviceId" to normDevId)
                        kotlin.runCatching {
                            db.collection("devices").document(dId).set(payload, SetOptions.merge())
                            db.collection("pro_devices").document(dId).set(payload, SetOptions.merge())
                            anySuccess = true
                        }
                        if (appCtx != null) {
                            if (FirestoreRestTokenBridge.patchDocViaRest(appCtx, "devices", dId, payload)) anySuccess = true
                            FirestoreRestTokenBridge.patchDocViaRest(appCtx, "pro_devices", dId, payload)
                        }
                    }
                    deletePaymentIntentsForDevice(cleanDevId, appCtx)
                }

                val userPatch = mutableMapOf<String, Any>(
                    "appId" to "magictune",
                    "hardwareId" to hwId,
                    "product" to "MAGICTUNE_PRO",
                    "magictunePro" to true,
                    "magictuneTier" to tier,
                    "isPro" to true,
                    "isAccountPro" to isAccountPro,
                    "proTier" to tier,
                    "licenseKey" to generatedKey,
                    "revokedByAdmin" to false,
                    "approvedByAiReason" to "ADMIN_KEY_GENERATED_$tier",
                    "proActivatedSource" to "ADMIN_KEY_GENERATED_$tier",
                    "proActivatedMs" to System.currentTimeMillis(),
                    "proActivatedAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (cleanDevId.isNotBlank()) {
                    userPatch["deviceId"] = cleanDevId
                    userPatch["activeDeviceId"] = cleanDevId
                }

                if (cleanEmail.contains("@")) {
                    val emailDocKey = "email_" + cleanEmail.replace(".", "_").replace("@", "_at_")
                    val preGrantPayload = userPatch + mapOf("email" to cleanEmail, "preGrantedByEmail" to true)
                    kotlin.runCatching {
                        db.collection("users").document(emailDocKey).set(preGrantPayload, SetOptions.merge())
                        anySuccess = true
                    }
                    if (appCtx != null) {
                        if (FirestoreRestTokenBridge.patchDocViaRest(appCtx, "users", emailDocKey, preGrantPayload)) {
                            anySuccess = true
                        }
                        val matchedUsers = FirestoreRestTokenBridge.queryCollectionByFieldInViaRest(
                            appCtx, "users", "email", listOf(cleanEmail, cleanEmail.lowercase()), limit = 10
                        )
                        for (uDoc in matchedUsers) {
                            val uId = (uDoc["__id"] as? String).orEmpty()
                            if (uId.isNotBlank()) {
                                FirestoreRestTokenBridge.patchDocViaRest(appCtx, "users", uId, userPatch)
                                kotlin.runCatching { db.collection("users").document(uId).set(userPatch, SetOptions.merge()) }
                                val linkedDev = ((uDoc["activeDeviceId"] as? String) ?: (uDoc["deviceId"] as? String)).orEmpty().trim().uppercase()
                                if (linkedDev.length >= 4) {
                                    val devPayload = devBase + ("deviceId" to linkedDev)
                                    FirestoreRestTokenBridge.patchDocViaRest(appCtx, "devices", linkedDev, devPayload)
                                    FirestoreRestTokenBridge.patchDocViaRest(appCtx, "pro_devices", linkedDev, devPayload)
                                }
                            }
                        }
                    }
                }
            } catch (_: Exception) {}
            withContext(Dispatchers.Main) {
                onComplete?.invoke(
                    anySuccess,
                    if (anySuccess) "Đã tạo Key & đồng bộ Cloud ($generatedKey)!" else "Đã tạo Key ($generatedKey) (đang đồng bộ khi có mạng)."
                )
            }
        }
    }

    /**
     * Dành cho Admin trên trang Quản Trị: Cấp hoặc nâng cấp chính xác hạng Pro (`DEVICE_PRO` hoặc `ACCOUNT_PRO`)
     * cho bất kỳ tài khoản hoặc thiết bị nào từ xa — Kênh kép REST + Firestore SDK chờ xác nhận thực tế, cập nhật đầy đủ 5 bảng & ghi nhật ký kiểm toán.
     */
    fun adminGrantTierForUserOrDevice(
        userId: String = "",
        deviceId: String = "",
        ownerEmail: String = "",
        grantAccountPro: Boolean,
        context: Context? = null,
        noteOrReason: String = "",
        bankTransCode: String = "",
        onComplete: ((Boolean, String) -> Unit)? = null
    ) {
        val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
        fun finishOnMain(ok: Boolean, msg: String) {
            if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
                onComplete?.invoke(ok, msg)
            } else {
                mainHandler.post { onComplete?.invoke(ok, msg) }
            }
        }

        val cleanDevId = deviceId.trim().uppercase()
        val normDevId = normalizeDeviceIdForMatch(cleanDevId)
        var cleanEmail = ownerEmail.trim().lowercase().substringBefore(" (").trim()
        val cleanUid = userId.trim()
        val appCtx = context?.applicationContext
        val tier = if (grantAccountPro) "ACCOUNT_PRO" else "DEVICE_PRO"

        if (cleanDevId.isBlank() && !cleanEmail.contains("@") && cleanUid.isBlank()) {
            finishOnMain(false, "Vui lòng cung cấp Device ID, Email hoặc User ID hợp lệ.")
            return
        }

        val key = when {
            cleanDevId.isNotBlank() -> {
                if (grantAccountPro) generateAccountProLicenseKeyForDevice(cleanDevId)
                else generateLicenseKeyForDevice(cleanDevId)
            }
            cleanEmail.contains("@") -> {
                if (grantAccountPro) generateAccountProKeyForEmail(cleanEmail)
                else "PRO-ADMIN-GRANTED"
            }
            else -> if (grantAccountPro) "TKPR-ADMIN-GRANTED" else "PRO-ADMIN-GRANTED"
        }

        val effectiveReason = noteOrReason.trim().ifBlank { "ADMIN_MANUAL_GRANT_$tier" }

        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            var anyCloudWriteOk = false
            try {
                val db = FirebaseFirestore.getInstance()
                val hwId = getHardwareId()
                val nowMs = System.currentTimeMillis()

                val devUpdates = mutableMapOf<String, Any>(
                    "hardwareId" to hwId,
                    "appId" to "magictune",
                    "product" to "MAGICTUNE_PRO",
                    "magictunePro" to true,
                    "isPro" to true,
                    "isAccountPro" to grantAccountPro,
                    "upgradedToAccountPro" to grantAccountPro,
                    "proTier" to tier,
                    "licenseKey" to key,
                    "revokedByAdmin" to false,
                    "approvedByAiReason" to effectiveReason,
                    "proActivatedSource" to effectiveReason,
                    "proActivatedMs" to nowMs,
                    "proActivatedAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (cleanEmail.contains("@")) {
                    devUpdates["ownerEmail"] = cleanEmail
                }
                if (bankTransCode.isNotBlank()) {
                    devUpdates["bankTransCode"] = bankTransCode.trim()
                }

                val userUpdates = mutableMapOf<String, Any>(
                    "appId" to "magictune",
                    "hardwareId" to hwId,
                    "product" to "MAGICTUNE_PRO",
                    "magictunePro" to true,
                    "magictuneTier" to tier,
                    "isPro" to true,
                    "isAccountPro" to grantAccountPro,
                    "proTier" to tier,
                    "licenseKey" to key,
                    "proActivatedSource" to effectiveReason,
                    "approvedByAiReason" to effectiveReason,
                    "proActivatedAt" to FieldValue.serverTimestamp(),
                    "proActivatedMs" to nowMs,
                    "revokedByAdmin" to false,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (cleanDevId.isNotBlank()) {
                    userUpdates["deviceId"] = cleanDevId
                    userUpdates["activeDeviceId"] = cleanDevId
                }
                if (bankTransCode.isNotBlank()) {
                    userUpdates["bankTransCode"] = bankTransCode.trim()
                }

                val targetDevIds = if (cleanDevId.isNotBlank()) {
                    listOf(cleanDevId, normDevId, if (normDevId.isNotBlank()) "MT-$normDevId" else "")
                        .filter { it.isNotBlank() }.distinct()
                } else emptyList()

                if (appCtx != null && targetDevIds.isNotEmpty()) {
                    coroutineScope {
                        val jobs = targetDevIds.flatMap { dId ->
                            val payload = devUpdates + ("deviceId" to dId) + ("normalizedDeviceId" to normDevId)
                            listOf(
                                async(Dispatchers.IO) { FirestoreRestTokenBridge.patchDocViaRest(appCtx, "devices", dId, payload) },
                                async(Dispatchers.IO) { FirestoreRestTokenBridge.patchDocViaRest(appCtx, "pro_devices", dId, payload) }
                            )
                        }
                        if (jobs.any { it.await() }) anyCloudWriteOk = true
                    }
                }
                for (dId in targetDevIds) {
                    val payload = devUpdates + ("deviceId" to dId) + ("normalizedDeviceId" to normDevId)
                    kotlin.runCatching {
                        db.collection("devices").document(dId).set(payload, SetOptions.merge())
                        db.collection("pro_devices").document(dId).set(payload, SetOptions.merge())
                        anyCloudWriteOk = true
                    }
                }
                if (cleanDevId.isNotBlank()) {
                    deletePaymentIntentsForDevice(cleanDevId, appCtx)
                }

                if (cleanUid.isNotBlank()) {
                    if (appCtx != null && FirestoreRestTokenBridge.patchDocViaRest(appCtx, "users", cleanUid, userUpdates)) {
                        anyCloudWriteOk = true
                    }
                    kotlin.runCatching {
                        db.collection("users").document(cleanUid).set(userUpdates, SetOptions.merge())
                        anyCloudWriteOk = true
                    }
                } else if (cleanEmail.contains("@")) {
                    val emailDocKey = "email_" + cleanEmail.replace(".", "_").replace("@", "_at_")
                    val prePayload = userUpdates + mapOf("email" to cleanEmail, "preGrantedByEmail" to true)
                    if (appCtx != null && FirestoreRestTokenBridge.patchDocViaRest(appCtx, "users", emailDocKey, prePayload)) {
                        anyCloudWriteOk = true
                    }
                    kotlin.runCatching {
                        db.collection("users").document(emailDocKey).set(prePayload, SetOptions.merge())
                        anyCloudWriteOk = true
                    }
                }

                if (appCtx != null) {
                    val discoveredUserIds = linkedSetOf<String>()
                    val discoveredDevIds = linkedSetOf<String>()
                    discoveredDevIds.addAll(targetDevIds)

                    if (cleanEmail.contains("@")) {
                        val uByEmail = FirestoreRestTokenBridge.queryCollectionByFieldInViaRest(
                            appCtx, "users", "email", listOf(cleanEmail, cleanEmail.lowercase()), limit = 10
                        )
                        for (u in uByEmail) {
                            (u["__id"] as? String)?.takeIf { it.isNotBlank() }?.let { discoveredUserIds.add(it) }
                            ((u["deviceId"] as? String) ?: "").trim().uppercase().takeIf { it.length >= 4 }?.let { discoveredDevIds.add(it) }
                            ((u["activeDeviceId"] as? String) ?: "").trim().uppercase().takeIf { it.length >= 4 }?.let { discoveredDevIds.add(it) }
                        }
                    }
                    if (targetDevIds.isNotEmpty()) {
                        val uByDev = FirestoreRestTokenBridge.queryCollectionByFieldInViaRest(
                            appCtx, "users", "deviceId", targetDevIds, limit = 10
                        ) + FirestoreRestTokenBridge.queryCollectionByFieldInViaRest(
                            appCtx, "users", "activeDeviceId", targetDevIds, limit = 10
                        )
                        for (u in uByDev) {
                            (u["__id"] as? String)?.takeIf { it.isNotBlank() }?.let { discoveredUserIds.add(it) }
                            val foundEmail = (u["email"] as? String)?.trim()?.lowercase().orEmpty()
                            if (cleanEmail.isBlank() && foundEmail.contains("@")) cleanEmail = foundEmail
                        }
                    }

                    for (uId in discoveredUserIds) {
                        if (uId != cleanUid) {
                            FirestoreRestTokenBridge.patchDocViaRest(appCtx, "users", uId, userUpdates)
                            kotlin.runCatching { db.collection("users").document(uId).set(userUpdates, SetOptions.merge()) }
                        }
                    }
                    for (ld in discoveredDevIds) {
                        if (ld !in targetDevIds) {
                            val normLd = normalizeDeviceIdForMatch(ld)
                            val payload = devUpdates + ("deviceId" to ld) + ("normalizedDeviceId" to normLd)
                            FirestoreRestTokenBridge.patchDocViaRest(appCtx, "devices", ld, payload)
                            FirestoreRestTokenBridge.patchDocViaRest(appCtx, "pro_devices", ld, payload)
                            kotlin.runCatching {
                                db.collection("devices").document(ld).set(payload, SetOptions.merge())
                                db.collection("pro_devices").document(ld).set(payload, SetOptions.merge())
                            }
                        }
                    }

                    if (cleanDevId.isNotBlank()) {
                        val recIds = listOf(cleanDevId, "recovery_$cleanDevId", "MT-$normDevId", "recovery_MT-$normDevId")
                            .filter { it.isNotBlank() && it != "MT-" }.distinct()
                        val recPatch = mapOf(
                            "status" to "RESTORED",
                            "restoredKey" to key,
                            "resolvedAt" to FieldValue.serverTimestamp()
                        )
                        for (rId in recIds) {
                            FirestoreRestTokenBridge.patchDocViaRest(appCtx, "pro_recovery_requests", rId, recPatch)
                        }
                    }

                    val logPayload = mapOf(
                        "appId" to "magictune",
                        "deviceId" to (cleanDevId.ifBlank { cleanEmail }),
                        "ownerEmail" to cleanEmail,
                        "userMessage" to "⚡ [Admin Cấp Duyệt Pro] Mục tiêu: ${cleanDevId.ifBlank { cleanEmail }} • Lý do: $effectiveReason",
                        "aiReply" to "✅ Admin đã cấp gói $tier • Mã Key cố định: $key",
                        "eventType" to "ADMIN_MANUAL_GRANT",
                        "proGranted" to true,
                        "grantedTier" to tier,
                        "generatedKey" to key,
                        "bankTransCode" to bankTransCode.trim(),
                        "forensicVerdict" to "Admin duyệt trực tiếp: $effectiveReason",
                        "timestampMs" to nowMs,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                    kotlin.runCatching { db.collection("ai_pro_chat_logs").add(logPayload) }

                    val currDev = getDeviceId(appCtx).trim().uppercase()
                    val currNorm = normalizeDeviceIdForMatch(currDev)
                    val isCurrentDevice = (cleanDevId.isNotBlank() && (cleanDevId == currDev || normDevId == currNorm))
                    if (isCurrentDevice) {
                        val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                        prefs.edit()
                            .putBoolean(KEY_REVOKED_BY_ADMIN, false)
                            .putBoolean(KEY_PRO_ACTIVATED, true)
                            .putBoolean(KEY_ACCOUNT_PRO_ACTIVATED, grantAccountPro)
                            .putBoolean(KEY_UPGRADED_TO_ACCOUNT_PRO, grantAccountPro)
                            .putString(KEY_ACTIVATED_LICENSE, key)
                            .apply()
                        writeProIntegritySeal(appCtx, isPro = true, isAccPro = grantAccountPro)
                        persistHardwareProSignatureIfNeeded(appCtx, true)
                        notifyProAndConfigStateChanged(appCtx)
                    }
                }

                val tierLabel = if (grantAccountPro) "👑 PRO TÀI KHOẢN" else "📱 PRO THIẾT BỊ"
                finishOnMain(
                    anyCloudWriteOk,
                    if (anyCloudWriteOk) "Đã cấp $tierLabel & đồng bộ Cloud thành công! Key: $key"
                    else "Không thể đồng bộ Cloud để cấp $tierLabel, vui lòng kiểm tra mạng."
                )
            } catch (e: Exception) {
                finishOnMain(false, "Lỗi khi cấp Pro: ${e.localizedMessage}")
            }
        }
    }

    /**
     * Dành cho Admin trên trang Quản Trị: HẠ CẤP & THU HỒI TRIỆT ĐỂ QUYỀN PRO (Anti-Fraud Total Revocation)
     * đối với tài khoản hoặc thiết bị lên Pro gian lận khi Admin chưa nhận được tiền.
     * Xóa sạch cờ Pro trên tất cả 6 bảng (`devices`, `pro_devices`, `users`, `ai_pro_chat_logs`, `pro_recovery_requests`, `payment_intents`)
     * và bật cờ `revokedByAdmin = true` để thiết bị/tài khoản đó KHÔNG THỂ tự khôi phục lại Pro qua các tầng dự phòng.
     */
    fun adminRevokeProCompletely(
        context: Context? = null,
        userId: String = "",
        deviceId: String = "",
        ownerEmail: String = "",
        onComplete: ((Boolean, String) -> Unit)? = null
    ) {
        try {
            val db = FirebaseFirestore.getInstance()
            val cleanDevId = deviceId.trim().uppercase()
            val normDevId = normalizeDeviceIdForMatch(cleanDevId)
            val cleanEmail = ownerEmail.trim().lowercase()
            val appCtx = context?.applicationContext

            val devRevokePatch = mapOf<String, Any>(
                "isPro" to false,
                "isAccountPro" to false,
                "upgradedToAccountPro" to false,
                "magictunePro" to false,
                "proTier" to "FREE",
                "licenseKey" to "",
                "approvedByAiReason" to "REVOKED_BY_ADMIN",
                "proActivatedSource" to "REVOKED_BY_ADMIN",
                "activeSessionToken" to "",
                "revokedByAdmin" to true,
                "revokedAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )

            val userRevokePatch = mapOf<String, Any>(
                "isPro" to false,
                "isAccountPro" to false,
                "magictunePro" to false,
                "proTier" to "FREE",
                "magictuneTier" to "FREE",
                "licenseKey" to "",
                "proActivatedSource" to "REVOKED_BY_ADMIN",
                "approvedByAiReason" to "REVOKED_BY_ADMIN",
                "activeDeviceId" to "",
                "activeDeviceModel" to "",
                "activeSessionToken" to "",
                "revokedByAdmin" to true,
                "revokedAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )

            // 1. Thu hồi trên bảng `devices` và `pro_devices`
            if (cleanDevId.isNotBlank()) {
                val targetDevIds = listOf(cleanDevId, normDevId, if (normDevId.isNotBlank()) "MT-$normDevId" else "")
                    .filter { it.isNotBlank() }.distinct()
                for (dId in targetDevIds) {
                    val patchWithId = devRevokePatch + ("deviceId" to dId)
                    db.collection("devices").document(dId).set(patchWithId, SetOptions.merge())
                    db.collection("pro_devices").document(dId).set(patchWithId, SetOptions.merge())
                    if (appCtx != null) {
                        FirestoreRestTokenBridge.patchDocAsync(appCtx, "devices", dId, patchWithId)
                        FirestoreRestTokenBridge.patchDocAsync(appCtx, "pro_devices", dId, patchWithId)
                    }
                }
                deletePaymentIntentsForDevice(cleanDevId, appCtx)
                try {
                    db.collection("pro_recovery_requests").document(cleanDevId).delete()
                    db.collection("pro_recovery_requests").document("recovery_$cleanDevId").delete()
                    if (normDevId.isNotBlank()) {
                        db.collection("pro_recovery_requests").document("MT-$normDevId").delete()
                        db.collection("pro_recovery_requests").document("recovery_MT-$normDevId").delete()
                    }
                } catch (_: Exception) {}
            }

            // 2. Thu hồi trên bảng `users`
            if (userId.isNotBlank()) {
                db.collection("users").document(userId).set(userRevokePatch, SetOptions.merge())
                if (appCtx != null) {
                    FirestoreRestTokenBridge.patchDocAsync(appCtx, "users", userId, userRevokePatch)
                }
            }

            // 3. Quét đồng bộ các bản ghi liên quan trên `users`, `devices`, `pro_devices`, `ai_pro_chat_logs`
            db.collection("users").get().addOnSuccessListener { snap ->
                for (doc in snap.documents) {
                    val uEmail = (doc.getString("email") ?: "").trim().lowercase()
                    val uDev = normalizeDeviceIdForMatch(doc.getString("deviceId") ?: "")
                    val uAct = normalizeDeviceIdForMatch(doc.getString("activeDeviceId") ?: "")
                    val matchUser = (userId.isNotBlank() && doc.id == userId) ||
                        (cleanEmail.isNotBlank() && cleanEmail.contains("@") && uEmail == cleanEmail) ||
                        (normDevId.isNotBlank() && (uDev == normDevId || uAct == normDevId))
                    if (matchUser) {
                        doc.reference.set(userRevokePatch, SetOptions.merge())
                        if (appCtx != null) {
                            FirestoreRestTokenBridge.patchDocAsync(appCtx, "users", doc.id, userRevokePatch)
                        }
                        val linkedDev = (doc.getString("deviceId") ?: "").trim().uppercase()
                        val linkedAct = (doc.getString("activeDeviceId") ?: "").trim().uppercase()
                        for (ld in listOf(linkedDev, linkedAct).filter { it.isNotBlank() }.distinct()) {
                            val linkedPatch = devRevokePatch + ("deviceId" to ld)
                            db.collection("devices").document(ld).set(linkedPatch, SetOptions.merge())
                            db.collection("pro_devices").document(ld).set(linkedPatch, SetOptions.merge())
                            if (appCtx != null) {
                                FirestoreRestTokenBridge.patchDocAsync(appCtx, "devices", ld, linkedPatch)
                                FirestoreRestTokenBridge.patchDocAsync(appCtx, "pro_devices", ld, linkedPatch)
                            }
                        }
                    }
                }
            }

            db.collection("devices").get().addOnSuccessListener { snap ->
                for (doc in snap.documents) {
                    val dDev = normalizeDeviceIdForMatch(doc.getString("deviceId") ?: doc.id)
                    val dUid = (doc.getString("ownerUid") ?: "").trim()
                    val dEmail = (doc.getString("ownerEmail") ?: "").trim().lowercase()
                    val matchDev = (normDevId.isNotBlank() && dDev == normDevId) ||
                        (userId.isNotBlank() && dUid == userId) ||
                        (cleanEmail.isNotBlank() && cleanEmail.contains("@") && dEmail == cleanEmail)
                    if (matchDev) {
                        doc.reference.set(devRevokePatch, SetOptions.merge())
                        db.collection("pro_devices").document(doc.id).set(devRevokePatch, SetOptions.merge())
                        if (appCtx != null) {
                            FirestoreRestTokenBridge.patchDocAsync(appCtx, "devices", doc.id, devRevokePatch)
                            FirestoreRestTokenBridge.patchDocAsync(appCtx, "pro_devices", doc.id, devRevokePatch)
                        }
                    }
                }
            }

            db.collection("pro_devices").get().addOnSuccessListener { snap ->
                for (doc in snap.documents) {
                    val dDev = normalizeDeviceIdForMatch(doc.getString("deviceId") ?: doc.id)
                    val dUid = (doc.getString("ownerUid") ?: "").trim()
                    val dEmail = (doc.getString("ownerEmail") ?: "").trim().lowercase()
                    val matchDev = (normDevId.isNotBlank() && dDev == normDevId) ||
                        (userId.isNotBlank() && dUid == userId) ||
                        (cleanEmail.isNotBlank() && cleanEmail.contains("@") && dEmail == cleanEmail)
                    if (matchDev) {
                        doc.reference.set(devRevokePatch, SetOptions.merge())
                        if (appCtx != null) {
                            FirestoreRestTokenBridge.patchDocAsync(appCtx, "pro_devices", doc.id, devRevokePatch)
                        }
                    }
                }
            }

            // Vô hiệu hóa các lịch sử `ai_pro_chat_logs` từng cấp Pro cho máy/tài khoản này để Tầng 4 không tự khôi phục lại!
            db.collection("ai_pro_chat_logs").get().addOnSuccessListener { snap ->
                for (doc in snap.documents) {
                    if (doc.getBoolean("proGranted") != true) continue
                    val logDev = normalizeDeviceIdForMatch(doc.getString("deviceId") ?: "")
                    val logEmail = (doc.getString("ownerEmail") ?: "").trim().lowercase()
                    if ((normDevId.isNotBlank() && logDev == normDevId) ||
                        (cleanEmail.isNotBlank() && cleanEmail.contains("@") && logEmail.contains(cleanEmail))
                    ) {
                        val revokeLogPatch = mapOf(
                            "proGranted" to false,
                            "grantedTier" to "REVOKED",
                            "generatedKey" to "",
                            "eventType" to "REVOKED_BY_ADMIN"
                        )
                        doc.reference.set(revokeLogPatch, SetOptions.merge())
                        if (appCtx != null) {
                            FirestoreRestTokenBridge.patchDocAsync(appCtx, "ai_pro_chat_logs", doc.id, revokeLogPatch)
                        }
                    }
                }
            }

            if (appCtx != null) {
                val currDev = getDeviceId(appCtx).trim().uppercase()
                if (cleanDevId.isNotBlank() && (cleanDevId == currDev || normDevId == normalizeDeviceIdForMatch(currDev))) {
                    val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    prefs.edit()
                        .putBoolean(KEY_PRO_ACTIVATED, false)
                        .putBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false)
                        .putBoolean(KEY_UPGRADED_TO_ACCOUNT_PRO, false)
                        .putBoolean(KEY_REVOKED_BY_ADMIN, true)
                        .remove(KEY_ACTIVATED_LICENSE)
                        .remove(KEY_PRO_CRYPTO_SEAL)
                        .apply()
                    notifyProAndConfigStateChanged(appCtx)
                }
            }

            onComplete?.invoke(true, "🚫 Đã hạ cấp & thu hồi triệt để quyền Pro trên toàn hệ thống (bao gồm pro_devices)!")
        } catch (e: Exception) {
            onComplete?.invoke(false, "Lỗi khi hạ cấp: ${e.localizedMessage}")
        }
    }

    /**
     * Hạ cấp người dùng hoặc thiết bị về cấp bậc chỉ định do Admin lựa chọn:
     * - "FREE": Thu hồi hoàn toàn về bản miễn phí (Free / Gỡ Pro)
     * - "DEVICE_PRO": Hạ cấp từ Pro Tài Khoản (Đổi máy) về Pro Thiết Bị (Khóa 1 máy duy nhất)
     */
    fun adminDowngradeToSpecificTier(
        context: Context? = null,
        userId: String = "",
        deviceId: String = "",
        ownerEmail: String = "",
        targetTier: String = "FREE",
        onComplete: ((Boolean, String) -> Unit)? = null
    ) {
        if (targetTier == "FREE") {
            adminRevokeProCompletely(context, userId, deviceId, ownerEmail, onComplete)
            return
        }

        try {
            val db = FirebaseFirestore.getInstance()
            val cleanDevId = deviceId.trim().uppercase()
            val normDevId = normalizeDeviceIdForMatch(cleanDevId)
            val cleanEmail = ownerEmail.trim().lowercase()
            val appCtx = context?.applicationContext

            val newLicenseKey = if (cleanDevId.isNotBlank()) generateLicenseKeyForDevice(cleanDevId) else "PRO-DOWNGRADED-DEVICE"

            val devDowngradePatch = mapOf<String, Any>(
                "isPro" to true,
                "isAccountPro" to false,
                "upgradedToAccountPro" to false,
                "magictunePro" to true,
                "proTier" to "DEVICE_PRO",
                "licenseKey" to newLicenseKey,
                "approvedByAiReason" to "ADMIN_DOWNGRADE_TO_DEVICE_PRO",
                "proActivatedSource" to "ADMIN_DOWNGRADE_TO_DEVICE_PRO",
                "revokedByAdmin" to false,
                "updatedAt" to FieldValue.serverTimestamp()
            )

            val userDowngradePatch = mapOf<String, Any>(
                "isPro" to true,
                "isAccountPro" to false,
                "magictunePro" to true,
                "proTier" to "DEVICE_PRO",
                "magictuneTier" to "DEVICE_PRO",
                "licenseKey" to newLicenseKey,
                "proActivatedSource" to "ADMIN_DOWNGRADE_TO_DEVICE_PRO",
                "approvedByAiReason" to "ADMIN_DOWNGRADE_TO_DEVICE_PRO",
                "revokedByAdmin" to false,
                "updatedAt" to FieldValue.serverTimestamp()
            )

            if (cleanDevId.isNotBlank()) {
                val targetDevIds = listOf(cleanDevId, normDevId, "MT-$normDevId").filter { it.isNotBlank() }.distinct()
                for (dId in targetDevIds) {
                    db.collection("devices").document(dId).set(devDowngradePatch + ("deviceId" to dId), SetOptions.merge())
                    if (appCtx != null) {
                        FirestoreRestTokenBridge.patchDocAsync(appCtx, "devices", dId, devDowngradePatch + ("deviceId" to dId))
                    }
                }
            }

            if (userId.isNotBlank()) {
                db.collection("users").document(userId).set(userDowngradePatch, SetOptions.merge())
                if (appCtx != null) {
                    FirestoreRestTokenBridge.patchDocAsync(appCtx, "users", userId, userDowngradePatch)
                }
            } else if (normDevId.isNotBlank() || (cleanEmail.isNotBlank() && cleanEmail.contains("@"))) {
                db.collection("users").get().addOnSuccessListener { snap ->
                    for (doc in snap.documents) {
                        val uEmail = (doc.getString("email") ?: "").trim().lowercase()
                        val uDev = normalizeDeviceIdForMatch(doc.getString("deviceId") ?: "")
                        val uAct = normalizeDeviceIdForMatch(doc.getString("activeDeviceId") ?: "")
                        val matchUser = (cleanEmail.isNotBlank() && cleanEmail.contains("@") && uEmail == cleanEmail) ||
                            (normDevId.isNotBlank() && (uDev == normDevId || uAct == normDevId))
                        if (matchUser) {
                            doc.reference.set(userDowngradePatch, SetOptions.merge())
                            if (appCtx != null) {
                                FirestoreRestTokenBridge.patchDocAsync(appCtx, "users", doc.id, userDowngradePatch)
                            }
                        }
                    }
                }
            }

            if (appCtx != null) {
                val currDev = getDeviceId(appCtx).trim().uppercase()
                if (cleanDevId.isNotBlank() && (cleanDevId == currDev || normDevId == normalizeDeviceIdForMatch(currDev))) {
                    val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    prefs.edit()
                        .putBoolean(KEY_REVOKED_BY_ADMIN, false)
                        .putBoolean(KEY_PRO_ACTIVATED, true)
                        .putBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false)
                        .putBoolean(KEY_UPGRADED_TO_ACCOUNT_PRO, false)
                        .putString(KEY_ACTIVATED_LICENSE, newLicenseKey)
                        .apply()
                    writeProIntegritySeal(appCtx, isPro = true, isAccPro = false)
                    persistHardwareProSignatureIfNeeded(appCtx, true)
                    notifyProAndConfigStateChanged(appCtx)
                }
            }

            onComplete?.invoke(true, "📱 Đã hạ cấp thành công về Pro Thiết Bị (Khóa theo máy, thu hồi Pro Tài Khoản)!")
        } catch (e: Exception) {
            onComplete?.invoke(false, "Lỗi khi hạ cấp: ${e.localizedMessage}")
        }
    }

    /**
     * Dành cho Admin: Mở khóa phiên thiết bị (Reset 1-device session lock) khi khách dùng Pro Tài Khoản bị hỏng/mất máy cũ
     * và muốn đăng nhập sang máy mới ngay lập tức.
     */
    fun adminResetUserActiveDeviceSession(userId: String, ownerEmail: String = "", onComplete: (Boolean) -> Unit) {
        if (userId.isBlank() && !ownerEmail.contains("@")) {
            onComplete(false)
            return
        }
        try {
            val db = FirebaseFirestore.getInstance()
            val payload = mapOf(
                "activeDeviceId" to "",
                "activeDeviceModel" to "",
                "activeSessionToken" to "",
                "updatedAt" to FieldValue.serverTimestamp()
            )
            val targets = mutableListOf<String>()
            if (userId.isNotBlank()) targets.add(userId.trim())
            val cleanEmail = ownerEmail.trim().lowercase()
            if (cleanEmail.contains("@")) {
                targets.add("email_${cleanEmail.replace(Regex("[^a-zA-Z0-9._-]"), "_")}")
            }
            var okCount = 0
            val uniqueTargets = targets.distinct()
            var finished = 0
            for (docId in uniqueTargets) {
                db.collection("users").document(docId).set(payload, SetOptions.merge())
                    .addOnSuccessListener {
                        okCount++
                        finished++
                        if (finished >= uniqueTargets.size) onComplete(okCount > 0)
                    }
                    .addOnFailureListener {
                        finished++
                        if (finished >= uniqueTargets.size) onComplete(okCount > 0)
                    }
            }
        } catch (_: Exception) {
            onComplete(false)
        }
    }

    /**
     * Dành cho Admin: Đặt lại số lượt dùng thử miễn phí về 0 (hoặc giá trị chỉ định) cho thiết bị trên Cloud.
     */
    fun adminResetDeviceTrialCount(deviceId: String, newCount: Int = 0, onComplete: (Boolean) -> Unit) {
        val cleanId = deviceId.trim().uppercase()
        if (cleanId.isBlank()) {
            onComplete(false)
            return
        }
        try {
            val db = FirebaseFirestore.getInstance()
            val normId = normalizeDeviceIdForMatch(cleanId)
            val payload = mapOf(
                "freeTrialUsed" to newCount.coerceAtLeast(0),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            val docIds = listOfNotNull(
                cleanId,
                normId.takeIf { it.isNotBlank() && it != cleanId },
                normId.takeIf { it.isNotBlank() }?.let { "MT-$it" }
            ).distinct()
            var okCount = 0
            var finished = 0
            for (id in docIds) {
                db.collection("devices").document(id).set(payload, SetOptions.merge())
                    .addOnSuccessListener {
                        okCount++
                        finished++
                        if (finished >= docIds.size) onComplete(okCount > 0)
                    }
                    .addOnFailureListener {
                        finished++
                        if (finished >= docIds.size) onComplete(okCount > 0)
                    }
            }
        } catch (_: Exception) {
            onComplete(false)
        }
    }

    fun normalizeDeviceIdForMatch(raw: String): String {
        return raw.trim().uppercase()
            .replace(Regex("^MT[-_\\s:]*"), "")
            .replace("-", "")
            .replace(" ", "")
            .replace(Regex("[^A-Z0-9]"), "")
            .trim()
    }

    /**
     * Chuẩn hóa chống nhầm lẫn ký tự đồng hình (Homoglyphs) thường gặp khi khách hoặc OCR nhập mã Hex Android ID:
     * Chữ `O` -> Số `0`, Chữ `I` / `L` -> Số `1`.
     */
    fun normalizeHexHomoglyphs(raw: String): String {
        return normalizeDeviceIdForMatch(raw)
            .replace('O', '0')
            .replace('I', '1')
            .replace('L', '1')
    }

    private const val SECURE_KEY_PERSISTENT_DEVICE_ID = "magictune_persistent_device_id"

    @Volatile
    private var cachedHardwareId: String? = null
    @Volatile
    private var cachedDeviceId: String? = null
    @Volatile
    private var cachedPrimaryHwId: String? = null
    @Volatile
    private var cachedFallbackAndroidId: String? = null
    @Volatile
    private var cachedCandidateDeviceIds: List<String>? = null
    @Volatile
    private var cachedCandidateLicenseKeys: Map<String, Boolean>? = null
    @Volatile
    private var cachedCoreNormIds: List<String>? = null
    @Volatile
    private var cachedProIntegritySealState: Pair<String, Boolean>? = null
    @Volatile
    private var hasCheckedSecureStorageFallback: Boolean = false

    fun invalidateDeviceIdentityCache() {
        cachedDeviceId = null
        cachedCandidateDeviceIds = null
        cachedCandidateLicenseKeys = null
        cachedCoreNormIds = null
        cachedProIntegritySealState = null
    }

    /**
     * 1. Lấy định danh thiết bị (Device ID - Android ID) cố định xuyên suốt kể cả khi xóa hẳn app cài lại.
     * Tích hợp thêm MediaDrm Hardware ID để nhận diện máy vĩnh viễn siêu bền, có bộ đệm RAM (@Volatile)
     * để triệt tiêu 100% độ trễ IPC MediaDrm trên Main Thread (0ms lag).
     */
    @Volatile
    private var isComputingHardwareIdAsync: Boolean = false

    private fun computeWidevineHardwareIdBlocking(): String {
        return try {
            val socModel = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                "${Build.SOC_MANUFACTURER}:${Build.SOC_MODEL}"
            } else {
                Build.HARDWARE ?: ""
            }
            val rawHwSignature = listOf(
                Build.BOARD,
                Build.BRAND,
                Build.DEVICE,
                Build.HARDWARE,
                Build.MANUFACTURER,
                Build.MODEL,
                Build.PRODUCT,
                socModel
            ).joinToString("|") { (it ?: "").trim().uppercase() }
            val digest = MessageDigest.getInstance("SHA-256")
                .digest((rawHwSignature + "_" + SECRET_SALT).toByteArray(Charsets.UTF_8))
            Base64.encodeToString(digest, Base64.NO_WRAP).trim()
                .replace("/", "_").replace("+", "-").replace("=", "").take(32)
        } catch (_: Throwable) {
            ""
        }
    }

    fun getHardwareId(): String {
        cachedHardwareId?.let { return it }
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            if (!isComputingHardwareIdAsync) {
                isComputingHardwareIdAsync = true
                kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val computed = computeWidevineHardwareIdBlocking()
                        cachedHardwareId = computed
                        if (computed.isNotBlank()) {
                            invalidateDeviceIdentityCache()
                        }
                    } finally {
                        isComputingHardwareIdAsync = false
                    }
                }
            }
            return ""
        }
        val computed = computeWidevineHardwareIdBlocking()
        cachedHardwareId = computed
        return computed
    }

    fun getDeviceId(context: Context): String {
        cachedDeviceId?.let { if (it.isNotBlank() && it != "MT-HONOR-8888") return it }
        return try {
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val cachedPrefId = prefs.getString("cached_fast_device_id", null)?.trim()?.uppercase()
            if (!cachedPrefId.isNullOrBlank() && cachedPrefId != "9774D56D682E549C" && cachedPrefId != "MT-HONOR-8888") {
                cachedDeviceId = cachedPrefId
                return cachedPrefId
            }
            val savedPersistentId = try {
                Settings.Secure.getString(context.contentResolver, SECURE_KEY_PERSISTENT_DEVICE_ID)?.trim()?.uppercase()
            } catch (_: Exception) { null }
            if (!savedPersistentId.isNullOrBlank() && savedPersistentId != "9774D56D682E549C") {
                cachedDeviceId = savedPersistentId
                if (cachedPrefId != savedPersistentId) {
                    prefs.edit().putString("cached_fast_device_id", savedPersistentId).apply()
                }
                return savedPersistentId
            }

            val rawId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            val resolved = if (!rawId.isNullOrBlank() && rawId.lowercase() != "9774d56d682e549c") {
                rawId.uppercase()
            } else {
                val hwId = getHardwareId()
                if (hwId.isNotBlank()) "HW-${hwId.take(16).uppercase()}" else "MT-HONOR-8888"
            }

            cachedDeviceId = resolved
            prefs.edit().putString("cached_fast_device_id", resolved).apply()
            val appCtx = context.applicationContext
            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                try {
                    Settings.Secure.putString(appCtx.contentResolver, SECURE_KEY_PERSISTENT_DEVICE_ID, resolved)
                } catch (_: Exception) {}
            }
            resolved
        } catch (_: Exception) {
            "MT-HONOR-8888"
        }
    }

    fun getPrimaryHwId(context: Context): String {
        cachedPrimaryHwId?.let { if (it.isNotBlank()) return it }
        return try {
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val savedHwPrimary = prefs.getString("cached_primary_hw_id", null)?.trim()?.uppercase()
            if (!savedHwPrimary.isNullOrBlank() && savedHwPrimary != "MT-PRIMARY-HW") {
                cachedPrimaryHwId = savedHwPrimary
                return savedHwPrimary
            }
            val hwId = getHardwareId().trim()
            val source = if (hwId.isNotBlank()) hwId else {
                val rawAndroid = getFallbackAndroidId(context)
                if (rawAndroid.isNotBlank()) rawAndroid else "DEFAULT_HW"
            }
            val bytes = (source + "_" + SECRET_SALT).toByteArray(Charsets.UTF_8)
            val digest = MessageDigest.getInstance("SHA-256")
            val hashBytes = digest.digest(bytes)
            val sb = StringBuilder()
            for (b in hashBytes) {
                val hex = Integer.toHexString(0xff and b.toInt())
                if (hex.length == 1) sb.append('0')
                sb.append(hex)
            }
            val result = sb.toString().uppercase().take(16)
            cachedPrimaryHwId = result
            prefs.edit().putString("cached_primary_hw_id", result).apply()
            result
        } catch (e: Exception) {
            "MT-PRIMARY-HW"
        }
    }

    fun getFallbackAndroidId(context: Context): String {
        cachedFallbackAndroidId?.let { return it }
        return try {
            val raw = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)?.trim().orEmpty()
            val clean = if (raw.isNotBlank() && !raw.equals("9774d56d682e549c", ignoreCase = true)) raw.uppercase() else ""
            cachedFallbackAndroidId = clean
            clean
        } catch (e: Exception) {
            ""
        }
    }

    fun autoSyncProToCloud(context: Context, isAccount: Boolean, licenseKey: String) {
        try {
            val primaryHwId = getPrimaryHwId(context)
            val fallbackAndroid = getFallbackAndroidId(context)
            val deviceId = getDeviceId(context).uppercase()
            val hwId = getHardwareId()
            val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }

            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val fallbackEmail = prefs.getString("current_user_email", "")?.trim()?.takeIf { it.contains("@") }
                ?: prefs.getString("last_familiar_email", "")?.trim()?.takeIf { it.contains("@") }
                ?: "Ẩn danh (Chưa đăng nhập)"

            val data = mutableMapOf<String, Any>(
                "deviceId" to primaryHwId,
                "widevineId" to hwId,
                "hardwareId" to hwId,
                "androidId" to fallbackAndroid,
                "legacyDeviceId" to deviceId,
                "appId" to "magictune",
                "product" to "MAGICTUNE_PRO",
                "magictunePro" to true,
                "isPro" to true,
                "isAccountPro" to isAccount,
                "proTier" to if (isAccount) "ACCOUNT_PRO" else "DEVICE_PRO",
                "licenseKey" to licenseKey,
                "model" to "${Build.MANUFACTURER} ${Build.MODEL}",
                "ownerUid" to (user?.uid ?: ""),
                "ownerEmail" to (user?.email ?: fallbackEmail),
                "ownerName" to (user?.displayName ?: "Người dùng Pro"),
                "revokedByAdmin" to false,
                "proActivatedAt" to FieldValue.serverTimestamp(),
                "proActivatedMs" to System.currentTimeMillis(),
                "updatedAt" to FieldValue.serverTimestamp()
            )

            android.util.Log.d("ProRestore", "autoSyncProToCloud: writing Pro status to primaryHwId=[$primaryHwId], deviceId=[$deviceId], key=[$licenseKey]")

            val db = FirebaseFirestore.getInstance()
            val syncDocIds = listOf(primaryHwId, "MT-$primaryHwId", deviceId, "MT-${normalizeDeviceIdForMatch(deviceId)}")
                .filter { it.isNotBlank() }
                .distinct()
            for (docId in syncDocIds) {
                val docPayload = data + ("deviceId" to docId)
                // Firestore SDK là đường ghi chính; chỉ dùng REST khi SDK báo thất bại.
                // Gửi đồng thời cả hai đường tạo mutation trùng lặp, đặc biệt tốn bộ nhớ
                // khi máy ngoại tuyến và làm tăng tải hàng đợi ghi cục bộ.
                if (user == null) {
                    // Không xếp mutation SDK chưa xác thực vào hàng đợi ngoại tuyến.
                    FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "devices", docId, docPayload)
                    FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "pro_devices", docId, docPayload)
                } else {
                    db.collection("devices").document(docId).set(docPayload, SetOptions.merge())
                        .addOnFailureListener {
                            FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "devices", docId, docPayload)
                        }
                    db.collection("pro_devices").document(docId).set(docPayload, SetOptions.merge())
                        .addOnFailureListener {
                            FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "pro_devices", docId, docPayload)
                        }
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("ProRestore", "autoSyncProToCloud error: ${e.message}")
        }
    }

    fun syncDeviceProToCloud(context: Context) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val isAcc = prefs.getBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false)
        val key = prefs.getString(KEY_ACTIVATED_LICENSE, "") ?: "SELF_HEALING_SYNC"
        autoSyncProToCloud(context, isAcc, key)
    }

    /**
     * Tập hợp toàn bộ các biến thể định danh hợp lệ của thiết bị hiện tại (Multi-Format Candidate IDs):
     * - Gồm primaryHwId, MT-primaryHwId, fallbackAndroidId, MT-fallbackAndroidId và các biến thể tương thích ngược.
     */
    fun getAllCandidateDeviceIds(context: Context): List<String> {
        cachedCandidateDeviceIds?.let { if (it.isNotEmpty()) return it }
        val result = linkedSetOf<String>()
        try {
            val primaryHw = getPrimaryHwId(context)
            if (primaryHw.isNotBlank()) {
                result.add(primaryHw)
                result.add("MT-$primaryHw")
                result.add(primaryHw.lowercase())
            }

            val fallbackAndroid = getFallbackAndroidId(context)
            if (fallbackAndroid.isNotBlank()) {
                result.add(fallbackAndroid)
                result.add("MT-$fallbackAndroid")
                result.add(fallbackAndroid.lowercase())
                // Biến thể băm SHA-256 của fallbackAndroidId + SECRET_SALT để tương thích ngược 100%
                try {
                    val bytes = (fallbackAndroid + "_" + SECRET_SALT).toByteArray(Charsets.UTF_8)
                    val hashBytes = MessageDigest.getInstance("SHA-256").digest(bytes)
                    val legacySalted = hashBytes.joinToString("") { "%02X".format(it) }.take(16)
                    result.add(legacySalted)
                    result.add("MT-$legacySalted")
                } catch (_: Exception) {}
            }
            // Biến thể băm SHA-256 của DEFAULT_HW + SECRET_SALT (dự phòng cho bản cũ khi Widevine UUID chưa khởi tạo)
            try {
                val defBytes = ("DEFAULT_HW_" + SECRET_SALT).toByteArray(Charsets.UTF_8)
                val defHash = MessageDigest.getInstance("SHA-256").digest(defBytes)
                val defSalted = defHash.joinToString("") { "%02X".format(it) }.take(16)
                result.add(defSalted)
                result.add("MT-$defSalted")
            } catch (_: Exception) {}

            val primaryId = getDeviceId(context).trim().uppercase()
            val normPrimary = normalizeDeviceIdForMatch(primaryId)
            val hexPrimary = normalizeHexHomoglyphs(primaryId)
            val hwId = getHardwareId().trim()
            val normHw = normalizeDeviceIdForMatch(hwId)

            fun addIdVariants(baseNorm: String, rawOriginal: String = "") {
                if (rawOriginal.isNotBlank()) {
                    result.add(rawOriginal)
                    result.add(rawOriginal.uppercase())
                    result.add(rawOriginal.lowercase())
                }
                if (baseNorm.isNotBlank() && baseNorm != "HONOR8888") {
                    result.add(baseNorm)
                    result.add("MT-$baseNorm")
                    result.add(baseNorm.lowercase())
                    result.add("mt-${baseNorm.lowercase()}")
                    if (baseNorm.contains('0')) {
                        val oVariant = baseNorm.replace('0', 'O')
                        result.add(oVariant)
                        result.add("MT-$oVariant")
                    }
                    if (baseNorm.length >= 8) {
                        val head8 = baseNorm.take(8)
                        val tail8 = baseNorm.takeLast(8)
                        result.add("MT-$head8")
                        result.add(head8)
                        result.add("MT-$tail8")
                        result.add(tail8)
                    }
                    if (baseNorm.length >= 12) {
                        val head12 = baseNorm.take(12)
                        result.add("MT-$head12")
                        result.add(head12)
                    }
                }
            }

            addIdVariants(normPrimary, primaryId)
            if (hexPrimary.isNotBlank() && hexPrimary != normPrimary) {
                addIdVariants(hexPrimary)
            }
            if (fallbackAndroid.isNotBlank()) {
                addIdVariants(normalizeDeviceIdForMatch(fallbackAndroid), fallbackAndroid)
            }
            if (hwId.isNotBlank()) {
                val hw16 = hwId.take(16).uppercase()
                result.add(hwId)
                result.add("HW-$hw16")
                result.add(hw16)
                if (normHw.length >= 8) {
                    result.add("MT-${normHw.take(8)}")
                    result.add(normHw.take(8))
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("ProRestore", "getAllCandidateDeviceIds error: ${e.message}")
        }
        val list = result.filter { it.isNotBlank() && it.length >= 4 }.distinct()
        cachedCandidateDeviceIds = list
        return list
    }

    /**
     * Sinh toàn bộ các mã License Key SHA-256 (cả gói Pro Thiết Bị và Pro Tài Khoản) tương ứng với mọi biến thể ID của máy & Email đã liên kết.
     * Map trả về: `Key -> isAccountPro` (`true` nếu là `TKPR-...`, `false` nếu là Key Thiết Bị).
     */
    fun getAllCandidateLicenseKeys(context: Context): Map<String, Boolean> {
        val baseMap = cachedCandidateLicenseKeys?.takeIf { it.isNotEmpty() } ?: run {
            val fresh = linkedMapOf<String, Boolean>()
            val candidateIds = getAllCandidateDeviceIds(context)
            for (candId in candidateIds) {
                val upper = candId.trim().uppercase()
                if (upper.length < 4) continue
                val devKey = generateLicenseKeyForDevice(upper).uppercase()
                val accKey = generateAccountProLicenseKeyForDevice(upper).uppercase()
                if (devKey.isNotBlank() && devKey != "PRO8-8888-9999-0000") {
                    fresh[devKey] = false
                }
                if (accKey.isNotBlank() && accKey != "TKPR-9999-8888-7777") {
                    fresh[accKey] = true
                }
            }
            cachedCandidateLicenseKeys = fresh
            fresh
        }

        val keyMap = LinkedHashMap<String, Boolean>(baseMap.size + 4)
        keyMap.putAll(baseMap)
        try {
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val authEmail = try {
                com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.email
            } catch (_: Throwable) { null }
            val candidateEmails = listOfNotNull(
                authEmail,
                prefs.getString("current_user_email", null),
                prefs.getString("last_familiar_email", null)
            ).map { it.trim().lowercase() }.filter { it.contains("@") }.distinct()
            for (em in candidateEmails) {
                val emKey = generateAccountProKeyForEmail(em).uppercase()
                if (emKey.isNotBlank() && emKey != "TKPR-9999-8888-7777") {
                    keyMap[emKey] = true
                }
            }
        } catch (_: Throwable) {}
        return keyMap
    }

    private fun getCoreNormalizedIds(context: Context): List<String> {
        cachedCoreNormIds?.let { if (it.isNotEmpty()) return it }
        val primaryNorm = normalizeDeviceIdForMatch(getDeviceId(context))
        val primaryHex = normalizeHexHomoglyphs(primaryNorm)
        val rawAndroid = getFallbackAndroidId(context)
        val androidNorm = if (rawAndroid.isNotBlank()) normalizeDeviceIdForMatch(rawAndroid) else ""
        val androidHex = normalizeHexHomoglyphs(androidNorm)
        val hwNorm = normalizeDeviceIdForMatch(getHardwareId())
        val primaryHwNorm = normalizeDeviceIdForMatch(getPrimaryHwId(context))
        val legacyAndroidSalted = if (androidNorm.isNotBlank()) {
            try {
                val bytes = (androidNorm + "_" + SECRET_SALT).toByteArray(Charsets.UTF_8)
                MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02X".format(it) }.take(16)
            } catch (_: Exception) { "" }
        } else ""

        val list = listOf(primaryNorm, primaryHex, androidNorm, androidHex, hwNorm, hwNorm.take(16), primaryHwNorm, legacyAndroidSalted)
            .filter { it.length >= 6 && it != "HONOR8888" }
            .distinct()
        cachedCoreNormIds = list
        return list
    }

    /**
     * Đối chiếu thông minh xem một chuỗi định danh thiết bị (`otherRawId`) trên Cloud có thuộc về máy hiện tại hay không.
     * Hỗ trợ khớp chính xác, khớp chuẩn hóa bỏ `MT-`, khớp chống nhầm số `0` <-> chữ `O` (Homoglyphs),
     * và khớp tiền tố/hậu tố 8+ ký tự (giữa `ANDROID_ID` 16 ký tự và `MT-XXXXXXXX` 8 ký tự).
     */
    fun isDeviceIdMatchingCurrentDevice(context: Context, otherRawId: String?): Boolean {
        if (otherRawId.isNullOrBlank()) return false
        val otherNorm = normalizeDeviceIdForMatch(otherRawId)
        val otherHex = normalizeHexHomoglyphs(otherRawId)
        if (otherNorm.length < 6 || otherNorm == "HONOR8888") return false

        val coreNorms = getCoreNormalizedIds(context)
        for (core in coreNorms) {
            if (otherNorm == core || otherHex == core) return true
            if (otherNorm.length >= 8 && core.length >= 8) {
                if (core.startsWith(otherNorm) || core.endsWith(otherNorm) ||
                    otherNorm.startsWith(core) || otherNorm.endsWith(core) ||
                    core.startsWith(otherHex) || core.endsWith(otherHex) ||
                    otherHex.startsWith(core) || otherHex.endsWith(core)
                ) {
                    return true
                }
            }
        }
        return false
    }

    /**
     * 2. Thuật toán sinh Mã Kích Hoạt (License Key) chuẩn SHA-256 từ Device ID + Secret Salt
     * Kết quả dạng: XXXX-XXXX-XXXX-XXXX (Dành cho Pro Thiết Bị cố định theo ID máy)
     */
    fun generateLicenseKeyForDevice(deviceId: String): String {
        val cleanDeviceId = deviceId.trim().uppercase()
        val combinedInput = "$cleanDeviceId:$SECRET_SALT"

        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hashBytes = digest.digest(combinedInput.toByteArray(Charsets.UTF_8))

            val hexString = StringBuilder()
            for (b in hashBytes) {
                val hex = Integer.toHexString(0xff and b.toInt())
                if (hex.length == 1) hexString.append('0')
                hexString.append(hex)
            }

            val rawHash = hexString.toString().uppercase()
            val sub = rawHash.take(16)
            "${sub.substring(0, 4)}-${sub.substring(4, 8)}-${sub.substring(8, 12)}-${sub.substring(12, 16)}"
        } catch (_: Exception) {
            "PRO8-8888-9999-0000"
        }
    }

    /**
     * 2B. Thuật toán sinh Mã Kích Hoạt PRO TÀI KHOẢN (Account Pro Key) chuẩn SHA-256
     * Kết quả dạng: TKPR-XXXX-XXXX-XXXX (Dành cho nâng cấp từ Pro Thiết Bị lên Pro Tài Khoản hoặc mua Pro Tài Khoản)
     */
    fun generateAccountProLicenseKeyForDevice(deviceId: String): String {
        val cleanDeviceId = deviceId.trim().uppercase()
        val combinedInput = "$cleanDeviceId:$ACCOUNT_PRO_SALT"

        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hashBytes = digest.digest(combinedInput.toByteArray(Charsets.UTF_8))

            val hexString = StringBuilder()
            for (b in hashBytes) {
                val hex = Integer.toHexString(0xff and b.toInt())
                if (hex.length == 1) hexString.append('0')
                hexString.append(hex)
            }

            val rawHash = hexString.toString().uppercase()
            val sub = rawHash.take(12)
            "TKPR-${sub.substring(0, 4)}-${sub.substring(4, 8)}-${sub.substring(8, 12)}"
        } catch (_: Exception) {
            "TKPR-9999-8888-7777"
        }
    }

    /**
     * 3. Kiểm tra Mã kích hoạt người dùng nhập vào (Nhận diện tự động cả Key Pro Thiết Bị và Key Pro Tài Khoản TKPR-...
     * trên mọi biến thể ID hợp lệ của thiết bị hiện tại)
     */
    fun verifyLicenseKey(context: Context, inputKey: String): Boolean {
        val cleanInput = inputKey.replace("-", "").replace(" ", "").trim().uppercase()
        if (cleanInput.length < 8) return false

        val candidateKeys = getAllCandidateLicenseKeys(context)
        for ((expectedKey, isAccountTier) in candidateKeys) {
            val cleanExpected = expectedKey.replace("-", "").replace(" ", "").trim().uppercase()
            if (cleanExpected.isNotBlank() && cleanInput == cleanExpected) {
                val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                prefs.edit().putBoolean(KEY_REVOKED_BY_ADMIN, false).apply()
                // QUY TẮC BẢO VỆ KHÁCH PRO: Nếu máy đang ở gói Pro Tài Khoản, nhập mã Pro Thiết Bị cũng tuyệt đối không bao giờ hạ cấp xuống Pro Thiết Bị
                val preserveAccountTier = isAccountTier || isAccountProActivated(context) || isUpgradedToAccountPro(context)
                if (preserveAccountTier) {
                    val keyToSave = if (isAccountTier) expectedKey else generateAccountProLicenseKeyForDevice(getDeviceId(context))
                    activateAccountPro(context, keyToSave, syncToCloud = true)
                } else {
                    setProActivated(context, true, expectedKey, syncToCloud = true)
                }
                return true
            }
        }
        return false
    }

    /**
     * Kiểm tra trạng thái đã kích hoạt PRO chưa (Tính cả quyền Admin hoặc Chế độ Free toàn cục)
     */
    private const val SECURE_KEY_PRO_HW_SIG = "magictune_pro_hw_sig"

    /**
     * Kiểm tra xem người dùng đang có gói PRO TÀI KHOẢN (Account Pro - Đổi máy tự do, tối đa 1 máy đăng nhập cùng lúc) hay không
     */
    /**
     * Kiểm tra xem người dùng đang có gói PRO TÀI KHOẢN (Account Pro - Đổi máy tự do, tối đa 1 máy đăng nhập cùng lúc) hay không
     */
    fun isAccountProActivated(context: Context): Boolean {
        if (isAdminSimulateFreeMode(context)) return false
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_REVOKED_BY_ADMIN, false)) return false
        if (isCurrentUserAdmin(context)) return true
        if (prefs.getBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false)) {
            return verifyProIntegritySeal(context)
        }
        return false
    }

    /**
     * Kiểm tra xem máy này đã từng nâng cấp từ Pro Thiết Bị lên Pro Tài Khoản chưa.
     * Khi đã chuyển đổi từ Pro Thiết Bị lên Pro Tài Khoản, quyền Pro sẽ đi theo Tài Khoản (nếu đăng nhập sang máy mới thì máy cũ đăng xuất và nhường quyền Pro cho máy mới).
     */
    fun isUpgradedToAccountPro(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_UPGRADED_TO_ACCOUNT_PRO, false)
    }

    /**
     * Kiểm tra xem máy đang ở gói PRO THIẾT BỊ (chưa nâng cấp lên Pro Tài Khoản) hay không
     */
    fun isDeviceProOnly(context: Context): Boolean {
        if (isAccountProActivated(context)) return false
        return isProActivated(context)
    }

    fun getProTierLabel(context: Context): String {
        if (isCurrentUserAdmin(context)) return "👑 ADMIN TOÀN QUYỀN"
        if (isAccountProActivated(context)) return "👑 PRO TÀI KHOẢN (Đổi máy tự do • 1 máy/lần)"
        if (isProActivated(context)) return "📱 PRO THIẾT BỊ (Cố định theo ID máy)"
        return "🔓 BẢN MIỄN PHÍ"
    }

    fun hasPendingAccountProBind(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_PENDING_ACCOUNT_PRO_BIND, false)
    }

    /**
     * Kích hoạt hoặc Nâng cấp lên gói PRO TÀI KHOẢN (Account-bound Pro).
     * Khi nâng cấp từ Pro Thiết Bị lên Pro Tài Khoản:
     * - Quyền Pro được gắn vào tài khoản đang đăng nhập (hoặc chờ gắn ngay khi đăng nhập).
     * - Chữ ký cứng theo ID máy cũ được gỡ bỏ để chuyển thành bản quyền theo Tài Khoản (đảm bảo quy tắc 1 máy duy nhất khi đổi sang máy khác).
     */
    private const val KEY_PRO_CRYPTO_SEAL = "pro_hw_crypto_seal_v28"
    private const val KEY_ADMIN_CRYPTO_SEAL = "admin_hw_crypto_seal_v28"
    private const val KEY_FREE_MODE_CRYPTO_SEAL = "free_mode_hw_crypto_seal_v28"
    private const val KEY_TRIAL_LIMIT_CRYPTO_SEAL = "trial_limit_hw_crypto_seal_v28"
    private const val SECURE_KEY_TRIAL_USED = "magictune_trial_used_secure"

    @Volatile
    private var lastTamperReportMs: Long = 0L

    private fun computeHardwareCryptoSealWithHw(devId: String, hwId: String, scopeTag: String, rawValue: String): String {
        return try {
            val payload = "$SECRET_SALT|$ACCOUNT_PRO_SALT|$devId|$hwId|$scopeTag|$rawValue|v2.8.1"
            val digest = MessageDigest.getInstance("SHA-256").digest(payload.toByteArray(Charsets.UTF_8))
            digest.joinToString("") { "%02X".format(it) }.take(32)
        } catch (_: Throwable) {
            ""
        }
    }

    private fun computeHardwareCryptoSeal(context: Context, scopeTag: String, rawValue: String): String {
        return try {
            val devId = getDeviceId(context).uppercase().trim()
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val savedHw = prefs.getString("cached_widevine_hw_id", null)?.uppercase()?.trim()
            val hwId = if (!savedHw.isNullOrBlank()) {
                savedHw
            } else {
                val rawHw = getHardwareId().uppercase().trim()
                if (rawHw.isNotBlank()) {
                    prefs.edit().putString("cached_widevine_hw_id", rawHw).apply()
                }
                rawHw
            }
            computeHardwareCryptoSealWithHw(devId, hwId, scopeTag, rawValue)
        } catch (_: Throwable) {
            ""
        }
    }

    /**
     * Chữ ký xác thực toàn cầu cho các cấu hình hệ thống từ Cloud Firestore (app_config/global)
     * Không gắn với phần cứng đơn lẻ để đảm bảo đồng bộ hoàn hảo giữa máy Admin và mọi máy người dùng.
     */
    private fun computeGlobalConfigSeal(scopeTag: String, rawValue: String): String {
        return try {
            val payload = "$SECRET_SALT|GLOBAL_CFG|$scopeTag|$rawValue|v2.9.0"
            val digest = MessageDigest.getInstance("SHA-256").digest(payload.toByteArray(Charsets.UTF_8))
            digest.joinToString("") { "%02X".format(it) }.take(32)
        } catch (_: Throwable) {
            ""
        }
    }

    fun writeProIntegritySeal(context: Context, isPro: Boolean, isAccPro: Boolean) {
        try {
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            if (!isPro && !isAccPro) {
                cachedProIntegritySealState = null
                prefs.edit().remove(KEY_PRO_CRYPTO_SEAL).apply()
                return
            }
            val seal = computeHardwareCryptoSeal(context, "PRO_INTEGRITY", "PRO=$isPro|ACC=$isAccPro")
            cachedProIntegritySealState = "PRO=$isPro|ACC=$isAccPro|$seal" to true
            prefs.edit().putString(KEY_PRO_CRYPTO_SEAL, seal).apply()
        } catch (_: Throwable) {}
    }

    private fun verifyProIntegritySeal(context: Context): Boolean {
        return try {
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            if (prefs.getBoolean(KEY_REVOKED_BY_ADMIN, false)) return false
            val localPro = prefs.getBoolean(KEY_PRO_ACTIVATED, false)
            val localAcc = prefs.getBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false)
            if (!localPro && !localAcc) return false

            val storedSeal = prefs.getString(KEY_PRO_CRYPTO_SEAL, "") ?: ""
            val stateKey = "PRO=$localPro|ACC=$localAcc|$storedSeal"
            cachedProIntegritySealState?.let { (cachedKey, cachedValid) ->
                if (cachedKey == stateKey) return cachedValid
            }

            val devId = getDeviceId(context).uppercase().trim()
            val expectedSeal = computeHardwareCryptoSeal(context, "PRO_INTEGRITY", "PRO=$localPro|ACC=$localAcc")
            val expectedFastSeal = computeHardwareCryptoSealWithHw(devId, "", "PRO_INTEGRITY", "PRO=$localPro|ACC=$localAcc")
            if (storedSeal.isNotBlank() && (storedSeal == expectedSeal || storedSeal == expectedFastSeal)) {
                cachedProIntegritySealState = stateKey to true
                return true
            }

            // Nếu đang ở trên Main Thread và Widevine Hardware ID chưa kịp nạp xong trên IO, tạm tin cậy storedSeal có độ dài chuẩn 32 ký tự SHA-256
            if (storedSeal.length == 32 && cachedHardwareId == null && android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
                return true
            }

            // Chỉ cho phép nâng cấp niêm phong nếu thiết bị đang có sẵn Mã Key mật mã SHA-256 hợp lệ của chính thiết bị này
            // hoặc phiên bản quyền hợp lệ từ Tài Khoản / Đám mây (tránh thu hồi oan người dùng Pro Tài Khoản chính chủ)
            val savedKey = (prefs.getString(KEY_ACTIVATED_LICENSE, "") ?: "").replace("-", "").replace(" ", "").trim().uppercase()
            val candidateKeys = getAllCandidateLicenseKeys(context)
            val hasValidCryptoKey = savedKey.length >= 12 && candidateKeys.any { (k, _) ->
                k.replace("-", "").replace(" ", "").trim().uppercase() == savedKey
            }
            val activeUser = try { com.google.firebase.Firebase.auth.currentUser?.takeIf { !it.isAnonymous } } catch (_: Exception) { null }
            val isRecognizedSystemKey = savedKey.startsWith("ADMIN_") ||
                savedKey.startsWith("SESSION_BORROWED") ||
                savedKey.startsWith("FIREBASE_") ||
                savedKey.startsWith("CLOUD_") ||
                savedKey.startsWith("ACCOUNT_PRO_") ||
                savedKey.startsWith("TKPR") ||
                savedKey.startsWith("CHAT_") ||
                savedKey.startsWith("AI_AUTO") ||
                savedKey.startsWith("AUTO_BANK") ||
                savedKey.startsWith("ONLINE_") ||
                savedKey.contains("GRANTED") ||
                savedKey.contains("RESTORED") ||
                savedKey.contains("VERIFIED") ||
                savedKey.length >= 12
            val isLegitimateAccountSession = activeUser != null && (localAcc || prefs.getBoolean(KEY_BORROWED_ACCOUNT_PRO_SESSION, false) || isRecognizedSystemKey)

            if (hasValidCryptoKey || (savedKey.startsWith("ADMIN_") && isCurrentUserAdmin(context)) || isLegitimateAccountSession || (isRecognizedSystemKey && !prefs.getBoolean(KEY_REVOKED_BY_ADMIN, false))) {
                writeProIntegritySeal(context, localPro, localAcc)
                return true
            }

            // Phát hiện can thiệp sửa file SharedPreferences XML trái phép (Mod / Hack APK / Clone dữ liệu)
            cachedProIntegritySealState = null
            prefs.edit()
                .putBoolean(KEY_PRO_ACTIVATED, false)
                .putBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false)
                .remove(KEY_PRO_CRYPTO_SEAL)
                .remove(KEY_ACTIVATED_LICENSE)
                .apply()
            reportTamperAttemptToCloud(context, "Phát hiện sửa đổi trái phép cờ Pro trong SharedPreferences XML (Không có chữ ký phần cứng SHA-256 hợp lệ)")
            false
        } catch (_: Throwable) {
            false
        }
    }

    private fun reportTamperAttemptToCloud(context: Context, reason: String) {
        val now = System.currentTimeMillis()
        if (now - lastTamperReportMs < 60_000L) return
        lastTamperReportMs = now
        try {
            val appCtx = context.applicationContext
            val deviceId = getDeviceId(appCtx).uppercase()
            val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
            val logId = "sec_${deviceId}_$now"
            val payload = mapOf(
                "id" to logId,
                "appId" to "magictune",
                "deviceId" to deviceId,
                "deviceModel" to "${Build.MANUFACTURER} ${Build.MODEL}",
                "userEmail" to (user?.email ?: "Khách vãng lai"),
                "userName" to (user?.displayName ?: "Cảnh báo Bảo mật"),
                "userMessage" to "🚨 [CẢNH BÁO MOD/HACK] $reason",
                "aiReply" to "🛡️ Hệ thống Anti-Mod SHA-256 đã tự động chặn và thu hồi trạng thái Pro giả mạo trên thiết bị $deviceId.",
                "proGranted" to false,
                "securityEvent" to "SECURITY_MOD_TAMPER_BLOCKED",
                "createdAt" to FieldValue.serverTimestamp()
            )
            if (user == null) {
                FirestoreRestTokenBridge.patchDocAsync(appCtx, "ai_pro_chat_logs", logId, payload)
            } else {
                FirebaseFirestore.getInstance().collection("ai_pro_chat_logs").document(logId).set(payload, SetOptions.merge())
            }
        } catch (_: Throwable) {}
    }

    @Volatile
    private var cachedSecureTrialCount: Int? = null

    private fun syncTrialCountToSecureStorage(context: Context, countUsed: Int) {
        cachedSecureTrialCount = countUsed
        val appCtx = context.applicationContext
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            try {
                Settings.Secure.putInt(appCtx.contentResolver, SECURE_KEY_TRIAL_USED, countUsed)
            } catch (_: Throwable) {}
        }
        try {
            com.example.core.shell.ShellEngine.getInstance(appCtx)
                .setPersistedSetting("secure", SECURE_KEY_TRIAL_USED, countUsed.toString())
        } catch (_: Throwable) {}
    }

    @Volatile
    private var isReadingTrialCountAsync: Boolean = false

    private fun readTrialCountFromSecureStorage(context: Context): Int {
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            cachedSecureTrialCount?.let { return it }
            if (!isReadingTrialCountAsync) {
                isReadingTrialCountAsync = true
                val appCtx = context.applicationContext
                kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                    try {
                        readTrialCountFromSecureStorage(appCtx)
                    } finally {
                        isReadingTrialCountAsync = false
                    }
                }
            }
            return 0
        }
        val fromShell = try {
            com.example.core.shell.ShellEngine.getInstance(context.applicationContext)
                .getPersistedSetting("secure", SECURE_KEY_TRIAL_USED)?.toIntOrNull() ?: 0
        } catch (_: Throwable) {
            0
        }
        val fromSecure = cachedSecureTrialCount ?: try {
            Settings.Secure.getInt(context.contentResolver, SECURE_KEY_TRIAL_USED, 0)
        } catch (_: Throwable) {
            0
        }
        val resolved = maxOf(0, fromSecure, fromShell)
        cachedSecureTrialCount = resolved
        return resolved
    }

    /**
     * Kiểm tra xem thiết bị hiện tại có SỞ HỮU MÃ KEY KÍCH HOẠT VĨNH VIỄN CỦA RIÊNG MÁY NÀY hay không:
     * - Trả về `true` nếu chính máy này đã mua Pro / kích hoạt bằng Key SHA-256 gắn với ID của máy này (Máy gốc đầu tiên).
     * - Trả về `false` nếu máy này là máy phụ/máy mới chỉ được hưởng quyền Pro tạm thời nhờ đang đăng nhập một Tài Khoản Pro (`isBorrowedFromAccountLogin == true`).
     *   Khi đó: máy phụ vẫn có đầy đủ tính năng Pro khi đang đăng nhập, KHÔNG hiện Key kích hoạt cố định, và khi đăng xuất sẽ quay về bản Miễn Phí!
     */
    fun hasOwnDevicePermanentKey(context: Context): Boolean {
        if (isCurrentUserAdmin(context)) return true
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_REVOKED_BY_ADMIN, false)) return false
        if (prefs.getBoolean(KEY_BORROWED_ACCOUNT_PRO_SESSION, false)) return false
        val savedKey = (prefs.getString(KEY_ACTIVATED_LICENSE, "") ?: "").trim()
        if (savedKey.equals("SESSION_BORROWED_ACCOUNT_PRO", ignoreCase = true)) return false
        return isProActivated(context)
    }

    fun activateAccountPro(
        context: Context,
        licenseKey: String = "ACCOUNT_PRO_UPGRADED",
        syncToCloud: Boolean = true,
        isBorrowedFromAccountLogin: Boolean = false
    ) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
        val isLoggedIn = user != null && !user.uid.isBlank()
        val effectiveKey = if (isBorrowedFromAccountLogin) "SESSION_BORROWED_ACCOUNT_PRO" else licenseKey

        prefs.edit()
            .putBoolean(KEY_REVOKED_BY_ADMIN, false)
            .putBoolean(KEY_PRO_ACTIVATED, true)
            .putBoolean(KEY_ACCOUNT_PRO_ACTIVATED, true)
            .putBoolean(KEY_UPGRADED_TO_ACCOUNT_PRO, !isBorrowedFromAccountLogin)
            .putBoolean(KEY_BORROWED_ACCOUNT_PRO_SESSION, isBorrowedFromAccountLogin)
            .putBoolean(KEY_PENDING_ACCOUNT_PRO_BIND, !isLoggedIn && !isBorrowedFromAccountLogin)
            .putString(KEY_ACTIVATED_LICENSE, effectiveKey)
            .apply()
        writeProIntegritySeal(context, isPro = true, isAccPro = true)
        _isProFlow.value = true

        if (isBorrowedFromAccountLogin) {
            // Máy phụ đăng nhập Tài Khoản Pro: Tuyệt đối KHÔNG ghi Key cứng vĩnh viễn vào Settings.Secure
            try {
                Settings.Secure.putString(context.contentResolver, SECURE_KEY_PRO_HW_SIG, "")
            } catch (_: Exception) {}
        } else {
            // Máy gốc đầu tiên mua Pro Tài Khoản: Lưu chữ ký phần cứng để máy gốc luôn sở hữu Key vĩnh viễn
            persistHardwareProSignatureIfNeeded(context, true)
            autoSyncProToCloud(context, isAccount = true, effectiveKey)
        }

        if (syncToCloud) {
            try {
                val deviceId = getDeviceId(context).uppercase()
                val db = FirebaseFirestore.getInstance()
                val sessionToken = prefs.getString(KEY_ACTIVE_SESSION_TOKEN, "")
                    ?.takeIf { it.isNotBlank() }
                    ?: "${deviceId}_${System.currentTimeMillis()}".also {
                        prefs.edit().putString(KEY_ACTIVE_SESSION_TOKEN, it).apply()
                    }

                val hwId = getHardwareId()
                if (!isBorrowedFromAccountLogin) {
                    val devData = mutableMapOf<String, Any>(
                        "deviceId" to deviceId,
                        "hardwareId" to hwId,
                        "appId" to "magictune",
                        "product" to "MAGICTUNE_PRO",
                        "magictunePro" to true,
                        "model" to "${Build.MANUFACTURER} ${Build.MODEL}",
                        "isPro" to true,
                        "isAccountPro" to true,
                        "upgradedToAccountPro" to true,
                        "proTier" to "ACCOUNT_PRO",
                        "licenseKey" to effectiveKey,
                        "ownerUid" to (user?.uid ?: ""),
                        "ownerEmail" to (user?.email ?: "Ẩn danh (Chưa đăng nhập)"),
                        "ownerName" to (user?.displayName ?: "Người dùng Pro Tài Khoản"),
                        "revokedByAdmin" to false,
                        "proActivatedAt" to FieldValue.serverTimestamp(),
                        "proActivatedMs" to System.currentTimeMillis(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                    if (user == null) {
                        FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "devices", deviceId, devData)
                    } else {
                        db.collection("devices").document(deviceId).set(devData, SetOptions.merge())
                    }
                }

                if (user != null) {
                    val userUpdates = mutableMapOf<String, Any>(
                        "uid" to user.uid,
                        "email" to (user.email ?: ""),
                        "displayName" to (user.displayName ?: "Người dùng"),
                        "isPro" to true,
                        "isAccountPro" to true,
                        "proTier" to "ACCOUNT_PRO",
                        "activeDeviceId" to deviceId,
                        "activeDeviceModel" to "${Build.MANUFACTURER} ${Build.MODEL}",
                        "activeSessionToken" to sessionToken,
                        "revokedByAdmin" to false,
                        "lastLogin" to FieldValue.serverTimestamp()
                    )
                    if (!isBorrowedFromAccountLogin) {
                        userUpdates["licenseKey"] = effectiveKey
                        userUpdates["deviceId"] = deviceId
                        userUpdates["proActivatedAt"] = FieldValue.serverTimestamp()
                        userUpdates["proActivatedMs"] = System.currentTimeMillis()
                        userUpdates["accountProActivatedAt"] = FieldValue.serverTimestamp()
                    }
                    db.collection("users").document(user.uid).set(userUpdates, SetOptions.merge())
                }
            } catch (_: Exception) {}
        }

        notifyProAndConfigStateChanged(context)
    }

    /**
     * Khi người dùng Đăng Xuất:
     * - Nếu đây là MÁY PHỤ đang dùng Pro nhờ đăng nhập Tài Khoản Pro (`KEY_BORROWED_ACCOUNT_PRO_SESSION == true` / không có Key vĩnh viễn riêng):
     *   Khi đăng xuất tài khoản, máy phụ lập tức quay về bản Miễn Phí (chỉ là Pro khi đang đăng nhập Tài Khoản Pro!).
     * - Nếu đây là MÁY GỐC đã mua Pro và sở hữu Key vĩnh viễn riêng (`hasOwnDevicePermanentKey == true`):
     *   Khi đăng xuất (mà chưa đăng nhập sang máy khác), máy gốc vẫn giữ nguyên quyền Pro.
     */
    fun deactivateAccountProOnLogout(context: Context) {
        if (isCurrentUserAdmin(context)) return // Admin không bị thu hồi Pro khi đăng xuất
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val isBorrowedSession = prefs.getBoolean(KEY_BORROWED_ACCOUNT_PRO_SESSION, false) ||
            (prefs.getString(KEY_ACTIVATED_LICENSE, "") ?: "").equals("SESSION_BORROWED_ACCOUNT_PRO", ignoreCase = true)

        if (isBorrowedSession) {
            prefs.edit()
                .putBoolean(KEY_PRO_ACTIVATED, false)
                .putBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false)
                .putBoolean(KEY_UPGRADED_TO_ACCOUNT_PRO, false)
                .putBoolean(KEY_BORROWED_ACCOUNT_PRO_SESSION, false)
                .putBoolean(KEY_PENDING_ACCOUNT_PRO_BIND, false)
                .remove(KEY_ACTIVATED_LICENSE)
                .remove(KEY_PRO_CRYPTO_SEAL)
                .remove(KEY_ACTIVE_SESSION_TOKEN)
                .apply()
            try {
                Settings.Secure.putString(context.contentResolver, SECURE_KEY_PRO_HW_SIG, "")
            } catch (_: Exception) {}
            _isProFlow.value = false
        } else {
            prefs.edit()
                .remove(KEY_ACTIVE_SESSION_TOKEN)
                .apply()
        }
        notifyProAndConfigStateChanged(context)
    }

    /**
     * Thu hồi quyền Pro Tài Khoản trên máy cũ khi phát hiện tài khoản đã thực sự đăng nhập trên Thiết Bị Mới (Single-Device Transfer)
     * hoặc khi bị Admin thu hồi trực tiếp trên Cloud.
     */
    fun revokeAccountProOnDeviceTransfer(context: Context) {
        if (isCurrentUserAdmin(context)) return
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val wasUpgradedToAccountPro = prefs.getBoolean(KEY_UPGRADED_TO_ACCOUNT_PRO, false)
        val wasAccountPro = prefs.getBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false)
        val wasBorrowed = prefs.getBoolean(KEY_BORROWED_ACCOUNT_PRO_SESSION, false)

        val editor = prefs.edit()
            .putBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false)
            .putBoolean(KEY_BORROWED_ACCOUNT_PRO_SESSION, false)
            .putBoolean(KEY_PENDING_ACCOUNT_PRO_BIND, false)
            .remove(KEY_ACTIVE_SESSION_TOKEN)

        if (wasAccountPro || wasUpgradedToAccountPro || wasBorrowed) {
            editor.putBoolean(KEY_PRO_ACTIVATED, false)
            editor.remove(KEY_ACTIVATED_LICENSE)
            editor.remove(KEY_PRO_CRYPTO_SEAL)
            try {
                Settings.Secure.putString(context.contentResolver, SECURE_KEY_PRO_HW_SIG, "")
            } catch (_: Exception) {}
        }
        editor.apply()
        _isProFlow.value = isProActivated(context)
        notifyProAndConfigStateChanged(context)
    }

    /**
     * Kiểm tra trạng thái đã kích hoạt PRO chưa (Tính cả Pro Tài Khoản, Pro Thiết Bị, quyền Admin,
     * kiểm tra niêm phong mật mã phần cứng SHA-256 chống Mod/Hack XML, và tự động phục hồi tức thì từ Settings.Secure khi gỡ app cài lại)
     */
    fun isProActivated(context: Context): Boolean {
        if (isAdminSimulateFreeMode(context)) return false
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_REVOKED_BY_ADMIN, false)) {
            return false
        }
        if (isCurrentUserAdmin(context)) {
            return true
        }
        if (prefs.getBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false) || prefs.getBoolean(KEY_PRO_ACTIVATED, false)) {
            if (verifyProIntegritySeal(context)) {
                return true
            }
        }
        // Không bao giờ chạy Settings.Secure + băm SHA-256 trên Main Thread để triệt tiêu 100% nghẽn IPC / ANR
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            if (!hasCheckedSecureStorageFallback) {
                val appCtx = context.applicationContext
                kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                    isProActivated(appCtx)
                }
            }
            return false
        }
        if (!hasCheckedSecureStorageFallback) {
            hasCheckedSecureStorageFallback = true
            try {
                val secEmail = Settings.Secure.getString(context.contentResolver, "magictune_familiar_email")?.trim()?.lowercase().orEmpty()
                if (secEmail.contains("@") && prefs.getString("last_familiar_email", "").isNullOrBlank()) {
                    prefs.edit()
                        .putString("last_familiar_email", secEmail)
                        .putBoolean("is_familiar_device_recognized", true)
                        .apply()
                }
            } catch (_: Exception) {}

            // Tự động nhận biết chữ ký phần cứng Pro đã lưu trong Settings.Secure (Hỗ trợ cả Pro Thiết Bị và Pro Tài Khoản khi gỡ app cài lại)
            try {
                val savedSig = Settings.Secure.getString(context.contentResolver, SECURE_KEY_PRO_HW_SIG)
                    ?.replace("-", "")?.replace(" ", "")?.trim()?.uppercase()
                if (!savedSig.isNullOrBlank() && savedSig.length >= 8) {
                    val candidateKeys = getAllCandidateLicenseKeys(context)
                    for ((expectedKey, isAcc) in candidateKeys) {
                        val cleanExpected = expectedKey.replace("-", "").replace(" ", "").trim().uppercase()
                        if (cleanExpected.isNotBlank() && savedSig == cleanExpected) {
                            prefs.edit()
                                .putBoolean(KEY_PRO_ACTIVATED, true)
                                .putBoolean(KEY_ACCOUNT_PRO_ACTIVATED, isAcc)
                                .putBoolean(KEY_UPGRADED_TO_ACCOUNT_PRO, isAcc)
                                .putString(KEY_ACTIVATED_LICENSE, expectedKey)
                                .apply()
                            writeProIntegritySeal(context, isPro = true, isAccPro = isAcc)
                            _isProFlow.value = true
                            return true
                        }
                    }
                }
            } catch (_: Exception) {}
        }
        return false
    }

    private const val KEY_VERIFIED_ADMIN_EMAIL = "verified_admin_email"
    @Volatile
    private var cachedVerifiedAdminEmailInRam: String = ""
    @Volatile
    private var adminFastPassState: Int = 0 // 1 = Đã xác thực Admin tức thì 0ns trong phiên
    @Volatile
    private var isMarkingAdminInProgress: Boolean = false
    @Volatile
    private var lastAdminCachePrewarmMs: Long = 0L

    fun prewarmAdminSessionAndCacheAsync(context: Context) {
        val now = System.currentTimeMillis()
        if (now - lastAdminCachePrewarmMs < 45_000L) return
        lastAdminCachePrewarmMs = now
        val appCtx = context.applicationContext
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            try {
                // Hydrate offline disk cache into AdminSessionCache immediately (0ms UI opening)
                com.example.core.auth.AdminSessionCache.ensureOfflineHydrated(appCtx)
                // Warm Bearer token & fresh snapshots silently in background
                FirestoreRestTokenBridge.getValidBearerToken(appCtx, forceRefresh = false)
                com.example.core.auth.AdminSessionCache.refreshFromCloud(appCtx, force = false)
            } catch (_: Throwable) {}
        }
    }

    fun markLocalAdminVerified(context: Context, email: String) {
        val clean = email.trim().lowercase()
        if (clean.isBlank()) return
        adminFastPassState = 1
        if (cachedVerifiedAdminEmailInRam == clean) {
            if (!adminPendingOrderListenerStarted && !isMarkingAdminInProgress) {
                startAdminPendingOrderPushListener(context)
            }
            prewarmAdminSessionAndCacheAsync(context)
            return
        }
        if (isMarkingAdminInProgress) return
        isMarkingAdminInProgress = true
        cachedVerifiedAdminEmailInRam = clean
        val appCtx = context.applicationContext
        prewarmAdminSessionAndCacheAsync(appCtx)
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                try {
                    val seal = computeHardwareCryptoSeal(appCtx, "ADMIN_VERIFIED", clean)
                    val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    prefs.edit()
                        .putString("current_user_email", clean)
                        .putString("current_user_role", "admin")
                        .putString(KEY_VERIFIED_ADMIN_EMAIL, clean)
                        .putString(KEY_ADMIN_CRYPTO_SEAL, seal)
                        .apply()
                    putSecureConfigString(appCtx, KEY_VERIFIED_ADMIN_EMAIL, clean)
                    putSecureConfigString(appCtx, KEY_ADMIN_CRYPTO_SEAL, seal)
                    startAdminPendingOrderPushListener(appCtx)
                } catch (_: Throwable) {
                } finally {
                    isMarkingAdminInProgress = false
                }
            }
            return
        }
        try {
            val seal = computeHardwareCryptoSeal(appCtx, "ADMIN_VERIFIED", clean)
            val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putString("current_user_email", clean)
                .putString("current_user_role", "admin")
                .putString(KEY_VERIFIED_ADMIN_EMAIL, clean)
                .putString(KEY_ADMIN_CRYPTO_SEAL, seal)
                .apply()
            putSecureConfigString(appCtx, KEY_VERIFIED_ADMIN_EMAIL, clean)
            putSecureConfigString(appCtx, KEY_ADMIN_CRYPTO_SEAL, seal)
            startAdminPendingOrderPushListener(appCtx)
        } catch (_: Throwable) {
        } finally {
            isMarkingAdminInProgress = false
        }
    }

    fun clearLocalAdminSession(context: Context) {
        cachedVerifiedAdminEmailInRam = ""
        adminFastPassState = 0
        lastAdminHeartbeatRamCheckMs = 0L
        try {
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .remove("current_user_role")
                .remove("current_user_email")
                .remove(KEY_VERIFIED_ADMIN_EMAIL)
                .remove(KEY_ADMIN_CRYPTO_SEAL)
                .apply()
            putSecureConfigString(context, KEY_VERIFIED_ADMIN_EMAIL, "")
            putSecureConfigString(context, KEY_ADMIN_CRYPTO_SEAL, "")
        } catch (_: Throwable) {}
    }

    fun isCurrentUserAdmin(context: Context): Boolean {
        // ⚡ TẦNG 1: Fast-Pass 0ns từ RAM nếu đã xác thực Admin trong phiên
        if (adminFastPassState == 1 && cachedVerifiedAdminEmailInRam.isNotBlank()) {
            return true
        }
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val savedEmail = (prefs.getString("current_user_email", "") ?: "").trim()
        val savedRole = (prefs.getString("current_user_role", "user") ?: "user").trim()
        val verifiedAdminEmail = (prefs.getString(KEY_VERIFIED_ADMIN_EMAIL, "") ?: "").trim().lowercase()

        // ⚡ TẦNG 2: Khớp tức thì từ SharedPreferences (0ms, không gọi Binder/IPC trên Main Thread)
        if (savedEmail.equals(ADMIN_EMAIL, ignoreCase = true) ||
            savedEmail.equals("vuongdhkmhn@gmail.com", ignoreCase = true) ||
            verifiedAdminEmail.equals(ADMIN_EMAIL, ignoreCase = true) ||
            verifiedAdminEmail.equals("vuongdhkmhn@gmail.com", ignoreCase = true) ||
            (savedRole.equals("admin", ignoreCase = true) && (savedEmail.isNotBlank() || verifiedAdminEmail.isNotBlank()))
        ) {
            val adminId = savedEmail.ifBlank { verifiedAdminEmail }.ifBlank { ADMIN_EMAIL }.lowercase()
            cachedVerifiedAdminEmailInRam = adminId
            adminFastPassState = 1
            prewarmAdminSessionAndCacheAsync(context)
            return true
        }

        val user = try { Firebase.auth.currentUser?.takeIf { !it.isAnonymous } } catch (_: Exception) { null }
        val email = (user?.email ?: "").trim()
        val phone = (user?.phoneNumber ?: "").trim()
        val isDirectAdminMatch = email.equals(ADMIN_EMAIL, ignoreCase = true) ||
            email.equals("vuongdhkmhn@gmail.com", ignoreCase = true) ||
            (phone.isNotBlank() && phone.contains(ADMIN_PHONE))

        if (isDirectAdminMatch) {
            val adminIdentifier = if (email.isNotBlank()) email.lowercase() else ADMIN_EMAIL
            adminFastPassState = 1
            if (cachedVerifiedAdminEmailInRam != adminIdentifier) {
                markLocalAdminVerified(context, adminIdentifier)
            }
            updateAdminHeartbeat(context)
            return true
        }
        if (user != null && savedRole.equals("admin", ignoreCase = true)) {
            val adminIdentifier = if (email.isNotBlank()) email.lowercase() else ADMIN_EMAIL
            adminFastPassState = 1
            if (cachedVerifiedAdminEmailInRam != adminIdentifier) {
                markLocalAdminVerified(context, adminIdentifier)
            }
            updateAdminHeartbeat(context)
            return true
        }
        if (verifiedAdminEmail.isNotBlank()) {
            val storedSeal = (prefs.getString(KEY_ADMIN_CRYPTO_SEAL, null) ?: "").trim()
            if (storedSeal.length == 32) {
                cachedVerifiedAdminEmailInRam = verifiedAdminEmail
                adminFastPassState = 1
                prewarmAdminSessionAndCacheAsync(context)
                return true
            }
        }
        return false
    }

    /**
     * Cổng kiểm duyệt duy nhất cho MỌI tính năng Pro trong ứng dụng.
     * Trả về Pair(ĐượcPhépChạy, ThôngBáoLog)
     */
    fun checkAndConsumeProOrTrial(context: Context, actionName: String): Pair<Boolean, String> {
        val isFreeMode = isAppFreeMode(context)
        val isSimulateFree = isAdminSimulateFreeMode(context)
        val isAdmin = isCurrentUserAdmin(context) && !isSimulateFree
        val isPro = isProActivated(context) && !isSimulateFree

        if (isAdmin) {
            return true to "👑 [ADMIN] Mở khóa toàn quyền tính năng: $actionName"
        }
        if (isPro) {
            val tierTag = if (isAccountProActivated(context)) "PRO TÀI KHOẢN" else "PRO THIẾT BỊ"
            return true to "⚡ [$tierTag] Đang thực thi tính năng: $actionName"
        }
        if (isFreeMode && !isSimulateFree) {
            return true to "🎁 [CHẾ ĐỘ MIỄN PHÍ] Đang thực thi tính năng: $actionName"
        }

        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val trialLimit = getFreeTrialLimit(context).coerceAtLeast(0)
        val currentTrialUsed = getUsedFreeTrials(context)

        // Nếu vừa mới trừ lượt trong vòng 2.5 giây (do ViewModel gọi rồi Repository gọi lại trong cùng 1 nút bấm)
        val now = System.currentTimeMillis()
        if (now - lastTrialConsumedTimestampMs < 2500L && currentTrialUsed <= trialLimit && trialLimit > 0) {
            return true to "✨ [DÙNG THỬ $currentTrialUsed/$trialLimit] Đang thực thi: $actionName"
        }

        if (currentTrialUsed < trialLimit) {
            val nextUsed = currentTrialUsed + 1
            lastTrialConsumedTimestampMs = now
            prefs.edit()
                .putInt("free_trial_count_used", nextUsed)
                .putBoolean(KEY_FREE_TRIAL_USED, nextUsed >= trialLimit)
                .apply()
            syncTrialCountToSecureStorage(context, nextUsed)
            syncDevicePresenceToCloud(context)
            return true to "✨ [BẢN MIỄN PHÍ - DÙNG THỬ LẦN $nextUsed/$trialLimit] Đã mở khóa dùng thử cho: '$actionName' (Còn lại ${trialLimit - nextUsed} lượt miễn phí)!"
        }

        return false to "🔒 TÍNH NĂNG BẢN QUYỀN PRO: Bạn đã dùng hết lượt miễn phí ($currentTrialUsed/$trialLimit lượt). Vui lòng nâng cấp Bản PRO Vĩnh Viễn để tiếp tục sử dụng '$actionName'!"
    }

    fun getRemainingFreeTrials(context: Context): Int {
        val limit = getFreeTrialLimit(context).coerceAtLeast(0)
        val used = getUsedFreeTrials(context)
        return (limit - used).coerceAtLeast(0)
    }

    /**
     * Toàn bộ tính năng AI đã chuyển sang dùng Groq miễn phí 100%, luôn mở cho tất cả mọi người
     * và tiết kiệm tối đa chi phí duy trì cho Admin.
     */
    fun canAccessMagicLive(@Suppress("UNUSED_PARAMETER") context: Context): Boolean {
        return true
    }

    fun getUsedFreeTrials(context: Context): Int {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val prefsUsed = prefs.getInt("free_trial_count_used", 0).coerceAtLeast(0)
        val secureUsed = readTrialCountFromSecureStorage(context)
        val actualUsed = maxOf(prefsUsed, secureUsed)
        if (actualUsed > prefsUsed) {
            prefs.edit()
                .putInt("free_trial_count_used", actualUsed)
                .putBoolean(KEY_FREE_TRIAL_USED, actualUsed >= getFreeTrialLimit(context))
                .apply()
        }
        return actualUsed
    }

    fun setProActivated(context: Context, activated: Boolean, licenseKey: String = "", syncToCloud: Boolean = true) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val editor = prefs.edit()
            .putBoolean(KEY_PRO_ACTIVATED, activated)
            .putBoolean(KEY_BORROWED_ACCOUNT_PRO_SESSION, false)
            .putString(KEY_ACTIVATED_LICENSE, licenseKey)
        if (activated) {
            editor.putBoolean(KEY_REVOKED_BY_ADMIN, false)
        } else {
            editor.putBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false)
        }
        editor.apply()
        writeProIntegritySeal(context, isPro = activated, isAccPro = if (activated) prefs.getBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false) else false)
        _isProFlow.value = activated

        // Lưu chữ ký bản quyền theo Device ID vào Settings.Secure của hệ thống (Chỉ áp dụng cho Pro Thiết Bị chưa chuyển lên Pro Tài Khoản)
        persistHardwareProSignatureIfNeeded(context, activated)

        if (activated) {
            autoSyncProToCloud(context, prefs.getBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false), licenseKey)
        }

        if (syncToCloud) {
            try {
                val deviceId = getDeviceId(context).uppercase()
                val hwId = getHardwareId()
                val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
                val db = FirebaseFirestore.getInstance()
                val data = mutableMapOf<String, Any>(
                    "deviceId" to deviceId,
                    "hardwareId" to hwId,
                    "model" to "${Build.MANUFACTURER} ${Build.MODEL}",
                    "isPro" to activated,
                    "licenseKey" to licenseKey,
                    "ownerUid" to (user?.uid ?: ""),
                    "ownerEmail" to (user?.email ?: "Ẩn danh (Chưa đăng nhập)"),
                    "ownerName" to (user?.displayName ?: "Thiết bị không tài khoản"),
                    "freeTrialUsed" to getUsedFreeTrials(context),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (activated) {
                    data["appId"] = "magictune"
                    data["product"] = "MAGICTUNE_PRO"
                    data["magictunePro"] = true
                    data["revokedByAdmin"] = false
                    data["proActivatedAt"] = FieldValue.serverTimestamp()
                }
                val normDevId = normalizeDeviceIdForMatch(deviceId)
                if (user == null) {
                    FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "devices", deviceId, data)
                    if (normDevId.isNotBlank() && normDevId != deviceId) {
                        FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "devices", normDevId, data)
                    }
                } else {
                    db.collection("devices").document(deviceId).set(data, SetOptions.merge())
                    if (normDevId.isNotBlank() && normDevId != deviceId) {
                        db.collection("devices").document(normDevId).set(data, SetOptions.merge())
                    }
                }

                if (user != null && activated) {
                    val userUpdates = mutableMapOf<String, Any>(
                        "isPro" to true,
                        "deviceId" to deviceId,
                        "revokedByAdmin" to false,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                    // Nếu tài khoản chưa từng là Account Pro thật sự thì đảm bảo không bị nhận nhầm thành Pro Tài Khoản
                    val isTrueAccPro = isAccountProActivated(context) &&
                        (prefs.getString(KEY_ACTIVATED_LICENSE, "") ?: "").startsWith("TKPR-", ignoreCase = true)
                    if (!isTrueAccPro) {
                        userUpdates["isAccountPro"] = false
                        userUpdates["proTier"] = "DEVICE_PRO"
                    }
                    db.collection("users").document(user.uid).set(
                        userUpdates,
                        SetOptions.merge()
                    )
                }
            } catch (_: Exception) {}
        }

        notifyProAndConfigStateChanged(context)
    }

    /**
     * Cài đặt Chế độ AI Tự Động Duyệt & Nâng Cấp Pro thay cho Admin (Auto-Pilot Rảnh Tay 100%)
     */
    fun getCustomYouTubeUrl(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString("custom_youtube_url", null)?.trim()
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, "custom_youtube_url")?.trim()
        if (!sec.isNullOrBlank()) {
            prefs.edit().putString("custom_youtube_url", sec).apply()
            return sec
        }
        return "https://youtube.com/@hanoioptical?si=WnwybrI1qY6A5ngQ"
    }

    fun setCustomYouTubeUrl(context: Context, url: String) {
        val clean = url.trim().ifBlank { "https://youtube.com/@hanoioptical?si=WnwybrI1qY6A5ngQ" }
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString("custom_youtube_url", clean).apply()
        putSecureConfigString(context, "custom_youtube_url", clean)
        syncCloudGlobalConfigMap(context, mapOf("custom_youtube_url" to clean))
        notifyProAndConfigStateChanged(context)
    }

    data class VerifiedProGrantResult(
        val success: Boolean,
        val targetDeviceId: String,
        val isAccountPro: Boolean,
        val generatedKey: String,
        val isCurrentDeviceActivated: Boolean,
        val summaryMessage: String
    )

    /**
     * HÀM THỰC THI CẤP PRO CÓ KIỂM CHỨNG THẬT SỰ (VERIFIED PRO GRANT):
     * - Cho phép Trợ lý AI / Hệ thống Auto-Admin thực sự ghi quyền Pro vào bộ nhớ máy + Settings.Secure + Firestore (`devices` & `users`)
     * - Kiểm tra đối chiếu sau khi ghi (`isProActivated(context) == true`) để đảm bảo KHÔNG BAO GIỜ có chuyện AI nhắn đã lên Pro mà người dùng chưa nhận được quyền Pro!
     * - Hỗ trợ cấp Pro cho cả máy hiện tại lẫn cấp Pro từ xa theo bất kỳ mã `MT-XXXX` nào mà người dùng gửi trong khung chat.
     */
    fun executeVerifiedProGrant(
        context: Context,
        rawTargetDeviceId: String = "",
        grantAccountPro: Boolean = false,
        reason: String = "AI_AUTO_ADMIN_APPROVED"
    ): VerifiedProGrantResult {
        val currentDeviceId = getDeviceId(context).trim().uppercase()
        val normalizedTargetId = rawTargetDeviceId.trim().uppercase()
            .let { id ->
                if (id.isBlank() || id.length < 4) currentDeviceId
                else id
            }
        val normTargetMatch = normalizeDeviceIdForMatch(normalizedTargetId)
        val isTargetingCurrentDevice = normTargetMatch.isNotBlank() &&
            normTargetMatch == normalizeDeviceIdForMatch(currentDeviceId)

        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val currentLicense = (prefs.getString(KEY_ACTIVATED_LICENSE, "") ?: "").trim()
        val hasVerifiedAccountProKey = currentLicense.startsWith("TKPR-", ignoreCase = true)
        val isAlreadyAccountPro = isTargetingCurrentDevice && hasVerifiedAccountProKey && (
            isAccountProActivated(context) ||
                isUpgradedToAccountPro(context)
            )
        // CHỐT CHẶN BẢO MẬT TUYỆT ĐỐI: Không bao giờ tự động nâng cấp từ Pro Thiết Bị lên Pro Tài Khoản!
        // Chỉ cấp Pro Tài Khoản khi:
        // 1. `grantAccountPro == true` (Người dùng đã thanh toán đủ gói Pro TK >= 95k hoặc nâng cấp >= 50k, hoặc Admin chỉ định)
        // 2. Thiết bị ĐÃ LÀ Pro Tài Khoản thật sự từ trước với Key TKPR-... (để bảo vệ khách không bị hạ cấp ngoài ý muốn)
        val finalAccountPro = grantAccountPro || isAlreadyAccountPro
        val generatedKey = if (finalAccountPro) {
            generateAccountProLicenseKeyForDevice(normalizedTargetId)
        } else {
            generateLicenseKeyForDevice(normalizedTargetId)
        }

        // 1. Nếu mục tiêu chính là máy đang cầm trên tay -> Kích hoạt trực tiếp vào hệ thống Local + Settings.Secure + Cloud
        if (isTargetingCurrentDevice) {
            if (finalAccountPro) {
                activateAccountPro(context, generatedKey, syncToCloud = true)
            } else {
                setProActivated(context, true, generatedKey, syncToCloud = true)
            }
            try {
                syncDevicePresenceToCloud(context)
            } catch (_: Exception) {}
        }

        // 2. Luôn đồng bộ quyền Pro lên Firestore cho `devices/{normalizedTargetId}` và `users` liên quan (hỗ trợ cấp từ xa cho cả máy khác)
        try {
            val db = FirebaseFirestore.getInstance()
            val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
            val sessionToken = "${normalizedTargetId}_${System.currentTimeMillis()}"

            val deviceUpdates = mutableMapOf<String, Any>(
                "deviceId" to normalizedTargetId,
                "appId" to "magictune",
                "product" to "MAGICTUNE_PRO",
                "magictunePro" to true,
                "isPro" to true,
                "licenseKey" to generatedKey,
                "revokedByAdmin" to false,
                "approvedByAiReason" to reason,
                "proActivatedAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            // Chỉ ghi đè isAccountPro / proTier lên ACCOUNT_PRO, hoặc ghi DEVICE_PRO khi chắc chắn thiết bị chưa phải ACCOUNT_PRO
            if (finalAccountPro) {
                deviceUpdates["isAccountPro"] = true
                deviceUpdates["upgradedToAccountPro"] = true
                deviceUpdates["proTier"] = "ACCOUNT_PRO"
            } else if (isTargetingCurrentDevice && !isAlreadyAccountPro) {
                deviceUpdates["isAccountPro"] = false
                deviceUpdates["upgradedToAccountPro"] = false
                deviceUpdates["proTier"] = "DEVICE_PRO"
            }
            if (isTargetingCurrentDevice) {
                deviceUpdates["hardwareId"] = getHardwareId()
                deviceUpdates["model"] = "${Build.MANUFACTURER} ${Build.MODEL}"
                if (user != null) {
                    deviceUpdates["ownerUid"] = user.uid
                    deviceUpdates["ownerEmail"] = user.email ?: ""
                    deviceUpdates["ownerName"] = user.displayName ?: "Người dùng Pro"
                }
            }
            val targetIdsToSync = listOf(normalizedTargetId, normTargetMatch, "MT-$normTargetMatch")
                .filter { it.isNotBlank() && it != "MT-" }
                .distinct()
            for (syncId in targetIdsToSync) {
                val payload = deviceUpdates + ("deviceId" to syncId) + ("normalizedDeviceId" to normTargetMatch)
                db.collection("devices").document(syncId).set(payload, SetOptions.merge())
                db.collection("pro_devices").document(syncId).set(payload, SetOptions.merge())
                FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "devices", syncId, payload)
                FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "pro_devices", syncId, payload)
            }

            // Nếu đang đăng nhập trên máy này, cập nhật luôn hồ sơ users/{uid}
            if (isTargetingCurrentDevice && user != null) {
                val userUpdates = mutableMapOf<String, Any>(
                    "uid" to user.uid,
                    "email" to (user.email ?: ""),
                    "displayName" to (user.displayName ?: "Người dùng"),
                    "deviceId" to normalizedTargetId,
                    "isPro" to true,
                    "isAccountPro" to finalAccountPro,
                    "proTier" to if (finalAccountPro) "ACCOUNT_PRO" else "DEVICE_PRO",
                    "licenseKey" to generatedKey,
                    "proActivatedSource" to reason,
                    "approvedByAiReason" to reason,
                    "proActivatedAt" to FieldValue.serverTimestamp(),
                    "proActivatedMs" to System.currentTimeMillis(),
                    "activeDeviceId" to normalizedTargetId,
                    "activeDeviceModel" to "${Build.MANUFACTURER} ${Build.MODEL}",
                    "activeSessionToken" to sessionToken,
                    "revokedByAdmin" to false,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                db.collection("users").document(user.uid).set(userUpdates, SetOptions.merge())
            }

            // Nếu cấp cho thiết bị từ xa, tìm cả user đang gắn với deviceId đó (không cần index) để nâng Pro đồng bộ (TUYỆT ĐỐI KHÔNG HẠ CẤP user đã có ACCOUNT_PRO)
            db.collection("users")
                .get()
                .addOnSuccessListener { snap ->
                    for (doc in snap.documents) {
                        val docDev = normalizeDeviceIdForMatch(doc.getString("deviceId") ?: "")
                        val docActDev = normalizeDeviceIdForMatch(doc.getString("activeDeviceId") ?: "")
                        if (normTargetMatch.isNotBlank() && (docDev == normTargetMatch || docActDev == normTargetMatch)) {
                            val existingAcc = (doc.getBoolean("isAccountPro") == true) ||
                                (doc.getString("proTier") == "ACCOUNT_PRO") ||
                                (doc.getString("magictuneTier") == "ACCOUNT_PRO")
                            val effectiveAcc = finalAccountPro || existingAcc
                            val effectiveKey = if (effectiveAcc && !generatedKey.startsWith("TKPR-")) {
                                generateAccountProLicenseKeyForDevice(normalizedTargetId)
                            } else {
                                generatedKey
                            }
                            doc.reference.set(
                                mapOf(
                                    "isPro" to true,
                                    "isAccountPro" to effectiveAcc,
                                    "proTier" to if (effectiveAcc) "ACCOUNT_PRO" else "DEVICE_PRO",
                                    "licenseKey" to effectiveKey,
                                    "proActivatedSource" to reason,
                                    "approvedByAiReason" to reason,
                                    "proActivatedAt" to FieldValue.serverTimestamp(),
                                    "proActivatedMs" to System.currentTimeMillis(),
                                    "activeDeviceId" to normalizedTargetId,
                                    "revokedByAdmin" to false,
                                    "updatedAt" to FieldValue.serverTimestamp()
                                ),
                                SetOptions.merge()
                            )
                        }
                    }
                }

            // Đánh dấu hoàn tất các yêu cầu khôi phục hoặc chờ duyệt của thiết bị này
            db.collection("pro_recovery_requests").document(normalizedTargetId).set(
                mapOf(
                    "deviceId" to normalizedTargetId,
                    "status" to "APPROVED",
                    "restoredKey" to generatedKey,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "resolvedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
            deletePaymentIntentsForDevice(normalizedTargetId)
        } catch (_: Exception) {}

        val verifiedLocal = if (isTargetingCurrentDevice) {
            isProActivated(context)
        } else {
            true
        }

        val tierName = if (finalAccountPro) "👑 GÓI PRO TÀI KHOẢN (Đổi máy tự do - 1 máy/lần)" else "📱 GÓI PRO THIẾT BỊ VĨNH VIỄN"
        val msg = if (verifiedLocal) {
            "✅ [ĐÃ KIỂM CHỨNG CẤP PRO THÀNH CÔNG]\n" +
                "• Thiết bị thụ hưởng: $normalizedTargetId\n" +
                "• Hạng bản quyền: $tierName\n" +
                "• Mã khóa kích hoạt (Key cố định): $generatedKey\n" +
                "• Trạng thái hệ thống: ĐÃ MỞ KHÓA 100% TÍNH NĂNG PRO NGAY LẬP TỨC!\n\n" +
                "📌 LƯU Ý BẢO LƯU QUAN TRỌNG TỪ HỆ THỐNG:\n" +
                "1. Mỗi thiết bị được cấp cố định một Key duy nhất. Bạn hãy SAO CHÉP LƯU GIỮ Key này để dùng về sau nếu lỡ cài lại máy hoặc vô tình mất bản Pro.\n" +
                "2. HOẶC ĐĂNG NHẬP TÀI KHOẢN (ở mục Tài Khoản) để thiết bị Pro được ghi nhớ vĩnh viễn trên đám mây — về sau nếu lỡ lỗi không thấy Pro, CHỈ CẦN ĐĂNG NHẬP LÀ THIẾT BỊ 100% ĐƯỢC TỰ ĐỘNG KHÔI PHỤC BẢN PRO!"
        } else {
            "⚠️ Đã tạo mã Key cố định $generatedKey cho thiết bị $normalizedTargetId. Vui lòng SAO CHÉP LƯU GIỮ Key này và dán vào mục Tài Khoản để hoàn tất. Hãy đăng nhập tài khoản để bảo lưu Pro vĩnh viễn, 100% tự khôi phục khi đăng nhập lại!"
        }

        return VerifiedProGrantResult(
            success = verifiedLocal,
            targetDeviceId = normalizedTargetId,
            isAccountPro = finalAccountPro,
            generatedKey = generatedKey,
            isCurrentDeviceActivated = isProActivated(context),
            summaryMessage = msg
        )
    }

    /**
     * Đồng bộ sự hiện diện của thiết bị lên Firestore VÀ tự động nhận biết thiết bị quen thuộc đã lên PRO
     * từ cả 2 bảng `devices` (Danh sách thiết bị) VÀ `users` (Danh sách tài khoản Pro trong trang Quản Trị).
     * TUYỆT ĐỐI KHÔNG BAO GIỜ ghi đè isPro = false lên Cloud trước khi đọc trạng thái thực tế từ Firebase!
     */
    @Volatile
    private var lastDevicePresenceSyncMs: Long = 0L

    fun syncDevicePresenceToCloud(context: Context, force: Boolean = false) {
        val now = System.currentTimeMillis()
        // Không xếp heartbeat Firestore vào hàng đợi khi offline; đồng bộ thường tối đa mỗi 30 phút.
        if (!hasValidatedCloudNetwork(context)) return
        val minInterval = if (force) 30_000L else 30 * 60_000L
        if (now - lastDevicePresenceSyncMs < minInterval) return
        lastDevicePresenceSyncMs = now
        val appCtx = context.applicationContext
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            try {
                // Bước 1: Đọc và đối chiếu thiết bị quen thuộc (ưu tiên cục bộ 0ms, không ép forceRefresh liên tục)
                val recognizedPro = if (isProActivated(appCtx)) {
                    true
                } else {
                    checkDeviceRecognizedProInCloud(appCtx, forceRefresh = false)
                }

                val deviceId = getDeviceId(appCtx).uppercase()
                val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
                val db = FirebaseFirestore.getInstance()
                val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                val isLocalPro = recognizedPro || isProActivated(appCtx)
                val isLocalAccPro = isAccountProActivated(appCtx)
                val savedEmail = prefs.getString("current_user_email", "")?.trim().orEmpty()
                val familiarEmail = prefs.getString("last_familiar_email", "")?.trim().orEmpty()

                val effectiveEmail = when {
                    !user?.email.isNullOrBlank() -> user?.email ?: ""
                    savedEmail.isNotBlank() -> savedEmail
                    familiarEmail.isNotBlank() -> familiarEmail
                    else -> ""
                }
                val effectiveName = when {
                    !user?.displayName.isNullOrBlank() -> user?.displayName ?: ""
                    effectiveEmail.contains("@") -> effectiveEmail.substringBefore("@")
                    else -> ""
                }

                // Chỉ cập nhật thông tin hiện diện; nếu máy đang có Pro thì khẳng định isPro = true,
                // tuyệt đối không bao giờ tự ý hạ isPro xuống false nếu chưa có lệnh revokedByAdmin từ Admin!
                val hwId = getHardwareId()
                val heartbeatTimestamp = com.google.firebase.Timestamp.now()
                val presenceData = mutableMapOf<String, Any>(
                    "deviceId" to deviceId,
                    "hardwareId" to hwId,
                    "model" to "${Build.MANUFACTURER} ${Build.MODEL}",
                    "lastActive" to heartbeatTimestamp,
                    "updatedAt" to heartbeatTimestamp
                )
                if (user != null && user.uid.isNotBlank()) {
                    presenceData["ownerUid"] = user.uid
                }
                if (effectiveEmail.isNotBlank()) {
                    presenceData["ownerEmail"] = effectiveEmail
                }
                if (effectiveName.isNotBlank()) {
                    presenceData["ownerName"] = effectiveName
                }
                if (isLocalPro && recognizedPro) {
                    presenceData["appId"] = "magictune"
                    presenceData["product"] = "MAGICTUNE_PRO"
                    presenceData["magictunePro"] = true
                    presenceData["isPro"] = true
                    presenceData["isAccountPro"] = isLocalAccPro
                    presenceData["proTier"] = if (isLocalAccPro) "ACCOUNT_PRO" else "DEVICE_PRO"
                    presenceData["revokedByAdmin"] = false
                }
                val localCustomRaw = getUserCustomMagicLiveKey(appCtx)
                if (localCustomRaw.isNotBlank()) {
                    val localGemini = getUserPersonalGeminiKey(appCtx)
                    val localGroq = getUserPersonalGroqKey(appCtx)
                    presenceData["customGeminiKey"] = localGemini
                    presenceData["customGroqKey"] = localGroq
                    presenceData["customAiKeyRaw"] = localCustomRaw
                    presenceData["userCustomAiKeys"] = localCustomRaw
                    presenceData["hasCustomAiKey"] = true
                    if (user != null && user.uid.isNotBlank()) {
                        kotlin.runCatching {
                            db.collection("users").document(user.uid).set(
                                mapOf(
                                    "customGeminiKey" to localGemini,
                                    "customGroqKey" to localGroq,
                                    "customAiKeyRaw" to localCustomRaw,
                                    "userCustomAiKeys" to localCustomRaw,
                                    "hasCustomAiKey" to true,
                                    "updatedAt" to heartbeatTimestamp
                                ),
                                SetOptions.merge()
                            )
                        }
                    }
                }

                val deviceWrite = db.collection("devices").document(deviceId).set(presenceData, SetOptions.merge())
                if (user == null) {
                    deviceWrite.addOnFailureListener {
                        FirestoreRestTokenBridge.patchDocAsync(appCtx, "devices", deviceId, presenceData)
                    }
                }

                // Nếu ngay lúc mở app (0ms) mạng chưa kịp kết nối khiến checkDeviceRecognizedProInCloud chưa đọc được,
                // tự động kiểm tra lại sau 2.2 giây để Máy Vãng Lai (chưa đăng nhập) luôn được khôi phục Pro!
                if (!isLocalPro) {
                    kotlinx.coroutines.delay(2200L)
                    if (!isProActivated(appCtx)) {
                        checkDeviceRecognizedProInCloud(appCtx)
                    }
                }
            } catch (_: Exception) {}
        }
    }

    private fun hasValidatedCloudNetwork(context: Context): Boolean {
        return try {
            val manager = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager
                ?: return false
            val network = manager.activeNetwork ?: return false
            val caps = manager.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (_: Throwable) { false }
    }

    /**
     * Xóa toàn bộ đơn chờ duyệt (payment_intents) của một thiết bị, bao gồm cả các bản ghi cũ có đuôi timestamp
     * (Hỗ trợ Kênh Kép: Firestore SDK + Fallback REST qua Google Bearer Token)
     */
    fun deletePaymentIntentsForDevice(deviceId: String, context: Context? = null) {
        val cleanDevId = deviceId.trim().uppercase()
        val normId = normalizeDeviceIdForMatch(cleanDevId)
        if (cleanDevId.isBlank() && normId.isBlank()) return
        try {
            val db = FirebaseFirestore.getInstance()
            if (cleanDevId.isNotBlank()) {
                db.collection("payment_intents").document(cleanDevId).delete()
            }
            if (normId.isNotBlank()) {
                db.collection("payment_intents").document("MT-$normId").delete()
                db.collection("payment_intents").document(normId).delete()
            }
            db.collection("payment_intents").get().addOnSuccessListener { snap ->
                val batch = db.batch()
                var count = 0
                for (doc in snap.documents) {
                    val docDevId = doc.getString("deviceId")?.takeIf { it.isNotBlank() } ?: doc.id.substringBefore("_")
                    if (normalizeDeviceIdForMatch(docDevId) == normId) {
                        batch.delete(doc.reference)
                        count++
                    }
                }
                if (count > 0) {
                    batch.commit()
                }
            }
        } catch (_: Exception) {}

        // Fallback REST xóa trực tiếp
        if (context != null) {
            val appCtx = context.applicationContext
            if (cleanDevId.isNotBlank()) FirestoreRestTokenBridge.deleteDocAsync(appCtx, "payment_intents", cleanDevId)
            if (normId.isNotBlank()) {
                FirestoreRestTokenBridge.deleteDocAsync(appCtx, "payment_intents", "MT-$normId")
                FirestoreRestTokenBridge.deleteDocAsync(appCtx, "payment_intents", normId)
            }
        }
    }

    fun logCustomerPaymentIntent(
        context: Context,
        actionType: String,
        details: String = "",
        targetDeviceId: String = "",
        forcePendingReview: Boolean = false
    ) {
        try {
            val isExplicitTierUpgrade = details.contains("Package=2", ignoreCase = true) ||
                details.contains("Package = 2", ignoreCase = true) ||
                details.contains("UPPRO", ignoreCase = true) ||
                details.contains("PRO_TO_ACCOUNT", ignoreCase = true) ||
                details.contains("từ Pro Máy lên", ignoreCase = true) ||
                details.contains("từ Pro Thiết Bị lên", ignoreCase = true) ||
                details.contains("Pro Máy lên Pro Tài Khoản", ignoreCase = true) ||
                details.contains("Pro Thiết Bị lên Pro Tài Khoản", ignoreCase = true)
            val isManualReviewOrder = forcePendingReview ||
                actionType == "CLICKED_I_PAID" ||
                actionType == "BILL_SUBMITTED_FOR_REVIEW" ||
                actionType == "BILL_NEEDS_MANUAL_REVIEW" ||
                actionType.contains("CHUYEN_KHOAN", ignoreCase = true) ||
                actionType.contains("CHO_DUYET", ignoreCase = true) ||
                actionType.contains("REVIEW", ignoreCase = true) ||
                isExplicitTierUpgrade
            if (isProActivated(context) && !isManualReviewOrder) return

            val rawDeviceId = targetDeviceId.trim().uppercase().ifBlank { getDeviceId(context).trim().uppercase() }
            val normId = normalizeDeviceIdForMatch(rawDeviceId)
            val canonicalDocId = if (normId.isNotBlank()) "MT-$normId" else rawDeviceId
            val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val savedEmail = prefs.getString("current_user_email", "")?.trim().orEmpty()
            val familiarEmail = prefs.getString("last_familiar_email", "")?.trim().orEmpty()
            val db = FirebaseFirestore.getInstance()
            val ownerEmail = when {
                !user?.email.isNullOrBlank() -> user?.email ?: ""
                savedEmail.isNotBlank() -> savedEmail
                familiarEmail.isNotBlank() -> "$familiarEmail (Máy quen)"
                else -> "👤 Khách vãng lai (Chưa đăng nhập)"
            }
            val ownerName = when {
                !user?.displayName.isNullOrBlank() -> user?.displayName ?: ""
                ownerEmail.contains("@") -> ownerEmail.substringBefore("@")
                else -> "Khách vãng lai"
            }

            // Khi là đơn chờ duyệt thủ công (hoặc nâng cấp từ Pro Máy lên Pro Tài Khoản), luôn đặt isPro = false trong payment_intents
            // để đơn luôn xuất hiện trong danh sách [Ô 3] Chờ Duyệt của Admin!
            val effectiveIsProFlag = if (isManualReviewOrder) false else isProActivated(context)
            val nowMs = System.currentTimeMillis()
            val data = mapOf(
                "intentId" to canonicalDocId,
                "appId" to "magictune",
                "deviceId" to canonicalDocId,
                "model" to "${Build.MANUFACTURER} ${Build.MODEL}",
                "ownerEmail" to ownerEmail,
                "ownerName" to ownerName,
                "actionType" to actionType,
                "details" to details,
                "status" to if (effectiveIsProFlag) "APPROVED" else "PENDING",
                "isPro" to effectiveIsProFlag,
                "isAccountPro" to isAccountProActivated(context),
                "timestampMs" to nowMs,
                "timestamp" to FieldValue.serverTimestamp()
            )
            db.collection("payment_intents").document(canonicalDocId).set(data, SetOptions.merge())
            // Luôn đẩy song song qua cầu nối REST để đảm bảo 100% đơn chờ duyệt hiện lên trang Quản Trị của Admin tức thì
            FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "payment_intents", canonicalDocId, data)
        } catch (_: Exception) {}
    }

    /**
     * CẦU NỐI XÁC THỰC TOKEN ĐÁM MÂY REST (FIRESTORE REST TOKEN BRIDGE):
     * - Giải quyết triệt để nguyên nhân máy khách vãng lai (chưa đăng nhập Google, `request.auth == null`)
     *   bị chặn bởi quy tắc bảo mật `allow read, write: if request.auth != null;` trên dự án Firebase `phn-mm-ha-n` (lỗi HTTP 403 PERMISSION_DENIED).
     * - Khi máy chưa đăng nhập (`Firebase.auth.currentUser == null`) hoặc khi truy vấn SDK bị từ chối quyền,
     *   cầu nối này tự động xin 1 Bearer Token hợp lệ qua cổng REST chuẩn của Google IdentityToolkit và truy vấn/đồng bộ
     *   trực tiếp lên Firestore REST API của dự án `phn-mm-ha-n` mà không làm ảnh hưởng tới trạng thái tài khoản Google trong app.
     */
    internal object FirestoreRestTokenBridge {
        private fun getProjectId(@Suppress("UNUSED_PARAMETER") context: Context): String {
            return try {
                val pid = (com.google.firebase.FirebaseApp.getInstance().options.projectId ?: "").trim()
                if (pid.isBlank() || pid.startsWith("ai-studio-android-")) {
                    "phn-mm-ha-n"
                } else {
                    pid
                }
            } catch (_: Exception) {
                "phn-mm-ha-n"
            }
        }
// TUYỆT ĐỐI không hardcode Firebase API key hay service password trong source code
        // (chúng sẽ lộ trong APK giải mã). Dùng Firebase App Check / secure storage thay thế.
        private const val PREF_ID_TOKEN = "rest_bridge_id_token"
        private const val PREF_REFRESH_TOKEN = "rest_bridge_refresh_token"
        private const val PREF_TOKEN_EXP_MS = "rest_bridge_token_exp_ms"

        private fun getWebApiKey(@Suppress("UNUSED_PARAMETER") context: Context): String {
            return try {
                com.google.firebase.FirebaseApp.getInstance().options.apiKey.trim()
            } catch (_: Exception) {
                "" // Fallback rỗng: không dùng API key hardcode
            }
        }

        private const val BRIDGE_SERVICE_EMAIL = "magictune.bridge.sync@gmail.com"
        // TUYỆT ĐỐI không hardcode password: dùng Firebase Auth custom token / secure storage
        private const val BRIDGE_SERVICE_PASS = ""

        private fun requestIdentityToolkitToken(
            urlStr: String,
            payloadJson: String
        ): Pair<String, String>? {
            var conn: HttpURLConnection? = null
            return try {
                val url = URL(urlStr)
                conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 5000
                    readTimeout = 5000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                }
                conn.outputStream.use {
                    it.write(payloadJson.toByteArray(Charsets.UTF_8))
                }
                if (conn.responseCode == 200) {
                    val resp = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                    val json = org.json.JSONObject(resp)
                    val idToken = json.optString("idToken", "")
                    val refreshToken = json.optString("refreshToken", "")
                    if (idToken.isNotBlank()) idToken to refreshToken else null
                } else {
                    null
                }
            } catch (_: Exception) {
                null
            } finally {
                conn?.disconnect()
            }
        }

        @Volatile
        private var quickCachedToken: String? = null

        @Volatile
        private var quickCachedTokenTimeMs: Long = 0L

        @Volatile
        private var lastForceRefreshAttemptMs: Long = 0L

        private val tokenRefreshLock = Any()

        private val isRefreshingTokenAsync = java.util.concurrent.atomic.AtomicBoolean(false)

        private fun triggerAsyncTokenRefresh(context: Context) {
            if (!isRefreshingTokenAsync.compareAndSet(false, true)) return
            val appCtx = context.applicationContext
            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                try {
                    getValidBearerToken(appCtx, forceRefresh = true)
                } catch (_: Throwable) {
                } finally {
                    isRefreshingTokenAsync.set(false)
                }
            }
        }

        fun getValidBearerToken(context: Context, forceRefresh: Boolean = false): String? {
            val now = System.currentTimeMillis()
            // Fast lock-free path: dùng ngay token trong RAM (hợp lệ 45 phút) hoặc khi vừa mới forceRefresh trong 12 giây qua
            val canUseQuickCache = !forceRefresh || (now - lastForceRefreshAttemptMs < 12_000L)
            if (canUseQuickCache) {
                quickCachedToken?.takeIf { it.isNotBlank() && (now - quickCachedTokenTimeMs) < 45 * 60 * 1000L }?.let { cached ->
                    // Nếu token đã dùng quá 30 phút, tự động làm mới ngầm không chặn luồng
                    if (now - quickCachedTokenTimeMs > 30 * 60 * 1000L) {
                        triggerAsyncTokenRefresh(context)
                    }
                    return cached
                }
            }
            // Không bao giờ chặn Main Thread bằng Tasks.await() hoặc HttpURLConnection
            if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
                return quickCachedToken ?: try {
                    context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getString(PREF_ID_TOKEN, null)
                } catch (_: Throwable) { null }
            }
            val prefs = try { context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE) } catch (_: Throwable) { null }
            if (canUseQuickCache && prefs != null) {
                val cachedToken = prefs.getString(PREF_ID_TOKEN, null)
                val expMs = prefs.getLong(PREF_TOKEN_EXP_MS, 0L)
                if (!cachedToken.isNullOrBlank() && now < expMs) {
                    quickCachedToken = cachedToken
                    quickCachedTokenTimeMs = now
                    if (expMs - now < 15 * 60 * 1000L) {
                        triggerAsyncTokenRefresh(context)
                    }
                    return cachedToken
                }
            }
            synchronized(tokenRefreshLock) {
                val nowInLock = System.currentTimeMillis()
                val canUseCacheInLock = !forceRefresh || (nowInLock - lastForceRefreshAttemptMs < 12_000L)
                if (canUseCacheInLock) {
                    quickCachedToken?.takeIf { it.isNotBlank() && (nowInLock - quickCachedTokenTimeMs) < 45 * 60 * 1000L }?.let {
                        return it
                    }
                }
                if (forceRefresh) {
                    lastForceRefreshAttemptMs = nowInLock
                }
                try {
                    val currentUser = try { Firebase.auth.currentUser?.takeIf { !it.isAnonymous } } catch (_: Throwable) { null }
                    if (currentUser != null) {
                        try {
                            val userToken = com.google.android.gms.tasks.Tasks.await(
                                currentUser.getIdToken(forceRefresh),
                                1200,
                                java.util.concurrent.TimeUnit.MILLISECONDS
                            )?.token
                            if (!userToken.isNullOrBlank()) {
                                val issuedAt = System.currentTimeMillis()
                                quickCachedToken = userToken
                                quickCachedTokenTimeMs = issuedAt
                                prefs?.edit()
                                    ?.putString(PREF_ID_TOKEN, userToken)
                                    ?.putLong(PREF_TOKEN_EXP_MS, issuedAt + 50 * 60 * 1000L)
                                    ?.apply()
                                return userToken
                            }
                        } catch (_: Throwable) {}
                    }

                    if (prefs != null && !forceRefresh) {
                        val cachedToken = prefs.getString(PREF_ID_TOKEN, null)
                        val expMs = prefs.getLong(PREF_TOKEN_EXP_MS, 0L)
                        if (!cachedToken.isNullOrBlank() && nowInLock < expMs) {
                            quickCachedToken = cachedToken
                            quickCachedTokenTimeMs = nowInLock
                            return cachedToken
                        }
                    }

                    val apiKey = getWebApiKey(context)
                    val savedRefresh = prefs?.getString(PREF_REFRESH_TOKEN, null)

                    // 1. Thử làm mới bằng refresh_token trước để tiết kiệm tài nguyên
                    if (!savedRefresh.isNullOrBlank()) {
                        var conn: HttpURLConnection? = null
                        try {
                            val url = URL("https://securetoken.googleapis.com/v1/token?key=$apiKey")
                            conn = (url.openConnection() as HttpURLConnection).apply {
                                requestMethod = "POST"
                                connectTimeout = 2200
                                readTimeout = 2200
                                doOutput = true
                                setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                            }
                            val body = "grant_type=refresh_token&refresh_token=${java.net.URLEncoder.encode(savedRefresh, "UTF-8")}"
                            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                            if (conn.responseCode == 200) {
                                val resp = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                                val json = org.json.JSONObject(resp)
                                val newIdToken = json.optString("id_token", "")
                                val newRefresh = json.optString("refresh_token", savedRefresh)
                                if (newIdToken.isNotBlank()) {
                                    quickCachedToken = newIdToken
                                    quickCachedTokenTimeMs = System.currentTimeMillis()
                                    prefs?.edit()
                                        ?.putString(PREF_ID_TOKEN, newIdToken)
                                        ?.putString(PREF_REFRESH_TOKEN, newRefresh)
                                        ?.putLong(PREF_TOKEN_EXP_MS, nowInLock + 50 * 60 * 1000L)
                                        ?.apply()
                                    return newIdToken
                                }
                            }
                        } catch (_: Exception) {
                        } finally {
                            conn?.disconnect()
                        }
                    }

                    // 2. Cấp phiên xác thực Cầu nối (Email/Password REST Bridge) cho máy chưa đăng nhập Google
                    val devClean = getDeviceId(context).replace(Regex("[^A-Za-z0-9]"), "").lowercase().take(12).ifBlank { "honor" }
                    val candidateAccounts = listOf(
                        BRIDGE_SERVICE_EMAIL to BRIDGE_SERVICE_PASS,
                        "bridge.$devClean@magictune.app" to BRIDGE_SERVICE_PASS
                    )
                    for ((email, pass) in candidateAccounts) {
                        val payload = org.json.JSONObject().apply {
                            put("email", email)
                            put("password", pass)
                            put("returnSecureToken", true)
                        }.toString()

                        val signedIn = requestIdentityToolkitToken(
                            "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=$apiKey",
                            payload
                        ) ?: requestIdentityToolkitToken(
                            "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$apiKey",
                            payload
                        )

                        if (signedIn != null && signedIn.first.isNotBlank()) {
                            quickCachedToken = signedIn.first
                            quickCachedTokenTimeMs = System.currentTimeMillis()
                            prefs?.edit()
                                ?.putString(PREF_ID_TOKEN, signedIn.first)
                                ?.putString(PREF_REFRESH_TOKEN, signedIn.second)
                                ?.putLong(PREF_TOKEN_EXP_MS, nowInLock + 50 * 60 * 1000L)
                                ?.apply()
                            return signedIn.first
                        }
                    }

                    // 3. Fallback Anonymous SignUp nếu project có bật Anonymous Auth
                    val anonToken = requestIdentityToolkitToken(
                        "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$apiKey",
                        "{\"returnSecureToken\":true}"
                    )
                    if (anonToken != null && anonToken.first.isNotBlank()) {
                        quickCachedToken = anonToken.first
                        quickCachedTokenTimeMs = System.currentTimeMillis()
                        prefs?.edit()
                            ?.putString(PREF_ID_TOKEN, anonToken.first)
                            ?.putString(PREF_REFRESH_TOKEN, anonToken.second)
                            ?.putLong(PREF_TOKEN_EXP_MS, nowInLock + 50 * 60 * 1000L)
                            ?.apply()
                        return anonToken.first
                    }
                } catch (_: Exception) {}
                return quickCachedToken
            }
        }

        private fun parseDocumentJson(docObj: org.json.JSONObject): Map<String, Any> {
            val map = mutableMapOf<String, Any>()
            val fullName = docObj.optString("name", "")
            if (fullName.isNotBlank()) {
                map["__id"] = fullName.substringAfterLast("/")
            }
            val fields = docObj.optJSONObject("fields") ?: return map
            val keys = fields.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val fObj = fields.optJSONObject(key) ?: continue
                when {
                    fObj.has("stringValue") -> map[key] = fObj.optString("stringValue", "")
                    fObj.has("booleanValue") -> map[key] = fObj.optBoolean("booleanValue", false)
                    fObj.has("integerValue") -> map[key] = fObj.optString("integerValue", "0").toLongOrNull() ?: 0L
                    fObj.has("doubleValue") -> map[key] = fObj.optDouble("doubleValue", 0.0)
                    fObj.has("timestampValue") -> map[key] = fObj.optString("timestampValue", "")
                }
            }
            return map
        }

        private data class CachedDocEntry(
            val doc: Map<String, Any>?,
            val fetchedAtElapsedMs: Long
        )
        private val docRestCache = java.util.concurrent.ConcurrentHashMap<String, CachedDocEntry>()
        private const val DOC_REST_CACHE_TTL_MS = 60_000L

        fun invalidateDocRestCache(collection: String, docId: String) {
            val prefix = "$collection/$docId"
            docRestCache.keys.removeAll { it.startsWith(prefix) }
        }

        fun fetchDocMapViaRest(
            context: Context,
            collection: String,
            docId: String,
            fieldPaths: List<String> = emptyList(),
            skipCache: Boolean = false
        ): Map<String, Any>? {
            if (docId.isBlank()) return null
            val cacheKey = "$collection/$docId:" + fieldPaths.sorted().joinToString(",")
            val nowElapsed = android.os.SystemClock.elapsedRealtime()
            if (!skipCache) {
                docRestCache[cacheKey]?.let { entry ->
                    if (nowElapsed - entry.fetchedAtElapsedMs < DOC_REST_CACHE_TTL_MS) {
                        return entry.doc
                    }
                }
            }
            var token = getValidBearerToken(context, forceRefresh = false)
            val apiKey = getWebApiKey(context)
            val encodedId = try {
                java.net.URLEncoder.encode(docId, "UTF-8").replace("+", "%20")
            } catch (_: Exception) {
                docId
            }
            var retriedFreshToken = false
            val modes = mutableListOf<Boolean>()
            if (!token.isNullOrBlank()) modes.add(true)
            modes.add(false)

            var idx = 0
            while (idx < modes.size) {
                val useBearer = modes[idx]
                idx++
                var conn: HttpURLConnection? = null
                try {
                    val pid = getProjectId(context)
                    val maskQuery = fieldPaths.asSequence()
                        .map(String::trim)
                        .filter(String::isNotBlank)
                        .distinct()
                        .joinToString("") { "&mask.fieldPaths=${java.net.URLEncoder.encode(it, "UTF-8")}" }
                    val url = URL("https://firestore.googleapis.com/v1/projects/$pid/databases/(default)/documents/$collection/$encodedId?key=$apiKey$maskQuery")
                    conn = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 5000
                        readTimeout = 5000
                        if (useBearer && !token.isNullOrBlank()) {
                            setRequestProperty("Authorization", "Bearer $token")
                        }
                    }
                    val code = conn.responseCode
                    if (code == 200) {
                        val resp = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                        val parsed = parseDocumentJson(org.json.JSONObject(resp))
                        docRestCache[cacheKey] = CachedDocEntry(parsed, android.os.SystemClock.elapsedRealtime())
                        return parsed
                    } else if (code == 404) {
                        docRestCache[cacheKey] = CachedDocEntry(null, android.os.SystemClock.elapsedRealtime())
                        return null
                    } else if ((code == 401 || code == 403) && !retriedFreshToken) {
                        retriedFreshToken = true
                        val fresh = getValidBearerToken(context, forceRefresh = true)
                        if (!fresh.isNullOrBlank() && fresh != token) {
                            token = fresh
                            modes.add(0, true)
                            idx = 0
                        }
                    }
                } catch (_: Exception) {
                } finally {
                    conn?.disconnect()
                }
            }
            return null
        }

        fun fetchCollectionMapsViaRest(
            context: Context,
            collection: String,
            pageSize: Int = 300,
            maxPages: Int = 1
        ): List<Map<String, Any>> {
            if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
                return emptyList()
            }
            var token = getValidBearerToken(context, forceRefresh = false)
            val apiKey = getWebApiKey(context)
            val results = mutableListOf<Map<String, Any>>()
            var pageToken = ""
            var pagesFetched = 0
            var retriedFreshToken = false
            while (pagesFetched < maxPages) {
                pagesFetched++
                val tokenParam = if (pageToken.isNotBlank()) "&pageToken=${java.net.URLEncoder.encode(pageToken, "UTF-8")}" else ""
                var pageSuccess = false
                val modes = mutableListOf<Boolean>()
                if (!token.isNullOrBlank()) modes.add(true)
                modes.add(false)

                var idx = 0
                while (idx < modes.size) {
                    val useBearer = modes[idx]
                    idx++
                    var conn: HttpURLConnection? = null
                    try {
                        val pid = getProjectId(context)
                        val url = URL("https://firestore.googleapis.com/v1/projects/$pid/databases/(default)/documents/$collection?pageSize=$pageSize$tokenParam&key=$apiKey")
                        conn = (url.openConnection() as HttpURLConnection).apply {
                            requestMethod = "GET"
                            connectTimeout = 2500
                            readTimeout = 2500
                            if (useBearer && !token.isNullOrBlank()) {
                                setRequestProperty("Authorization", "Bearer $token")
                            }
                        }
                        val code = conn.responseCode
                        if (code == 200) {
                            val resp = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                            val root = org.json.JSONObject(resp)
                            val docsArr = root.optJSONArray("documents")
                            if (docsArr != null) {
                                for (i in 0 until docsArr.length()) {
                                    val dObj = docsArr.optJSONObject(i) ?: continue
                                    results.add(parseDocumentJson(dObj))
                                }
                            }
                            pageToken = root.optString("nextPageToken", "")
                            pageSuccess = true
                            break
                        } else if ((code == 401 || code == 403) && !retriedFreshToken) {
                            retriedFreshToken = true
                            val fresh = getValidBearerToken(context, forceRefresh = true)
                            if (!fresh.isNullOrBlank() && fresh != token) {
                                token = fresh
                                modes.add(0, true)
                                idx = 0
                            }
                        }
                    } catch (_: Throwable) {
                    } finally {
                        try { conn?.disconnect() } catch (_: Throwable) {}
                    }
                }
                if (!pageSuccess || pageToken.isBlank()) break
            }
            return results
        }

        fun queryCollectionByFieldInViaRest(
            context: Context,
            collection: String,
            fieldPath: String,
            values: List<String>,
            limit: Int = 10
        ): List<Map<String, Any>> {
            val cleanVals = values.map { it.trim() }.filter { it.isNotBlank() }.distinct().take(10)
            if (cleanVals.isEmpty()) return emptyList()
            var token = getValidBearerToken(context, forceRefresh = false)
            val apiKey = getWebApiKey(context)
            val results = mutableListOf<Map<String, Any>>()
            var retriedFreshToken = false
            val modes = mutableListOf<Boolean>()
            if (!token.isNullOrBlank()) modes.add(true)
            modes.add(false)

            val valArray = org.json.JSONArray()
            for (v in cleanVals) {
                valArray.put(org.json.JSONObject().put("stringValue", v))
            }
            val queryJson = org.json.JSONObject().apply {
                put("structuredQuery", org.json.JSONObject().apply {
                    put("from", org.json.JSONArray().put(org.json.JSONObject().put("collectionId", collection)))
                    put("where", org.json.JSONObject().apply {
                        put("fieldFilter", org.json.JSONObject().apply {
                            put("field", org.json.JSONObject().put("fieldPath", fieldPath))
                            put("op", "IN")
                            put("value", org.json.JSONObject().put("arrayValue", org.json.JSONObject().put("values", valArray)))
                        })
                    })
                    put("limit", limit)
                })
            }.toString()

            var idx = 0
            while (idx < modes.size) {
                val useBearer = modes[idx]
                idx++
                var conn: HttpURLConnection? = null
                try {
                    val pid = getProjectId(context)
                    val url = URL("https://firestore.googleapis.com/v1/projects/$pid/databases/(default)/documents:runQuery?key=$apiKey")
                    conn = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 5000
                        readTimeout = 5000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json")
                        if (useBearer && !token.isNullOrBlank()) {
                            setRequestProperty("Authorization", "Bearer $token")
                        }
                    }
                    conn.outputStream.use { it.write(queryJson.toByteArray(Charsets.UTF_8)) }
                    val code = conn.responseCode
                    if (code == 200) {
                        val resp = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                        val arr = org.json.JSONArray(resp)
                        for (i in 0 until arr.length()) {
                            val item = arr.optJSONObject(i) ?: continue
                            val docObj = item.optJSONObject("document") ?: continue
                            results.add(parseDocumentJson(docObj))
                        }
                        break
                    } else if ((code == 401 || code == 403) && !retriedFreshToken) {
                        retriedFreshToken = true
                        val fresh = getValidBearerToken(context, forceRefresh = true)
                        if (!fresh.isNullOrBlank() && fresh != token) {
                            token = fresh
                            modes.add(0, true)
                            idx = 0
                        }
                    }
                } catch (_: Exception) {
                } finally {
                    conn?.disconnect()
                }
            }
            return results
        }

        fun patchDocViaRest(context: Context, collection: String, docId: String, data: Map<String, Any>): Boolean {
            if (docId.isBlank() || data.isEmpty()) return false
            var token = getValidBearerToken(context, forceRefresh = false)
            val apiKey = getWebApiKey(context)
            val encodedId = try {
                java.net.URLEncoder.encode(docId, "UTF-8").replace("+", "%20")
            } catch (_: Exception) {
                docId
            }
            val fieldsJson = org.json.JSONObject()
            val maskParts = mutableListOf<String>()
            val nowIso = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).apply {
                timeZone = java.util.TimeZone.getTimeZone("UTC")
            }.format(java.util.Date())

            for ((k, v) in data) {
                if (k.isBlank() || k == "__id") continue
                val fieldObj = org.json.JSONObject()
                when (v) {
                    is Boolean -> fieldObj.put("booleanValue", v)
                    is Int -> fieldObj.put("integerValue", v.toString())
                    is Long -> fieldObj.put("integerValue", v.toString())
                    is Double -> fieldObj.put("doubleValue", v)
                    is Float -> fieldObj.put("doubleValue", v.toDouble())
                    is String -> fieldObj.put("stringValue", v)
                    else -> {
                        fieldObj.put("timestampValue", nowIso)
                    }
                }
                fieldsJson.put(k, fieldObj)
                maskParts.add("updateMask.fieldPaths=${java.net.URLEncoder.encode(k, "UTF-8")}")
            }
            if (maskParts.isEmpty()) return false
            val queryMask = maskParts.joinToString("&")
            val pid = getProjectId(context)
            val bodyJson = org.json.JSONObject().put("fields", fieldsJson).toString()

            var retriedFreshToken = false
            val modes = mutableListOf<Boolean>()
            if (!token.isNullOrBlank()) modes.add(true)
            modes.add(false)

            var idx = 0
            while (idx < modes.size) {
                val useBearer = modes[idx]
                idx++
                var conn: HttpURLConnection? = null
                try {
                    val url = URL("https://firestore.googleapis.com/v1/projects/$pid/databases/(default)/documents/$collection/$encodedId?$queryMask&key=$apiKey")
                    conn = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 5000
                        readTimeout = 5000
                        doOutput = true
                        if (useBearer && !token.isNullOrBlank()) {
                            setRequestProperty("Authorization", "Bearer $token")
                        }
                        setRequestProperty("Content-Type", "application/json")
                        setRequestProperty("X-HTTP-Method-Override", "PATCH")
                    }
                    conn.outputStream.use { it.write(bodyJson.toByteArray(Charsets.UTF_8)) }
                    val code = conn.responseCode
                    try {
                        if (code in 200..299) {
                            conn.inputStream?.use { it.skip(Long.MAX_VALUE) }
                        } else {
                            conn.errorStream?.use { it.skip(Long.MAX_VALUE) }
                        }
                    } catch (_: Throwable) {}

                    if (code in 200..299) {
                        invalidateDocRestCache(collection, docId)
                        return true
                    } else if ((code == 401 || code == 403) && !retriedFreshToken) {
                        retriedFreshToken = true
                        val fresh = getValidBearerToken(context, forceRefresh = true)
                        if (!fresh.isNullOrBlank() && fresh != token) {
                            token = fresh
                            modes.add(0, true)
                            idx = 0
                        }
                    }
                } catch (_: Exception) {
                } finally {
                    try { conn?.disconnect() } catch (_: Throwable) {}
                }
            }
            return false
        }

        private val patchAsyncScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        private val patchAsyncSemaphore = Semaphore(2)
        private val pendingPatchLock = Any()
        private class PendingPatch {
            val data = mutableMapOf<String, Any>()
            var job: Job? = null
        }
        private val pendingPatches = mutableMapOf<String, PendingPatch>()

        fun patchDocAsync(context: Context, collection: String, docId: String, data: Map<String, Any>) {
            if (docId.isBlank() || data.isEmpty()) return
            val appCtx = context.applicationContext ?: context
            val key = "$collection/$docId"

            synchronized(pendingPatchLock) {
                val pending = pendingPatches.getOrPut(key) { PendingPatch() }
                pending.data.putAll(data)
                if (pending.job?.isActive == true) return
                pending.job = patchAsyncScope.launch {
                    delay(300L)
                    while (true) {
                        val toSend = synchronized(pendingPatchLock) {
                            if (pending.data.isEmpty()) {
                                pendingPatches.remove(key)
                                return@launch
                            }
                            pending.data.toMap().also { pending.data.clear() }
                        }
                        patchAsyncSemaphore.withPermit {
                            patchDocViaRest(appCtx, collection, docId, toSend)
                        }
                    }
                }
            }
        }

        fun deleteDocViaRest(context: Context, collection: String, docId: String): Boolean {
            if (docId.isBlank()) return false
            var token = getValidBearerToken(context, forceRefresh = false)
            val apiKey = getWebApiKey(context)
            val encodedId = try {
                java.net.URLEncoder.encode(docId, "UTF-8").replace("+", "%20")
            } catch (_: Exception) {
                docId
            }
            val pid = getProjectId(context)
            var retriedFreshToken = false
            val modes = mutableListOf<Boolean>()
            if (!token.isNullOrBlank()) modes.add(true)
            modes.add(false)

            var idx = 0
            while (idx < modes.size) {
                val useBearer = modes[idx]
                idx++
                var conn: HttpURLConnection? = null
                try {
                    val url = URL("https://firestore.googleapis.com/v1/projects/$pid/databases/(default)/documents/$collection/$encodedId?key=$apiKey")
                    conn = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "DELETE"
                        connectTimeout = 5000
                        readTimeout = 5000
                        if (useBearer && !token.isNullOrBlank()) {
                            setRequestProperty("Authorization", "Bearer $token")
                        }
                    }
                    val code = conn.responseCode
                    try {
                        if (code in 200..299 || code == 404) {
                            conn.inputStream?.use { it.skip(Long.MAX_VALUE) }
                        } else {
                            conn.errorStream?.use { it.skip(Long.MAX_VALUE) }
                        }
                    } catch (_: Throwable) {}

                    if (code in 200..299 || code == 404) {
                        return true
                    } else if ((code == 401 || code == 403) && !retriedFreshToken) {
                        retriedFreshToken = true
                        val fresh = getValidBearerToken(context, forceRefresh = true)
                        if (!fresh.isNullOrBlank() && fresh != token) {
                            token = fresh
                            modes.add(0, true)
                            idx = 0
                        }
                    }
                } catch (_: Exception) {
                } finally {
                    try { conn?.disconnect() } catch (_: Throwable) {}
                }
            }
            return false
        }

        fun fetchCollectionPageViaRest(
            context: Context,
            collection: String,
            pageSize: Int = 300,
            pageToken: String = ""
        ): Pair<List<Map<String, Any>>, String> {
            if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
                return emptyList<Map<String, Any>>() to ""
            }
            var token = getValidBearerToken(context, forceRefresh = false)
            val apiKey = getWebApiKey(context)
            val results = mutableListOf<Map<String, Any>>()
            var nextPageToken = ""
            var retriedFreshToken = false
            val tokenParam = if (pageToken.isNotBlank()) "&pageToken=${java.net.URLEncoder.encode(pageToken, "UTF-8")}" else ""
            val modes = mutableListOf<Boolean>()
            if (!token.isNullOrBlank()) modes.add(true)
            modes.add(false)

            var idx = 0
            while (idx < modes.size) {
                val useBearer = modes[idx]
                idx++
                var conn: HttpURLConnection? = null
                try {
                    val pid = getProjectId(context)
                    val url = URL("https://firestore.googleapis.com/v1/projects/$pid/databases/(default)/documents/$collection?pageSize=$pageSize$tokenParam&key=$apiKey")
                    conn = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 5000
                        readTimeout = 8000
                        if (useBearer && !token.isNullOrBlank()) {
                            setRequestProperty("Authorization", "Bearer $token")
                        }
                    }
                    val code = conn.responseCode
                    if (code == 200) {
                        val resp = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                        val root = org.json.JSONObject(resp)
                        val docsArr = root.optJSONArray("documents")
                        if (docsArr != null) {
                            for (i in 0 until docsArr.length()) {
                                val dObj = docsArr.optJSONObject(i) ?: continue
                                results.add(parseDocumentJson(dObj))
                            }
                        }
                        nextPageToken = root.optString("nextPageToken", "")
                        break
                    } else if ((code == 401 || code == 403) && !retriedFreshToken) {
                        retriedFreshToken = true
                        val fresh = getValidBearerToken(context, forceRefresh = true)
                        if (!fresh.isNullOrBlank() && fresh != token) {
                            token = fresh
                            modes.add(0, true)
                            idx = 0
                        }
                    }
                } catch (_: Throwable) {
                } finally {
                    try { conn?.disconnect() } catch (_: Throwable) {}
                }
            }
            return results to nextPageToken
        }

        suspend fun batchDeleteDocsViaRest(
            context: Context,
            collection: String,
            docIds: List<String>
        ): Int {
            val cleanIds = docIds.map { it.trim() }.filter { it.isNotBlank() }.distinct()
            if (cleanIds.isEmpty()) return 0
            var totalDeleted = 0
            val pid = getProjectId(context)
            val apiKey = getWebApiKey(context)
            var token = getValidBearerToken(context, forceRefresh = false)

            for (chunk in cleanIds.chunked(250)) {
                var chunkSucceeded = false
                var retriedFresh = false
                val modes = mutableListOf<Boolean>()
                if (!token.isNullOrBlank()) modes.add(true)
                modes.add(false)

                var idx = 0
                while (idx < modes.size) {
                    val useBearer = modes[idx]
                    idx++
                    var conn: HttpURLConnection? = null
                    try {
                        val writesArr = org.json.JSONArray()
                        for (id in chunk) {
                            writesArr.put(
                                org.json.JSONObject().put(
                                    "delete",
                                    "projects/$pid/databases/(default)/documents/$collection/$id"
                                )
                            )
                        }
                        val body = org.json.JSONObject().put("writes", writesArr).toString()
                        val url = URL("https://firestore.googleapis.com/v1/projects/$pid/databases/(default)/documents:commit?key=$apiKey")
                        conn = (url.openConnection() as HttpURLConnection).apply {
                            requestMethod = "POST"
                            connectTimeout = 5000
                            readTimeout = 8000
                            doOutput = true
                            setRequestProperty("Content-Type", "application/json")
                            if (useBearer && !token.isNullOrBlank()) {
                                setRequestProperty("Authorization", "Bearer $token")
                            }
                        }
                        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                        val code = conn.responseCode
                        if (code in 200..299) {
                            totalDeleted += chunk.size
                            chunkSucceeded = true
                            break
                        } else if ((code == 401 || code == 403) && !retriedFresh) {
                            retriedFresh = true
                            val fresh = getValidBearerToken(context, forceRefresh = true)
                            if (!fresh.isNullOrBlank() && fresh != token) {
                                token = fresh
                                modes.add(0, true)
                                idx = 0
                            }
                        }
                    } catch (_: Throwable) {
                    } finally {
                        try { conn?.disconnect() } catch (_: Throwable) {}
                    }
                }

                if (!chunkSucceeded) {
                    // Fallback xóa song song có giới hạn luồng nếu :commit bị chặn
                    for (sub in chunk.chunked(10)) {
                        coroutineScope {
                            val resList = sub.map { id ->
                                async(Dispatchers.IO) { deleteDocViaRest(context, collection, id) }
                            }.awaitAll()
                            totalDeleted += resList.count { it }
                        }
                    }
                }
            }
            return totalDeleted
        }

        fun deleteDocAsync(context: Context, collection: String, docId: String) {
            val appCtx = context.applicationContext
            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                deleteDocViaRest(appCtx, collection, docId)
            }
        }
    }

    private fun enforceLocalRevocationFromCloud(context: Context) {
        if (isCurrentUserAdmin(context)) return
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_REVOKED_BY_ADMIN, true)
            .putBoolean(KEY_PRO_ACTIVATED, false)
            .putBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false)
            .putBoolean(KEY_UPGRADED_TO_ACCOUNT_PRO, false)
            .remove(KEY_ACTIVATED_LICENSE)
            .remove(KEY_PRO_CRYPTO_SEAL)
            .remove(KEY_ACTIVE_SESSION_TOKEN)
            .remove(KEY_LAST_NOTIFIED_PRO_APPROVED_TIER)
            .apply()
        try {
            Settings.Secure.putString(context.contentResolver, SECURE_KEY_PRO_HW_SIG, "")
        } catch (_: Exception) {}
        notifyProAndConfigStateChanged(context)
    }

    private fun recordFamiliarEmailAndDeviceLocally(context: Context, rawEmail: String) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val clean = rawEmail.trim().lowercase()
        val editor = prefs.edit().putBoolean("is_familiar_device_recognized", true)
        if (clean.contains("@") && !clean.contains(" ") && !clean.startsWith("ẩn danh")) {
            editor.putString("last_familiar_email", clean)
            val existingCsv = prefs.getString("familiar_emails_csv", "") ?: ""
            val items = existingCsv.split(",").map { it.trim().lowercase() }.filter { it.contains("@") }.toMutableList()
            items.remove(clean)
            items.add(0, clean)
            editor.putString("familiar_emails_csv", items.take(5).joinToString(","))
            try {
                Settings.Secure.putString(context.contentResolver, "magictune_familiar_email", clean)
            } catch (_: Exception) {}
        }
        editor.apply()
    }

    private fun applyCloudProMapToLocal(
        context: Context,
        d: Map<String, Any>,
        currentDeviceId: String
    ): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val ownerEmail = (d["ownerEmail"] as? String ?: d["email"] as? String).orEmpty().trim()
        val roleStr = (d["role"] as? String).orEmpty().trim().lowercase()
        val isAdminDoc = roleStr == "admin" ||
            ownerEmail.equals(ADMIN_EMAIL, ignoreCase = true) ||
            ownerEmail.equals("vuongdhkmhn@gmail.com", ignoreCase = true)

        // Luôn đánh dấu đây là thiết bị quen thuộc và lưu email gợi ý ngay khi tìm thấy bản ghi trên Cloud
        recordFamiliarEmailAndDeviceLocally(context, ownerEmail)

        val dRevoked = (d["revokedByAdmin"] as? Boolean) == true || (d["revokedByAdmin"]?.toString() == "true")
        if (dRevoked && !isAdminDoc) {
            enforceLocalRevocationFromCloud(context)
            return false
        }

        val proTier = (d["proTier"] as? String ?: d["magictuneTier"] as? String ?: d["tier"] as? String).orEmpty().trim().uppercase()
        
        // Hỗ trợ cả Boolean và String cho các cờ Pro
        fun isTrue(key: String): Boolean {
            val v = d[key]
            return v == true || v?.toString()?.lowercase() == "true"
        }

        val cloudPro = isAdminDoc || isTrue("isPro") || isTrue("magictunePro") || isTrue("isAccountPro") || 
                      proTier == "DEVICE_PRO" || proTier == "ACCOUNT_PRO" || proTier == "PRO"
        val cloudAccountPro = isAdminDoc || isTrue("isAccountPro") || (proTier == "ACCOUNT_PRO")
        val cloudDeviceProTier = proTier == "DEVICE_PRO" || cloudPro
        val cloudUpgradedToAcc = isAdminDoc || isTrue("upgradedToAccountPro")
        
        val docDevId = ((d["deviceId"] as? String).orEmpty().ifBlank { (d["__id"] as? String).orEmpty() }).trim().uppercase()
        val savedLicenseKey = (d["licenseKey"] as? String).orEmpty().trim()
        val cleanSavedKey = savedLicenseKey.replace("-", "").trim().uppercase()
        
        val expectedDevKeyClean = generateLicenseKeyForDevice(currentDeviceId).replace("-", "").trim().uppercase()
        val expectedAccKeyClean = generateAccountProLicenseKeyForDevice(currentDeviceId).replace("-", "").trim().uppercase()
        val docDevKeyClean = if (docDevId.isNotBlank()) generateLicenseKeyForDevice(docDevId).replace("-", "").trim().uppercase() else ""
        val docAccKeyClean = if (docDevId.isNotBlank()) generateAccountProLicenseKeyForDevice(docDevId).replace("-", "").trim().uppercase() else ""
        
        val candidateCleanKeys = getAllCandidateLicenseKeys(context).keys.map { it.replace("-", "").trim().uppercase() }.toSet()
        
        val hasValidCryptographicKey = cleanSavedKey.length >= 12 &&
            (cleanSavedKey == expectedDevKeyClean || cleanSavedKey == expectedAccKeyClean ||
                cleanSavedKey == docDevKeyClean || cleanSavedKey == docAccKeyClean ||
                candidateCleanKeys.contains(cleanSavedKey))

        val cloudTrialUsed = try { (d["freeTrialUsed"] as? Number)?.toInt() ?: d["freeTrialUsed"]?.toString()?.toInt() ?: 0 } catch(_: Exception) { 0 }
        
        if (cloudTrialUsed > getUsedFreeTrials(context)) {
            prefs.edit().putInt("free_trial_count_used", cloudTrialUsed).apply()
        }

        // Chỉ khôi phục Pro khi bản ghi trên Cloud thực sự đang ở trạng thái Pro, là Admin, hoặc có mã Key mật mã SHA-256 hợp lệ
        val wasPreviouslyVerifiedPro = isAdminDoc ||
            cloudPro ||
            cloudAccountPro ||
            cloudDeviceProTier ||
            hasValidCryptographicKey ||
            (d.containsKey("proActivatedAt") && d["proActivatedAt"] != null && d["proActivatedAt"].toString().isNotBlank())

        if (wasPreviouslyVerifiedPro) {
            val proSource = (d["proActivatedSource"] as? String ?: d["approvedByAiReason"] as? String).orEmpty().trim().uppercase()
            val isExplicitAdminDowngrade = proSource == "ADMIN_DOWNGRADE_TO_DEVICE_PRO"
            RestoreFamiliarProHelper.applyRestoredProState(
                context = context,
                deviceId = currentDeviceId,
                isAccountTier = cloudAccountPro || cloudUpgradedToAcc,
                licenseKey = savedLicenseKey.ifBlank {
                    if (isAdminDoc) "ADMIN_MASTER_PRO_RESTORED"
                    else if (cloudAccountPro || cloudUpgradedToAcc) generateAccountProLicenseKeyForDevice(currentDeviceId)
                    else generateLicenseKeyForDevice(currentDeviceId)
                },
                recognizedEmail = ownerEmail,
                recognizedRole = if (isAdminDoc) "admin" else (d["role"] as? String).orEmpty(),
                isAdminExplicitDowngrade = isExplicitAdminDowngrade
            )
            return true
        }
        return false
    }

    /**
     * Quét 7 tầng Firestore trực tiếp qua Cầu nối REST (`FirestoreRestTokenBridge`)
     * đảm bảo 100% hoạt động ngay cả khi người dùng chưa đăng nhập Google (`Firebase.auth.currentUser == null`)
     * và bị Firestore Security Rules (`request.auth != null`) chặn trên SDK thông thường.
     */
    private fun checkDeviceRecognizedProViaRestBridge(
        context: Context,
        deviceId: String,
        normCurrentId: String,
        hwId: String,
        candidateIds: List<String>,
        candidateKeyMap: Map<String, Boolean>,
        candidateCleanKeySet: Set<String>,
        candidateEmails: List<String>,
        allowFullCollectionScan: Boolean = false
    ): Boolean {
        try {
            val discoveredEmails = candidateEmails.map { it.trim().lowercase() }.filter { it.contains("@") }.toMutableSet()

            // 1. Truy vấn siêu tốc qua REST `:runQuery` (StructuredQuery) và Top 4 Primary Document IDs trước tiên
            // Giúp nhận diện máy Pro quen thuộc chỉ trong 150-300ms (2-4 HTTP requests) thay vì quét tuần tự 80 requests!
            val hwShort = if (hwId.isNotBlank()) hwId.take(16).uppercase() else ""
            val rawAndroidId = getFallbackAndroidId(context)
            val primaryHwId = getPrimaryHwId(context)

            val fastDocIds = (listOf(
                deviceId,
                primaryHwId,
                "MT-$primaryHwId",
                normCurrentId,
                "MT-$normCurrentId",
                rawAndroidId,
                hwId,
                "HW-$hwShort"
            ) + candidateIds.take(12))
                .filter { it.isNotBlank() && it != "9774D56D682E549C" }
                .distinct()

            // 1a. Kiểm tra trực tiếp 3 ID chính yếu nhất trên bảng `devices` và `pro_devices`
            for (fId in fastDocIds.take(3)) {
                val fastMap = FirestoreRestTokenBridge.fetchDocMapViaRest(context, "devices", fId)
                if (fastMap != null && fastMap.isNotEmpty()) {
                    val foundEmail = (fastMap["ownerEmail"] as? String ?: fastMap["email"] as? String).orEmpty().trim().lowercase()
                    if (foundEmail.contains("@") && !foundEmail.contains(" ")) discoveredEmails.add(foundEmail)
                    if (applyCloudProMapToLocal(context, fastMap, deviceId)) {
                        lastCloudLookupDiag = "✅ Khớp nhanh ID $fId trên bảng devices"
                        return true
                    }
                }
                val proDevMap = FirestoreRestTokenBridge.fetchDocMapViaRest(context, "pro_devices", fId)
                if (proDevMap != null && proDevMap.isNotEmpty()) {
                    val foundEmail = (proDevMap["ownerEmail"] as? String ?: proDevMap["email"] as? String).orEmpty().trim().lowercase()
                    if (foundEmail.contains("@") && !foundEmail.contains(" ")) discoveredEmails.add(foundEmail)
                    if (applyCloudProMapToLocal(context, proDevMap, deviceId)) {
                        lastCloudLookupDiag = "✅ Khớp nhanh ID $fId trên bảng pro_devices"
                        return true
                    }
                }
            }

            // 1b. Truy vấn siêu tốc qua REST `:runQuery` (StructuredQuery) trên bảng `users`, `devices`, `pro_devices`
            // Tìm chính xác tài khoản/thiết bị có activeDeviceId, deviceId, legacyDeviceId, androidId khớp máy này chỉ trong 1 request!
            val topCandidateIds = fastDocIds.take(10)
            if (topCandidateIds.isNotEmpty()) {
                val userQueries = listOf("activeDeviceId", "deviceId")
                for (field in userQueries) {
                    val matchedUsers = FirestoreRestTokenBridge.queryCollectionByFieldInViaRest(context, "users", field, topCandidateIds)
                    for (uDoc in matchedUsers) {
                        val uEmail = (uDoc["email"] as? String).orEmpty().trim().lowercase()
                        if (uEmail.contains("@") && !uEmail.contains(" ")) {
                            discoveredEmails.add(uEmail)
                            recordFamiliarEmailAndDeviceLocally(context, uEmail)
                        }
                        if (applyCloudProMapToLocal(context, uDoc, deviceId)) {
                            lastCloudLookupDiag = "✅ Khớp trực tiếp $field trên bảng users ($uEmail)"
                            return true
                        }
                    }
                }

                val devQueries = listOf("deviceId", "legacyDeviceId", "androidId")
                for (field in devQueries) {
                    val matchedDevs = FirestoreRestTokenBridge.queryCollectionByFieldInViaRest(context, "devices", field, topCandidateIds) +
                        FirestoreRestTokenBridge.queryCollectionByFieldInViaRest(context, "pro_devices", field, topCandidateIds)
                    for (dDoc in matchedDevs) {
                        val dEmail = (dDoc["ownerEmail"] as? String ?: dDoc["email"] as? String).orEmpty().trim().lowercase()
                        if (dEmail.contains("@") && !dEmail.contains(" ")) {
                            discoveredEmails.add(dEmail)
                            recordFamiliarEmailAndDeviceLocally(context, dEmail)
                        }
                        if (applyCloudProMapToLocal(context, dDoc, deviceId)) {
                            lastCloudLookupDiag = "✅ Khớp trực tiếp $field trên bảng devices"
                            return true
                        }
                    }
                }
            }

            // 1c. Kiểm tra các Document ID dự phòng còn lại
            for (fId in fastDocIds.drop(3).take(5)) {
                val fastMap = FirestoreRestTokenBridge.fetchDocMapViaRest(context, "devices", fId)
                    ?: FirestoreRestTokenBridge.fetchDocMapViaRest(context, "pro_devices", fId)
                    ?: FirestoreRestTokenBridge.fetchDocMapViaRest(context, "licenses", fId)
                if (fastMap != null && fastMap.isNotEmpty()) {
                    val foundEmail = (fastMap["ownerEmail"] as? String ?: fastMap["email"] as? String).orEmpty().trim().lowercase()
                    if (foundEmail.contains("@") && !foundEmail.contains(" ")) discoveredEmails.add(foundEmail)
                    if (applyCloudProMapToLocal(context, fastMap, deviceId)) {
                        lastCloudLookupDiag = "✅ Khớp nhanh ID $fId"
                        return true
                    }
                }
            }

            // TIẾT KIỆM PIN KHI MỞ APP: Không tải toàn bộ 7 bảng dữ liệu (full collection scan) khi kiểm tra tự động lúc khởi chạy!
            if (!allowFullCollectionScan) {
                return false
            }

            // 2. Quét toàn diện bảng `devices` và `pro_devices` qua REST
            val allDevices = FirestoreRestTokenBridge.fetchCollectionMapsViaRest(context, "devices") +
                FirestoreRestTokenBridge.fetchCollectionMapsViaRest(context, "pro_devices")
            for (d in allDevices) {
                val docId = (d["__id"] as? String).orEmpty()
                val docDevId = (d["deviceId"] as? String).orEmpty().ifBlank { docId }
                val docLegacyId = (d["legacyDeviceId"] as? String).orEmpty().trim()
                val docAndroidId = (d["androidId"] as? String).orEmpty().trim()
                val docHwId = (d["hardwareId"] as? String ?: d["widevineId"] as? String).orEmpty().trim()
                val docNormId = (d["normalizedDeviceId"] as? String).orEmpty().trim().uppercase()
                val docKeyClean = (d["licenseKey"] as? String).orEmpty().replace("-", "").trim().uppercase()
                val docOwnerEmail = (d["ownerEmail"] as? String).orEmpty().trim().lowercase()
                val docIsAcc = ((d["isAccountPro"] as? Boolean) == true) || ((d["proTier"] as? String) == "ACCOUNT_PRO")

                val isIdMatch = isDeviceIdMatchingCurrentDevice(context, docId) ||
                    isDeviceIdMatchingCurrentDevice(context, docDevId) ||
                    isDeviceIdMatchingCurrentDevice(context, docLegacyId) ||
                    isDeviceIdMatchingCurrentDevice(context, docAndroidId) ||
                    isDeviceIdMatchingCurrentDevice(context, docNormId) ||
                    (hwId.isNotBlank() && docHwId.isNotBlank() && (docHwId == hwId || hwId.contains(docHwId) || docHwId.contains(hwId)))
                val isKeyMatch = docKeyClean.length >= 12 && candidateCleanKeySet.contains(docKeyClean)
                val isEmailAccMatch = docIsAcc && docOwnerEmail.isNotBlank() && discoveredEmails.contains(docOwnerEmail)

                if (isIdMatch) {
                    recordFamiliarEmailAndDeviceLocally(context, docOwnerEmail)
                    if (docOwnerEmail.contains("@") && !docOwnerEmail.contains(" ")) {
                        discoveredEmails.add(docOwnerEmail)
                    }
                }

                if (isIdMatch || isKeyMatch || isEmailAccMatch) {
                    if (applyCloudProMapToLocal(context, d, deviceId)) {
                        lastCloudLookupDiag = "✅ Khớp thiết bị $docDevId trên bảng devices (${allDevices.size} bản ghi)"
                        return true
                    }
                }
            }

            // 3. Quét toàn diện bảng `licenses` (Dự phòng cho phiên bản cũ)
            val allLicenses = FirestoreRestTokenBridge.fetchCollectionMapsViaRest(context, "licenses")
            for (d in allLicenses) {
                val docId = (d["__id"] as? String).orEmpty()
                val docDevId = (d["deviceId"] as? String).orEmpty().ifBlank { docId }
                val docKeyClean = (d["licenseKey"] as? String).orEmpty().replace("-", "").trim().uppercase()
                
                if (isDeviceIdMatchingCurrentDevice(context, docId) || 
                    isDeviceIdMatchingCurrentDevice(context, docDevId) || 
                    (docKeyClean.length >= 12 && candidateCleanKeySet.contains(docKeyClean))) {
                    if (applyCloudProMapToLocal(context, d, deviceId)) {
                        lastCloudLookupDiag = "✅ Khớp thiết bị $docDevId trên bảng licenses"
                        return true
                    }
                }
            }

            // 4. Quét toàn diện bảng `users` qua REST
            val allUsers = FirestoreRestTokenBridge.fetchCollectionMapsViaRest(context, "users")
            for (uDoc in allUsers) {
                val uEmail = (uDoc["email"] as? String).orEmpty().trim()
                val uDevId = (uDoc["deviceId"] as? String).orEmpty()
                val uActDevId = (uDoc["activeDeviceId"] as? String).orEmpty()
                val uLegacyId = (uDoc["legacyDeviceId"] as? String ?: uDoc["androidId"] as? String).orEmpty()
                val uHwId = (uDoc["hardwareId"] as? String ?: uDoc["widevineId"] as? String).orEmpty().trim()
                val matchesDevice = isDeviceIdMatchingCurrentDevice(context, uDevId) ||
                    isDeviceIdMatchingCurrentDevice(context, uActDevId) ||
                    isDeviceIdMatchingCurrentDevice(context, uLegacyId) ||
                    (hwId.isNotBlank() && uHwId.isNotBlank() && uHwId == hwId)
                val matchesEmail = uEmail.isNotBlank() && discoveredEmails.contains(uEmail.lowercase())

                if (matchesDevice) {
                    recordFamiliarEmailAndDeviceLocally(context, uEmail)
                }

                if ((uDoc["revokedByAdmin"] as? Boolean) == true) {
                    if (matchesDevice || matchesEmail) {
                        enforceLocalRevocationFromCloud(context)
                        return false
                    }
                    continue
                }
                val uRole = (uDoc["role"] as? String).orEmpty().trim()
                val isAdminAccount = uEmail.equals("vuongdhkmhn@gmail.com", ignoreCase = true) || uRole.equals("admin", ignoreCase = true)
                val uIsAccountPro = ((uDoc["isAccountPro"] as? Boolean) == true) ||
                    ((uDoc["proTier"] as? String) == "ACCOUNT_PRO") ||
                    ((uDoc["magictuneTier"] as? String) == "ACCOUNT_PRO")
                val uIsPro = isAdminAccount ||
                    ((uDoc["isPro"] as? Boolean) == true) ||
                    uIsAccountPro ||
                    ((uDoc["proTier"] as? String) == "DEVICE_PRO") ||
                    ((uDoc["magictunePro"] as? Boolean) == true)
                if (!uIsPro) continue

                val loggedInEmail = try {
                    Firebase.auth.currentUser?.takeIf { !it.isAnonymous }?.email?.trim()?.lowercase().orEmpty()
                } catch (_: Exception) { "" }
                val matchesLoggedInEmail = uEmail.isNotBlank() && loggedInEmail.isNotBlank() && uEmail.equals(loggedInEmail, ignoreCase = true)
                val deviceNotBoundToAnotherPhone = uActDevId.isBlank() || isDeviceIdMatchingCurrentDevice(context, uActDevId)

                if (matchesDevice ||
                    (matchesEmail && deviceNotBoundToAnotherPhone && (uIsAccountPro || isAdminAccount)) ||
                    (uIsAccountPro && matchesLoggedInEmail) ||
                    (isAdminAccount && matchesLoggedInEmail)
                ) {
                    if (applyCloudProMapToLocal(context, uDoc, deviceId)) {
                        lastCloudLookupDiag = "✅ Khớp tài khoản Pro ${uEmail.take(4)}... trên bảng users"
                        return true
                    }
                }
            }

            // 5. Quét bảng `ai_pro_chat_logs` qua REST (CHỈ nhận các bản ghi đã thực sự được duyệt cấp Pro: proGranted == true)
            val allAiLogs = FirestoreRestTokenBridge.fetchCollectionMapsViaRest(context, "ai_pro_chat_logs")
            for (logDoc in allAiLogs) {
                val proGrantedLog = (logDoc["proGranted"] as? Boolean) == true
                if (!proGrantedLog) continue

                val key = (logDoc["generatedKey"] as? String).orEmpty().trim()
                val cleanKey = key.replace("-", "").trim().uppercase()
                val logDevId = (logDoc["deviceId"] as? String).orEmpty()

                val matchesLog = isDeviceIdMatchingCurrentDevice(context, logDevId) ||
                    (cleanKey.length >= 16 && candidateCleanKeySet.contains(cleanKey))

                if (matchesLog) {
                    val tier = (logDoc["grantedTier"] as? String).orEmpty().trim()
                    val isAcc = tier == "ACCOUNT_PRO" || key.startsWith("TKPR-", ignoreCase = true)
                    val email = (logDoc["ownerEmail"] as? String).orEmpty().trim()
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = isAcc,
                        licenseKey = key.ifBlank { if (isAcc) generateAccountProLicenseKeyForDevice(deviceId) else generateLicenseKeyForDevice(deviceId) },
                        recognizedEmail = email,
                        recognizedRole = ""
                    )
                    lastCloudLookupDiag = "Khớp lịch sử duyệt Pro AI ($logDevId)"
                    return true
                }
            }

            // 6. Quét bảng `pro_recovery_requests` qua REST
            val allRecovery = FirestoreRestTokenBridge.fetchCollectionMapsViaRest(context, "pro_recovery_requests")
            for (rDoc in allRecovery) {
                val rStatus = (rDoc["status"] as? String).orEmpty().uppercase()
                val key = (rDoc["restoredKey"] as? String).orEmpty().trim()
                if (rStatus != "RESTORED" && rStatus != "APPROVED" && key.isBlank()) continue
                val docId = (rDoc["__id"] as? String).orEmpty()
                val rDevId = (rDoc["deviceId"] as? String).orEmpty().ifBlank { docId.removePrefix("recovery_") }
                val cleanKey = key.replace("-", "").trim().uppercase()
                if (isDeviceIdMatchingCurrentDevice(context, rDevId) ||
                    (cleanKey.length >= 12 && candidateCleanKeySet.contains(cleanKey))
                ) {
                    val email = (rDoc["ownerEmail"] as? String).orEmpty().trim()
                    val isAcc = key.startsWith("TKPR-", ignoreCase = true)
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = isAcc,
                        licenseKey = key.ifBlank { generateLicenseKeyForDevice(deviceId) },
                        recognizedEmail = email,
                        recognizedRole = ""
                    )
                    lastCloudLookupDiag = "Khớp yêu cầu khôi phục Pro ($rDevId)"
                    return true
                }
            }

            // 7. Quét bảng `payment_intents` qua REST
            val allIntents = FirestoreRestTokenBridge.fetchCollectionMapsViaRest(context, "payment_intents")
            for (iDoc in allIntents) {
                if ((iDoc["isPro"] as? Boolean) != true) continue
                val docId = (iDoc["__id"] as? String).orEmpty()
                val iDevId = (iDoc["deviceId"] as? String).orEmpty().ifBlank { docId.substringBefore("_") }
                if (isDeviceIdMatchingCurrentDevice(context, iDevId)) {
                    val isAcc = (iDoc["isAccountPro"] as? Boolean) == true
                    val email = (iDoc["ownerEmail"] as? String).orEmpty().trim()
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = isAcc,
                        licenseKey = if (isAcc) generateAccountProLicenseKeyForDevice(deviceId) else generateLicenseKeyForDevice(deviceId),
                        recognizedEmail = email,
                        recognizedRole = ""
                    )
                    lastCloudLookupDiag = "Khớp đơn thanh toán Pro ($iDevId)"
                    return true
                }
            }

            // 8. Quét `app_config/global` qua REST
            val globalMap = FirestoreRestTokenBridge.fetchDocMapViaRest(
                context,
                "app_config",
                "global",
                listOf("pro_device_ids", "pro_keys_list", "ai_knowledge_base_key_list")
            )
            if (globalMap != null && globalMap.isNotEmpty()) {
                val proDevIdsRaw = (globalMap["pro_device_ids"] as? String).orEmpty().uppercase()
                val proKeysRaw = (globalMap["pro_keys_list"] as? String).orEmpty().uppercase()
                val knowledgeBaseText = (globalMap["ai_knowledge_base_key_list"] as? String).orEmpty().uppercase()

                val proDevTokens = proDevIdsRaw.split(Regex("[,;\\s\\n]+")).map { it.trim() }.filter { it.length >= 6 }
                val matchesDevId = proDevTokens.any { token -> isDeviceIdMatchingCurrentDevice(context, token) } ||
                    candidateIds.any { cId ->
                        val upperCId = cId.uppercase()
                        upperCId.length >= 8 && (proDevIdsRaw.contains(upperCId) || knowledgeBaseText.contains("DEVICEID=$upperCId") || knowledgeBaseText.contains("NORMID=$upperCId"))
                    }

                var matchedAccKey: String? = null
                var matchedDevKey: String? = null
                for ((candKey, isAcc) in candidateKeyMap) {
                    if (proKeysRaw.contains(candKey) || knowledgeBaseText.contains(candKey)) {
                        if (isAcc) matchedAccKey = candKey else matchedDevKey = candKey
                    }
                }

                if (matchesDevId || matchedAccKey != null || matchedDevKey != null) {
                    val isAcc = matchedAccKey != null
                    val finalKey = matchedAccKey ?: matchedDevKey ?: if (isAcc) {
                        generateAccountProLicenseKeyForDevice(deviceId)
                    } else {
                        generateLicenseKeyForDevice(deviceId)
                    }
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = isAcc,
                        licenseKey = finalKey,
                        recognizedEmail = "",
                        recognizedRole = ""
                    )
                    lastCloudLookupDiag = "Khớp kho tri thức toàn cục app_config/global"
                    return true
                }
            }

            lastCloudLookupDiag = "Đã đối chiếu trực tiếp ${allDevices.size} thiết bị & ${allUsers.size} tài khoản trên Cloud phn-mm-ha-n"
        } catch (e: Exception) {
            android.util.Log.e("LicenseManager", "REST Bridge lookup error: ${e.localizedMessage}")
        }
        return false
    }

    /**
     * Kiểm tra toàn diện xem thiết bị hiện tại có phải là thiết bị quen thuộc đã lên Pro trên Firebase hay không.
     * Quét đồng thời CẢ 2 NGUỒN dữ liệu trên Firebase:
     * 1. Bảng `devices` (Danh sách thiết bị đã đăng ký trên Firebase — kể cả khôi phục lại nếu từng có licenseKey / proActivatedAt mà chưa bị Admin thu hồi).
     * 2. Bảng `users` (Danh sách tài khoản Pro trong trang Quản Trị của Admin — kiểm tra xem tài khoản Pro nào đang chứa `deviceId` / `activeDeviceId` / `activeDeviceModel` của máy này).
     * Khi phát hiện khớp ở bất kỳ nguồn nào -> Tự động kích hoạt lại Pro ngay lập tức cho thiết bị mà không cần người dùng phải thao tác!
     */
    private suspend fun getDocFresh(
        docRef: com.google.firebase.firestore.DocumentReference
    ): com.google.firebase.firestore.DocumentSnapshot? = withContext(Dispatchers.IO) {
        kotlinx.coroutines.withTimeoutOrNull(6_000L) {
            try {
                docRef.get(com.google.firebase.firestore.Source.SERVER).await()
            } catch (_: Exception) {
                try {
                    docRef.get(com.google.firebase.firestore.Source.DEFAULT).await()
                } catch (_: Exception) {
                    null
                }
            }
        }
    }

    private suspend fun getQueryFresh(
        query: com.google.firebase.firestore.Query
    ): com.google.firebase.firestore.QuerySnapshot? = withContext(Dispatchers.IO) {
        kotlinx.coroutines.withTimeoutOrNull(8_000L) {
            try {
                query.get(com.google.firebase.firestore.Source.SERVER).await()
            } catch (_: Exception) {
                try {
                    query.get(com.google.firebase.firestore.Source.DEFAULT).await()
                } catch (_: Exception) {
                    null
                }
            }
        }
    }

    private suspend fun queryWhereInBatches(
        collection: com.google.firebase.firestore.CollectionReference,
        field: String,
        rawValues: Collection<String>
    ): List<com.google.firebase.firestore.DocumentSnapshot> = withContext(Dispatchers.IO) {
        val cleanList = rawValues.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        if (cleanList.isEmpty()) return@withContext emptyList()
        val results = mutableListOf<com.google.firebase.firestore.DocumentSnapshot>()
        val seenIds = mutableSetOf<String>()
        for (chunk in cleanList.chunked(10)) {
            if (chunk.isEmpty()) continue
            val snap = getQueryFresh(collection.whereIn(field, chunk))
            if (snap != null) {
                for (doc in snap.documents) {
                    if (seenIds.add(doc.id)) {
                        results.add(doc)
                    }
                }
            }
        }
        results
    }

    /**
     * HỆ THỐNG TRUY VẤN ĐÁM MÂY ĐA NGUỒN & ĐA CHIỀU (8-LAYER MULTI-VECTOR TARGETED CLOUD LOOKUP):
     * Kiểm tra toàn diện thiết bị hiện tại trên Cloud Firebase (không cần chỉ mục phức tạp Composite Index)
     * bằng mọi biến thể định danh phần cứng (`ANDROID_ID` 16 ký tự, `MT-XXXXXXXX` 8 ký tự, `MediaDrm Widevine HW-ID`),
     * mọi biến thể mã khóa SHA-256 cố định (`candidateKeys`), và đối chiếu chuẩn hóa sâu trên 8 tầng dữ liệu:
     * - Tầng 0: Chữ ký phần cứng bảo mật nội bộ (`Settings.Secure`) trên mọi biến thể Key của máy.
     * - Tầng 1: Tài khoản đang đăng nhập (`uid` & `email`), Email quen thuộc lưu trên máy & Đặc quyền Admin.
     * - Tầng 2: Bảng `devices` (5 phương thức: `hardwareId`, Direct `Document ID`, `whereIn("deviceId")`, `whereIn("licenseKey")`, `ownerEmail` & Quét chuẩn hóa sâu).
     * - Tầng 3: Bảng `users` (4 phương thức: `hardwareId`, `whereIn("deviceId")`, `whereIn("activeDeviceId")`, `email` & Quét chuẩn hóa sâu).
     * - Tầng 4: Bảng `ai_pro_chat_logs` (3 phương thức: `whereIn("deviceId")`, `whereIn("generatedKey")` & Quét nội dung biên lai AI đã duyệt).
     * - Tầng 5: Bảng `pro_recovery_requests` (3 phương thức: Direct `Document ID`, `whereIn("deviceId")` / `whereIn("restoredKey")` & Quét chuẩn hóa).
     * - Tầng 6: Bảng `payment_intents` (3 phương thức: Direct `Document ID`, `whereIn("deviceId")` & Quét chuẩn hóa các đơn `isPro == true`).
     * - Tầng 7 & 8: Kho Tri Thức Toàn Cục (`app_config/global`) & Danh sách thiết bị Pro từ xa (`PAID_DEVICES_URL`).
     */
    private val cloudProCheckMutex = Mutex()
    @Volatile
    private var lastCloudProCheckMs: Long = 0L
    @Volatile
    private var lastCloudProCheckResult: Boolean = false

    @Volatile
    private var hasShownRecognizedProToastInSession: Boolean = false

    fun showRecognizedProToastOnce(
        context: Context,
        message: String = "🔄 Nhận diện thiết bị quen thuộc! Khôi phục bản Pro vĩnh viễn thành công."
    ) {
        if (hasShownRecognizedProToastInSession) return
        hasShownRecognizedProToastInSession = true
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            try {
                android.widget.Toast.makeText(context.applicationContext, message, android.widget.Toast.LENGTH_LONG).show()
            } catch (_: Exception) {}
        }
    }

    /**
     * Tra cứu thông tin Thiết Bị Quen Thuộc (Familiar Device + Danh sách Email gợi ý) qua cả Cầu nối REST và SDK,
     * đảm bảo hoạt động 100% ngay cả khi người dùng vừa xóa app cài lại và chưa đăng nhập.
     */
    suspend fun fetchFamiliarDeviceInfoFromCloud(context: Context): Pair<Boolean, List<String>> = withContext(Dispatchers.IO) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val emails = mutableListOf<String>()
        try {
            val secEmail = Settings.Secure.getString(context.contentResolver, "magictune_familiar_email")?.trim()?.lowercase().orEmpty()
            if (secEmail.contains("@") && !secEmail.contains(" ")) {
                emails.add(secEmail)
            }
        } catch (_: Exception) {}

        val lastEmail = prefs.getString("last_familiar_email", "")?.trim()?.lowercase().orEmpty()
        val curEmail = prefs.getString("current_user_email", "")?.trim()?.lowercase().orEmpty()
        val csv = prefs.getString("familiar_emails_csv", "").orEmpty()
        if (lastEmail.contains("@") && !emails.contains(lastEmail)) emails.add(lastEmail)
        if (curEmail.contains("@") && !emails.contains(curEmail)) emails.add(curEmail)
        csv.split(",").map { it.trim().lowercase() }.forEach {
            if (it.contains("@") && !emails.contains(it)) emails.add(it)
        }

        var isFamiliar = emails.isNotEmpty() ||
            prefs.getBoolean("is_familiar_device_recognized", false) ||
            isProActivated(context)

        val deviceId = getDeviceId(context).trim().uppercase()
        val primaryHwId = getPrimaryHwId(context)
        val candidateIds = (listOf(primaryHwId, "MT-$primaryHwId", deviceId, "MT-${normalizeDeviceIdForMatch(deviceId)}") + getAllCandidateDeviceIds(context).take(8))
            .filter { it.isNotBlank() }
            .distinct()

        // 1. Kiểm tra qua REST Bridge trên devices & pro_devices & users
        try {
            for (cId in candidateIds.take(6)) {
                val devMap = FirestoreRestTokenBridge.fetchDocMapViaRest(context, "devices", cId)
                    ?: FirestoreRestTokenBridge.fetchDocMapViaRest(context, "pro_devices", cId)
                if (devMap != null && devMap.isNotEmpty()) {
                    isFamiliar = true
                    val ownerEmail = (devMap["ownerEmail"] as? String ?: devMap["email"] as? String).orEmpty().trim().lowercase()
                    if (ownerEmail.contains("@") && !ownerEmail.contains(" ") && !ownerEmail.startsWith("ẩn danh")) {
                        emails.remove(ownerEmail)
                        emails.add(0, ownerEmail)
                        recordFamiliarEmailAndDeviceLocally(context, ownerEmail)
                    }
                    applyCloudProMapToLocal(context, devMap, deviceId)
                }
            }
            val topIds = candidateIds.take(10)
            if (topIds.isNotEmpty()) {
                val matchedUsers = FirestoreRestTokenBridge.queryCollectionByFieldInViaRest(context, "users", "activeDeviceId", topIds) +
                    FirestoreRestTokenBridge.queryCollectionByFieldInViaRest(context, "users", "deviceId", topIds)
                for (uDoc in matchedUsers) {
                    isFamiliar = true
                    val uEmail = (uDoc["email"] as? String).orEmpty().trim().lowercase()
                    if (uEmail.contains("@") && !uEmail.contains(" ")) {
                        if (!emails.contains(uEmail)) emails.add(uEmail)
                        recordFamiliarEmailAndDeviceLocally(context, uEmail)
                    }
                    applyCloudProMapToLocal(context, uDoc, deviceId)
                }
            }
        } catch (_: Exception) {}

        Pair(isFamiliar, emails.distinct())
    }

    suspend fun checkDeviceRecognizedProInCloud(
        context: Context,
        forceRefresh: Boolean = true,
        allowFullCollectionScan: Boolean = false
    ): Boolean = withContext(Dispatchers.IO) {
        if (isAdminSimulateFreeMode(context)) {
            _isProFlow.value = false
            return@withContext false
        }
        try {
            kotlinx.coroutines.withContext(kotlinx.coroutines.NonCancellable) {
                cloudProCheckMutex.withLock {
                    if (isAdminSimulateFreeMode(context)) {
                        _isProFlow.value = false
                        return@withLock false
                    }
                    val now = System.currentTimeMillis()
                    // Chống gọi dồn dập nhiều lần liên tiếp khi vừa mở ứng dụng (cooldown 45s cho kiểm tra tự động)
                    val cooldownMs = if (allowFullCollectionScan) 8_000L else if (forceRefresh) 25_000L else 60_000L
                    if (lastCloudProCheckMs > 0L && (now - lastCloudProCheckMs) < cooldownMs) {
                        return@withLock lastCloudProCheckResult || isProActivated(context)
                    }
                    val found = kotlinx.coroutines.withTimeoutOrNull(10000L) {
                        performDeviceRecognizedProCheckInternal(context, allowFullCollectionScan = allowFullCollectionScan)
                    } ?: false
                    if (isAdminSimulateFreeMode(context)) {
                        _isProFlow.value = false
                        return@withLock false
                    }
                    val finalPro = found || isProActivated(context)
                    lastCloudProCheckMs = System.currentTimeMillis()
                    lastCloudProCheckResult = finalPro
                    finalPro
                }
            }
        } catch (e: Exception) {
            isProActivated(context)
        }
    }

    private suspend fun performDeviceRecognizedProCheckInternal(
        context: Context,
        allowFullCollectionScan: Boolean = false
    ): Boolean {
        try {
            val auth = Firebase.auth
            val current = auth.currentUser
            if (current != null && current.isAnonymous) {
                // Tuyệt đối không dùng phiên Anonymous trên FirebaseAuth vì sẽ làm giao diện hiểu nhầm là đã đăng nhập tài khoản!
                auth.signOut()
            }
        } catch (_: Throwable) {}

        val deviceId = getDeviceId(context).trim().uppercase()
        val normCurrentId = normalizeDeviceIdForMatch(deviceId)
        val hwId = getHardwareId().trim()
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val user = try { Firebase.auth.currentUser?.takeIf { !it.isAnonymous } } catch (_: Exception) { null }

        // Tập hợp đầy đủ mọi biến thể ID và Mã Key SHA-256 của thiết bị hiện tại
        val candidateIds = getAllCandidateDeviceIds(context)
        val candidateKeyMap = getAllCandidateLicenseKeys(context)
        val candidateKeys = candidateKeyMap.keys.toList()
        val candidateCleanKeySet = candidateKeys.map { it.replace("-", "").trim().uppercase() }.toSet()

        val savedEmail = prefs.getString("current_user_email", "")?.trim()?.lowercase().orEmpty()
        val familiarEmail = prefs.getString("last_familiar_email", "")?.trim()?.lowercase().orEmpty()
        val authEmail = user?.email?.trim()?.lowercase().orEmpty()
        val candidateEmails = listOf(authEmail, savedEmail, familiarEmail)
            .filter { it.isNotBlank() && it.contains("@") && !it.contains(" ") }
            .distinct()

        // Quét ngay qua Cầu nối Xác thực REST (`FirestoreRestTokenBridge` - dùng chung nguồn dữ liệu trực tiếp với trang Quản Trị Admin)
        val matchedViaRest = checkDeviceRecognizedProViaRestBridge(
            context = context,
            deviceId = deviceId,
            normCurrentId = normCurrentId,
            hwId = hwId,
            candidateIds = candidateIds,
            candidateKeyMap = candidateKeyMap,
            candidateCleanKeySet = candidateCleanKeySet,
            candidateEmails = candidateEmails,
            allowFullCollectionScan = allowFullCollectionScan
        )
        if (matchedViaRest) return true

        // Nếu chỉ kiểm tra tự động lúc mở app và chưa đăng nhập tài khoản Google -> Dừng ngay sau khi đã kiểm tra REST mục tiêu để tiết kiệm 100% pin & mạng!
        if (!allowFullCollectionScan && user == null && candidateEmails.isEmpty()) {
            return false
        }

        try {
            val db = FirebaseFirestore.getInstance()

            // =========================================================================
            // TẦNG 1: TÀI KHOẢN ĐANG ĐĂNG NHẬP / EMAIL QUEN THUỘC / ADMIN CHÍNH CHỦ
            // =========================================================================
            if (user != null) {
                val isAdminUser = authEmail.equals(ADMIN_EMAIL, ignoreCase = true) || authEmail.equals("vuongdhkmhn@gmail.com", ignoreCase = true)
                val uDoc = getDocFresh(db.collection("users").document(user.uid))
                val uRevoked = uDoc?.getBoolean("revokedByAdmin") == true
                if (uRevoked && !isAdminUser) {
                    enforceLocalRevocationFromCloud(context)
                    return false
                }
                val isAccTier = isAdminUser ||
                    (uDoc?.getBoolean("isAccountPro") == true) ||
                    (uDoc?.getString("proTier") == "ACCOUNT_PRO") ||
                    (uDoc?.getString("magictuneTier") == "ACCOUNT_PRO")
                val uDevId = uDoc?.getString("deviceId") ?: ""
                val uActDevId = uDoc?.getString("activeDeviceId") ?: ""
                val deviceMatchesUser = uDevId.isBlank() ||
                    isDeviceIdMatchingCurrentDevice(context, uDevId) ||
                    isDeviceIdMatchingCurrentDevice(context, uActDevId) ||
                    (hwId.isNotBlank() && uDoc?.getString("hardwareId") == hwId)
                val rawUserPro = (uDoc?.getBoolean("isPro") == true) ||
                    isAccTier ||
                    (uDoc?.getString("proTier") == "DEVICE_PRO") ||
                    (uDoc?.getBoolean("magictunePro") == true)
                val uIsPro = isAdminUser || isAccTier || (rawUserPro && deviceMatchesUser)
                if (uIsPro && !uRevoked) {
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = isAccTier,
                        licenseKey = if (isAdminUser) "ADMIN_MASTER_PRO_RESTORED"
                        else if (isAccTier) generateAccountProLicenseKeyForDevice(deviceId)
                        else generateLicenseKeyForDevice(deviceId),
                        recognizedEmail = authEmail,
                        recognizedRole = if (isAdminUser) "admin" else (uDoc?.getString("role") ?: "")
                    )
                    return true
                }
            }

            // Kiểm tra theo danh sách Email quen thuộc trên bảng `users`
            if (candidateEmails.isNotEmpty()) {
                val emailUserDocs = queryWhereInBatches(db.collection("users"), "email", candidateEmails)
                for (uDoc in emailUserDocs) {
                    if (uDoc.getBoolean("revokedByAdmin") == true) {
                        enforceLocalRevocationFromCloud(context)
                        return false
                    }
                    val uEmail = (uDoc.getString("email") ?: "").trim()
                    val uRole = (uDoc.getString("role") ?: "user").trim()
                    val isAdminAccount = uEmail.equals("vuongdhkmhn@gmail.com", ignoreCase = true) || uRole.equals("admin", ignoreCase = true)
                    val uIsAccountPro = (uDoc.getBoolean("isAccountPro") == true) ||
                        (uDoc.getString("proTier") == "ACCOUNT_PRO") ||
                        (uDoc.getString("magictuneTier") == "ACCOUNT_PRO")
                    val uIsPro = isAdminAccount ||
                        (uDoc.getBoolean("isPro") == true) ||
                        uIsAccountPro ||
                        (uDoc.getString("proTier") == "DEVICE_PRO") ||
                        (uDoc.getBoolean("magictunePro") == true)
                    if (!uIsPro) continue

                    val uDevId = uDoc.getString("deviceId") ?: ""
                    val uActDevId = uDoc.getString("activeDeviceId") ?: ""
                    val deviceMatchesUser = isDeviceIdMatchingCurrentDevice(context, uDevId) ||
                        isDeviceIdMatchingCurrentDevice(context, uActDevId) ||
                        (hwId.isNotBlank() && uDoc.getString("hardwareId") == hwId)
                    val isCurrentlyLoggedInWithThisEmail = authEmail.isNotBlank() && uEmail.equals(authEmail, ignoreCase = true)

                    // Mở khóa nếu trùng khớp ID thiết bị của máy này, hoặc đang thực sự đăng nhập bằng tài khoản Admin / Account Pro đó
                    if (deviceMatchesUser || (isCurrentlyLoggedInWithThisEmail && (isAdminAccount || uIsAccountPro))) {
                        RestoreFamiliarProHelper.applyRestoredProState(
                            context = context,
                            deviceId = deviceId,
                            isAccountTier = uIsAccountPro || (isAdminAccount && isCurrentlyLoggedInWithThisEmail),
                            licenseKey = if (isAdminAccount && isCurrentlyLoggedInWithThisEmail) "ADMIN_MASTER_PRO_RESTORED"
                            else if (uIsAccountPro) generateAccountProLicenseKeyForDevice(deviceId)
                            else generateLicenseKeyForDevice(deviceId),
                            recognizedEmail = uEmail,
                            recognizedRole = if (isAdminAccount && isCurrentlyLoggedInWithThisEmail) "admin" else ""
                        )
                        return true
                    }
                }
            }

            // =========================================================================
            // TẦNG 2: BẢNG `devices` — TRUY VẤN 5 PHƯƠNG THỨC (MULTI-VECTOR DEVICES LOOKUP)
            // =========================================================================
            val checkedDeviceDocIds = mutableSetOf<String>()

            // 2A. Phương thức 1: Truy vấn theo Hardware ID (`MediaDrm Widevine ID`)
            if (hwId.isNotBlank()) {
                val hwVariants = listOf(hwId, hwId.take(16).uppercase(), "HW-${hwId.take(16).uppercase()}").distinct()
                val hwDocs = queryWhereInBatches(db.collection("devices"), "hardwareId", hwVariants)
                for (d in hwDocs) {
                    checkedDeviceDocIds.add(d.id)
                    if (d.getBoolean("revokedByAdmin") == true) {
                        enforceLocalRevocationFromCloud(context)
                        return false
                    }
                    if (applyCloudProRecordToLocal(context, d, deviceId)) return true
                }
            }

            // 2B. Phương thức 2: Truy vấn trực tiếp theo Document ID trên toàn bộ biến thể ID (`candidateIds`)
            for (candId in candidateIds) {
                if (!checkedDeviceDocIds.add(candId)) continue
                val d = getDocFresh(db.collection("devices").document(candId))
                if (d != null && d.exists()) {
                    if (d.getBoolean("revokedByAdmin") == true) {
                        enforceLocalRevocationFromCloud(context)
                        return false
                    }
                    if (applyCloudProRecordToLocal(context, d, deviceId)) return true
                }
            }

            // 2C. Phương thức 3: Truy vấn hàng loạt `whereIn("deviceId", ...)` cho tất cả biến thể ID
            val devFieldDocs = queryWhereInBatches(db.collection("devices"), "deviceId", candidateIds)
            for (d in devFieldDocs) {
                if (checkedDeviceDocIds.add(d.id)) {
                    if (d.getBoolean("revokedByAdmin") == true) {
                        enforceLocalRevocationFromCloud(context)
                        return false
                    }
                    if (applyCloudProRecordToLocal(context, d, deviceId)) return true
                }
            }

            // 2D. Phương thức 4: Truy vấn hàng loạt `whereIn("licenseKey", ...)` theo mã khóa SHA-256 cố định của máy
            val keyFieldDocs = queryWhereInBatches(db.collection("devices"), "licenseKey", candidateKeys)
            for (d in keyFieldDocs) {
                if (checkedDeviceDocIds.add(d.id)) {
                    if (d.getBoolean("revokedByAdmin") == true) {
                        enforceLocalRevocationFromCloud(context)
                        return false
                    }
                    if (applyCloudProRecordToLocal(context, d, deviceId)) return true
                }
            }

            // 2E. Phương thức 5: Truy vấn theo `ownerEmail` quen thuộc & Quét đối chiếu chuẩn hóa sâu trên `devices`
            if (candidateEmails.isNotEmpty()) {
                val ownerDocs = queryWhereInBatches(db.collection("devices"), "ownerEmail", candidateEmails)
                for (d in ownerDocs) {
                    val dDevId = d.getString("deviceId") ?: d.id
                    val dHwId = d.getString("hardwareId") ?: ""
                    val dIsAcc = (d.getBoolean("isAccountPro") == true) || (d.getString("proTier") == "ACCOUNT_PRO")
                    if (dIsAcc || isDeviceIdMatchingCurrentDevice(context, dDevId) || (hwId.isNotBlank() && dHwId == hwId)) {
                        if (d.getBoolean("revokedByAdmin") == true) {
                            enforceLocalRevocationFromCloud(context)
                            return false
                        }
                        if (applyCloudProRecordToLocal(context, d, deviceId)) return true
                    }
                }
            }

            val allDevicesSnap = if (allowFullCollectionScan) getQueryFresh(db.collection("devices")) else null
            if (allDevicesSnap != null) {
                for (d in allDevicesSnap.documents) {
                    if (checkedDeviceDocIds.contains(d.id)) continue
                    val docDevId = d.getString("deviceId") ?: d.id
                    val docHwId = (d.getString("hardwareId") ?: "").trim()
                    val docKeyClean = (d.getString("licenseKey") ?: "").replace("-", "").trim().uppercase()

                    val isIdMatch = isDeviceIdMatchingCurrentDevice(context, d.id) ||
                        isDeviceIdMatchingCurrentDevice(context, docDevId) ||
                        (hwId.isNotBlank() && docHwId.isNotBlank() && docHwId == hwId)
                    val isKeyMatch = docKeyClean.length >= 12 && candidateCleanKeySet.contains(docKeyClean)

                    if (isIdMatch || isKeyMatch) {
                        if (d.getBoolean("revokedByAdmin") == true && isIdMatch) {
                            enforceLocalRevocationFromCloud(context)
                            return false
                        }
                        if (applyCloudProRecordToLocal(context, d, deviceId)) return true
                    }
                }
            }

            // =========================================================================
            // TẦNG 3: BẢNG `users` — TRUY VẤN 4 PHƯƠNG THỨC (MULTI-VECTOR USERS LOOKUP)
            // =========================================================================
            val checkedUserDocIds = mutableSetOf<String>()
            val matchedUserDocs = mutableListOf<com.google.firebase.firestore.DocumentSnapshot>()

            // 3A. Theo `hardwareId`
            if (hwId.isNotBlank()) {
                matchedUserDocs.addAll(queryWhereInBatches(db.collection("users"), "hardwareId", listOf(hwId, hwId.take(16).uppercase())))
            }
            // 3B. Theo `deviceId` (mọi biến thể ID)
            matchedUserDocs.addAll(queryWhereInBatches(db.collection("users"), "deviceId", candidateIds))
            // 3C. Theo `activeDeviceId` (mọi biến thể ID)
            matchedUserDocs.addAll(queryWhereInBatches(db.collection("users"), "activeDeviceId", candidateIds))

            for (uDoc in matchedUserDocs) {
                if (!checkedUserDocIds.add(uDoc.id)) continue
                if (uDoc.getBoolean("revokedByAdmin") == true) continue

                val uRole = (uDoc.getString("role") ?: "user").trim()
                val uEmail = (uDoc.getString("email") ?: "").trim()
                val isAdminAccount = uEmail.equals("vuongdhkmhn@gmail.com", ignoreCase = true) || uRole.equals("admin", ignoreCase = true)
                val uIsAccountPro = (uDoc.getBoolean("isAccountPro") == true) || (uDoc.getString("proTier") == "ACCOUNT_PRO")
                val uIsPro = (uDoc.getBoolean("isPro") == true) || uIsAccountPro || (uDoc.getString("proTier") == "DEVICE_PRO")

                if (isAdminAccount || uIsPro) {
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = uIsAccountPro,
                        licenseKey = if (isAdminAccount) "ADMIN_MASTER_PRO_RESTORED"
                        else if (uIsAccountPro) generateAccountProLicenseKeyForDevice(deviceId)
                        else generateLicenseKeyForDevice(deviceId),
                        recognizedEmail = uEmail,
                        recognizedRole = if (isAdminAccount) "admin" else ""
                    )
                    return true
                }
            }

            // 3D. Quét đối chiếu chuẩn hóa sâu trên `users`
            val allUsersSnap = if (allowFullCollectionScan) getQueryFresh(db.collection("users")) else null
            if (allUsersSnap != null) {
                for (uDoc in allUsersSnap.documents) {
                    if (checkedUserDocIds.contains(uDoc.id)) continue
                    if (uDoc.getBoolean("revokedByAdmin") == true) continue

                    val uDevId = uDoc.getString("deviceId") ?: ""
                    val uActDevId = uDoc.getString("activeDeviceId") ?: ""
                    val uHwId = uDoc.getString("hardwareId") ?: ""
                    if (isDeviceIdMatchingCurrentDevice(context, uDevId) ||
                        isDeviceIdMatchingCurrentDevice(context, uActDevId) ||
                        (hwId.isNotBlank() && uHwId == hwId)
                    ) {
                        val uRole = (uDoc.getString("role") ?: "user").trim()
                        val uEmail = (uDoc.getString("email") ?: "").trim()
                        val isAdminAccount = uEmail.equals("vuongdhkmhn@gmail.com", ignoreCase = true) || uRole.equals("admin", ignoreCase = true)
                        val uIsAccountPro = (uDoc.getBoolean("isAccountPro") == true) || (uDoc.getString("proTier") == "ACCOUNT_PRO")
                        val uIsPro = (uDoc.getBoolean("isPro") == true) || uIsAccountPro || (uDoc.getString("proTier") == "DEVICE_PRO")
                        if (isAdminAccount || uIsPro) {
                            RestoreFamiliarProHelper.applyRestoredProState(
                                context = context,
                                deviceId = deviceId,
                                isAccountTier = uIsAccountPro,
                                licenseKey = if (isAdminAccount) "ADMIN_MASTER_PRO_RESTORED"
                                else if (uIsAccountPro) generateAccountProLicenseKeyForDevice(deviceId)
                                else generateLicenseKeyForDevice(deviceId),
                                recognizedEmail = uEmail,
                                recognizedRole = if (isAdminAccount) "admin" else ""
                            )
                            return true
                        }
                    }
                }
            }

            // =========================================================================
            // TẦNG 4: BẢNG `ai_pro_chat_logs` — TRUY VẤN 3 PHƯƠNG THỨC (AI AUDIT LOGS LOOKUP)
            // =========================================================================
            val checkedLogIds = mutableSetOf<String>()
            val matchedLogs = mutableListOf<com.google.firebase.firestore.DocumentSnapshot>()
            // 4A. Theo `deviceId` (mọi biến thể ID)
            matchedLogs.addAll(queryWhereInBatches(db.collection("ai_pro_chat_logs"), "deviceId", candidateIds))
            // 4B. Theo `generatedKey` (mọi biến thể Key SHA-256)
            matchedLogs.addAll(queryWhereInBatches(db.collection("ai_pro_chat_logs"), "generatedKey", candidateKeys))

            for (logDoc in matchedLogs) {
                if (!checkedLogIds.add(logDoc.id)) continue
                val key = (logDoc.getString("generatedKey") ?: "").trim()
                val proGrantedLog = logDoc.getBoolean("proGranted") == true
                if (proGrantedLog) {
                    val tier = (logDoc.getString("grantedTier") ?: "").trim()
                    val isAcc = tier == "ACCOUNT_PRO" || key.startsWith("TKPR-", ignoreCase = true)
                    val email = (logDoc.getString("ownerEmail") ?: "").trim()
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = isAcc,
                        licenseKey = key.ifBlank { if (isAcc) generateAccountProLicenseKeyForDevice(deviceId) else generateLicenseKeyForDevice(deviceId) },
                        recognizedEmail = email,
                        recognizedRole = ""
                    )
                    return true
                }
            }

            // 4C. Quét chuẩn hóa sâu trên `ai_pro_chat_logs` (chỉ nhận các bản ghi proGranted == true)
            val allAiLogsSnap = if (allowFullCollectionScan) getQueryFresh(db.collection("ai_pro_chat_logs")) else null
            if (allAiLogsSnap != null) {
                for (logDoc in allAiLogsSnap.documents) {
                    if (checkedLogIds.contains(logDoc.id)) continue
                    val proGrantedLog = logDoc.getBoolean("proGranted") == true
                    if (!proGrantedLog) continue

                    val key = (logDoc.getString("generatedKey") ?: "").trim()
                    val cleanKey = key.replace("-", "").trim().uppercase()
                    val logDevId = logDoc.getString("deviceId") ?: ""

                    val matchesLog = isDeviceIdMatchingCurrentDevice(context, logDevId) ||
                        (cleanKey.length >= 16 && candidateCleanKeySet.contains(cleanKey))

                    if (matchesLog) {
                        val tier = (logDoc.getString("grantedTier") ?: "").trim()
                        val isAcc = tier == "ACCOUNT_PRO" || key.startsWith("TKPR-", ignoreCase = true)
                        val email = (logDoc.getString("ownerEmail") ?: "").trim()
                        RestoreFamiliarProHelper.applyRestoredProState(
                            context = context,
                            deviceId = deviceId,
                            isAccountTier = isAcc,
                            licenseKey = key.ifBlank { if (isAcc) generateAccountProLicenseKeyForDevice(deviceId) else generateLicenseKeyForDevice(deviceId) },
                            recognizedEmail = email,
                            recognizedRole = ""
                        )
                        return true
                    }
                }
            }

            // =========================================================================
            // TẦNG 5: BẢNG `pro_recovery_requests` — TRUY VẤN 3 PHƯƠNG THỨC
            // =========================================================================
            val checkedRecoveryIds = mutableSetOf<String>()
            val recoveryCandidateDocs = mutableListOf<com.google.firebase.firestore.DocumentSnapshot>()

            // 5A. Direct Document ID (`recovery_<ID>` và `<ID>`)
            val recoveryDocIdCandidates = candidateIds.flatMap { listOf("recovery_$it", it) }.distinct()
            for (rId in recoveryDocIdCandidates) {
                val rDoc = getDocFresh(db.collection("pro_recovery_requests").document(rId))
                if (rDoc != null && rDoc.exists() && checkedRecoveryIds.add(rDoc.id)) {
                    recoveryCandidateDocs.add(rDoc)
                }
            }
            // 5B. `whereIn` trên `deviceId` và `restoredKey`
            for (rDoc in queryWhereInBatches(db.collection("pro_recovery_requests"), "deviceId", candidateIds)) {
                if (checkedRecoveryIds.add(rDoc.id)) recoveryCandidateDocs.add(rDoc)
            }
            for (rDoc in queryWhereInBatches(db.collection("pro_recovery_requests"), "restoredKey", candidateKeys)) {
                if (checkedRecoveryIds.add(rDoc.id)) recoveryCandidateDocs.add(rDoc)
            }

            for (rDoc in recoveryCandidateDocs) {
                val rStatus = (rDoc.getString("status") ?: "").uppercase()
                val key = (rDoc.getString("restoredKey") ?: "").trim()
                if (rStatus == "RESTORED" || rStatus == "APPROVED" || key.isNotBlank()) {
                    val email = (rDoc.getString("ownerEmail") ?: "").trim()
                    val isAcc = key.startsWith("TKPR-", ignoreCase = true)
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = isAcc,
                        licenseKey = key.ifBlank { generateLicenseKeyForDevice(deviceId) },
                        recognizedEmail = email,
                        recognizedRole = ""
                    )
                    return true
                }
            }

            // 5C. Quét chuẩn hóa sâu trên `pro_recovery_requests`
            val allRecoverySnap = if (allowFullCollectionScan) getQueryFresh(db.collection("pro_recovery_requests")) else null
            if (allRecoverySnap != null) {
                for (rDoc in allRecoverySnap.documents) {
                    if (checkedRecoveryIds.contains(rDoc.id)) continue
                    val rStatus = (rDoc.getString("status") ?: "").uppercase()
                    val key = (rDoc.getString("restoredKey") ?: "").trim()
                    if (rStatus != "RESTORED" && rStatus != "APPROVED" && key.isBlank()) continue

                    val rDevId = rDoc.getString("deviceId") ?: rDoc.id.removePrefix("recovery_")
                    val cleanKey = key.replace("-", "").trim().uppercase()
                    if (isDeviceIdMatchingCurrentDevice(context, rDevId) ||
                        (cleanKey.length >= 12 && candidateCleanKeySet.contains(cleanKey))
                    ) {
                        val email = (rDoc.getString("ownerEmail") ?: "").trim()
                        val isAcc = key.startsWith("TKPR-", ignoreCase = true)
                        RestoreFamiliarProHelper.applyRestoredProState(
                            context = context,
                            deviceId = deviceId,
                            isAccountTier = isAcc,
                            licenseKey = key.ifBlank { generateLicenseKeyForDevice(deviceId) },
                            recognizedEmail = email,
                            recognizedRole = ""
                        )
                        return true
                    }
                }
            }

            // =========================================================================
            // TẦNG 6: BẢNG `payment_intents` — TRUY VẤN 3 PHƯƠNG THỨC
            // =========================================================================
            val checkedIntentIds = mutableSetOf<String>()
            val intentDocs = mutableListOf<com.google.firebase.firestore.DocumentSnapshot>()

            // 6A. Direct Document ID
            for (candId in candidateIds) {
                val iDoc = getDocFresh(db.collection("payment_intents").document(candId))
                if (iDoc != null && iDoc.exists() && checkedIntentIds.add(iDoc.id)) {
                    intentDocs.add(iDoc)
                }
            }
            // 6B. `whereIn` trên `deviceId`
            for (iDoc in queryWhereInBatches(db.collection("payment_intents"), "deviceId", candidateIds)) {
                if (checkedIntentIds.add(iDoc.id)) intentDocs.add(iDoc)
            }

            for (iDoc in intentDocs) {
                if (iDoc.getBoolean("isPro") == true) {
                    val isAcc = iDoc.getBoolean("isAccountPro") == true
                    val email = (iDoc.getString("ownerEmail") ?: "").trim()
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = isAcc,
                        licenseKey = if (isAcc) generateAccountProLicenseKeyForDevice(deviceId) else generateLicenseKeyForDevice(deviceId),
                        recognizedEmail = email,
                        recognizedRole = ""
                    )
                    return true
                }
            }

            // 6C. Quét chuẩn hóa sâu trên `payment_intents` (hỗ trợ cả Doc ID có hậu tố timestamp `MT-XXXX_1710...`)
            val allIntentsSnap = if (allowFullCollectionScan) getQueryFresh(db.collection("payment_intents")) else null
            if (allIntentsSnap != null) {
                for (iDoc in allIntentsSnap.documents) {
                    if (checkedIntentIds.contains(iDoc.id)) continue
                    if (iDoc.getBoolean("isPro") != true) continue
                    val iDevId = iDoc.getString("deviceId")?.takeIf { it.isNotBlank() } ?: iDoc.id.substringBefore("_")
                    if (isDeviceIdMatchingCurrentDevice(context, iDevId)) {
                        val isAcc = iDoc.getBoolean("isAccountPro") == true
                        val email = (iDoc.getString("ownerEmail") ?: "").trim()
                        RestoreFamiliarProHelper.applyRestoredProState(
                            context = context,
                            deviceId = deviceId,
                            isAccountTier = isAcc,
                            licenseKey = if (isAcc) generateAccountProLicenseKeyForDevice(deviceId) else generateLicenseKeyForDevice(deviceId),
                            recognizedEmail = email,
                            recognizedRole = ""
                        )
                        return true
                    }
                }
            }

            // =========================================================================
            // TẦNG 7: BẢNG `app_config/global` (DANH SÁCH PRO & KHO TRI THỨC TOÀN CỤC)
            // =========================================================================
            val globalConfigMap = FirestoreRestTokenBridge.fetchDocMapViaRest(
                context,
                "app_config",
                "global",
                listOf("pro_device_ids", "pro_keys_list", "ai_knowledge_base_key_list")
            )
            if (!globalConfigMap.isNullOrEmpty()) {
                val proDevIdsRaw = (globalConfigMap["pro_device_ids"] as? String ?: "").uppercase()
                val proKeysRaw = (globalConfigMap["pro_keys_list"] as? String ?: "").uppercase()
                val knowledgeBaseText = (globalConfigMap["ai_knowledge_base_key_list"] as? String ?: "").uppercase()

                val proDevTokens = proDevIdsRaw.split(Regex("[,;\\s\\n]+")).map { it.trim() }.filter { it.length >= 6 }
                val matchesDevId = proDevTokens.any { token -> isDeviceIdMatchingCurrentDevice(context, token) } ||
                    candidateIds.any { cId ->
                        val upperCId = cId.uppercase()
                        upperCId.length >= 8 && (proDevIdsRaw.contains(upperCId) || knowledgeBaseText.contains("DEVICEID=$upperCId") || knowledgeBaseText.contains("NORMID=$upperCId"))
                    }

                var matchedAccKey: String? = null
                var matchedDevKey: String? = null
                for ((candKey, isAcc) in candidateKeyMap) {
                    if (proKeysRaw.contains(candKey) || knowledgeBaseText.contains(candKey)) {
                        if (isAcc) matchedAccKey = candKey else matchedDevKey = candKey
                    }
                }

                if (matchesDevId || matchedAccKey != null || matchedDevKey != null) {
                    val isAcc = matchedAccKey != null
                    val finalKey = matchedAccKey ?: matchedDevKey ?: if (isAcc) {
                        generateAccountProLicenseKeyForDevice(deviceId)
                    } else {
                        generateLicenseKeyForDevice(deviceId)
                    }
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = isAcc,
                        licenseKey = finalKey,
                        recognizedEmail = "",
                        recognizedRole = ""
                    )
                    return true
                }
            }

            // =========================================================================
            // TẦNG 8: ĐỐI CHIẾU DANH SÁCH THIẾT BỊ TRẢ PHÍ TỪ XA (`PAID_DEVICES_URL`)
            // =========================================================================
            if (!prefs.getBoolean(KEY_REVOKED_BY_ADMIN, false)) {
                var connection: HttpURLConnection? = null
                try {
                    val url = URL(PAID_DEVICES_URL)
                    connection = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 4500
                        readTimeout = 4500
                        useCaches = false
                    }
                    if (connection.responseCode == 200) {
                        val content = BufferedReader(InputStreamReader(connection.inputStream)).use { it.readText().uppercase() }
                        val remoteLines = content.split(Regex("[\\s,;\\n]+")).map { it.trim() }.filter { it.length >= 6 }
                        val matchedRemote = remoteLines.any { token -> isDeviceIdMatchingCurrentDevice(context, token) } ||
                            candidateIds.any { cId -> cId.length >= 8 && content.contains(cId.uppercase()) }
                        if (matchedRemote) {
                            RestoreFamiliarProHelper.applyRestoredProState(
                                context = context,
                                deviceId = deviceId,
                                isAccountTier = false,
                                licenseKey = generateLicenseKeyForDevice(deviceId),
                                recognizedEmail = "",
                                recognizedRole = ""
                            )
                            return true
                        }
                    }
                } catch (_: Exception) {
                } finally {
                    connection?.disconnect()
                }
            }

        } catch (e: Exception) {
            android.util.Log.e("LicenseManager", "Error checking Pro in cloud: ${e.localizedMessage}")
        }

        // Cuối cùng, trả về trạng thái Pro hiện tại của máy (bao gồm Tầng 0 - chữ ký phần cứng Settings.Secure)
        return isProActivated(context)
    }

    /**
     * HÀM ĐỒNG BỘ TOÀN BỘ KNOWLEDGE BASE & KEY LIST AI LÊN CLOUD FIREBASE
     * Quét tất cả người dùng, thiết bị, log AI, yêu cầu khôi phục để tạo bộ tri thức chuẩn hóa 100%
     */
    fun syncAllKnowledgeBaseAndKeyListToCloud(
        context: Context,
        additionalGroqKeys: String = "",
        onComplete: (Boolean, Int, Int, String) -> Unit
    ) {
        val appCtx = context.applicationContext
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = FirebaseFirestore.getInstance()

                // Quét 4 collection đồng thời song song (Parallel Async) với timeout 6s mỗi truy vấn SDK
                val usersDef = async {
                    kotlinx.coroutines.withTimeoutOrNull(6000L) {
                        try { db.collection("users").get().await() } catch (_: Exception) { null }
                    }
                }
                val devicesDef = async {
                    kotlinx.coroutines.withTimeoutOrNull(6000L) {
                        try { db.collection("devices").get().await() } catch (_: Exception) { null }
                    }
                }
                val recoveryDef = async {
                    kotlinx.coroutines.withTimeoutOrNull(6000L) {
                        try { db.collection("pro_recovery_requests").get().await() } catch (_: Exception) { null }
                    }
                }
                val aiLogsDef = async {
                    kotlinx.coroutines.withTimeoutOrNull(6000L) {
                        try { db.collection("ai_pro_chat_logs").get().await() } catch (_: Exception) { null }
                    }
                }

                val usersSnap = usersDef.await()
                val devicesSnap = devicesDef.await()
                val recoverySnap = recoveryDef.await()
                val aiLogsSnap = aiLogsDef.await()

                val proDeviceIds = mutableSetOf<String>()
                val proKeys = mutableSetOf<String>()
                val proUserEmails = mutableSetOf<String>()
                val knowledgeLines = mutableListOf<String>()

                // 1. Quét bảng users (SDK hoặc REST Fallback)
                if (usersSnap != null && !usersSnap.isEmpty) {
                    for (doc in usersSnap.documents) {
                        val isPro = doc.getBoolean("isPro") == true || doc.getBoolean("isAccountPro") == true || doc.getString("proTier") == "ACCOUNT_PRO"
                        val revoked = doc.getBoolean("revokedByAdmin") == true
                        if (isPro && !revoked) {
                            val email = (doc.getString("email") ?: "").trim()
                            val devId = (doc.getString("deviceId") ?: "").trim().uppercase()
                            val actDevId = (doc.getString("activeDeviceId") ?: "").trim().uppercase()
                            if (email.isNotBlank()) proUserEmails.add(email.lowercase())
                            if (devId.isNotBlank()) {
                                proDeviceIds.add(devId)
                                proDeviceIds.add(normalizeDeviceIdForMatch(devId))
                            }
                            if (actDevId.isNotBlank()) {
                                proDeviceIds.add(actDevId)
                                proDeviceIds.add(normalizeDeviceIdForMatch(actDevId))
                            }
                            knowledgeLines.add("USER_PRO: email=$email, deviceId=$devId, activeDeviceId=$actDevId")
                        }
                    }
                } else {
                    // Fallback REST users với timeout 5s
                    val restUsers = kotlinx.coroutines.withTimeoutOrNull(5000L) {
                        FirestoreRestTokenBridge.fetchCollectionMapsViaRest(appCtx, "users", 200)
                    } ?: emptyList()
                    for (map in restUsers) {
                        val isPro = (map["isPro"] == true) || (map["isAccountPro"] == true) || (map["proTier"] == "ACCOUNT_PRO")
                        val revoked = map["revokedByAdmin"] == true
                        if (isPro && !revoked) {
                            val email = (map["email"] as? String ?: "").trim()
                            val devId = (map["deviceId"] as? String ?: "").trim().uppercase()
                            val actDevId = (map["activeDeviceId"] as? String ?: "").trim().uppercase()
                            if (email.isNotBlank()) proUserEmails.add(email.lowercase())
                            if (devId.isNotBlank()) {
                                proDeviceIds.add(devId)
                                proDeviceIds.add(normalizeDeviceIdForMatch(devId))
                            }
                            if (actDevId.isNotBlank()) {
                                proDeviceIds.add(actDevId)
                                proDeviceIds.add(normalizeDeviceIdForMatch(actDevId))
                            }
                            knowledgeLines.add("USER_PRO: email=$email, deviceId=$devId, activeDeviceId=$actDevId")
                        }
                    }
                }

                // 2. Quét bảng devices (SDK hoặc REST Fallback)
                if (devicesSnap != null && !devicesSnap.isEmpty) {
                    for (doc in devicesSnap.documents) {
                        val devId = (doc.getString("deviceId") ?: doc.id).trim().uppercase()
                        val normId = normalizeDeviceIdForMatch(devId)
                        val isPro = doc.getBoolean("isPro") == true || doc.getBoolean("isAccountPro") == true || doc.getString("proTier") == "ACCOUNT_PRO"
                        val revoked = doc.getBoolean("revokedByAdmin") == true
                        val key = (doc.getString("licenseKey") ?: "").trim()

                        if ((isPro || key.isNotBlank()) && !revoked) {
                            if (devId.isNotBlank()) proDeviceIds.add(devId)
                            if (normId.isNotBlank()) proDeviceIds.add(normId)
                            if (key.isNotBlank()) proKeys.add(key)
                            val ownerEmail = (doc.getString("ownerEmail") ?: "").trim()
                            if (ownerEmail.contains("@")) proUserEmails.add(ownerEmail.lowercase())
                            knowledgeLines.add("DEVICE_PRO: deviceId=$devId, normId=$normId, key=$key, owner=$ownerEmail")
                        }
                    }
                } else {
                    // Fallback REST devices
                    val restDevices = kotlinx.coroutines.withTimeoutOrNull(5000L) {
                        FirestoreRestTokenBridge.fetchCollectionMapsViaRest(appCtx, "devices", 300)
                    } ?: emptyList()
                    for (map in restDevices) {
                        val devId = (map["deviceId"] as? String ?: map["__id"] as? String ?: "").trim().uppercase()
                        val normId = normalizeDeviceIdForMatch(devId)
                        val isPro = (map["isPro"] == true) || (map["isAccountPro"] == true) || (map["proTier"] == "ACCOUNT_PRO")
                        val revoked = map["revokedByAdmin"] == true
                        val key = (map["licenseKey"] as? String ?: "").trim()

                        if ((isPro || key.isNotBlank()) && !revoked) {
                            if (devId.isNotBlank()) proDeviceIds.add(devId)
                            if (normId.isNotBlank()) proDeviceIds.add(normId)
                            if (key.isNotBlank()) proKeys.add(key)
                            val ownerEmail = (map["ownerEmail"] as? String ?: "").trim()
                            if (ownerEmail.contains("@")) proUserEmails.add(ownerEmail.lowercase())
                            knowledgeLines.add("DEVICE_PRO: deviceId=$devId, normId=$normId, key=$key, owner=$ownerEmail")
                        }
                    }
                }

                // 3. Quét bảng ai_pro_chat_logs
                if (aiLogsSnap != null && !aiLogsSnap.isEmpty) {
                    for (doc in aiLogsSnap.documents) {
                        val granted = doc.getBoolean("proGranted") == true
                        val key = (doc.getString("generatedKey") ?: "").trim()
                        val devId = (doc.getString("deviceId") ?: "").trim().uppercase()
                        val normId = normalizeDeviceIdForMatch(devId)
                        if ((granted || key.isNotBlank()) && devId.isNotBlank()) {
                            proDeviceIds.add(devId)
                            if (normId.isNotBlank()) proDeviceIds.add(normId)
                            if (key.isNotBlank()) proKeys.add(key)
                            knowledgeLines.add("AI_LOG_PRO: deviceId=$devId, key=$key")
                        }
                    }
                } else {
                    val restLogs = kotlinx.coroutines.withTimeoutOrNull(5000L) {
                        FirestoreRestTokenBridge.fetchCollectionMapsViaRest(appCtx, "ai_pro_chat_logs", 150)
                    } ?: emptyList()
                    for (map in restLogs) {
                        val granted = map["proGranted"] == true
                        val key = (map["generatedKey"] as? String ?: "").trim()
                        val devId = (map["deviceId"] as? String ?: "").trim().uppercase()
                        val normId = normalizeDeviceIdForMatch(devId)
                        if ((granted || key.isNotBlank()) && devId.isNotBlank()) {
                            proDeviceIds.add(devId)
                            if (normId.isNotBlank()) proDeviceIds.add(normId)
                            if (key.isNotBlank()) proKeys.add(key)
                            knowledgeLines.add("AI_LOG_PRO: deviceId=$devId, key=$key")
                        }
                    }
                }

                // 4. Quét bảng pro_recovery_requests
                if (recoverySnap != null && !recoverySnap.isEmpty) {
                    for (doc in recoverySnap.documents) {
                        val status = (doc.getString("status") ?: "").uppercase()
                        val devId = (doc.getString("deviceId") ?: doc.id).trim().uppercase()
                        val key = (doc.getString("restoredKey") ?: "").trim()
                        if ((status == "RESTORED" || status == "APPROVED") && devId.isNotBlank()) {
                            proDeviceIds.add(devId)
                            val normId = normalizeDeviceIdForMatch(devId)
                            if (normId.isNotBlank()) proDeviceIds.add(normId)
                            if (key.isNotBlank()) proKeys.add(key)
                        }
                    }
                }

                // Đồng bộ ngược lại bảng devices cho từng thiết bị Pro (Safe batch write)
                try {
                    val batch = db.batch()
                    var batchCount = 0
                    for (pId in proDeviceIds) {
                        if (pId.length < 3) continue
                        val devRef = db.collection("devices").document(pId)
                        val expectedKey = if (pId.startsWith("TKPR-")) pId else generateLicenseKeyForDevice(pId)
                        batch.set(
                            devRef,
                            mapOf(
                                "deviceId" to pId,
                                "isPro" to true,
                                "revokedByAdmin" to false,
                                "licenseKey" to expectedKey,
                                "updatedAt" to FieldValue.serverTimestamp()
                            ),
                            SetOptions.merge()
                        )
                        batchCount++
                        if (batchCount >= 450) break
                    }
                    if (batchCount > 0) {
                        kotlinx.coroutines.withTimeoutOrNull(6000L) {
                            batch.commit().await()
                        }
                    }
                } catch (be: Exception) {
                    android.util.Log.w("LicenseManager", "Batch write devices warning: ${be.message}")
                }

                // Lưu kho API Key AI nếu có
                val cleanPool = additionalGroqKeys.trim().ifBlank { getGroqApiKeyPool(appCtx) }
                if (cleanPool.isNotBlank()) {
                    setGroqApiKeyPool(appCtx, cleanPool)
                }

                // Cắt tỉa nếu knowledgeBaseText quá lớn để đảm bảo an toàn dung lượng Firestore
                val trimmedKnowledge = if (knowledgeLines.size > 2000) {
                    knowledgeLines.take(2000).joinToString("\n")
                } else {
                    knowledgeLines.joinToString("\n")
                }

                val proDeviceIdsJoined = proDeviceIds.joinToString(",")
                val proKeysJoined = proKeys.joinToString(",")
                val proEmailsJoined = proUserEmails.joinToString(",")

                val globalConfigUpdates = mutableMapOf<String, Any>(
                    "ai_knowledge_base_key_list" to trimmedKnowledge,
                    "pro_device_ids" to proDeviceIdsJoined,
                    "pro_keys_list" to proKeysJoined,
                    "pro_user_emails" to proEmailsJoined,
                    "updatedAt" to System.currentTimeMillis()
                )
                if (cleanPool.isNotBlank()) {
                    globalConfigUpdates[KEY_GROQ_API_KEY_POOL] = cleanPool
                }
                val magic_livePool = getMagicLiveApiKeyPool(appCtx)
                if (magic_livePool.isNotBlank()) {
                    globalConfigUpdates[KEY_GEMINI_API_KEY_POOL] = magic_livePool
                }

                // Document này có các chuỗi chỉ mục lớn; dùng REST để tránh Firestore SDK tạo overlay cục bộ lớn.
                val writeSuccess = kotlinx.coroutines.withTimeoutOrNull(8000L) {
                    withContext(Dispatchers.IO) {
                        FirestoreRestTokenBridge.patchDocViaRest(appCtx, "app_config", "global", globalConfigUpdates)
                    }
                } ?: false

                withContext(Dispatchers.Main) {
                    if (writeSuccess || proDeviceIds.isNotEmpty()) {
                        onComplete(true, proDeviceIds.size, proKeys.size, "Đã đồng bộ ${proDeviceIds.size} thiết bị Pro và ${proKeys.size} Mã Key vào Knowledge Base & Cloud Firebase thành công!")
                    } else {
                        onComplete(false, proDeviceIds.size, proKeys.size, "Đã gom ${proDeviceIds.size} thiết bị Pro nhưng máy chủ Firebase tạm thời không phản hồi. Vui lòng thử lại sau vài giây.")
                    }
                }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) {
                    onComplete(true, 0, 0, "Đã hoàn tất đồng bộ dữ liệu nội bộ và sẵn sàng phục vụ.")
                }
            }
        }
    }

    /**
     * Lưu chữ ký phần cứng Pro của thiết bị vào `Settings.Secure` (và qua `ShellEngine` nếu ADB/Shizuku đang bật)
     * để cả các máy Pro của Tài Khoản Vãng Lai (chưa từng đăng nhập) vẫn tự động được nhận diện trong 0ms ngay khi cài lại app!
     */
    fun persistHardwareProSignatureIfNeeded(context: Context, activated: Boolean = isProActivated(context)) {
        val appCtx = context.applicationContext
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            try {
                val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                val deviceId = getDeviceId(appCtx).uppercase()
                val isAcc = prefs.getBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false) || prefs.getBoolean(KEY_UPGRADED_TO_ACCOUNT_PRO, false)
                val expectedSig = if (activated) {
                    val rawKey = if (isAcc) generateAccountProLicenseKeyForDevice(deviceId) else generateLicenseKeyForDevice(deviceId)
                    rawKey.replace("-", "").trim().uppercase()
                } else {
                    ""
                }
                val familiarEmail = prefs.getString("current_user_email", "")?.trim()?.takeIf { it.contains("@") }
                    ?: prefs.getString("last_familiar_email", "")?.trim()?.takeIf { it.contains("@") }
                    ?: ""
                var wroteViaResolver = false
                try {
                    wroteViaResolver = Settings.Secure.putString(appCtx.contentResolver, SECURE_KEY_PRO_HW_SIG, expectedSig)
                    Settings.Secure.putString(appCtx.contentResolver, SECURE_KEY_PERSISTENT_DEVICE_ID, deviceId)
                    if (familiarEmail.isNotBlank()) {
                        Settings.Secure.putString(appCtx.contentResolver, "magictune_familiar_email", familiarEmail.lowercase())
                    }
                } catch (_: Exception) {}

                if (!wroteViaResolver) {
                    val shell = com.example.core.shell.ShellEngine.getInstance(appCtx)
                    if (shell.state.value.isAdbReady) {
                        try {
                            val pkg = appCtx.packageName
                            val emailCmd = if (familiarEmail.isNotBlank()) {
                                "; settings put secure magictune_familiar_email '${familiarEmail.lowercase()}' >/dev/null 2>&1"
                            } else ""
                            shell.execute(
                                "pm grant --user 0 $pkg android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1 || true; " +
                                    "settings put secure $SECURE_KEY_PRO_HW_SIG '$expectedSig' >/dev/null 2>&1; " +
                                    "settings put secure $SECURE_KEY_PERSISTENT_DEVICE_ID '$deviceId' >/dev/null 2>&1" +
                                    emailCmd
                            )
                        } catch (_: Exception) {}
                    }
                }
            } catch (_: Exception) {}
        }
    }

    fun applyCloudUserDevicePro(
        context: Context,
        email: String = "",
        role: String = ""
    ) {
        val appCtx = context.applicationContext
        if (isAdminSimulateFreeMode(appCtx)) return
        val deviceId = getDeviceId(appCtx).trim().uppercase()
        RestoreFamiliarProHelper.applyRestoredProState(
            context = appCtx,
            deviceId = deviceId,
            isAccountTier = false,
            licenseKey = generateLicenseKeyForDevice(deviceId),
            recognizedEmail = email,
            recognizedRole = role
        )
    }

    private object RestoreFamiliarProHelper {
        @Synchronized
        fun applyRestoredProState(
            context: Context,
            deviceId: String,
            isAccountTier: Boolean,
            licenseKey: String,
            recognizedEmail: String,
            recognizedRole: String,
            isAdminExplicitDowngrade: Boolean = false
        ) {
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val wasRevoked = prefs.getBoolean(KEY_REVOKED_BY_ADMIN, false)
            val wasPro = prefs.getBoolean(KEY_PRO_ACTIVATED, false)
            val existingKey = prefs.getString(KEY_ACTIVATED_LICENSE, "") ?: ""
            val isVerifiedAccountKey = existingKey.startsWith("TKPR-", ignoreCase = true) || licenseKey.startsWith("TKPR-", ignoreCase = true)
            val wasAccTier = isVerifiedAccountKey && (
                prefs.getBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false) ||
                prefs.getBoolean(KEY_UPGRADED_TO_ACCOUNT_PRO, false) ||
                existingKey.startsWith("TKPR-", ignoreCase = true)
            )

            // QUY TẮC BẢO VỆ KHÁCH PRO: Chỉ có Admin (isAdminExplicitDowngrade = true) mới có quyền hạ cấp từ Pro Tài Khoản xuống Pro Thiết Bị.
            // Mọi luồng khôi phục tự động / Chatbot / đồng bộ lịch sử cũ tuyệt đối KHÔNG BAO GIỜ được hạ cấp khách đang có Pro Tài Khoản THẬT SỰ!
            val effectiveAccountTier = if (isAdminExplicitDowngrade && !isCurrentUserAdmin(context)) {
                false
            } else {
                isAccountTier || wasAccTier || licenseKey.startsWith("TKPR-", ignoreCase = true)
            }

            val resolvedKey = when {
                effectiveAccountTier && !licenseKey.startsWith("TKPR-", ignoreCase = true) && !licenseKey.startsWith("ADMIN_", ignoreCase = true) -> {
                    if (existingKey.startsWith("TKPR-", ignoreCase = true) || existingKey.startsWith("ADMIN_", ignoreCase = true)) {
                        existingKey
                    } else {
                        generateAccountProLicenseKeyForDevice(deviceId)
                    }
                }
                licenseKey.isNotBlank() -> licenseKey
                existingKey.isNotBlank() -> existingKey
                else -> "CLOUD_FAMILIAR_DEVICE_RESTORED"
            }

            val stateChanged = wasRevoked || !wasPro || (wasAccTier != effectiveAccountTier) || (existingKey != resolvedKey)
            val isNewlyGrantedPro = (!wasPro || wasRevoked)
            val isNewlyUpgradedToAccountPro = (wasPro && !wasAccTier && effectiveAccountTier)

            val editor = prefs.edit()
                .putBoolean(KEY_REVOKED_BY_ADMIN, false)
                .putBoolean(KEY_PRO_ACTIVATED, true)
                .putBoolean(KEY_ACCOUNT_PRO_ACTIVATED, effectiveAccountTier)
                .putBoolean(KEY_UPGRADED_TO_ACCOUNT_PRO, effectiveAccountTier)
                .putString(KEY_ACTIVATED_LICENSE, resolvedKey)

            val activeUser = try { Firebase.auth.currentUser?.takeIf { !it.isAnonymous } } catch (_: Exception) { null }
            if (recognizedEmail.contains("@") && !recognizedEmail.contains(" ")) {
                editor.putString("last_familiar_email", recognizedEmail.lowercase())
                if (activeUser != null && prefs.getString("current_user_email", "").isNullOrBlank()) {
                    editor.putString("current_user_email", recognizedEmail.lowercase())
                }
            }
            if (activeUser != null && (
                    recognizedRole.equals("admin", ignoreCase = true) ||
                        recognizedEmail.equals("vuongdhkmhn@gmail.com", ignoreCase = true)
                    )
            ) {
                editor.putString("current_user_role", "admin")
                markLocalAdminVerified(context, recognizedEmail.ifBlank { "vuongdhkmhn@gmail.com" })
            }
            editor.apply()
            writeProIntegritySeal(context, isPro = true, isAccPro = effectiveAccountTier)
            _isProFlow.value = isProActivated(context)

            if (isNewlyGrantedPro || isNewlyUpgradedToAccountPro) {
                notifyProApprovedIfNeeded(
                    context = context,
                    isAccountPro = effectiveAccountTier,
                    targetEmail = recognizedEmail,
                    deviceId = deviceId
                )
            }

            // Chỉ đồng bộ ngược lên Cloud khi trạng thái Pro thực sự đổi. Ghi định kỳ
            // tại đây khiến các snapshot listener tự kích hoạt lại và tạo thêm mutation
            // trong Firestore dù không có thay đổi cần lưu.
            if (stateChanged) {
                persistHardwareProSignatureIfNeeded(context, true)
                autoSyncProToCloud(context, effectiveAccountTier, resolvedKey)

                try {
                    val db = FirebaseFirestore.getInstance()
                    val hwId = getHardwareId()
                    val normId = normalizeDeviceIdForMatch(deviceId)
                    val updateData = mutableMapOf<String, Any>(
                        "deviceId" to deviceId,
                        "normalizedDeviceId" to normId,
                        "hardwareId" to hwId,
                        "model" to "${Build.MANUFACTURER} ${Build.MODEL}",
                        "isPro" to true,
                        "isAccountPro" to effectiveAccountTier,
                        "upgradedToAccountPro" to effectiveAccountTier,
                        "proTier" to if (effectiveAccountTier) "ACCOUNT_PRO" else "DEVICE_PRO",
                        "revokedByAdmin" to false,
                        "licenseKey" to resolvedKey.ifBlank { generateLicenseKeyForDevice(deviceId) },
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                    if (recognizedEmail.contains("@") && !recognizedEmail.contains(" ")) {
                        updateData["ownerEmail"] = recognizedEmail
                    }
                    val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
                    // `autoSyncProToCloud` ở trên đã đồng bộ deviceId và MT-deviceId.
                    // Chỉ cần cập nhật bí danh normalized riêng; tránh xếp cùng payload
                    // nhiều lần lên mutation queue cho các document đã được đồng bộ.
                    if (normId.isNotBlank() && normId != deviceId) {
                        val normalizedPayload = updateData + ("deviceId" to normId)
                        if (user == null) {
                            FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "devices", normId, normalizedPayload)
                        } else {
                            db.collection("devices").document(normId).set(normalizedPayload, SetOptions.merge())
                                .addOnFailureListener {
                                    FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "devices", normId, normalizedPayload)
                                }
                        }
                    }
                } catch (_: Exception) {}
            }

            if (stateChanged && !isAdminSimulateFreeMode(context)) {
                notifyProAndConfigStateChanged(context)
            }
        }
    }

    fun getProPrice(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString("pro_price", null)
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, "pro_price")
        if (!sec.isNullOrBlank()) {
            prefs.edit().putString("pro_price", sec).apply()
            return sec
        }
        return "50.000đ"
    }

    fun getProOriginalPrice(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString("pro_price_original", null)
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, "pro_price_original")
        if (!sec.isNullOrBlank()) {
            prefs.edit().putString("pro_price_original", sec).apply()
            return sec
        }
        return "80.000đ"
    }

    fun setProOriginalPrice(context: Context, price: String) {
        val clean = price.trim().ifBlank { "80.000đ" }
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString("pro_price_original", clean).apply()
        putSecureConfigString(context, "pro_price_original", clean)
        syncCloudGlobalConfigMap(context, mapOf("pro_price_original" to clean))
        notifyProAndConfigStateChanged(context)
    }

    /**
     * Giá mua thẳng gói PRO TÀI KHOẢN (Đăng nhập đổi máy tự do - 1 máy hoạt động cùng lúc)
     * Cao hơn gói Pro theo ID máy (Mặc định: 100.000đ)
     */
    fun getAccountProPrice(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString("account_pro_price", null)
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, "account_pro_price")
        if (!sec.isNullOrBlank()) {
            prefs.edit().putString("account_pro_price", sec).apply()
            return sec
        }
        return "100.000đ"
    }

    fun getAccountProOriginalPrice(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString("account_pro_price_original", null)
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, "account_pro_price_original")
        if (!sec.isNullOrBlank()) {
            prefs.edit().putString("account_pro_price_original", sec).apply()
            return sec
        }
        return "160.000đ"
    }

    fun setAccountProOriginalPrice(context: Context, price: String) {
        val clean = price.trim().ifBlank { "160.000đ" }
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString("account_pro_price_original", clean).apply()
        putSecureConfigString(context, "account_pro_price_original", clean)
        syncCloudGlobalConfigMap(context, mapOf("account_pro_price_original" to clean))
        notifyProAndConfigStateChanged(context)
    }

    fun isProSaleActive(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        if (prefs.contains("is_pro_sale_active")) {
            return prefs.getBoolean("is_pro_sale_active", true)
        }
        val sec = getSecureConfigString(context, "is_pro_sale_active")
        if (!sec.isNullOrBlank()) {
            val v = sec.toBooleanStrictOrNull() ?: true
            prefs.edit().putBoolean("is_pro_sale_active", v).apply()
            return v
        }
        return true
    }

    fun setProSaleActive(context: Context, active: Boolean) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean("is_pro_sale_active", active).apply()
        putSecureConfigString(context, "is_pro_sale_active", active.toString())
        syncCloudGlobalConfigMap(context, mapOf("is_pro_sale_active" to active))
        notifyProAndConfigStateChanged(context)
    }

    fun setAccountProPrice(context: Context, price: String) {
        val clean = price.trim().ifBlank { "100.000đ" }
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString("account_pro_price", clean).apply()
        putSecureConfigString(context, "account_pro_price", clean)
        syncCloudGlobalConfigMap(context, mapOf("account_pro_price" to clean))
        notifyProAndConfigStateChanged(context)
    }

    /**
     * Phí nâng cấp từ PRO THIẾT BỊ (ID máy) lên PRO TÀI KHOẢN (Trả thêm tiền chênh lệch)
     * Mặc định: 50.000đ
     */
    fun getUpgradeToAccountProPrice(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString("upgrade_account_pro_price", null)
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, "upgrade_account_pro_price")
        if (!sec.isNullOrBlank()) {
            prefs.edit().putString("upgrade_account_pro_price", sec).apply()
            return sec
        }
        return "50.000đ"
    }

    fun setUpgradeToAccountProPrice(context: Context, price: String) {
        val clean = price.trim().ifBlank { "50.000đ" }
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString("upgrade_account_pro_price", clean).apply()
        putSecureConfigString(context, "upgrade_account_pro_price", clean)
        syncCloudGlobalConfigMap(context, mapOf("upgrade_account_pro_price" to clean))
        notifyProAndConfigStateChanged(context)
    }

    /**
     * Lưu đồng thời cả giá gốc, giá giảm Pro và cấu hình đợt giảm giá vào SharedPreferences + Settings.Secure + Firestore app_config/global trong 1 lệnh nguyên tử
     */
    fun saveAllProPrices(
        context: Context,
        proPrice: String,
        accountProPrice: String,
        upgradeAccountProPrice: String,
        proPriceOriginal: String = "80.000đ",
        accountProPriceOriginal: String = "160.000đ",
        isProSaleActive: Boolean = true,
        onComplete: ((Boolean) -> Unit)? = null
    ) {
        val cleanPro = proPrice.trim().ifBlank { "50.000đ" }
        val cleanAcc = accountProPrice.trim().ifBlank { "100.000đ" }
        val cleanUpg = upgradeAccountProPrice.trim().ifBlank { "50.000đ" }
        val cleanProOrig = proPriceOriginal.trim().ifBlank { "80.000đ" }
        val cleanAccOrig = accountProPriceOriginal.trim().ifBlank { "160.000đ" }

        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString("pro_price", cleanPro)
            .putString("account_pro_price", cleanAcc)
            .putString("upgrade_account_pro_price", cleanUpg)
            .putString("pro_price_original", cleanProOrig)
            .putString("account_pro_price_original", cleanAccOrig)
            .putBoolean("is_pro_sale_active", isProSaleActive)
            .apply()

        putSecureConfigString(context, "pro_price", cleanPro)
        putSecureConfigString(context, "account_pro_price", cleanAcc)
        putSecureConfigString(context, "upgrade_account_pro_price", cleanUpg)
        putSecureConfigString(context, "pro_price_original", cleanProOrig)
        putSecureConfigString(context, "account_pro_price_original", cleanAccOrig)
        putSecureConfigString(context, "is_pro_sale_active", isProSaleActive.toString())

        notifyProAndConfigStateChanged(context)

        syncCloudGlobalConfigMap(
            context,
            mapOf(
                "pro_price" to cleanPro,
                "account_pro_price" to cleanAcc,
                "upgrade_account_pro_price" to cleanUpg,
                "pro_price_original" to cleanProOrig,
                "account_pro_price_original" to cleanAccOrig,
                "is_pro_sale_active" to isProSaleActive
            ),
            onComplete
        )
    }

    /**
     * Xử lý tin nhắn SMS từ Ngân hàng / Momo
     */
    fun processIncomingSmsText(context: Context, rawBody: String, sender: String = ""): Boolean {
        return processIncomingPaymentText(context, rawBody, sender, source = "SMS")
    }

    /**
     * Kiểm tra thông báo/SMS có chứa từ khóa báo giao dịch thất bại, không đủ số dư, hủy bỏ, mã OTP hay yêu cầu chuyển tiền không.
     */
    fun containsPaymentFailureKeywords(upperText: String): Boolean {
        return upperText.contains("KHONG DU") ||
                upperText.contains("KHÔNG ĐỦ") ||
                upperText.contains("THAT BAI") ||
                upperText.contains("THẤT BẠI") ||
                upperText.contains("KHONG THANH CONG") ||
                upperText.contains("KHÔNG THÀNH CÔNG") ||
                upperText.contains("CHUA THANH CONG") ||
                upperText.contains("CHƯA THÀNH CÔNG") ||
                upperText.contains("TU CHOI") ||
                upperText.contains("TỪ CHỐI") ||
                upperText.contains("BI HUY") ||
                upperText.contains("BỊ HỦY") ||
                upperText.contains("DA HUY") ||
                upperText.contains("ĐÃ HỦY") ||
                upperText.contains("LOI GIAO DICH") ||
                upperText.contains("LỖI GIAO DỊCH") ||
                upperText.contains("MA OTP") ||
                upperText.contains("MÃ OTP") ||
                upperText.contains("MA XAC THUC") ||
                upperText.contains("MÃ XÁC THỰC") ||
                upperText.contains("KHONG CHIA SE MA") ||
                upperText.contains("KHÔNG CHIA SẺ MÃ") ||
                upperText.contains("YEU CAU CHUYEN") ||
                upperText.contains("YÊU CẦU CHUYỂN") ||
                upperText.contains("NHAC NO") ||
                upperText.contains("NHẮC NỢ")
    }

    /**
     * Kiểm tra đầu số gửi SMS có phải là Brandname chính thống của Ngân Hàng / Ví điện tử hay không.
     * Chặn hoàn toàn các số điện thoại cá nhân (09..., 03..., 07..., 08..., 05..., +84...) gửi tin nhắn SMS giả mạo biến động số dư!
     */
    fun isOfficialBankSmsSender(sender: String): Boolean {
        val clean = sender.trim().uppercase()
        if (clean.isBlank()) return false
        // Nếu người gửi chỉ toàn chữ số hoặc bắt đầu bằng +84 / 84 / 03 / 05 / 07 / 08 / 09 (số ĐT cá nhân) -> Chặn!
        val digitsOnly = clean.replace("+", "").replace(" ", "").replace("-", "")
        if (digitsOnly.all { it.isDigit() }) return false
        if (clean.startsWith("+84") || clean.startsWith("09") || clean.startsWith("03") ||
            clean.startsWith("07") || clean.startsWith("08") || clean.startsWith("05")
        ) {
            return false
        }

        val bankBrandnames = listOf(
            "MBBANK", "MB", "VIETCOMBANK", "VCB", "TECHCOMBANK", "TCB",
            "BIDV", "VIETINBANK", "CTG", "AGRIBANK", "ACB", "VPBANK",
            "TPBANK", "TPB", "SACOMBANK", "STB", "MSB", "OCB", "VIB",
            "SHB", "HDBANK", "SEABANK", "LPBANK", "LIENVIET", "EXIMBANK",
            "CAKE", "TIMO", "TNEX", "MOMO", "ZALOPAY", "VIETTELPAY",
            "VIETTELMONEY", "VNPAY", "NAMABANK", "BACABANK", "PVCOMBANK",
            "ABBANK", "KIENLONGBANK", "VIETBANK", "NCB", "BVBANK"
        )
        return bankBrandnames.any { clean.contains(it) }
    }

    /**
     * Bóc tách số tiền giao dịch thực tế (VNĐ) từ thông báo Ngân hàng / SMS.
     * Loại bỏ phần "Số dư cuối / SD:" để tránh trường hợp khách chuyển 1.000đ nhưng số dư tài khoản còn 500.000đ!
     */
    fun extractMaxVndAmount(rawText: String, deviceIdToStrip: String = ""): Long {
        var cleaned = rawText.uppercase()
        if (deviceIdToStrip.isNotBlank()) {
            cleaned = cleaned.replace(deviceIdToStrip.uppercase(), " ")
            cleaned = cleaned.replace(deviceIdToStrip.uppercase().replace("MT-", ""), " ")
        }
        // Loại bỏ số tài khoản 9-16 chữ số liền nhau để không nhầm STK với số tiền
        cleaned = cleaned.replace(Regex("\\b0[0-9]{8,15}\\b"), " ")

        // 1. Ưu tiên tìm số tiền đi kèm dấu +/- hoặc sau từ khóa GD / Số tiền / Thay đổi (Số tiền giao dịch trực tiếp)
        val signedTxRegex = Regex("""(?:GD|GIAO\s*DỊCH|GIAO\s*DICH|SỐ\s*TIỀN|SO\s*TIEN|THAY\s*ĐỔI|THAY\s*DOI|CHUYỂN|CHUYEN)?\s*[:=]?\s*[+-]\s*([0-9]{1,3}(?:[.,][0-9]{3})+|[0-9]{5,9})\s*(?:VND|VNĐ|Đ|D|\b)""")
        val signedMatches = signedTxRegex.findAll(cleaned).mapNotNull { m ->
            m.groupValues.getOrNull(1)?.replace(".", "")?.replace(",", "")?.toLongOrNull()
        }.filter { it in 1_000L..500_000_000L }.toList()

        if (signedMatches.isNotEmpty()) {
            // Nếu có số tiền biến động trực tiếp (+/-), trả về số tiền biến động đầu tiên (nếu < 50.000đ như 1.000đ/2.000đ sẽ bị phát hiện ngay!)
            return signedMatches.first()
        }

        // 2. Xóa các cụm "SD: xxx VND" / "Số dư: xxx VND" (không có chữ "thay đổi") trước khi quét số tiền kèm đơn vị VND/đ
        val withoutBalance = cleaned.replace(
            Regex("""(?:SD|SỐ\s*DƯ\s*CUỐI|SO\s*DU\s*CUOI|SỐ\s*DƯ\s*KHẢ\s*DỤNG|SO\s*DU\s*KHA\s*DUNG|SỐ\s*DƯ|SO\s*DU)\s*[:=]?\s*[0-9]{1,3}(?:[.,][0-9]{3})*\s*(?:VND|VNĐ|Đ|D)?"""),
            " "
        )

        val currencyRegex = Regex("""\b([0-9]{1,3}(?:[.,][0-9]{3})+|[0-9]{5,9})\s*(?:VND|VNĐ|Đ)\b""")
        val currencyMatches = currencyRegex.findAll(withoutBalance).mapNotNull { m ->
            m.groupValues.getOrNull(1)?.replace(".", "")?.replace(",", "")?.toLongOrNull()
        }.filter { it in 1_000L..500_000_000L }.toList()

        if (currencyMatches.isNotEmpty()) {
            return currencyMatches.first()
        }
        return 0L
    }

    /**
     * Danh sách Package chính thống của các Ngân Hàng & Ví Điện Tử tại Việt Nam
     * Chỉ chấp nhận thông báo biến động số dư từ các package trong danh sách trắng này (hoặc SMS Brandname ngân hàng).
     */
    val OFFICIAL_BANK_APP_PACKAGES = setOf(
        "com.mbmobile", // MB Bank
        "com.VCB", // Vietcombank
        "vn.com.techcombank.bb.app", "com.techcombank.bb.app", // Techcombank
        "com.vnpay.bidv", // BIDV SmartBanking
        "com.vietinbank.ipay", // VietinBank iPay
        "com.vnpay.agribank", // Agribank Plus / E-Mobile Banking
        "mobile.acb.com.vn", "com.acb.acbmobile", // ACB One
        "com.vnpay.vpbankonline", "vn.com.vpbank.neo", // VPBank NEO
        "com.tpb.mb.gprsandroid", "com.tpb.mobile", // TPBank Mobile
        "com.sacombank.ewallet", "com.vnpay.sacombank", // Sacombank Pay / mBanking
        "com.vib.myvib2", "com.vib.myvib", // MyVIB
        "vn.shb.mbanking", "com.shb.saigonhanoi", // SHB Mobile / SAHA
        "com.hdbank.ipayment", // HDBank
        "vn.com.ocb.omni", "com.ocb.omniextra", // OCB OMNI
        "vn.com.msb.smartbanking", // MSB mBank
        "vn.com.seabank.mb1", // SeAMobile
        "vn.com.lpb.lienviet24h", // LPBank / LienViet24h
        "com.vnpay.eximbank", // Eximbank EDigi
        "com.cake.banking", "vn.be.cake", // Cake by VPBank
        "io.lifestyle.timo", "vn.timo.plus", "vn.banvietbank.timo", // Timo
        "vn.tnex.consumer", // TNEX
        "com.mservice.momotransfer", // MoMo
        "com.bplus.vtpay", // Viettel Money
        "vn.zalopay.app", // ZaloPay
        "com.vnpay.wallet", // VNPAY
        "com.namabank.ebanking", // Nam A Bank
        "com.bab.mobilebanking", // Bac A Bank
        "com.pvcombank.mobile", // PVcomBank
        "com.abbank.abditizen", // ABBANK
        "com.kienlongbank.mb", // KienlongBank
        "com.vnpay.vietbank", // Vietbank
        "com.ncb.bank" // NCB iziMobile
    )

    val SYSTEM_SMS_APP_PACKAGES = setOf(
        "com.google.android.apps.messaging",
        "com.android.mms",
        "com.hihonor.mms",
        "com.huawei.message",
        "com.samsung.android.messaging",
        "com.miui.mms",
        "com.coloros.mms",
        "com.oppo.mms"
    )

    val BLOCKED_SOCIAL_CHAT_PACKAGES = setOf(
        "com.zing.zalo",
        "com.facebook.orca",
        "com.facebook.katana",
        "com.facebook.lite",
        "org.telegram.messenger",
        "org.telegram.messenger.web",
        "com.whatsapp",
        "com.viber.voip",
        "com.discord",
        "com.google.android.gm",
        "com.android.chrome",
        "com.ss.android.ugc.trill",
        "com.zhiliaoapp.musically",
        "com.shopee.vn"
    )

    fun isNotificationListenerGranted(context: Context): Boolean {
        return try {
            val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: ""
            flat.contains(context.packageName)
        } catch (_: Exception) {
            false
        }
    }

    fun autoEnableNotificationListenerIfAdmin(context: Context) {
        if (!isCurrentUserAdmin(context)) return
        val appCtx = context.applicationContext
        if (isNotificationListenerGranted(appCtx)) return
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            try {
                val component = "${appCtx.packageName}/com.example.core.receiver.BankingNotificationListenerService"
                val engine = com.example.core.shell.ShellEngine.getInstance(appCtx)
                if (engine.state.value.isAdbReady) {
                    val existing = try {
                        Settings.Secure.getString(appCtx.contentResolver, "enabled_notification_listeners").orEmpty()
                    } catch (_: Exception) { "" }
                    val merged = if (existing.isBlank()) component
                    else if (existing.contains(component)) existing
                    else "$existing:$component"
                    engine.execute(
                        "cmd notification allow_listener $component >/dev/null 2>&1; " +
                            "settings put secure enabled_notification_listeners '$merged' >/dev/null 2>&1; " +
                            "pm grant ${appCtx.packageName} android.permission.RECEIVE_SMS >/dev/null 2>&1; " +
                            "appops set ${appCtx.packageName} RECEIVE_SMS allow >/dev/null 2>&1"
                    )
                }
            } catch (_: Throwable) {}
        }
    }

    /**
     * Bóc tách số tiền cộng thực tế (+VNĐ) chỉ từ phần Header của Ngân hàng (trước phần Nội dung chuyển khoản ND:),
     * đảm bảo khách hàng KHÔNG THỂ lừa hệ thống bằng cách chuyển 1.000đ rồi gõ "+50,000VND" vào nội dung chuyển khoản!
     */
    fun extractVerifiedBankCreditedAmountVnd(rawText: String, deviceIdToStrip: String = ""): Long {
        val upper = rawText.uppercase()
        // Cắt bỏ phần nội dung chuyển khoản do người gửi tự nhập (ND:, NOI DUNG:, REM:, MO TA:, LOI NHAN:)
        val memoSplitRegex = Regex("""\b(?:ND|NOI\s*DUNG|NỘI\s*DUNG|REM|REMARK|MO\s*TA|MÔ\s*TẢ|LOI\s*NHAN|LỜI\s*NHẮN|CONTENT)\s*[:=\-]""")
        val matchSplit = memoSplitRegex.find(upper)
        val bankHeaderOnly = if (matchSplit != null && matchSplit.range.first > 8) {
            upper.substring(0, matchSplit.range.first)
        } else {
            upper
        }

        // Kiểm tra nếu trong phần biến động chính có dấu trừ (-) trước số tiền -> Là giao dịch chuyển tiền đi (DEBIT), từ chối ngay!
        val debitRegex = Regex("""(?:GD|GIAO\s*DỊCH|GIAO\s*DICH|PS|SỐ\s*TIỀN|SO\s*TIEN|THAY\s*ĐỔI|THAY\s*DOI|TK\s*[A-Z0-9*]+)?\s*[:=]?\s*-\s*([0-9]{1,3}(?:[.,][0-9]{3})+|[0-9]{4,9})\s*(?:VND|VNĐ|Đ|D|\b)""")
        if (debitRegex.containsMatchIn(bankHeaderOnly)) {
            return -1L
        }

        // Ưu tiên tuyệt đối bắt số tiền có dấu CỘNG (+) rõ ràng từ Ngân hàng (VD: +50,000VND, +100.000d, GD: +50,000)
        val creditSignedRegex = Regex("""\+\s*([0-9]{1,3}(?:[.,][0-9]{3})+|[0-9]{5,9})\s*(?:VND|VNĐ|Đ|D|\b)""")
        val creditMatch = creditSignedRegex.find(bankHeaderOnly)
        if (creditMatch != null) {
            val amt = creditMatch.groupValues.getOrNull(1)?.replace(".", "")?.replace(",", "")?.toLongOrNull() ?: 0L
            if (amt in 1_000L..500_000_000L) return amt
        }

        // Trường hợp thông báo của ví/ngân hàng viết bằng chữ "nhận được 50.000đ" / "tăng 50,000 VND"
        val creditWordsRegex = Regex("""(?:NHẬN\s*ĐƯỢC|NHAN\s*DUOC|CỘNG|CONG|TĂNG|TANG|NHẬN\s*TIỀN|NHAN\s*TIEN)\s*[:+]?\s*([0-9]{1,3}(?:[.,][0-9]{3})+|[0-9]{5,9})\s*(?:VND|VNĐ|Đ|D|\b)""")
        val wordMatch = creditWordsRegex.find(bankHeaderOnly)
        if (wordMatch != null) {
            val amt = wordMatch.groupValues.getOrNull(1)?.replace(".", "")?.replace(",", "")?.toLongOrNull() ?: 0L
            if (amt in 1_000L..500_000_000L) return amt
        }

        return 0L
    }

    /**
     * Bóc tách Mã Thiết Bị (Device ID) từ nội dung chuyển khoản ngân hàng/SMS.
     * Hỗ trợ chuẩn `MT-XXXXXXXX`, `HW-XXXXXXXX`, mã 16 ký tự Hex Android ID (VD: `13D1B4AC26201E06`),
     * hoặc mã đi ngay sau từ khóa `TKPRO`, `TKPR`, `UPPRO`, `PRO`.
     */
    fun extractCandidateDeviceIdsFromBankMemo(rawText: String): List<String> {
        val upper = rawText.uppercase()
        val results = mutableListOf<String>()

        // 1. Bắt định dạng tường minh MT-XXXX hoặc HW-XXXX
        Regex("""\b(MT-[A-Z0-9]{6,16}|HW-[A-Z0-9]{8,16})\b""").findAll(upper).forEach { m ->
            val v = m.groupValues[1].trim()
            if (v.isNotBlank() && !results.contains(v)) results.add(v)
        }

        // 2. Bắt mã đi kèm từ khóa TKPRO / TKPR / UPPRO / MAGICTUNE
        Regex("""\b(?:TKPRO|TKPR|UPPRO|MAGICTUNE)\s*[:\-_]?\s*(MT-[A-Z0-9]{6,16}|[A-F0-9]{8,16})\b""").findAll(upper).forEach { m ->
            val v = m.groupValues[1].trim()
            if (v.isNotBlank() && !results.contains(v)) results.add(v)
        }

        // 3. Bắt chuẩn 16 ký tự Hexadecimal Android ID (như 13D1B4AC26201E06) có chứa cả chữ A-F và số 0-9 (không phải chuỗi toàn số của STK/Ref)
        Regex("""\b([0-9A-F]{16})\b""").findAll(upper).forEach { m ->
            val token = m.groupValues[1].trim()
            val hasHexLetter = token.any { it in 'A'..'F' }
            val hasDigit = token.any { it.isDigit() }
            if (hasHexLetter && hasDigit && !results.contains(token)) {
                results.add(token)
            }
        }

        // 4. Bắt phần sau từ khóa ND: / NOI DUNG: nếu khách chuyển khoản có chứa mã Hex 8-16 ký tự
        val memoPart = Regex("""(?:ND|NOI\s*DUNG|NỘI\s*DUNG|REM|MO\s*TA|MÔ\s*TẢ|LOI\s*NHAN|LỜI\s*NHẮN)\s*[:=\-]\s*(.+)$""")
            .find(upper)?.groupValues?.getOrNull(1) ?: upper
        val ignoredBankTokens = setOf(
            "MBVCB", "IBFT", "NAPAS", "VIETQR", "CHUYEN", "KHOAN", "THANH", "TOAN",
            "TKPRO", "UPPRO", "MAGICTUNE", "NGUYEN", "TRAN", "PHAM", "HOANG", "HUYNH", "VUONG"
        )
        Regex("""\b([0-9A-F]{8,16})\b""").findAll(memoPart).forEach { m ->
            val token = m.groupValues[1].trim()
            val hasHexLetter = token.any { it in 'A'..'F' }
            val hasDigit = token.any { it.isDigit() }
            if (hasHexLetter && hasDigit && !ignoredBankTokens.contains(token) && !results.contains(token)) {
                results.add(token)
            }
        }

        return results
    }

    private val adminBankPaymentLock = Any()

    /**
     * HỆ THỐNG AUTO-ADMIN DUYỆT PRO TỰ ĐỘNG QUA THÔNG BÁO NGÂN HÀNG & SMS TRÊN MÁY ADMIN:
     * - Chỉ chạy trên máy Admin (`isCurrentUserAdmin(context) == true`) và khi công tắc `isAutoApproveNotificationPaymentEnabled` đang BẬT.
     * - Chống gian lận 7 lớp:
     *   1. Kiểm tra nguồn thông báo từ đúng Package Ngân Hàng chính thống hoặc SMS Brandname Ngân Hàng (chặn 100% Zalo, Messenger, Telegram, SMS từ SĐT cá nhân 09/03/07/08/05/+84).
     *   2. Chặn thông báo giao dịch thất bại, OTP, nhắc nợ, hủy bỏ.
     *   3. Chặn giao dịch trừ tiền (-50.000đ, chuyển tiền đi).
     *   4. Chỉ đọc số tiền cộng (+VNĐ) ở phần Header của Ngân hàng (trước phần ND:), chặn triệt để trò chuyển 1.000đ nhưng ghi "+50,000VND" trong nội dung chuyển khoản, và loại bỏ hoàn toàn Số dư cuối (SD:).
     *   5. Kiểm tra đuôi Số tài khoản nhận khớp với STK của Admin (nếu thông báo có hiển thị STK).
     *   6. Trích xuất chính xác Device ID của khách từ nội dung chuyển khoản & đối chiếu với Cloud (`devices` / `payment_intents` / `pro_recovery_requests`).
     *   7. Chống trùng lặp (Anti-Replay Hash) — mỗi biến động số dư chỉ được duyệt đúng 1 lần duy nhất.
     */
    fun processAdminIncomingBankPaymentNotification(
        context: Context,
        sourcePackageOrSender: String,
        rawTitle: String,
        rawText: String,
        isSms: Boolean = false,
        rawPeopleAndMeta: String = ""
    ): Boolean {
        val appCtx = context.applicationContext
        if (!isCurrentUserAdmin(appCtx)) return false
        if (!isAutoApproveNotificationPaymentEnabled(appCtx)) return false

        val cleanSource = sourcePackageOrSender.trim()
        if (cleanSource.isBlank()) return false

        // LỚP 1: XÁC MINH NGUỒN CHÍNH THỐNG (CHỐNG GIẢ MẠO TỪ ZALO / MESSENGER / SĐT CÁ NHÂN)
        if (!isSms) {
            if (BLOCKED_SOCIAL_CHAT_PACKAGES.contains(cleanSource) || cleanSource == appCtx.packageName) {
                return false
            }
            val isOfficialBankApp = OFFICIAL_BANK_APP_PACKAGES.contains(cleanSource)
            val isSystemSmsNotification = SYSTEM_SMS_APP_PACKAGES.contains(cleanSource)
            if (!isOfficialBankApp && !isSystemSmsNotification) {
                return false
            }
            if (isSystemSmsNotification) {
                // Nếu là thông báo từ ứng dụng Tin nhắn SMS mặc định của máy:
                // Tiêu đề (Title) BẮT BUỘC phải là Brandname Ngân hàng chính thống (VD: MBBANK, Vietcombank, BIDV, Techcombank...)
                // và KHÔNG ĐƯỢC chứa số điện thoại cá nhân (+84, 09, 03, 07, 08, 05) trong Title hay Metadata người gửi!
                if (!isOfficialBankSmsSender(rawTitle)) {
                    return false
                }
                val upperMeta = (rawTitle + " " + rawPeopleAndMeta).uppercase()
                if (Regex("""(?:\+84|84|0[35789])[0-9]{8,9}""").containsMatchIn(upperMeta.replace(" ", "").replace("-", ""))) {
                    return false
                }
            }
        } else {
            // Nếu đến từ BroadcastReceiver SMS: Người gửi BẮT BUỘC là Brandname Ngân hàng chính thống
            if (!isOfficialBankSmsSender(cleanSource)) {
                return false
            }
        }

        val combinedText = "$rawTitle | $rawText".trim()
        val upperFull = combinedText.uppercase()

        // LỚP 2: CHẶN THÔNG BÁO LỖI, OTP, NHẮC NỢ, GIAO DỊCH THẤT BẠI
        if (containsPaymentFailureKeywords(upperFull)) {
            return false
        }

        // LỚP 3 & 4: TRÍCH XUẤT SỐ TIỀN CỘNG (+VNĐ) TỪ HEADER NGÂN HÀNG (TRƯỚC NỘI DUNG CK & KHÔNG TÍNH SỐ DƯ CUỐI)
        val candidateIds = extractCandidateDeviceIdsFromBankMemo(combinedText)
        if (candidateIds.isEmpty()) {
            return false
        }
        val primaryCandidateId = candidateIds.first()
        val creditedAmountVnd = extractVerifiedBankCreditedAmountVnd(rawText.ifBlank { combinedText }, primaryCandidateId)
        if (creditedAmountVnd <= 0L) {
            return false
        }

        val configuredDeviceProVnd = getProPrice(appCtx).replace(Regex("[^0-9]"), "").toLongOrNull()?.takeIf { it >= 10_000L } ?: 50_000L
        val configuredAccountProVnd = getAccountProPrice(appCtx).replace(Regex("[^0-9]"), "").toLongOrNull()?.takeIf { it >= 20_000L } ?: 100_000L
        val configuredUpgradeVnd = getUpgradeToAccountProPrice(appCtx).replace(Regex("[^0-9]"), "").toLongOrNull()?.takeIf { it >= 10_000L } ?: 50_000L

        if (creditedAmountVnd < configuredDeviceProVnd && creditedAmountVnd < configuredUpgradeVnd) {
            // Ghi nhật ký cảnh báo nếu có người cố tình chuyển số tiền nhỏ (VD: 1.000đ, 5.000đ) kèm mã máy để thử lừa hệ thống
            logAiProChatInteraction(
                context = appCtx,
                userMessage = "🚨 [Cảnh báo chuyển thiếu tiền] Nguồn: $cleanSource • Số tiền: +${creditedAmountVnd}đ • Mã máy: $primaryCandidateId",
                aiReply = "🛡️ Hệ thống Auto-Admin đã chặn tự động duyệt vì số tiền nhận thực tế (+${creditedAmountVnd}đ) thấp hơn mức phí quy định (${configuredDeviceProVnd}đ).",
                eventType = "BILL_REJECTED",
                proGranted = false,
                grantedTier = "NONE",
                targetDeviceId = primaryCandidateId,
                forensicVerdict = "Chuyển thiếu tiền (+${creditedAmountVnd}đ < ${configuredDeviceProVnd}đ) | Nội dung gốc: ${rawText.take(180)}"
            )
            return false
        }

        // LỚP 5: KIỂM TRA ĐUÔI SỐ TÀI KHOẢN NHẬN CỦA ADMIN (NẾU THÔNG BÁO CÓ GHI STK)
        val adminAcc = getPaymentAccountNumber(appCtx).replace(Regex("[^0-9]"), "")
        val adminTail = if (adminAcc.length >= 4) adminAcc.takeLast(4) else adminAcc
        if (adminTail.length >= 4) {
            val headerPart = upperFull.substringBefore("ND:").substringBefore("NOI DUNG").substringBefore("NỘI DUNG")
            val accMatch = Regex("""(?:TK|STK|TÀI\s*KHOẢN|TAI\s*KHOAN)\s*[:=]?\s*([0-9*xX]{4,16})""").find(headerPart)
            if (accMatch != null) {
                val notifiedAccDigits = accMatch.groupValues[1].replace(Regex("[^0-9]"), "")
                if (notifiedAccDigits.length >= 4 && !notifiedAccDigits.endsWith(adminTail) && !adminAcc.endsWith(notifiedAccDigits)) {
                    // Thông báo biến động của một tài khoản ngân hàng khác không phải STK nhận tiền MagicTune của Admin
                    return false
                }
            }
        }

        // LỚP 6: CHỐNG DUYỆT TRÙNG LẶP (ANTI-REPLAY DEDUPLICATION)
        val txSignature = computeByteArraySha256(
            "${cleanSource.uppercase()}|$primaryCandidateId|$creditedAmountVnd|${rawText.trim().uppercase()}".toByteArray(Charsets.UTF_8)
        ).take(24)

        synchronized(adminBankPaymentLock) {
            val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val processedSet = prefs.getStringSet("processed_admin_bank_tx_hashes", emptySet())?.toMutableSet() ?: mutableSetOf()
            if (processedSet.contains(txSignature)) {
                return false
            }
            processedSet.add(txSignature)
            if (processedSet.size > 500) {
                val trimmed = processedSet.toList().takeLast(400).toMutableSet()
                prefs.edit().putStringSet("processed_admin_bank_tx_hashes", trimmed).apply()
            } else {
                prefs.edit().putStringSet("processed_admin_bank_tx_hashes", processedSet).apply()
            }
        }

        // LỚP 7: ĐỐI CHIẾU CLOUD & QUYẾT ĐỊNH HẠNG PRO (DEVICE_PRO vs ACCOUNT_PRO) CHÍNH XÁC 100%
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            try {
                var resolvedTargetId = primaryCandidateId
                var isTargetAlreadyDeviceProOnCloud = false

                // Kiểm tra trên Cloud xem mã máy nào trong candidateIds đã tồn tại trong `payment_intents` hoặc `devices`
                for (cand in candidateIds) {
                    val normCand = normalizeDeviceIdForMatch(cand)
                    val devDoc = FirestoreRestTokenBridge.fetchDocMapViaRest(appCtx, "devices", cand)
                        ?: FirestoreRestTokenBridge.fetchDocMapViaRest(appCtx, "devices", normCand)
                        ?: FirestoreRestTokenBridge.fetchDocMapViaRest(appCtx, "devices", "MT-$normCand")
                    if (devDoc != null && devDoc.isNotEmpty()) {
                        resolvedTargetId = (devDoc["deviceId"] as? String)?.trim()?.uppercase()?.takeIf { it.isNotBlank() } ?: cand
                        val wasPro = (devDoc["isPro"] as? Boolean) == true ||
                            (devDoc["magictunePro"] as? Boolean) == true ||
                            (devDoc["proTier"] as? String)?.uppercase() == "DEVICE_PRO"
                        val wasRevoked = (devDoc["revokedByAdmin"] as? Boolean) == true
                        if (wasPro && !wasRevoked) {
                            isTargetAlreadyDeviceProOnCloud = true
                        }
                        break
                    }
                }

                val isExplicitUpgradeMemo = upperFull.contains("UPPRO")
                val isExplicitAccountProMemo = upperFull.contains("TKPRO") || upperFull.contains("TKPR")

                // Quy tắc chống gian lận hạng gói:
                // - Chỉ cấp Pro Tài Khoản (100k) nếu:
                //   (a) Số tiền chuyển >= 95.000đ (hoặc >= configuredAccountProVnd * 95%), HOẶC
                //   (b) Thiết bị đó ĐÃ LÀ PRO THIẾT BỊ trên Cloud (`isTargetAlreadyDeviceProOnCloud == true`) và chuyển thêm >= 50.000đ (nâng cấp `UPPRO`).
                // - Nếu thiết bị đang là Free mà chỉ chuyển 50.000đ (dù cố tình ghi chữ TKPRO hay UPPRO), hệ thống chỉ cấp đúng gói PRO THIẾT BỊ (50.000đ)!
                val grantAccountPro = (creditedAmountVnd >= (configuredAccountProVnd * 95 / 100)) ||
                    (isTargetAlreadyDeviceProOnCloud && creditedAmountVnd >= configuredUpgradeVnd && (isExplicitUpgradeMemo || isExplicitAccountProMemo))

                val sourceLabel = if (isSms) "SMS Ngân Hàng ($cleanSource)" else "App Ngân Hàng ($cleanSource)"
                val reason = "AUTO_BANK_NOTIF_VERIFIED (+${creditedAmountVnd}đ qua $sourceLabel | Mã đối soát: ${txSignature.take(10)})"

                val grantResult = executeVerifiedProGrant(
                    context = appCtx,
                    rawTargetDeviceId = resolvedTargetId,
                    grantAccountPro = grantAccountPro,
                    reason = reason
                )

                // Tăng bộ đếm số máy được Auto-Admin duyệt tự động
                val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                val newCount = prefs.getInt("auto_approved_pro_count_session", 0) + 1
                prefs.edit().putInt("auto_approved_pro_count_session", newCount).apply()

                val tierName = if (grantResult.isAccountPro) "👑 PRO TÀI KHOẢN" else "📱 PRO THIẾT BỊ"
                logCustomerPaymentIntent(
                    context = appCtx,
                    actionType = "AUTO_BANK_NOTIF_APPROVED",
                    details = "Đã nhận +${creditedAmountVnd}đ từ $sourceLabel • Tự động kích hoạt $tierName cho máy $resolvedTargetId • Key: ${grantResult.generatedKey}"
                )

                logAiProChatInteraction(
                    context = appCtx,
                    userMessage = "🔔 [Biến động số dư +${creditedAmountVnd}đ] $sourceLabel: ${rawText.take(200)}",
                    aiReply = "✅ Auto-Admin đã xác thực biến động số dư +${creditedAmountVnd}đ hợp lệ và tự động kích hoạt $tierName cho thiết bị $resolvedTargetId (Key: ${grantResult.generatedKey}).",
                    eventType = "BANK_NOTIF_AUTO_APPROVED",
                    proGranted = true,
                    grantedTier = if (grantResult.isAccountPro) "ACCOUNT_PRO" else "DEVICE_PRO",
                    generatedKey = grantResult.generatedKey,
                    targetDeviceId = resolvedTargetId,
                    bankTransCode = txSignature.take(12),
                    forensicVerdict = "Xác thực chính gốc từ $sourceLabel | Số tiền: +${creditedAmountVnd}đ | Thiết bị: $resolvedTargetId"
                )

                showAdminAutoApprovedLocalNotification(
                    context = appCtx,
                    targetDeviceId = resolvedTargetId,
                    amountVnd = creditedAmountVnd,
                    tierName = tierName,
                    sourceLabel = sourceLabel
                )
            } catch (_: Exception) {}
        }
        return true
    }

    private fun showAdminAutoApprovedLocalNotification(
        context: Context,
        targetDeviceId: String,
        amountVnd: Long,
        tierName: String,
        sourceLabel: String
    ) {
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? android.app.NotificationManager ?: return
            val channelId = "magictune_admin_auto_pay_channel"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = android.app.NotificationChannel(
                    channelId,
                    "Auto-Admin Duyệt Pro Tự Động",
                    android.app.NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Thông báo khi hệ thống tự động nhận tiền và kích hoạt Pro cho khách hàng"
                    lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                }
                nm.createNotificationChannel(channel)
            }
            val formattedAmt = java.text.NumberFormat.getInstance(java.util.Locale.forLanguageTag("vi-VN")).format(amountVnd)
            val notif = androidx.core.app.NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("💰 Đã nhận +${formattedAmt}đ • Tự động cấp Pro!")
                .setContentText("Đã mở khóa $tierName cho máy $targetDeviceId ($sourceLabel)")
                .setStyle(
                    androidx.core.app.NotificationCompat.BigTextStyle().bigText(
                        "🎉 Hệ thống Auto-Admin vừa phát hiện biến động số dư +${formattedAmt}đ từ $sourceLabel.\n" +
                            "• Thiết bị khách: $targetDeviceId\n" +
                            "• Gói kích hoạt: $tierName\n" +
                            "• Trạng thái: Đã đồng bộ lên Firebase Cloud thành công (Admin rảnh tay 100%)!"
                    )
                )
                .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
                .setVisibility(androidx.core.app.NotificationCompat.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .build()
            nm.notify((System.currentTimeMillis() % 100000).toInt(), notif)
        } catch (_: Throwable) {}
    }

    data class AdminCloudLookupResult(
        val foundOnCloud: Boolean = false,
        val resolvedDeviceId: String = "",
        val resolvedUserId: String = "",
        val resolvedEmail: String = "",
        val deviceModel: String = "",
        val proTier: String = "FREE",
        val isPro: Boolean = false,
        val isAccountPro: Boolean = false,
        val revokedByAdmin: Boolean = false,
        val licenseKeyOnCloud: String = "",
        val deviceProKey: String = "",
        val accountProKey: String = "",
        val sourceSummary: String = "",
        val bankTransCode: String = "",
        val lastReason: String = ""
    )

    data class AutoAdminDryRunResult(
        val passedAllChecks: Boolean = false,
        val layer1BankSourceOk: Boolean = false,
        val layer2NoFailureKeywordOk: Boolean = false,
        val layer3AmountVnd: Long = 0L,
        val layer4HeaderAmountOk: Boolean = false,
        val layer5BankAccountOk: Boolean = false,
        val layer6CandidateIds: List<String> = emptyList(),
        val primaryDeviceId: String = "",
        val recommendedTier: String = "NONE",
        val failureReason: String = "",
        val summaryText: String = ""
    )

    /**
     * Tra cứu nhanh hồ sơ bản quyền Pro trực tiếp trên Cloud (`devices`, `pro_devices`, `users`) theo Device ID hoặc Email.
     */
    suspend fun adminLookupTargetViaCloud(context: Context, rawQuery: String): AdminCloudLookupResult =
        kotlinx.coroutines.withContext(Dispatchers.IO) {
            val appCtx = context.applicationContext
            val cleanQuery = rawQuery.trim()
            if (cleanQuery.isBlank()) return@withContext AdminCloudLookupResult()

            val isEmailQuery = cleanQuery.contains("@")
            val cleanEmail = if (isEmailQuery) cleanQuery.lowercase() else ""
            val cleanDevId = if (!isEmailQuery) cleanQuery.uppercase() else ""
            val normDevId = normalizeDeviceIdForMatch(cleanDevId)

            var devMap: Map<String, Any>? = null
            var proDevMap: Map<String, Any>? = null
            var userMap: Map<String, Any>? = null
            var resolvedUserId = ""

            if (cleanDevId.isNotBlank()) {
                val idVariants = listOf(cleanDevId, normDevId, if (normDevId.isNotBlank()) "MT-$normDevId" else "")
                    .filter { it.isNotBlank() }.distinct()
                for (idVar in idVariants) {
                    if (devMap == null) devMap = FirestoreRestTokenBridge.fetchDocMapViaRest(appCtx, "devices", idVar)
                    if (proDevMap == null) proDevMap = FirestoreRestTokenBridge.fetchDocMapViaRest(appCtx, "pro_devices", idVar)
                }
                val uHits = FirestoreRestTokenBridge.queryCollectionByFieldInViaRest(appCtx, "users", "deviceId", idVariants, 5)
                    .ifEmpty { FirestoreRestTokenBridge.queryCollectionByFieldInViaRest(appCtx, "users", "activeDeviceId", idVariants, 5) }
                userMap = uHits.firstOrNull()
                if (userMap == null && devMap != null) {
                    val uid = (devMap["ownerUid"] as? String)?.trim().orEmpty()
                    if (uid.isNotBlank()) {
                        resolvedUserId = uid
                        userMap = FirestoreRestTokenBridge.fetchDocMapViaRest(appCtx, "users", uid)
                    }
                }
            } else if (cleanEmail.contains("@")) {
                val uHits = FirestoreRestTokenBridge.queryCollectionByFieldInViaRest(
                    appCtx,
                    "users",
                    "email",
                    listOf(cleanEmail, cleanEmail.uppercase()),
                    5
                )
                userMap = uHits.firstOrNull()
                    ?: FirestoreRestTokenBridge.fetchDocMapViaRest(
                        appCtx,
                        "users",
                        "email_${cleanEmail.replace(Regex("[^a-zA-Z0-9._-]"), "_")}"
                    )
                val linkedDev = (userMap?.get("activeDeviceId") as? String)?.trim().orEmpty()
                    .ifBlank { (userMap?.get("deviceId") as? String)?.trim().orEmpty() }
                if (linkedDev.isNotBlank()) {
                    val normLinked = normalizeDeviceIdForMatch(linkedDev)
                    for (cand in listOf(linkedDev.uppercase(), normLinked, if (normLinked.isNotBlank()) "MT-$normLinked" else "").distinct()) {
                        if (devMap == null) devMap = FirestoreRestTokenBridge.fetchDocMapViaRest(appCtx, "devices", cand)
                        if (proDevMap == null) proDevMap = FirestoreRestTokenBridge.fetchDocMapViaRest(appCtx, "pro_devices", cand)
                    }
                }
                if (devMap == null) {
                    devMap = FirestoreRestTokenBridge.queryCollectionByFieldInViaRest(
                        appCtx, "devices", "ownerEmail", listOf(cleanEmail, cleanEmail.uppercase()), 3
                    ).firstOrNull()
                }
                if (proDevMap == null) {
                    proDevMap = FirestoreRestTokenBridge.queryCollectionByFieldInViaRest(
                        appCtx, "pro_devices", "ownerEmail", listOf(cleanEmail, cleanEmail.uppercase()), 3
                    ).firstOrNull()
                }
            }

            val finalDevId = (devMap?.get("deviceId") as? String)?.trim()?.uppercase()?.takeIf { it.isNotBlank() }
                ?: (proDevMap?.get("deviceId") as? String)?.trim()?.uppercase()?.takeIf { it.isNotBlank() }
                ?: (userMap?.get("activeDeviceId") as? String)?.trim()?.uppercase()?.takeIf { it.isNotBlank() }
                ?: (userMap?.get("deviceId") as? String)?.trim()?.uppercase()?.takeIf { it.isNotBlank() }
                ?: cleanDevId

            val finalEmail = (userMap?.get("email") as? String)?.trim()?.lowercase()?.takeIf { it.contains("@") }
                ?: (devMap?.get("ownerEmail") as? String)?.trim()?.lowercase()?.takeIf { it.contains("@") }
                ?: (proDevMap?.get("ownerEmail") as? String)?.trim()?.lowercase()?.takeIf { it.contains("@") }
                ?: cleanEmail

            if (resolvedUserId.isBlank()) {
                resolvedUserId = (userMap?.get("userId") as? String)?.trim().orEmpty()
                    .ifBlank { (userMap?.get("uid") as? String)?.trim().orEmpty() }
                    .ifBlank { (devMap?.get("ownerUid") as? String)?.trim().orEmpty() }
            }

            val revoked = ((devMap?.get("revokedByAdmin") as? Boolean) == true) ||
                ((proDevMap?.get("revokedByAdmin") as? Boolean) == true) ||
                ((userMap?.get("revokedByAdmin") as? Boolean) == true)

            val rawAccountPro = ((devMap?.get("isAccountPro") as? Boolean) == true) ||
                ((proDevMap?.get("isAccountPro") as? Boolean) == true) ||
                ((userMap?.get("isAccountPro") as? Boolean) == true) ||
                ((devMap?.get("proTier") as? String)?.equals("ACCOUNT_PRO", ignoreCase = true) == true) ||
                ((proDevMap?.get("proTier") as? String)?.equals("ACCOUNT_PRO", ignoreCase = true) == true) ||
                ((userMap?.get("proTier") as? String)?.equals("ACCOUNT_PRO", ignoreCase = true) == true)

            val rawIsPro = ((devMap?.get("isPro") as? Boolean) == true) ||
                ((proDevMap?.get("isPro") as? Boolean) == true) ||
                ((userMap?.get("isPro") as? Boolean) == true) ||
                ((devMap?.get("magictunePro") as? Boolean) == true) ||
                ((proDevMap?.get("magictunePro") as? Boolean) == true)

            val effectivePro = rawIsPro && !revoked
            val effectiveAccPro = effectivePro && rawAccountPro
            val tier = when {
                revoked -> "REVOKED"
                effectiveAccPro -> "ACCOUNT_PRO"
                effectivePro -> "DEVICE_PRO"
                else -> "FREE"
            }

            val sources = mutableListOf<String>()
            if (devMap != null) sources.add("devices")
            if (proDevMap != null) sources.add("pro_devices")
            if (userMap != null) sources.add("users")

            val cloudKey = (proDevMap?.get("licenseKey") as? String)?.takeIf { it.isNotBlank() }
                ?: (devMap?.get("licenseKey") as? String)?.takeIf { it.isNotBlank() }
                ?: (userMap?.get("licenseKey") as? String).orEmpty()

            val devKey = if (finalDevId.isNotBlank()) generateLicenseKeyForDevice(finalDevId) else ""
            val accKey = when {
                finalDevId.isNotBlank() -> generateAccountProLicenseKeyForDevice(finalDevId)
                finalEmail.contains("@") -> generateAccountProKeyForEmail(finalEmail)
                else -> ""
            }

            AdminCloudLookupResult(
                foundOnCloud = sources.isNotEmpty(),
                resolvedDeviceId = finalDevId,
                resolvedUserId = resolvedUserId,
                resolvedEmail = finalEmail,
                deviceModel = (devMap?.get("model") as? String)?.takeIf { it.isNotBlank() }
                    ?: (proDevMap?.get("deviceModel") as? String).orEmpty(),
                proTier = tier,
                isPro = effectivePro,
                isAccountPro = effectiveAccPro,
                revokedByAdmin = revoked,
                licenseKeyOnCloud = cloudKey,
                deviceProKey = devKey,
                accountProKey = accKey,
                sourceSummary = if (sources.isEmpty()) "Chưa có trên Cloud" else sources.joinToString(" + "),
                bankTransCode = (devMap?.get("bankTransCode") as? String)
                    ?: (proDevMap?.get("bankTransCode") as? String)
                    ?: (userMap?.get("bankTransCode") as? String).orEmpty(),
                lastReason = (devMap?.get("approvedByAiReason") as? String)?.takeIf { it.isNotBlank() }
                    ?: (userMap?.get("approvedByAiReason") as? String)?.takeIf { it.isNotBlank() }
                    ?: (devMap?.get("proActivatedSource") as? String).orEmpty()
            )
        }

    /**
     * Chạy giả lập (Dry-Run) 7 lớp bảo mật Auto-Admin trên một đoạn thông báo/SMS ngân hàng bất kỳ mà KHÔNG ghi dữ liệu thật.
     */
    fun dryRunTestBankNotification(
        context: Context,
        rawBody: String,
        bankSourcePackageOrBrand: String = "com.mbmobile",
        isSms: Boolean = false
    ): AutoAdminDryRunResult {
        val appCtx = context.applicationContext
        val cleanSource = bankSourcePackageOrBrand.trim()
        val combinedText = "$cleanSource | $rawBody".trim()
        val upperFull = combinedText.uppercase()

        val l1SourceOk = if (!isSms) {
            !BLOCKED_SOCIAL_CHAT_PACKAGES.contains(cleanSource) &&
                OFFICIAL_BANK_APP_PACKAGES.contains(cleanSource)
        } else {
            isOfficialBankSmsSender(cleanSource)
        }
        val l2NoFailureOk = !containsPaymentFailureKeywords(upperFull)
        val candidateIds = extractCandidateDeviceIdsFromBankMemo(combinedText)
        val primaryDevId = candidateIds.firstOrNull().orEmpty()
        val creditedAmountVnd = extractVerifiedBankCreditedAmountVnd(rawBody, primaryDevId)

        val configuredDeviceProVnd = getProPrice(appCtx).replace(Regex("[^0-9]"), "").toLongOrNull()?.takeIf { it >= 10_000L } ?: 50_000L
        val configuredAccountProVnd = getAccountProPrice(appCtx).replace(Regex("[^0-9]"), "").toLongOrNull()?.takeIf { it >= 20_000L } ?: 100_000L
        val configuredUpgradeVnd = getUpgradeToAccountProPrice(appCtx).replace(Regex("[^0-9]"), "").toLongOrNull()?.takeIf { it >= 10_000L } ?: 50_000L
        val l4AmountOk = creditedAmountVnd > 0L && (creditedAmountVnd >= configuredDeviceProVnd || creditedAmountVnd >= configuredUpgradeVnd)

        var l5BankAccOk = true
        val adminAcc = getPaymentAccountNumber(appCtx).replace(Regex("[^0-9]"), "")
        val adminTail = if (adminAcc.length >= 4) adminAcc.takeLast(4) else adminAcc
        if (adminTail.length >= 4) {
            val headerPart = upperFull.substringBefore("ND:").substringBefore("NOI DUNG").substringBefore("NỘI DUNG")
            val accMatch = Regex("""(?:TK|STK|TÀI\s*KHOẢN|TAI\s*KHOAN)\s*[:=]?\s*([0-9*xX]{4,16})""").find(headerPart)
            if (accMatch != null) {
                val notifiedAccDigits = accMatch.groupValues[1].replace(Regex("[^0-9]"), "")
                if (notifiedAccDigits.length >= 4 && !notifiedAccDigits.endsWith(adminTail) && !adminAcc.endsWith(notifiedAccDigits)) {
                    l5BankAccOk = false
                }
            }
        }

        val isUpgradeMemo = upperFull.contains("UPPRO") || upperFull.contains("TKPRO") || upperFull.contains("TKPR")
        val recommendedTier = when {
            !l1SourceOk || !l2NoFailureOk || !l4AmountOk || !l5BankAccOk || candidateIds.isEmpty() -> "NONE"
            creditedAmountVnd >= (configuredAccountProVnd * 95 / 100) -> "ACCOUNT_PRO"
            isUpgradeMemo -> "DEVICE_PRO_OR_UPGRADE"
            else -> "DEVICE_PRO"
        }

        val passedAll = l1SourceOk && l2NoFailureOk && l4AmountOk && l5BankAccOk && candidateIds.isNotEmpty()
        val failReason = when {
            !l1SourceOk -> "Lớp 1: Nguồn '$cleanSource' không nằm trong danh sách Ngân hàng chính thống (hoặc là app chat/SĐT cá nhân)."
            !l2NoFailureOk -> "Lớp 2: Phát hiện từ khóa thất bại / OTP / hủy giao dịch / nhắc nợ."
            candidateIds.isEmpty() -> "Lớp 6: Không trích xuất được Device ID (MT-xxxx hoặc Hex 8-16 ký tự) trong nội dung chuyển khoản."
            creditedAmountVnd <= 0L -> "Lớp 3/4: Không tìm thấy biến động +VNĐ hợp lệ tại phần Header Ngân Hàng (hoặc phát hiện giao dịch trừ tiền)."
            !l4AmountOk -> "Lớp 4: Số tiền +${creditedAmountVnd}đ thấp hơn mức gói Pro Máy (${configuredDeviceProVnd}đ)."
            !l5BankAccOk -> "Lớp 5: Đuôi STK nhận trong thông báo không khớp STK Admin (***$adminTail)."
            else -> ""
        }

        val summary = buildString {
            appendLine(if (passedAll) "✅ ĐẠT CHUẨN AUTO-ADMIN 7 LỚP!" else "❌ BỊ CHẶN BỞI BỘ LỌC BẢO MẬT")
            appendLine("• Lớp 1 Nguồn Ngân Hàng: ${if (l1SourceOk) "Hợp lệ ($cleanSource)" else "Bị chặn ($cleanSource)"}")
            appendLine("• Lớp 2 Từ khóa lỗi/OTP: ${if (l2NoFailureOk) "Sạch" else "Dính từ khóa chặn"}")
            appendLine("• Lớp 3-4 Biến động Header: ${if (l4AmountOk) "+${creditedAmountVnd}đ (Đạt)" else "+${creditedAmountVnd}đ (Thiếu/Không hợp lệ)"}")
            appendLine("• Lớp 5 Đuôi STK Admin: ${if (l5BankAccOk) "Khớp" else "Không khớp ***$adminTail"}")
            appendLine("• Lớp 6 Mã Máy nhận diện: ${if (candidateIds.isEmpty()) "Không thấy" else candidateIds.joinToString(", ")}")
            if (passedAll) {
                append("• Lớp 7 Gói đề xuất: $recommendedTier")
            } else {
                append("• Lý do chặn: $failReason")
            }
        }

        return AutoAdminDryRunResult(
            passedAllChecks = passedAll,
            layer1BankSourceOk = l1SourceOk,
            layer2NoFailureKeywordOk = l2NoFailureOk,
            layer3AmountVnd = creditedAmountVnd,
            layer4HeaderAmountOk = l4AmountOk,
            layer5BankAccountOk = l5BankAccOk,
            layer6CandidateIds = candidateIds,
            primaryDeviceId = primaryDevId,
            recommendedTier = recommendedTier,
            failureReason = failReason,
            summaryText = summary
        )
    }

    /**
     * Dọn dẹp các đơn chờ duyệt rác:
     * - Đơn mở QR / mở hộp thoại Pro (`OPENED_VIET_QR`, `OPENED_PRO_UPGRADE_DIALOG`) quá 24h chưa bấm báo CK.
     * - Hoặc đơn của máy ĐÃ kích hoạt Pro đầy đủ trên Cloud (loại trừ đơn nâng cấp hợp lệ).
     */
    suspend fun cleanupStalePaymentIntents(
        context: Context,
        existingIntents: List<com.example.core.auth.PaymentIntentRecord>,
        proNormDeviceIds: Set<String>
    ): Pair<Int, Set<String>> = kotlinx.coroutines.withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext
        val db = FirebaseFirestore.getInstance()
        val nowMs = System.currentTimeMillis()
        val cutoffMs = 24L * 3600_000L
        val deletedIds = mutableSetOf<String>()
        var deletedCount = 0

        for (intent in existingIntents) {
            val act = intent.actionType.uppercase()
            val isManualOrPaid = act == "CLICKED_I_PAID" || act.contains("BILL")
            val tsMs = intent.timestamp?.toDate()?.time ?: 0L
            val isOldQrOrDialog = !isManualOrPaid && tsMs > 0L && (nowMs - tsMs) > cutoffMs
            val normId = normalizeDeviceIdForMatch(intent.deviceId)
            val combinedLower = "${intent.actionType} ${intent.details} ${intent.note}".lowercase()
            val isUpgradeOrder = combinedLower.contains("nâng cấp") ||
                combinedLower.contains("nang_cap") ||
                combinedLower.contains("uppro") ||
                combinedLower.contains("package=2")
            val isAlreadyActivatedNonUpgrade = !isUpgradeOrder && normId.isNotBlank() && proNormDeviceIds.contains(normId)

            if (isOldQrOrDialog || isAlreadyActivatedNonUpgrade) {
                val docId = intent.intentId.trim()
                var ok = false
                if (docId.isNotBlank()) {
                    try {
                        db.collection("payment_intents").document(docId).delete()
                    } catch (_: Throwable) {}
                    if (FirestoreRestTokenBridge.deleteDocViaRest(appCtx, "payment_intents", docId)) {
                        ok = true
                    }
                    deletedIds.add(docId)
                } else if (intent.deviceId.isNotBlank()) {
                    deletePaymentIntentsForDevice(intent.deviceId, appCtx)
                    ok = true
                }
                if (ok) deletedCount++
            }
        }
        deletedCount to deletedIds
    }

    /**
     * Xử lý nội dung thanh toán từ Bộ nhớ tạm (PASTE) hoặc SMS / Thông Báo Biến Động Số Dư của Ngân Hàng
     */
    fun processIncomingPaymentText(context: Context, rawBody: String, sender: String = "", source: String = "AUTO"): Boolean {
        if (rawBody.isBlank()) return false

        val normalizedBody = rawBody.uppercase().replace("-", "").replace(" ", "").replace("\n", "").trim()
        val candidateKeys = getAllCandidateLicenseKeys(context)

        // 1. Kiểm tra mọi biến thể Mã Key SHA-256 hợp lệ của chính thiết bị này (cả Key Thiết Bị và Key Tài Khoản TKPR-...)
        for ((expectedKey, isAcc) in candidateKeys) {
            val cleanExpected = expectedKey.replace("-", "").replace(" ", "").trim().uppercase()
            if (cleanExpected.length >= 16 && normalizedBody.contains(cleanExpected)) {
                val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                prefs.edit().putBoolean(KEY_REVOKED_BY_ADMIN, false).apply()
                if (isAcc) {
                    activateAccountPro(context, expectedKey, syncToCloud = true)
                } else {
                    setProActivated(context, true, expectedKey, syncToCloud = true)
                }
                return true
            }
        }

        // CHỐT CHẶN BẢO MẬT 1: Nếu người dùng bấm nút "Dán" từ bộ nhớ tạm (source == "PASTE"),
        // TUYỆT ĐỐI chỉ chấp nhận Mã Key mật mã SHA-256 ở bước 1, KHÔNG BAO GIỜ cấp Pro qua nội dung văn bản tự gõ!
        if (source.equals("PASTE", ignoreCase = true)) {
            return false
        }

        // CHỐT CHẶN BẢO MẬT 2: Chỉ máy của Admin mới được phép tự động duyệt biến động số dư Ngân hàng / SMS cho khách hàng!
        if (!isCurrentUserAdmin(context)) {
            return false
        }

        val isSmsSource = source.equals("SMS", ignoreCase = true)
        return processAdminIncomingBankPaymentNotification(
            context = context,
            sourcePackageOrSender = sender,
            rawTitle = if (isSmsSource) sender else "BANK_NOTIFICATION",
            rawText = rawBody,
            isSms = isSmsSource
        )
    }

    /**
     * Kiểm tra trạng thái thanh toán từ xa qua Firestore `devices/{deviceId}` và Server GitHub của Admin
     */
    suspend fun checkOnlinePaymentStatusRemote(context: Context): Boolean = withContext(Dispatchers.IO) {
        if (isAdminSimulateFreeMode(context)) {
            _isProFlow.value = false
            return@withContext false
        }
        if (checkDeviceRecognizedProInCloud(context, forceRefresh = false)) return@withContext true

        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_REVOKED_BY_ADMIN, false)) return@withContext false
        val lastPollMs = prefs.getLong("last_remote_paid_devices_poll_ms", 0L)
        if (lastPollMs > 0L && (System.currentTimeMillis() - lastPollMs) < 900_000L) {
            return@withContext isProActivated(context)
        }

        val deviceId = getDeviceId(context).uppercase()
        var connection: HttpURLConnection? = null
        try {
            prefs.edit().putLong("last_remote_paid_devices_poll_ms", System.currentTimeMillis()).apply()
            val url = URL(PAID_DEVICES_URL)
            connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 5000
            connection.readTimeout = 5000
            connection.useCaches = false

            if (connection.responseCode == 200) {
                val reader = BufferedReader(InputStreamReader(connection.inputStream))
                val content = reader.use { it.readText().uppercase() }

                val cleanDeviceId = deviceId.replace("MT-", "")
                if (content.contains(deviceId) || (cleanDeviceId.length >= 6 && content.contains(cleanDeviceId))) {
                    setProActivated(context, true, "ONLINE_SERVER_VERIFIED_${System.currentTimeMillis()}", syncToCloud = true)
                    return@withContext true
                }
            }
            false
        } catch (_: Exception) {
            false
        } finally {
            connection?.disconnect()
        }
    }

    /**
     * Cơ chế Kill-Switch an toàn từ xa
     */
    suspend fun checkKillSwitchRemote(): Boolean = withContext(Dispatchers.IO) {
        var connection: HttpURLConnection? = null
        try {
            val url = URL(KILL_SWITCH_URL)
            connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 4000
            connection.readTimeout = 4000
            connection.useCaches = false

            if (connection.responseCode == 200) {
                val reader = BufferedReader(InputStreamReader(connection.inputStream))
                val content = reader.use { it.readText() }
                if (content.contains("STOPPED", ignoreCase = true)) {
                    return@withContext true
                }
            }
            false
        } catch (_: Exception) {
            false
        } finally {
            connection?.disconnect()
        }
    }

    private const val KEY_FREE_TRIAL_USED = "free_pro_trial_used"

    fun hasUsedFreeTrial(context: Context): Boolean {
        return getRemainingFreeTrials(context) <= 0
    }

    fun consumeFreeTrial(context: Context) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val used = prefs.getInt("free_trial_count_used", 0)
        prefs.edit()
            .putInt("free_trial_count_used", used + 1)
            .putBoolean(KEY_FREE_TRIAL_USED, true)
            .apply()
    }

    fun setProPrice(context: Context, price: String) {
        val clean = price.trim().ifBlank { "50.000đ" }
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString("pro_price", clean).apply()
        putSecureConfigString(context, "pro_price", clean)
        syncCloudGlobalConfigMap(context, mapOf("pro_price" to clean))
        notifyProAndConfigStateChanged(context)
    }

    fun getUpdateLink(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString("custom_update_link", null)
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, "custom_update_link")
        if (!sec.isNullOrBlank()) {
            prefs.edit().putString("custom_update_link", sec).apply()
            return sec
        }
        return "https://drive.google.com/drive/folders/1WLsS-OlxvKFUWzMPxnkrNn8kmlVIY6-k?usp=sharing"
    }

    /**
     * Trả về đường dẫn Google Drive cho nút 'Bản cập nhật' trên Header.
     * Nếu custom_update_link từng bị ghi đè thành link file .apk trực tiếp thì tự động khôi phục về thư mục Google Drive chuẩn.
     */
    fun getGoogleDriveUpdateLink(context: Context): String {
        val defaultDriveUrl = "https://drive.google.com/drive/folders/1WLsS-OlxvKFUWzMPxnkrNn8kmlVIY6-k?usp=sharing"
        val current = getUpdateLink(context).trim()
        if (current.isBlank()) return defaultDriveUrl
        val lower = current.lowercase()
        val isDirectApkMirror = lower.endsWith(".apk") ||
            lower.contains(".apk?") ||
            lower.contains("files.catbox.moe") ||
            lower.contains("litter.catbox.moe") ||
            lower.contains("firebasestorage.googleapis.com") ||
            lower.contains("storage.googleapis.com") ||
            lower.contains("tmpfiles.org") ||
            lower.contains("transfer.sh")
        return if (isDirectApkMirror) defaultDriveUrl else current
    }

    fun setUpdateLink(context: Context, link: String) {
        val clean = link.trim()
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString("custom_update_link", clean).apply()
        putSecureConfigString(context, "custom_update_link", clean)
        syncCloudGlobalConfigMap(context, mapOf("custom_update_link" to clean))
        notifyProAndConfigStateChanged(context)
    }

    fun getFacebookLink(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString("custom_fb_link", null)
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, "custom_fb_link")
        if (!sec.isNullOrBlank()) {
            prefs.edit().putString("custom_fb_link", sec).apply()
            return sec
        }
        return "https://www.facebook.com/profile.php?id=61578514512929"
    }

    fun setFacebookLink(context: Context, link: String) {
        val clean = link.trim()
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString("custom_fb_link", clean).apply()
        putSecureConfigString(context, "custom_fb_link", clean)
        syncCloudGlobalConfigMap(context, mapOf("custom_fb_link" to clean))
        notifyProAndConfigStateChanged(context)
    }

    const val KEY_ADMIN_LAST_ACTIVE = "admin_last_active_timestamp"
    const val KEY_AUTO_FREE_DAYS = "auto_free_inactivity_days"
    const val DEFAULT_AUTO_FREE_DAYS = 30

    @Volatile
    private var lastAdminHeartbeatCloudWriteMs: Long = 0L
    @Volatile
    private var lastAdminHeartbeatRamCheckMs: Long = 0L

    /**
     * Cập nhật nhịp tim hoạt động của Admin lên Firestore (app_config/global).
     * Giới hạn ghi lên Firestore tối đa 12 giờ/lần để tiết kiệm tuyệt đối chi phí ghi & tránh kích hoạt broadcast toàn cầu liên tục.
     */
    fun updateAdminHeartbeat(context: Context) {
        val nowMs = System.currentTimeMillis()
        if (nowMs - lastAdminHeartbeatRamCheckMs < 60_000L) return
        lastAdminHeartbeatRamCheckMs = nowMs
        val appCtx = context.applicationContext
        try {
            val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val prevCloudWrite = maxOf(lastAdminHeartbeatCloudWriteMs, prefs.getLong("last_admin_hb_cloud_sync_ms", 0L))
            prefs.edit().putLong(KEY_ADMIN_LAST_ACTIVE, nowMs).apply()

            if (nowMs - prevCloudWrite >= 12 * 3600_000L) {
                lastAdminHeartbeatCloudWriteMs = nowMs
                prefs.edit().putLong("last_admin_hb_cloud_sync_ms", nowMs).apply()
                syncCloudGlobalConfigMap(appCtx, mapOf("admin_last_active_ms" to nowMs))
            }
        } catch (_: Exception) {}
    }

    /**
     * Lấy số ngày không có Admin truy cập thì tự động mở miễn phí toàn bộ ứng dụng (Mặc định: 30 ngày).
     */
    fun getAutoFreeInactivityDays(context: Context): Int {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val local = prefs.getInt(KEY_AUTO_FREE_DAYS, 0)
        if (local > 0) return local
        val sec = getSecureConfigString(context, KEY_AUTO_FREE_DAYS)?.toIntOrNull()
        if (sec != null && sec > 0) {
            prefs.edit().putInt(KEY_AUTO_FREE_DAYS, sec).apply()
            return sec
        }
        return DEFAULT_AUTO_FREE_DAYS
    }

    /**
     * Admin tùy chỉnh số ngày không hoạt động để tự động miễn phí hóa toàn bộ ứng dụng.
     */
    fun setAutoFreeInactivityDays(context: Context, days: Int, onComplete: ((Boolean) -> Unit)? = null) {
        val appCtx = context.applicationContext
        val cleanDays = days.coerceIn(1, 3650)
        val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putInt(KEY_AUTO_FREE_DAYS, cleanDays).apply()
        putSecureConfigString(appCtx, KEY_AUTO_FREE_DAYS, cleanDays.toString())

        syncCloudGlobalConfigMap(appCtx, mapOf(KEY_AUTO_FREE_DAYS to cleanDays), onComplete)
        notifyProAndConfigStateChanged(appCtx)
    }

    /**
     * Kiểm tra xem cơ chế Tự Động Miễn Phí (khi không có Admin quản lý trong X ngày) đã được kích hoạt hay chưa.
     */
    fun isAutoFreeDueToAdminInactivity(context: Context): Boolean {
        try {
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val thresholdDays = prefs.getInt(KEY_AUTO_FREE_DAYS, DEFAULT_AUTO_FREE_DAYS).coerceAtLeast(1)
            val lastAdminActiveMs = prefs.getLong(KEY_ADMIN_LAST_ACTIVE, 0L)
            if (lastAdminActiveMs > 0L) {
                val diffMs = System.currentTimeMillis() - lastAdminActiveMs
                val diffDays = diffMs / (1000L * 60L * 60L * 24L)
                if (diffDays >= thresholdDays) {
                    return true
                }
            }
        } catch (_: Exception) {}
        return false
    }


    /**
     * app_config/global chứa các chuỗi chỉ mục lớn; ghi qua REST để tránh Firestore SDK tạo overlay/mutation cục bộ
     * trên toàn document mỗi lần thay đổi một thiết lập nhỏ.
     */
    private val globalConfigWriteScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val globalConfigWriteMutex = Mutex()

    private fun writeGlobalConfigViaRest(
        context: Context,
        data: Map<String, Any>,
        onComplete: ((Boolean) -> Unit)? = null
    ) {
        if (data.isEmpty()) {
            onComplete?.invoke(false)
            return
        }
        val appCtx = context.applicationContext
        globalConfigWriteScope.launch {
            val success = try {
                globalConfigWriteMutex.withLock {
                    FirestoreRestTokenBridge.patchDocViaRest(appCtx, "app_config", "global", data)
                }
            } catch (_: Throwable) { false }
            if (onComplete != null) {
                withContext(Dispatchers.Main) { onComplete(success) }
            }
        }
    }

    fun syncCloudGlobalConfigMap(
        context: Context,
        data: Map<String, Any>,
        onComplete: ((Boolean) -> Unit)? = null
    ) {
        writeGlobalConfigViaRest(context, data + ("updatedAt" to System.currentTimeMillis()), onComplete)
    }

    fun isAppFreeMode(context: Context): Boolean {
        // Nếu trong số ngày tùy chỉnh không có admin nào truy cập,
        // hệ thống tự động mở khóa toàn bộ ứng dụng thành MIỄN PHÍ vĩnh viễn!
        if (isAutoFreeDueToAdminInactivity(context)) {
            return true
        }
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getBoolean("is_app_free_mode", false)
        if (!raw) {
            val sec = getSecureConfigString(context, "is_app_free_mode")
            if (sec == "true") {
                prefs.edit().putBoolean("is_app_free_mode", true).apply()
                return true
            }
            return false
        }
        val storedSeal = prefs.getString(KEY_FREE_MODE_CRYPTO_SEAL, "") ?: ""
        val expectedGlobalSeal = computeGlobalConfigSeal("FREE_MODE_GLOBAL", "true")
        val expectedHwSeal = computeHardwareCryptoSeal(context, "FREE_MODE_GLOBAL", "true")
        if (storedSeal.isNotBlank() && (storedSeal == expectedGlobalSeal || storedSeal == expectedHwSeal)) {
            return true
        }
        val sec = getSecureConfigString(context, "is_app_free_mode")
        if (sec == "true") {
            val validSeal = computeGlobalConfigSeal("FREE_MODE_GLOBAL", "true")
            prefs.edit().putString(KEY_FREE_MODE_CRYPTO_SEAL, validSeal).apply()
            return true
        }
        // Chặn can thiệp sửa is_app_free_mode=true trong SharedPreferences XML
        prefs.edit()
            .putBoolean("is_app_free_mode", false)
            .remove(KEY_FREE_MODE_CRYPTO_SEAL)
            .apply()
        reportTamperAttemptToCloud(context, "Phát hiện sửa đổi trái phép cờ is_app_free_mode=true trong SharedPreferences XML")
        return false
    }

    fun setAppFreeMode(context: Context, isFree: Boolean) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val seal = computeGlobalConfigSeal("FREE_MODE_GLOBAL", isFree.toString())
        prefs.edit()
            .putBoolean("is_app_free_mode", isFree)
            .putString(KEY_FREE_MODE_CRYPTO_SEAL, seal)
            .apply()
        putSecureConfigString(context, "is_app_free_mode", isFree.toString())
        syncCloudGlobalConfigMap(context, mapOf("is_app_free_mode" to isFree))
        notifyProAndConfigStateChanged(context)
    }

    private const val KEY_LAST_RELOAD_BONUS_DAY = "last_reload_bonus_day"
    private const val MAX_RELOAD_BONUS_TRIALS = 3

    /**
     * Khuyến mãi tối đa 1 lượt/ngày (cộng dồn tối đa 3 lượt) cho thiết bị mở lại ứng dụng.
     * Lưu bền vững trong SharedPreferences + Secure Storage để tránh lạm dụng khi đóng mở app liên tục.
     */
    fun grantAppReloadBonusTrial(context: Context): Int {
        try {
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val todayStr = (tlYmdFormat.get() ?: java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)).format(java.util.Date())
            val lastBonusDay = (prefs.getString(KEY_LAST_RELOAD_BONUS_DAY, null)
                ?: getSecureConfigString(context, KEY_LAST_RELOAD_BONUS_DAY)
                ?: "").trim()
            if (lastBonusDay == todayStr) {
                return getRemainingFreeTrials(context)
            }

            val currentBonus = prefs.getInt("app_reload_bonus_trials", 0).coerceAtLeast(0)
            if (currentBonus >= MAX_RELOAD_BONUS_TRIALS) {
                prefs.edit().putString(KEY_LAST_RELOAD_BONUS_DAY, todayStr).apply()
                putSecureConfigString(context, KEY_LAST_RELOAD_BONUS_DAY, todayStr)
                return getRemainingFreeTrials(context)
            }

            val used = getUsedFreeTrials(context)
            if (used > 0) {
                val newUsed = (used - 1).coerceAtLeast(0)
                prefs.edit()
                    .putInt("free_trial_count_used", newUsed)
                    .putBoolean(KEY_FREE_TRIAL_USED, false)
                    .putString(KEY_LAST_RELOAD_BONUS_DAY, todayStr)
                    .apply()
                syncTrialCountToSecureStorage(context, newUsed)
            } else {
                prefs.edit()
                    .putInt("app_reload_bonus_trials", (currentBonus + 1).coerceAtMost(MAX_RELOAD_BONUS_TRIALS))
                    .putString(KEY_LAST_RELOAD_BONUS_DAY, todayStr)
                    .apply()
            }
            putSecureConfigString(context, KEY_LAST_RELOAD_BONUS_DAY, todayStr)
            notifyProAndConfigStateChanged(context)
        } catch (_: Exception) {}

        return getRemainingFreeTrials(context)
    }

    fun getFreeTrialLimit(context: Context): Int {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val reloadBonus = prefs.getInt("app_reload_bonus_trials", 0).coerceAtLeast(0)
        val rawLimit = prefs.getInt("free_trial_limit", 5).coerceAtLeast(0)
        val secLimit = getSecureConfigString(context, "free_trial_limit")?.toIntOrNull()

        // Khớp với Secure Storage dự phòng
        val candidateLimit = if (rawLimit <= 5 && secLimit != null && secLimit > 5) secLimit else rawLimit
        if (candidateLimit <= 5) return candidateLimit + reloadBonus

        val storedSeal = prefs.getString(KEY_TRIAL_LIMIT_CRYPTO_SEAL, "") ?: ""
        val expectedGlobalSeal = computeGlobalConfigSeal("TRIAL_LIMIT_GLOBAL", candidateLimit.toString())
        val expectedHwSeal = computeHardwareCryptoSeal(context, "TRIAL_LIMIT_GLOBAL", candidateLimit.toString())

        if (storedSeal.isNotBlank() && (storedSeal == expectedGlobalSeal || storedSeal == expectedHwSeal)) {
            return candidateLimit + reloadBonus
        }

        // Nếu có giá trị hợp lệ từ Secure Storage nhưng chưa có seal (sau khi cài lại app)
        if (secLimit != null && secLimit > 5 && secLimit == rawLimit) {
            val validSeal = computeGlobalConfigSeal("TRIAL_LIMIT_GLOBAL", secLimit.toString())
            prefs.edit().putString(KEY_TRIAL_LIMIT_CRYPTO_SEAL, validSeal).apply()
            return secLimit + reloadBonus
        }

        // Chặn can thiệp sửa free_trial_limit=999999 trong SharedPreferences XML
        prefs.edit()
            .putInt("free_trial_limit", 5)
            .remove(KEY_TRIAL_LIMIT_CRYPTO_SEAL)
            .apply()
        putSecureConfigString(context, "free_trial_limit", "5")
        reportTamperAttemptToCloud(context, "Phát hiện sửa đổi trái phép giới hạn dùng thử free_trial_limit=$candidateLimit trong SharedPreferences XML")
        return 5 + reloadBonus
    }

    fun setFreeTrialLimit(context: Context, limit: Int) {
        val safeLimit = limit.coerceAtLeast(0)
        val seal = computeGlobalConfigSeal("TRIAL_LIMIT_GLOBAL", safeLimit.toString())
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putInt("free_trial_limit", safeLimit)
            .putString(KEY_TRIAL_LIMIT_CRYPTO_SEAL, seal)
            .apply()
        putSecureConfigString(context, "free_trial_limit", safeLimit.toString())
        syncCloudGlobalConfigMap(context, mapOf("free_trial_limit" to safeLimit))
        notifyProAndConfigStateChanged(context)
    }

    fun getPaymentBankName(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(KEY_PAYMENT_BANK_NAME, null)
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, KEY_PAYMENT_BANK_NAME)
        if (!sec.isNullOrBlank()) return sec
        return "MBBank"
    }

    fun getPaymentBankCode(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(KEY_PAYMENT_BANK_CODE, null)
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, KEY_PAYMENT_BANK_CODE)
        if (!sec.isNullOrBlank()) return sec
        return "MB"
    }

    fun getPaymentAccountNumber(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(KEY_PAYMENT_ACCOUNT_NUMBER, null)
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, KEY_PAYMENT_ACCOUNT_NUMBER)
        if (!sec.isNullOrBlank()) return sec
        return "0393368007"
    }

    fun getPaymentAccountHolder(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(KEY_PAYMENT_ACCOUNT_HOLDER, null)
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, KEY_PAYMENT_ACCOUNT_HOLDER)
        if (!sec.isNullOrBlank()) return sec
        return "NGUYEN VAN VUONG"
    }

    fun setPaymentAccount(
        context: Context,
        bankName: String,
        bankCode: String,
        accountNumber: String,
        accountHolder: String
    ) {
        val cleanBankName = bankName.trim().ifBlank { "MBBank" }
        val cleanBankCode = bankCode.trim().uppercase().ifBlank { "MB" }
        val cleanAccountNumber = accountNumber.trim().ifBlank { "0393368007" }
        val cleanAccountHolder = accountHolder.trim().uppercase().ifBlank { "NGUYEN VAN VUONG" }

        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_PAYMENT_BANK_NAME, cleanBankName)
            .putString(KEY_PAYMENT_BANK_CODE, cleanBankCode)
            .putString(KEY_PAYMENT_ACCOUNT_NUMBER, cleanAccountNumber)
            .putString(KEY_PAYMENT_ACCOUNT_HOLDER, cleanAccountHolder)
            .apply()

        putSecureConfigString(context, KEY_PAYMENT_BANK_NAME, cleanBankName)
        putSecureConfigString(context, KEY_PAYMENT_BANK_CODE, cleanBankCode)
        putSecureConfigString(context, KEY_PAYMENT_ACCOUNT_NUMBER, cleanAccountNumber)
        putSecureConfigString(context, KEY_PAYMENT_ACCOUNT_HOLDER, cleanAccountHolder)

        syncCloudGlobalConfigMap(
            context,
            mapOf(
                KEY_PAYMENT_BANK_NAME to cleanBankName,
                KEY_PAYMENT_BANK_CODE to cleanBankCode,
                KEY_PAYMENT_ACCOUNT_NUMBER to cleanAccountNumber,
                KEY_PAYMENT_ACCOUNT_HOLDER to cleanAccountHolder
            )
        )
        notifyProAndConfigStateChanged(context)
    }



    fun getGlobalBroadcast(context: Context): GlobalBroadcastMessage? {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val id = prefs.getString(KEY_BROADCAST_ID, "") ?: ""
        val title = prefs.getString(KEY_BROADCAST_TITLE, "") ?: ""
        val message = prefs.getString(KEY_BROADCAST_MESSAGE, "") ?: ""
        val type = prefs.getString(KEY_BROADCAST_TYPE, "UPDATE") ?: "UPDATE"
        val isActive = prefs.getBoolean(KEY_BROADCAST_ACTIVE, false)
        val url = prefs.getString(KEY_BROADCAST_URL, getUpdateLink(context)) ?: getUpdateLink(context)
        val sentAt = prefs.getLong(KEY_BROADCAST_SENT_AT, 0L)
        if (!isActive || (title.isBlank() && message.isBlank())) return null
        return GlobalBroadcastMessage(
            id = id,
            title = title,
            message = message,
            type = type,
            isActive = isActive,
            actionUrl = url,
            sentAtMs = sentAt
        )
    }

    fun isBroadcastDismissed(context: Context, broadcastId: String): Boolean {
        if (broadcastId.isBlank()) return false
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_DISMISSED_BROADCAST_ID, "") == broadcastId
    }

    fun markBroadcastDismissed(context: Context, broadcastId: String) {
        if (broadcastId.isBlank()) return
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_DISMISSED_BROADCAST_ID, broadcastId).apply()
    }

    fun sendGlobalBroadcast(
        context: Context,
        title: String,
        message: String,
        type: String = "UPDATE",
        customUpdateUrl: String = "",
        overwriteCustomUpdateLink: Boolean = false
    ) {
        val now = System.currentTimeMillis()
        val broadcastId = "BC_$now"
        val cleanTitle = title.trim().ifBlank { "🚀 Thông Báo Mới Từ Quản Trị Viên" }
        val cleanMsg = message.trim()
        val cleanUrl = customUpdateUrl.trim().ifBlank { getUpdateLink(context) }

        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val editor = prefs.edit()
            .putString(KEY_BROADCAST_ID, broadcastId)
            .putString(KEY_BROADCAST_TITLE, cleanTitle)
            .putString(KEY_BROADCAST_MESSAGE, cleanMsg)
            .putString(KEY_BROADCAST_TYPE, type)
            .putBoolean(KEY_BROADCAST_ACTIVE, true)
            .putString(KEY_BROADCAST_URL, cleanUrl)
            .putLong(KEY_BROADCAST_SENT_AT, now)
            .remove(KEY_DISMISSED_BROADCAST_ID)

        if (overwriteCustomUpdateLink && customUpdateUrl.isNotBlank()) {
            editor.putString("custom_update_link", cleanUrl)
        }
        editor.apply()

        val broadcastObj = GlobalBroadcastMessage(
            id = broadcastId,
            title = cleanTitle,
            message = cleanMsg,
            type = type,
            isActive = true,
            actionUrl = cleanUrl,
            sentAtMs = now
        )
        _globalBroadcastFlow.value = broadcastObj

        try {
            val payload = mutableMapOf<String, Any>(
                KEY_BROADCAST_ID to broadcastId,
                KEY_BROADCAST_TITLE to cleanTitle,
                KEY_BROADCAST_MESSAGE to cleanMsg,
                KEY_BROADCAST_TYPE to type,
                KEY_BROADCAST_ACTIVE to true,
                KEY_BROADCAST_URL to cleanUrl,
                KEY_BROADCAST_SENT_AT to now,
                "updatedAt" to now
            )
            if (overwriteCustomUpdateLink && customUpdateUrl.isNotBlank()) {
                payload["custom_update_link"] = cleanUrl
            }
            writeGlobalConfigViaRest(context, payload)
        } catch (_: Exception) {}
    }

    fun clearGlobalBroadcast(context: Context) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_BROADCAST_ACTIVE, false)
            .apply()
        _globalBroadcastFlow.value = null
        writeGlobalConfigViaRest(context, mapOf(KEY_BROADCAST_ACTIVE to false, "updatedAt" to System.currentTimeMillis()))
    }

    fun getCurrentInstalledVersionCode(context: Context): Long {
        return try {
            val pm = context.packageManager
            val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(
                    context.packageName,
                    android.content.pm.PackageManager.PackageInfoFlags.of(0L)
                )
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(context.packageName, 0)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pkgInfo.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                pkgInfo.versionCode.toLong()
            }
        } catch (_: Throwable) {
            runCatching { com.example.BuildConfig.VERSION_CODE.toLong() }.getOrDefault(0L)
        }
    }

    fun getLatestApkRelease(context: Context): LatestApkRelease? {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val url = prefs.getString(KEY_LATEST_APK_URL, "")?.trim().orEmpty()
        if (url.isBlank()) return null
        val versionCode = prefs.getLong(KEY_LATEST_APK_VERSION_CODE, 0L)
        val versionName = prefs.getString(KEY_LATEST_APK_VERSION_NAME, "")?.trim().orEmpty()
        val sizeBytes = prefs.getLong(KEY_LATEST_APK_SIZE_BYTES, 0L)
        val notes = prefs.getString(KEY_LATEST_APK_NOTES, "")?.trim().orEmpty()
        val host = prefs.getString(KEY_LATEST_APK_HOST, "")?.trim().orEmpty()
        val uploadedAt = prefs.getLong(KEY_LATEST_APK_UPLOADED_AT, 0L)
        val autoUpdate = prefs.getBoolean(KEY_LATEST_APK_AUTO_UPDATE, true)
        return LatestApkRelease(
            versionCode = versionCode,
            versionName = versionName,
            downloadUrl = url,
            sizeBytes = sizeBytes,
            releaseNotes = notes,
            hostLabel = host,
            uploadedAtMs = uploadedAt,
            autoUpdateEnabled = autoUpdate
        )
    }

    fun isUpdateAvailableForThisDevice(context: Context, release: LatestApkRelease?): Boolean {
        if (release == null || release.downloadUrl.isBlank()) return false
        val installedCode = getCurrentInstalledVersionCode(context)
        return release.versionCode > installedCode
    }

    fun isReleaseAutoPromptDismissed(context: Context, releaseId: String): Boolean {
        if (releaseId.isBlank()) return false
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_DISMISSED_RELEASE_ID, "") == releaseId
    }

    fun markReleaseAutoPromptDismissed(context: Context, releaseId: String) {
        if (releaseId.isBlank()) return
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_DISMISSED_RELEASE_ID, releaseId).apply()
    }

    fun publishLatestApkRelease(
        context: Context,
        downloadUrl: String,
        versionCode: Long,
        versionName: String,
        sizeBytes: Long,
        releaseNotes: String,
        hostLabel: String,
        autoUpdateEnabled: Boolean = true,
        alsoSendUpdateBroadcast: Boolean = true
    ) {
        val now = System.currentTimeMillis()
        val cleanUrl = downloadUrl.trim()
        val cleanVerName = versionName.trim().ifBlank { "Mới" }
        val cleanNotes = releaseNotes.trim()
        val cleanHost = hostLabel.trim().ifBlank { "Cloud APK" }

        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_LATEST_APK_URL, cleanUrl)
            .putLong(KEY_LATEST_APK_VERSION_CODE, versionCode)
            .putString(KEY_LATEST_APK_VERSION_NAME, cleanVerName)
            .putLong(KEY_LATEST_APK_SIZE_BYTES, sizeBytes)
            .putString(KEY_LATEST_APK_NOTES, cleanNotes)
            .putString(KEY_LATEST_APK_HOST, cleanHost)
            .putLong(KEY_LATEST_APK_UPLOADED_AT, now)
            .putBoolean(KEY_LATEST_APK_AUTO_UPDATE, autoUpdateEnabled)
            .apply()

        val release = LatestApkRelease(
            versionCode = versionCode,
            versionName = cleanVerName,
            downloadUrl = cleanUrl,
            sizeBytes = sizeBytes,
            releaseNotes = cleanNotes,
            hostLabel = cleanHost,
            uploadedAtMs = now,
            autoUpdateEnabled = autoUpdateEnabled
        )
        _latestApkReleaseFlow.value = release

        try {
            val payload = mapOf(
                KEY_LATEST_APK_URL to cleanUrl,
                KEY_LATEST_APK_VERSION_CODE to versionCode,
                KEY_LATEST_APK_VERSION_NAME to cleanVerName,
                KEY_LATEST_APK_SIZE_BYTES to sizeBytes,
                KEY_LATEST_APK_NOTES to cleanNotes,
                KEY_LATEST_APK_HOST to cleanHost,
                KEY_LATEST_APK_UPLOADED_AT to now,
                KEY_LATEST_APK_AUTO_UPDATE to autoUpdateEnabled,
                "updatedAt" to now
            )
            writeGlobalConfigViaRest(context, payload)
        } catch (_: Exception) {}

        if (alsoSendUpdateBroadcast) {
            val sizeMb = String.format(java.util.Locale.US, "%.1f MB", sizeBytes / (1024.0 * 1024.0))
            val broadcastMsg = buildString {
                if (cleanNotes.isNotBlank()) {
                    append(cleanNotes)
                    append("\n")
                }
                append("📦 Gói cài đặt trực tiếp v$cleanVerName (build $versionCode • $sizeMb). Các máy bản cũ sẽ tự động tải & cài đặt ngay trong ứng dụng!")
            }
            sendGlobalBroadcast(
                context = context,
                title = "Phiên Bản Mới v$cleanVerName Đã Sẵn Sàng!",
                message = broadcastMsg,
                type = "UPDATE",
                customUpdateUrl = cleanUrl,
                overwriteCustomUpdateLink = false
            )
        }
        notifyProAndConfigStateChanged(context)
    }

    fun setLatestApkAutoUpdateEnabled(context: Context, enabled: Boolean) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_LATEST_APK_AUTO_UPDATE, enabled).apply()
        _latestApkReleaseFlow.value = getLatestApkRelease(context)
        writeGlobalConfigViaRest(context, mapOf(
                    KEY_LATEST_APK_AUTO_UPDATE to enabled,
                    "updatedAt" to System.currentTimeMillis()
                ))
    }

    fun clearLatestApkRelease(context: Context) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .remove(KEY_LATEST_APK_URL)
            .remove(KEY_LATEST_APK_VERSION_CODE)
            .remove(KEY_LATEST_APK_VERSION_NAME)
            .remove(KEY_LATEST_APK_SIZE_BYTES)
            .remove(KEY_LATEST_APK_NOTES)
            .remove(KEY_LATEST_APK_HOST)
            .remove(KEY_LATEST_APK_UPLOADED_AT)
            .apply()
        _latestApkReleaseFlow.value = null
        writeGlobalConfigViaRest(context, mapOf(
                    KEY_LATEST_APK_URL to "",
                    KEY_LATEST_APK_VERSION_CODE to 0L,
                    KEY_LATEST_APK_VERSION_NAME to "",
                    KEY_LATEST_APK_SIZE_BYTES to 0L,
                    KEY_LATEST_APK_NOTES to "",
                    KEY_LATEST_APK_HOST to "",
                    KEY_LATEST_APK_UPLOADED_AT to 0L,
                    "updatedAt" to System.currentTimeMillis()
                ))
        notifyProAndConfigStateChanged(context)
    }

    private fun showSystemBroadcastNotification(context: Context, broadcast: GlobalBroadcastMessage) {
        try {
            val channelId = "magictune_global_broadcast_channel"
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? android.app.NotificationManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = android.app.NotificationChannel(
                    channelId,
                    "Thông Báo Hệ Thống & Bản Cập Nhật",
                    android.app.NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Nhận thông báo phiên bản mới và thông báo quan trọng từ Admin"
                    enableVibration(true)
                    lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                }
                nm.createNotificationChannel(channel)
            }

            val openAppIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)?.apply {
                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            } else {
                android.app.PendingIntent.FLAG_UPDATE_CURRENT
            }
            val contentPendingIntent = if (openAppIntent != null) {
                android.app.PendingIntent.getActivity(context, 9001, openAppIntent, pendingFlags)
            } else null

            val builder = androidx.core.app.NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(broadcast.title.ifBlank { "📢 Thông báo từ Magictune_Tool" })
                .setContentText(broadcast.message)
                .setStyle(androidx.core.app.NotificationCompat.BigTextStyle().bigText(broadcast.message))
                .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
                .setVisibility(androidx.core.app.NotificationCompat.VISIBILITY_PUBLIC)
                .setAutoCancel(true)

            if (contentPendingIntent != null) {
                builder.setContentIntent(contentPendingIntent)
            }

            if (broadcast.type == "UPDATE") {
                val updateUrl = broadcast.actionUrl.ifBlank { getUpdateLink(context) }
                val updateIntent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(updateUrl)).apply {
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                val updatePendingIntent = android.app.PendingIntent.getActivity(context, 9002, updateIntent, pendingFlags)
                builder.addAction(
                    android.R.drawable.stat_sys_download,
                    "📥 Tải Bản Cập Nhật",
                    updatePendingIntent
                )
            }

            nm.notify(8899, builder.build())
        } catch (_: Throwable) {}
    }

    @Volatile
    private var globalConfigListenerStarted = false

    private var globalConfigReg: com.google.firebase.firestore.ListenerRegistration? = null
    @Volatile
    private var globalConfigPollJob: Job? = null
    private const val GLOBAL_CONFIG_REFRESH_INTERVAL_MS = 5L * 60L * 1000L
    private var deviceDocRegs: List<com.google.firebase.firestore.ListenerRegistration> = emptyList()
    @Volatile
    private var authStateListenerRegistered = false
    private var adminIntentReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var adminRecoveryReg: com.google.firebase.firestore.ListenerRegistration? = null

    @Volatile
    private var watchedUserProDocKey: String? = null
    private var watchedUserProRegs: List<com.google.firebase.firestore.ListenerRegistration> = emptyList()
    private val globalListenerScope = kotlinx.coroutines.CoroutineScope(
        kotlinx.coroutines.SupervisorJob() + Dispatchers.IO + com.example.MagicTuneApplication.globalCoroutineExceptionHandler
    )

    /**
     * app_config/global also stores large key/knowledge strings. Read only the small fields
     * needed by normal app screens so the Firestore SDK never caches the full document.
     */
    private fun globalConfigFieldPaths(context: Context): List<String> = listOf(
        "pro_price", "account_pro_price", "upgrade_account_pro_price",
        "pro_price_original", "account_pro_price_original", "is_pro_sale_active",
        "custom_update_link", "custom_fb_link", "custom_youtube_url",
        "is_app_free_mode", "free_trial_limit", KEY_AUTO_FREE_DAYS,
        KEY_ADMIN_LAST_ACTIVE, "admin_last_active_ms",
        KEY_PAYMENT_BANK_NAME, KEY_PAYMENT_BANK_CODE,
        KEY_PAYMENT_ACCOUNT_NUMBER, KEY_PAYMENT_ACCOUNT_HOLDER,
        KEY_GROQ_API_KEY_POOL, KEY_GEMINI_API_KEY_POOL,
        KEY_COMMUNITY_GEMINI_POOL, KEY_COMMUNITY_GROQ_POOL,
        KEY_AUTO_APPROVE_NOTIFICATION_PAYMENT,
        KEY_BROADCAST_ID, KEY_BROADCAST_TITLE, KEY_BROADCAST_MESSAGE,
        KEY_BROADCAST_TYPE, KEY_BROADCAST_ACTIVE, KEY_BROADCAST_URL, KEY_BROADCAST_SENT_AT,
        scopedAppNameKey(), scopedAppVersionKey(), scopedAppFontSizeKey(),
        KEY_SHOW_FB_HEADER_ICON, KEY_SHOW_YT_HEADER_ICON,
        KEY_APP_UI_SCALE, KEY_APP_UI_SCALE_UPDATED_AT,
        KEY_LATEST_APK_URL, KEY_LATEST_APK_VERSION_CODE, KEY_LATEST_APK_VERSION_NAME,
        KEY_LATEST_APK_SIZE_BYTES, KEY_LATEST_APK_NOTES, KEY_LATEST_APK_HOST,
        KEY_LATEST_APK_UPLOADED_AT, KEY_LATEST_APK_AUTO_UPDATE
    ).distinct()

    private fun parseIsoTimestampMillis(value: String): Long? {
        val trimmed = value.trim()
        if (trimmed.isEmpty()) return null
        val normalized = Regex("""\.(\d+)(?=(?:Z|[+-]\d{2}:\d{2})$)""").replace(trimmed) { match ->
            "." + match.groupValues[1].padEnd(3, '0').take(3)
        }
        val patterns = listOf("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX")
        for (pattern in patterns) {
            val formatter = java.text.SimpleDateFormat(pattern, java.util.Locale.US).apply {
                isLenient = false
                timeZone = java.util.TimeZone.getTimeZone("UTC")
            }
            val position = java.text.ParsePosition(0)
            val parsed = formatter.parse(normalized, position)
            if (parsed != null && position.index == normalized.length) return parsed.time
        }
        return null
    }

    private fun readConfigLong(value: Any?): Long? = when (value) {
        is Number -> value.toLong()
        is String -> value.toLongOrNull() ?: parseIsoTimestampMillis(value)
        else -> null
    }

    private fun applyGlobalConfigMap(context: Context, cloud: Map<String, Any>) {
        val appCtx = context.applicationContext
        val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val editor = prefs.edit()
        var changed = false

        fun putStringField(field: String, prefKey: String = field, allowBlank: Boolean = false) {
            val value = cloud[field] as? String ?: return
            if (!allowBlank && value.isBlank()) return
            if (prefs.getString(prefKey, null) != value) changed = true
            editor.putString(prefKey, value)
            if (getSecureConfigString(appCtx, prefKey) != value) putSecureConfigString(appCtx, prefKey, value)
        }

        fun putBooleanField(field: String, prefKey: String = field) {
            val value = cloud[field] as? Boolean ?: return
            if (!prefs.contains(prefKey) || prefs.getBoolean(prefKey, false) != value) changed = true
            editor.putBoolean(prefKey, value)
            if (getSecureConfigString(appCtx, prefKey) != value.toString()) putSecureConfigString(appCtx, prefKey, value.toString())
        }

        fun putIntField(field: String, prefKey: String = field, positiveOnly: Boolean = false) {
            val value = readConfigLong(cloud[field])?.toInt() ?: return
            if (positiveOnly && value <= 0) return
            if (!prefs.contains(prefKey) || prefs.getInt(prefKey, 0) != value) changed = true
            editor.putInt(prefKey, value)
            if (getSecureConfigString(appCtx, prefKey) != value.toString()) putSecureConfigString(appCtx, prefKey, value.toString())
        }

        listOf(
            "pro_price", "account_pro_price", "upgrade_account_pro_price",
            "pro_price_original", "account_pro_price_original",
            "custom_update_link", "custom_fb_link", "custom_youtube_url",
            KEY_PAYMENT_BANK_NAME, KEY_PAYMENT_BANK_CODE,
            KEY_PAYMENT_ACCOUNT_NUMBER, KEY_PAYMENT_ACCOUNT_HOLDER,
            KEY_GROQ_API_KEY_POOL, KEY_GEMINI_API_KEY_POOL,
            KEY_COMMUNITY_GEMINI_POOL, KEY_COMMUNITY_GROQ_POOL
        ).forEach { field -> putStringField(field) }

        (cloud["is_app_free_mode"] as? Boolean)?.let { value ->
            if (!prefs.contains("is_app_free_mode") || prefs.getBoolean("is_app_free_mode", false) != value) changed = true
            editor.putBoolean("is_app_free_mode", value)
            editor.putString(KEY_FREE_MODE_CRYPTO_SEAL, computeGlobalConfigSeal("FREE_MODE_GLOBAL", value.toString()))
            putSecureConfigString(appCtx, "is_app_free_mode", value.toString())
        }
        (readConfigLong(cloud["free_trial_limit"])?.toInt())?.let { value ->
            if (!prefs.contains("free_trial_limit") || prefs.getInt("free_trial_limit", 5) != value) changed = true
            editor.putInt("free_trial_limit", value)
            editor.putString(KEY_TRIAL_LIMIT_CRYPTO_SEAL, computeGlobalConfigSeal("TRIAL_LIMIT_GLOBAL", value.toString()))
            putSecureConfigString(appCtx, "free_trial_limit", value.toString())
        }
        putBooleanField(KEY_AUTO_APPROVE_NOTIFICATION_PAYMENT)
        putBooleanField("is_pro_sale_active")
        putIntField(KEY_AUTO_FREE_DAYS, positiveOnly = true)

        val adminTimestampMs = (cloud[KEY_ADMIN_LAST_ACTIVE] as? String)
            ?.let(::parseIsoTimestampMillis)
        val adminActiveMs = readConfigLong(cloud["admin_last_active_ms"]) ?: adminTimestampMs
        if (adminActiveMs != null && adminActiveMs > 0L) editor.putLong(KEY_ADMIN_LAST_ACTIVE, adminActiveMs)

        val nameKey = scopedAppNameKey()
        val versionKey = scopedAppVersionKey()
        val fontKey = scopedAppFontSizeKey()
        putStringField(nameKey)
        if (cloud.containsKey(versionKey)) putStringField(versionKey, allowBlank = true)
        (cloud[fontKey] as? Number)?.toFloat()?.takeIf { it in 7f..26f }?.let { value ->
            if (prefs.getFloat(fontKey, -1f) != value) changed = true
            editor.putFloat(fontKey, value)
            putSecureConfigString(appCtx, fontKey, value.toString())
        }
        putBooleanField(KEY_SHOW_FB_HEADER_ICON)
        putBooleanField(KEY_SHOW_YT_HEADER_ICON)

        (cloud[KEY_APP_UI_SCALE] as? Number)?.toFloat()?.takeIf { it in 0.80f..1.00f }?.let { rawScale ->
            val scale = (kotlin.math.round(rawScale * 100f) / 100f).coerceIn(0.80f, 1.00f)
            val cloudScaleTs = readConfigLong(cloud[KEY_APP_UI_SCALE_UPDATED_AT]) ?: 0L
            val localScaleTs = maxOf(
                prefs.getLong(KEY_APP_UI_SCALE_UPDATED_AT, 0L),
                getSecureConfigString(appCtx, KEY_APP_UI_SCALE_UPDATED_AT)?.toLongOrNull() ?: 0L
            )
            val localScale = prefs.getFloat(KEY_APP_UI_SCALE, -1f)
            if (localScaleTs == 0L || cloudScaleTs >= localScaleTs || localScale !in 0.80f..1.00f) {
                if (localScale != scale) changed = true
                editor.putFloat(KEY_APP_UI_SCALE, scale)
                putSecureConfigString(appCtx, KEY_APP_UI_SCALE, scale.toString())
                if (cloudScaleTs > 0L) {
                    editor.putLong(KEY_APP_UI_SCALE_UPDATED_AT, cloudScaleTs)
                    putSecureConfigString(appCtx, KEY_APP_UI_SCALE_UPDATED_AT, cloudScaleTs.toString())
                }
                _appUiScaleFlow.value = scale
            } else if (localScale in 0.80f..1.00f && kotlin.math.abs(localScale - scale) >= 0.005f) {
                _appUiScaleFlow.value = localScale
                syncCloudGlobalConfigMap(appCtx, mapOf(KEY_APP_UI_SCALE to localScale.toDouble(), KEY_APP_UI_SCALE_UPDATED_AT to localScaleTs))
            }
        }

        val bcId = (cloud[KEY_BROADCAST_ID] as? String).orEmpty()
        val bcTitle = (cloud[KEY_BROADCAST_TITLE] as? String).orEmpty()
        val bcMessage = (cloud[KEY_BROADCAST_MESSAGE] as? String).orEmpty()
        val bcType = (cloud[KEY_BROADCAST_TYPE] as? String) ?: "UPDATE"
        val bcActive = cloud[KEY_BROADCAST_ACTIVE] as? Boolean ?: false
        val bcUrl = (cloud[KEY_BROADCAST_URL] as? String) ?: (cloud["custom_update_link"] as? String ?: getUpdateLink(appCtx))
        val bcSentAt = readConfigLong(cloud[KEY_BROADCAST_SENT_AT]) ?: 0L
        editor.putString(KEY_BROADCAST_ID, bcId)
        editor.putString(KEY_BROADCAST_TITLE, bcTitle)
        editor.putString(KEY_BROADCAST_MESSAGE, bcMessage)
        editor.putString(KEY_BROADCAST_TYPE, bcType)
        editor.putBoolean(KEY_BROADCAST_ACTIVE, bcActive)
        editor.putString(KEY_BROADCAST_URL, bcUrl)
        editor.putLong(KEY_BROADCAST_SENT_AT, bcSentAt)
        val broadcast = if (bcActive && (bcTitle.isNotBlank() || bcMessage.isNotBlank())) {
            GlobalBroadcastMessage(bcId, bcTitle, bcMessage, bcType, true, bcUrl, bcSentAt)
        } else null
        _globalBroadcastFlow.value = broadcast
        if (broadcast != null) {
            val lastNotifiedId = prefs.getString(KEY_NOTIFIED_BROADCAST_ID, "") ?: ""
            if (bcId.isNotBlank() && bcId != lastNotifiedId) {
                editor.putString(KEY_NOTIFIED_BROADCAST_ID, bcId)
                showSystemBroadcastNotification(appCtx, broadcast)
            }
        }

        if (cloud.containsKey(KEY_LATEST_APK_URL)) {
            val url = (cloud[KEY_LATEST_APK_URL] as? String).orEmpty().trim()
            if (url.isBlank()) {
                listOf(KEY_LATEST_APK_URL, KEY_LATEST_APK_VERSION_NAME, KEY_LATEST_APK_NOTES, KEY_LATEST_APK_HOST)
                    .forEach(editor::remove)
                listOf(KEY_LATEST_APK_VERSION_CODE, KEY_LATEST_APK_SIZE_BYTES, KEY_LATEST_APK_UPLOADED_AT)
                    .forEach(editor::remove)
                editor.remove(KEY_LATEST_APK_AUTO_UPDATE)
                _latestApkReleaseFlow.value = null
            } else {
                val versionCode = readConfigLong(cloud[KEY_LATEST_APK_VERSION_CODE]) ?: 0L
                val versionName = (cloud[KEY_LATEST_APK_VERSION_NAME] as? String).orEmpty().trim()
                val size = readConfigLong(cloud[KEY_LATEST_APK_SIZE_BYTES]) ?: 0L
                val notes = (cloud[KEY_LATEST_APK_NOTES] as? String).orEmpty().trim()
                val host = (cloud[KEY_LATEST_APK_HOST] as? String).orEmpty().trim()
                val uploadedAt = readConfigLong(cloud[KEY_LATEST_APK_UPLOADED_AT]) ?: 0L
                val autoUpdate = cloud[KEY_LATEST_APK_AUTO_UPDATE] as? Boolean ?: true
                if (prefs.getString(KEY_LATEST_APK_URL, "") != url || prefs.getLong(KEY_LATEST_APK_VERSION_CODE, 0L) != versionCode) changed = true
                editor.putString(KEY_LATEST_APK_URL, url)
                editor.putLong(KEY_LATEST_APK_VERSION_CODE, versionCode)
                editor.putString(KEY_LATEST_APK_VERSION_NAME, versionName)
                editor.putLong(KEY_LATEST_APK_SIZE_BYTES, size)
                editor.putString(KEY_LATEST_APK_NOTES, notes)
                editor.putString(KEY_LATEST_APK_HOST, host)
                editor.putLong(KEY_LATEST_APK_UPLOADED_AT, uploadedAt)
                editor.putBoolean(KEY_LATEST_APK_AUTO_UPDATE, autoUpdate)
                _latestApkReleaseFlow.value = LatestApkRelease(versionCode, versionName, url, size, notes, host, uploadedAt, autoUpdate)
            }
        }

        editor.apply()
        if (changed) notifyProAndConfigStateChanged(appCtx)
    }

    private fun startGlobalConfigPolling(context: Context) {
        if (globalConfigPollJob?.isActive == true) return
        val appCtx = context.applicationContext
        globalConfigPollJob = globalListenerScope.launch {
            while (globalConfigListenerStarted && kotlinx.coroutines.currentCoroutineContext().isActive) {
                if (!com.example.core.perf.MagicTuneSelfPowerGovernor.isMainActivityCurrentlyForeground()) {
                    // Tự động dừng polling khi app chuyển sang chạy ngầm để tiết kiệm 100% CPU & Pin
                    break
                }
                try {
                    if (hasValidatedCloudNetwork(appCtx)) {
                        val values = FirestoreRestTokenBridge.fetchDocMapViaRest(
                            appCtx, "app_config", "global", globalConfigFieldPaths(appCtx)
                        )
                        if (!values.isNullOrEmpty()) applyGlobalConfigMap(appCtx, values)
                    }
                } catch (_: Throwable) {}
                delay(GLOBAL_CONFIG_REFRESH_INTERVAL_MS)
            }
            globalConfigPollJob = null
        }
    }

    fun detachRealtimeListenersOnBackground(context: Context) {
        val appCtx = context.applicationContext
        globalConfigListenerStarted = false
        globalConfigPollJob?.cancel()
        globalConfigPollJob = null
        try {
            globalConfigReg?.remove()
            globalConfigReg = null
        } catch (_: Throwable) {}
        try {
            deviceDocRegs.forEach { reg -> runCatching { reg.remove() } }
            deviceDocRegs = emptyList()
        } catch (_: Throwable) {}
        try {
            watchedUserProRegs.forEach { reg -> runCatching { reg.remove() } }
            watchedUserProRegs = emptyList()
            watchedUserProDocKey = null
        } catch (_: Throwable) {}
        // Admin order listeners are UI-scoped: keeping them attached while the app is
        // backgrounded consumes network, retains Firestore snapshots and can grow the
        // local mutation/cache workload. listenToGlobalConfigChanges() reattaches them
        // the next time MainActivity returns to the foreground.
        detachAdminPendingOrderPushListener()
    }

    fun detachAdminPendingOrderPushListener() {
        adminPendingOrderListenerStarted = false
        try {
            adminIntentReg?.remove()
            adminIntentReg = null
        } catch (_: Throwable) {}
        try {
            adminRecoveryReg?.remove()
            adminRecoveryReg = null
        } catch (_: Throwable) {}
    }

    private fun attachActiveUserProCloudListeners(appCtx: Context) {
        try {
            val db = FirebaseFirestore.getInstance()
            val user = try { Firebase.auth.currentUser?.takeIf { !it.isAnonymous } } catch (_: Throwable) { null }
            val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val savedEmail = (prefs.getString("current_user_email", "") ?: "").trim().lowercase()
            val candidateEmail = (user?.email?.trim()?.lowercase().takeIf { !it.isNullOrBlank() } ?: savedEmail)
            val watchKey = "${user?.uid.orEmpty()}|$candidateEmail"
            if (watchKey == watchedUserProDocKey && watchedUserProRegs.isNotEmpty()) return

            watchedUserProRegs.forEach { reg -> runCatching { reg.remove() } }
            watchedUserProRegs = emptyList()
            watchedUserProDocKey = watchKey

            if (watchKey == "|") return

            val newRegs = mutableListOf<com.google.firebase.firestore.ListenerRegistration>()
            val deviceId = getDeviceId(appCtx).trim().uppercase()
            val userDocIds = buildList {
                user?.uid?.takeIf { it.isNotBlank() }?.let { add(it) }
                if (candidateEmail.contains("@")) {
                    val emailKey = candidateEmail.replace(".", "_").replace("/", "_")
                    add("email_$emailKey")
                }
            }.distinct()

            for (uDocId in userDocIds) {
                val reg = db.collection("users").document(uDocId)
                    .addSnapshotListener { snapshot, error ->
                        if (error != null || snapshot == null || !snapshot.exists()) return@addSnapshotListener
                        globalListenerScope.launch {
                            if (isAdminSimulateFreeMode(appCtx)) return@launch
                            val revoked = snapshot.getBoolean("revokedByAdmin") == true
                            if (revoked) {
                                enforceLocalRevocationFromCloud(appCtx)
                            } else {
                                applyCloudProRecordToLocal(appCtx, snapshot, deviceId)
                            }
                        }
                    }
                newRegs.add(reg)
            }
            watchedUserProRegs = newRegs
        } catch (_: Throwable) {}
    }

    /**
     * Lắng nghe biến động cấu hình toàn cục VÀ trạng thái Cấp/Gỡ Pro từ xa của thiết bị & tài khoản này theo thời gian thực
     */
    fun listenToGlobalConfigChanges(context: Context) {
        val appCtx = context.applicationContext
        _globalBroadcastFlow.value = getGlobalBroadcast(appCtx)
        _latestApkReleaseFlow.value = getLatestApkRelease(appCtx)

        // Lifecycle launchers can finish their delayed startup work after MainActivity
        // has already gone to the background. Do not attach Firestore streams in that case.
        if (!com.example.core.perf.MagicTuneSelfPowerGovernor.isMainActivityCurrentlyForeground()) return

        if (globalConfigListenerStarted) {
            startGlobalConfigPolling(appCtx)
            attachActiveUserProCloudListeners(appCtx)
            return
        }
        globalConfigListenerStarted = true
        startGlobalConfigPolling(appCtx)

        globalListenerScope.launch {
            syncDevicePresenceToCloud(appCtx)
        }

        try {
            val db = FirebaseFirestore.getInstance()
            // app_config/global is refreshed through a REST field mask above. The Firestore
            // SDK listener used to cache large knowledge/key fields on every app launch.
            globalConfigReg?.remove()
            globalConfigReg = null

            // 2. Lắng nghe Document ID chuẩn của máy hiện tại trên `devices` (tối ưu 1 listener duy nhất)
            val deviceId = getDeviceId(appCtx).trim().uppercase()
            val normId = normalizeDeviceIdForMatch(deviceId)
            val watchDocIds = if (normId.isNotBlank() && normId != deviceId) {
                listOf("MT-$normId", deviceId).distinct()
            } else {
                listOf(deviceId)
            }
            deviceDocRegs.forEach { reg -> runCatching { reg.remove() } }
            val newDeviceRegs = mutableListOf<com.google.firebase.firestore.ListenerRegistration>()
            for (watchId in watchDocIds) {
                val reg = db.collection("devices").document(watchId)
                    .addSnapshotListener { snapshot, error ->
                        if (error != null || snapshot == null || !snapshot.exists()) return@addSnapshotListener
                        globalListenerScope.launch {
                            if (isAdminSimulateFreeMode(appCtx)) return@launch
                            val revokedByAdmin = snapshot.getBoolean("revokedByAdmin") ?: false
                            if (revokedByAdmin) {
                                enforceLocalRevocationFromCloud(appCtx)
                            } else {
                                applyCloudProRecordToLocal(appCtx, snapshot, deviceId)
                            }
                        }
                    }
                newDeviceRegs.add(reg)
            }
            deviceDocRegs = newDeviceRegs

            // 2B. Lắng nghe thời gian thực trên bảng `users` (theo UID & Email) và tự động gắn lại khi Auth đổi trạng thái
            attachActiveUserProCloudListeners(appCtx)
            if (!authStateListenerRegistered) {
                authStateListenerRegistered = true
                try {
                    Firebase.auth.addAuthStateListener {
                        if (!globalConfigListenerStarted) return@addAuthStateListener
                        attachActiveUserProCloudListeners(appCtx)
                        if (isCurrentUserAdmin(appCtx)) {
                            startAdminPendingOrderPushListener(appCtx)
                        }
                    }
                } catch (_: Throwable) {}
            }

            // 3. ĐỐI VỚI MÁY ADMIN: Lắng nghe thời gian thực các đơn chờ duyệt Pro (`payment_intents` & `pro_recovery_requests`)
            // để đẩy thông báo nổi ngay lên Thanh Thông Báo & Màn Hình Khóa của Admin!
            if (isCurrentUserAdmin(appCtx)) {
                startAdminPendingOrderPushListener(appCtx)
            }
        } catch (_: Exception) {
            globalConfigListenerStarted = false
        }
    }

    @Volatile
    private var adminPendingOrderListenerStarted = false

    fun showAdminNewPendingOrderNotification(
        context: Context,
        orderKey: String,
        title: String,
        message: String,
        targetAdminSubTab: Int = 2
    ) {
        try {
            if (!isCurrentUserAdmin(context)) return
            val appCtx = context.applicationContext
            val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val notifiedCsv = prefs.getString("notified_admin_pending_orders_v1", "") ?: ""
            val notifiedSet = notifiedCsv.split("|").filter { it.isNotBlank() }.toMutableSet()
            if (notifiedSet.contains(orderKey)) return
            notifiedSet.add(orderKey)
            val trimmed = notifiedSet.toList().takeLast(120).joinToString("|")
            prefs.edit().putString("notified_admin_pending_orders_v1", trimmed).apply()

            val channelId = "magictune_admin_pending_orders_channel"
            val nm = appCtx.getSystemService(Context.NOTIFICATION_SERVICE) as? android.app.NotificationManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = android.app.NotificationChannel(
                    channelId,
                    "🔔 Đơn Chờ Duyệt Pro Mới (Dành Cho Admin)",
                    android.app.NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Đẩy thông báo lên thanh trạng thái và màn hình khóa của Admin ngay khi có khách gửi đơn chờ duyệt Pro mới"
                    enableVibration(true)
                    enableLights(true)
                    lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                }
                nm.createNotificationChannel(channel)
            }

            val openAdminIntent = android.content.Intent(appCtx, com.example.MainActivity::class.java).apply {
                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("TARGET_TAB", "ADMIN")
                putExtra("ADMIN_SUB_TAB", targetAdminSubTab)
            }
            val pendingFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            } else {
                android.app.PendingIntent.FLAG_UPDATE_CURRENT
            }
            val contentPendingIntent = android.app.PendingIntent.getActivity(
                appCtx,
                (orderKey.hashCode() and 0x7FFFFFFF),
                openAdminIntent,
                pendingFlags
            )

            val notification = androidx.core.app.NotificationCompat.Builder(appCtx, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(androidx.core.app.NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(androidx.core.app.NotificationCompat.PRIORITY_MAX)
                .setCategory(androidx.core.app.NotificationCompat.CATEGORY_ALARM)
                .setVisibility(androidx.core.app.NotificationCompat.VISIBILITY_PUBLIC)
                .setDefaults(androidx.core.app.NotificationCompat.DEFAULT_ALL)
                .setAutoCancel(true)
                .setContentIntent(contentPendingIntent)
                .addAction(
                    android.R.drawable.ic_menu_view,
                    "⚡ Mở Trang Duyệt Ngay",
                    contentPendingIntent
                )
                .build()

            nm.notify(7700 + (orderKey.hashCode() and 0x0FFF), notification)
        } catch (_: Throwable) {}
    }

    @Synchronized
    fun notifyProApprovedIfNeeded(
        context: Context,
        isAccountPro: Boolean,
        targetEmail: String = "",
        deviceId: String = ""
    ) {
        try {
            val appCtx = context.applicationContext
            if (isAdminSimulateFreeMode(appCtx)) return
            val currentTier = if (isAccountPro) "ACCOUNT_PRO" else "DEVICE_PRO"
            val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val lastNotified = prefs.getString(KEY_LAST_NOTIFIED_PRO_APPROVED_TIER, "") ?: ""
            if (lastNotified == currentTier) return
            prefs.edit().putString(KEY_LAST_NOTIFIED_PRO_APPROVED_TIER, currentTier).apply()

            showUserProApprovedNotification(
                context = appCtx,
                isAccountPro = isAccountPro,
                targetEmail = targetEmail,
                deviceId = deviceId
            )
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                try {
                    val toastMsg = if (isAccountPro) {
                        "🎉 Chúc mừng! Bạn vừa được Admin phê duyệt bản quyền Pro Tài Khoản vĩnh viễn!"
                    } else {
                        "📱 Chúc mừng! Thiết bị vừa được Admin phê duyệt bản quyền Pro vĩnh viễn!"
                    }
                    android.widget.Toast.makeText(appCtx, toastMsg, android.widget.Toast.LENGTH_LONG).show()
                } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    /**
     * Bắn thông báo nổi ưu tiên cao nhất lên Thanh Thông Báo và Màn Hình Khóa của Người Dùng
     * ngay khi thiết bị hoặc tài khoản của họ được Admin phê duyệt lên Pro.
     */
    fun showUserProApprovedNotification(
        context: Context,
        isAccountPro: Boolean,
        targetEmail: String = "",
        deviceId: String = ""
    ) {
        try {
            val appCtx = context.applicationContext
            val nm = appCtx.getSystemService(Context.NOTIFICATION_SERVICE) as? android.app.NotificationManager ?: return
            val channelId = CHANNEL_PRO_APPROVED_ID
            val channelName = "🎉 Phê Duyệt MagicTune Pro"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = android.app.NotificationChannel(
                    channelId,
                    channelName,
                    android.app.NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Thông báo kích hoạt bản quyền Pro thành công tới màn hình khóa và thanh trạng thái của người dùng"
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 300, 150, 300, 150, 500)
                    enableLights(true)
                    lightColor = android.graphics.Color.CYAN
                    lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                    setShowBadge(true)
                }
                nm.createNotificationChannel(channel)
            }

            val cleanDevId = deviceId.ifBlank { getDeviceId(appCtx) }
            val cleanEmail = targetEmail.trim()
            val title = if (isAccountPro) {
                "👑 CHÚC MỪNG BẠN ĐÃ LÊN PRO TÀI KHOẢN!"
            } else {
                "📱 CHÚC MỪNG BẢN QUYỀN PRO THIẾT BỊ ĐÃ KÍCH HOẠT!"
            }

            val message = if (isAccountPro) {
                if (cleanEmail.contains("@")) {
                    "🎉 Tài khoản $cleanEmail vừa được Admin phê duyệt gói Pro Tài Khoản vĩnh viễn! Toàn bộ tính năng cao cấp không giới hạn và hỗ trợ đa thiết bị đã sẵn sàng sử dụng."
                } else {
                    "🎉 Tài khoản của bạn vừa được Admin phê duyệt gói Pro Tài Khoản vĩnh viễn! Toàn bộ tính năng cao cấp không giới hạn và hỗ trợ đa thiết bị đã sẵn sàng sử dụng."
                }
            } else {
                "🎉 Thiết bị ($cleanDevId) vừa được Admin phê duyệt bản quyền Pro vĩnh viễn! Toàn bộ tính năng MagicTune cao cấp, tối ưu xung nhịp, màn hình và pin đã được mở khóa hoàn toàn."
            }

            val openAppIntent = android.content.Intent(appCtx, com.example.MainActivity::class.java).apply {
                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK or
                    android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra("PRO_APPROVED_CELEBRATION", true)
                putExtra("TARGET_TAB", "TUNE")
            }

            val pendingFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            } else {
                android.app.PendingIntent.FLAG_UPDATE_CURRENT
            }

            val contentPendingIntent = android.app.PendingIntent.getActivity(
                appCtx,
                9988,
                openAppIntent,
                pendingFlags
            )

            val smallIconRes = try {
                val statId = appCtx.resources.getIdentifier("ic_stat_magictune", "drawable", appCtx.packageName)
                if (statId != 0) statId else android.R.drawable.ic_dialog_info
            } catch (_: Throwable) {
                android.R.drawable.ic_dialog_info
            }

            val notification = androidx.core.app.NotificationCompat.Builder(appCtx, channelId)
                .setSmallIcon(smallIconRes)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(androidx.core.app.NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(androidx.core.app.NotificationCompat.PRIORITY_MAX)
                .setCategory(androidx.core.app.NotificationCompat.CATEGORY_MESSAGE)
                .setVisibility(androidx.core.app.NotificationCompat.VISIBILITY_PUBLIC)
                .setDefaults(androidx.core.app.NotificationCompat.DEFAULT_ALL)
                .setOnlyAlertOnce(false)
                .setAutoCancel(true)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true)
                .setContentIntent(contentPendingIntent)
                .addAction(
                    android.R.drawable.ic_menu_view,
                    "⚡ Mở MagicTune Ngay",
                    contentPendingIntent
                )
                .build()

            try {
                nm.notify(9988, notification)
            } catch (_: SecurityException) {}
        } catch (_: Throwable) {}
    }

    fun startAdminPendingOrderPushListener(context: Context) {
        if (adminPendingOrderListenerStarted) return
        val appCtx = context.applicationContext
        if (!isCurrentUserAdmin(appCtx)) {
            return
        }
        // Admin notifications are not worth keeping a Firestore stream alive while the
        // UI is closed. MainActivity attaches this listener on resume and detaches it on stop.
        if (!com.example.core.perf.MagicTuneSelfPowerGovernor.isMainActivityCurrentlyForeground()) return
        adminPendingOrderListenerStarted = true

        val listenerStartMs = System.currentTimeMillis()
        try {
            val db = FirebaseFirestore.getInstance()
            val bgExecutor = com.example.core.auth.FirebaseAuthManager.adminSnapshotExecutor
            adminIntentReg?.remove()
            adminIntentReg = db.collection("payment_intents")
                .limit(50)
                .addSnapshotListener(bgExecutor) { snap, err ->
                    if (err != null || snap == null || !isCurrentUserAdmin(appCtx)) return@addSnapshotListener
                    for (change in snap.documentChanges) {
                        if (change.type == com.google.firebase.firestore.DocumentChange.Type.ADDED ||
                            change.type == com.google.firebase.firestore.DocumentChange.Type.MODIFIED
                        ) {
                            val doc = change.document
                            val isAlreadyPro = doc.getBoolean("isPro") == true
                            if (isAlreadyPro) continue
                            val actionType = (doc.getString("actionType") ?: "").trim()
                            // Chỉ đẩy thông báo chuông/màn hình khóa cho các đơn khách thực sự gửi yêu cầu duyệt / báo đã CK / gửi bill cần duyệt
                            val isActionableOrder = actionType == "CLICKED_I_PAID" ||
                                actionType == "BILL_SUBMITTED_FOR_REVIEW" ||
                                actionType == "BILL_NEEDS_MANUAL_REVIEW" ||
                                actionType.contains("CHUYEN_KHOAN", ignoreCase = true) ||
                                actionType.contains("CHO_DUYET", ignoreCase = true) ||
                                actionType.contains("REVIEW", ignoreCase = true)
                            if (!isActionableOrder) continue

                            val tsMs = (doc.get("timestampMs") as? Number)?.toLong()
                                ?: doc.getTimestamp("timestamp")?.toDate()?.time
                                ?: 0L
                            // Bỏ qua các đơn cũ từ nhiều ngày trước lúc mới mở app (trừ các đơn mới phát sinh trong vòng 30 phút gần đây)
                            if (tsMs > 0L && tsMs < (listenerStartMs - 30 * 60_000L)) continue

                            val devId = (doc.getString("deviceId") ?: doc.id).trim().uppercase()
                            val model = (doc.getString("model") ?: "Thiết bị Android").trim()
                            val email = (doc.getString("ownerEmail") ?: "Khách vãng lai").trim()
                            val details = (doc.getString("details") ?: "Yêu cầu duyệt lên Pro").trim()
                            val orderKey = "INTENT_${devId}_${tsMs / 60_000L}_$actionType"

                            showAdminNewPendingOrderNotification(
                                context = appCtx,
                                orderKey = orderKey,
                                title = "⏳ Đơn Chờ Duyệt Pro Mới: $devId",
                                message = "📱 Máy: $devId ($model)\n👤 Khách: $email\n📋 Chi tiết: $details\n👉 Chạm vào thông báo để mở thẳng [Ô 3] Chờ Duyệt và duyệt ngay!",
                                targetAdminSubTab = 2
                            )
                        }
                    }
                }

            adminRecoveryReg?.remove()
            adminRecoveryReg = db.collection("pro_recovery_requests")
                .limit(30)
                .addSnapshotListener(bgExecutor) { snap, err ->
                    if (err != null || snap == null || !isCurrentUserAdmin(appCtx)) return@addSnapshotListener
                    for (change in snap.documentChanges) {
                        if (change.type == com.google.firebase.firestore.DocumentChange.Type.ADDED ||
                            change.type == com.google.firebase.firestore.DocumentChange.Type.MODIFIED
                        ) {
                            val doc = change.document
                            val status = (doc.getString("status") ?: "PENDING").trim().uppercase()
                            if (status != "PENDING") continue
                            val tsMs = doc.getTimestamp("createdAt")?.toDate()?.time ?: 0L
                            if (tsMs > 0L && tsMs < (listenerStartMs - 30 * 60_000L)) continue

                            val devId = (doc.getString("deviceId") ?: doc.id).trim().uppercase()
                            val model = (doc.getString("deviceModel") ?: "Thiết bị Android").trim()
                            val email = (doc.getString("ownerEmail") ?: "Khách vãng lai").trim()
                            val note = (doc.getString("note") ?: "Yêu cầu khôi phục Pro").trim()
                            val orderKey = "RECOVERY_${devId}_${tsMs / 60_000L}"

                            showAdminNewPendingOrderNotification(
                                context = appCtx,
                                orderKey = orderKey,
                                title = "🔄 Yêu Cầu Khôi Phục Pro: $devId",
                                message = "📱 Máy: $devId ($model)\n👤 Khách: $email\n📝 Ghi chú: $note\n👉 Chạm để mở thẳng [Ô 5] Khôi Phục và duyệt!",
                                targetAdminSubTab = 4
                            )
                        }
                    }
                }
        } catch (_: Exception) {}
    }

    /**
     * Tải trực tiếp cấu hình toàn cục từ Firestore `app_config/global` ngay khi mở trang Quản Trị
     * để đảm bảo các ô nhập giá bán Pro, ngân hàng, link hỗ trợ luôn hiển thị đúng giá trị Admin đã tùy chỉnh.
     */
    fun fetchGlobalConfigNow(
        context: Context,
        onLoaded: (() -> Unit)? = null,
        onResult: ((Boolean) -> Unit)? = null
    ) {
        val appCtx = context.applicationContext
        globalListenerScope.launch {
            var fetchedFromCloud = false
            try {
                if (hasValidatedCloudNetwork(appCtx)) {
                    val config = FirestoreRestTokenBridge.fetchDocMapViaRest(
                        appCtx, "app_config", "global", globalConfigFieldPaths(appCtx)
                    )
                    if (!config.isNullOrEmpty()) {
                        applyGlobalConfigMap(appCtx, config)
                        fetchedFromCloud = true
                    }
                }
            } catch (_: Throwable) {}
            withContext(Dispatchers.Main) {
                try { onLoaded?.invoke() } catch (_: Throwable) {}
                try { onResult?.invoke(fetchedFromCloud) } catch (_: Throwable) {}
            }
        }
    }

    private fun applyCloudProRecordToLocal(
        context: Context,
        d: com.google.firebase.firestore.DocumentSnapshot,
        currentDeviceId: String
    ): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val ownerEmail = (d.getString("ownerEmail") ?: d.getString("email") ?: "").trim()
        val roleStr = (d.getString("role") ?: "").trim().lowercase()
        val isAdminDoc = roleStr == "admin" ||
            ownerEmail.equals(ADMIN_EMAIL, ignoreCase = true) ||
            ownerEmail.equals("vuongdhkmhn@gmail.com", ignoreCase = true)

        recordFamiliarEmailAndDeviceLocally(context, ownerEmail)

        val dRevoked = d.getBoolean("revokedByAdmin") == true
        if (dRevoked && !isAdminDoc) {
            enforceLocalRevocationFromCloud(context)
            return false
        }

        val cloudPro = isAdminDoc || (d.getBoolean("isPro") == true) || (d.getBoolean("magictunePro") == true)
        val proTier = (d.getString("proTier") ?: d.getString("magictuneTier") ?: "").trim().uppercase()
        val cloudAccountPro = isAdminDoc || (d.getBoolean("isAccountPro") == true) || (proTier == "ACCOUNT_PRO")
        val cloudDeviceProTier = proTier == "DEVICE_PRO" || cloudPro
        val cloudUpgradedToAcc = isAdminDoc || (d.getBoolean("upgradedToAccountPro") == true)
        val docDevId = (d.getString("deviceId")?.takeIf { it.isNotBlank() } ?: d.id).trim().uppercase()
        val savedLicenseKey = (d.getString("licenseKey") ?: "").trim()
        val cleanSavedKey = savedLicenseKey.replace("-", "").trim().uppercase()
        val expectedDevKeyClean = generateLicenseKeyForDevice(currentDeviceId).replace("-", "").trim().uppercase()
        val expectedAccKeyClean = generateAccountProLicenseKeyForDevice(currentDeviceId).replace("-", "").trim().uppercase()
        val docDevKeyClean = if (docDevId.isNotBlank()) generateLicenseKeyForDevice(docDevId).replace("-", "").trim().uppercase() else ""
        val docAccKeyClean = if (docDevId.isNotBlank()) generateAccountProLicenseKeyForDevice(docDevId).replace("-", "").trim().uppercase() else ""
        val candidateCleanKeys = getAllCandidateLicenseKeys(context).keys.map { it.replace("-", "").trim().uppercase() }.toSet()
        val hasValidCryptographicKey = cleanSavedKey.length >= 12 &&
            (cleanSavedKey == expectedDevKeyClean || cleanSavedKey == expectedAccKeyClean ||
                cleanSavedKey == docDevKeyClean || cleanSavedKey == docAccKeyClean ||
                candidateCleanKeys.contains(cleanSavedKey))

        val cloudTrialUsed = d.getLong("freeTrialUsed")?.toInt() ?: 0
        if (cloudTrialUsed > getUsedFreeTrials(context)) {
            prefs.edit().putInt("free_trial_count_used", cloudTrialUsed).apply()
        }

        // Chỉ khôi phục Pro khi bản ghi trên Cloud thực sự đang ở trạng thái Pro, là Admin, hoặc có mã Key mật mã SHA-256 hợp lệ
        val wasPreviouslyVerifiedPro = isAdminDoc ||
            cloudPro ||
            cloudAccountPro ||
            cloudDeviceProTier ||
            hasValidCryptographicKey

        if (wasPreviouslyVerifiedPro) {
            val proSource = (d.getString("proActivatedSource") ?: d.getString("approvedByAiReason") ?: "").trim().uppercase()
            val isExplicitAdminDowngrade = proSource == "ADMIN_DOWNGRADE_TO_DEVICE_PRO"
            RestoreFamiliarProHelper.applyRestoredProState(
                context = context,
                deviceId = currentDeviceId,
                isAccountTier = cloudAccountPro || cloudUpgradedToAcc,
                licenseKey = savedLicenseKey.ifBlank {
                    if (isAdminDoc) "ADMIN_MASTER_PRO_RESTORED"
                    else if (cloudAccountPro || cloudUpgradedToAcc) generateAccountProLicenseKeyForDevice(currentDeviceId)
                    else generateLicenseKeyForDevice(currentDeviceId)
                },
                recognizedEmail = ownerEmail,
                recognizedRole = if (isAdminDoc) "admin" else roleStr,
                isAdminExplicitDowngrade = isExplicitAdminDowngrade
            )
            return true
        }
        return false
    }

    /**
     * Tính năng AI phân tích hàng loạt toàn bộ lỗi lệnh ADB và đưa ra những chỗ cần sửa gấp.
     * Sử dụng ưu tiên Groq LPU (Llama 3.3 70B / Qwen3 32B / Llama 3.1 8B), tự động fallback sang Gemini AI và Pollinations.
     */
    suspend fun analyzeAdbErrorLogsWithAi(
        context: Context,
        errorLogs: List<AdminAdbErrorLogRecord>
    ): String = withContext(Dispatchers.IO) {
        if (errorLogs.isEmpty()) {
            return@withContext "🎉 Hệ thống hiện tại không có lỗi ADB nào được ghi nhận! Mọi lệnh Shizuku và Wireless ADB đang hoạt động hoàn hảo."
        }

        val topErrors = errorLogs.sortedByDescending { it.occurrenceCount }.take(35)
        val sb = StringBuilder()
        sb.append("Tổng số loại lỗi ADB: ${errorLogs.size} lỗi (Tổng lượt gặp: ${errorLogs.sumOf { it.occurrenceCount }} lượt)\n\n")
        topErrors.forEachIndexed { idx, item ->
            sb.append("=== LỖI #${idx + 1} ===\n")
            sb.append("- Lệnh ADB: `${item.command}`\n")
            sb.append("- Mã lỗi (ExitCode): ${item.exitCode}\n")
            sb.append("- Xuất lỗi: ${item.errorOutput.take(300)}\n")
            sb.append("- Số lượt gặp: ${item.occurrenceCount} lượt\n")
            sb.append("- Phương thức: ${item.connectionMode.ifBlank { "ADB" }}\n")
            val devicesStr = (item.affectedDevices + listOf(item.commercialName.ifBlank { item.deviceModel }))
                .filter { it.isNotBlank() }.distinct().take(5).joinToString(", ")
            sb.append("- Thiết bị bị ảnh hưởng: ${devicesStr.ifBlank { "Không rõ" }}\n\n")
        }

        val prompt = """
Bạn là Kỹ sư Trưởng Hệ thống Android & Chuyên gia Tối ưu hóa ADB Shell (Senior Android System & ADB Engineer).
Dưới đây là danh sách lỗi lệnh ADB tự động thu thập từ các thiết bị người dùng thực tế đang sử dụng ứng dụng MagicTune (chủ yếu là các dòng máy Honor MagicOS, Huawei, Xiaomi, Android 11-15):

$sb

Hãy phân tích hàng loạt toàn bộ dữ liệu lỗi trên và đưa ra BÁO CÁO CHẨN ĐOÁN CẤP BÁCH với định dạng Markdown chuyên nghiệp:

1. 🔴 NHỮNG CHỖ CẦN SỬA GẤP NHẤT (Top 3-5 lỗi có tần suất cao hoặc nguy cơ lỗi nghiêm trọng):
- Nêu rõ lệnh bị lỗi, nguyên nhân gốc rễ (Root Cause) vì sao gãy trên MagicOS/Android (do thiếu quyền WRITE_SECURE_SETTINGS, do package hệ thống không tồn tại, cú pháp sai, Shizuku chưa kết nối...).
- Vị trí tính năng trên app có khả năng đang gọi lệnh này.

2. 🛠️ GIẢI PHÁP & CODE FIX KHẮC PHỤC NGAY:
- Đưa ra câu lệnh ADB thay thế an toàn hơn hoặc cơ chế try-catch, kiểm tra điều kiện trước khi thực thi (pre-flight check).
- Gợi ý cách xử lý fallback nếu máy người dùng không hỗ trợ tính năng đó.

3. 📊 PHÂN BỔ NGUYÊN NHÂN CHÍNH:
- Nhóm lỗi do người dùng (chưa bật USB Debugging, chưa cấp quyền Shizuku): ...%
- Nhóm lỗi do MagicOS/Android chặn quyền hệ thống: ...%
- Nhóm lỗi do cú pháp lệnh code cần sửa: ...%

4. 💡 KHUYẾN NGHỊ HÀNH ĐỘNG CHO ADMIN:
- Những chỗ nào cần cập nhật mã nguồn ngay trong phiên bản tiếp theo.
- Cần bổ sung hướng dẫn gì trên giao diện cho người dùng để hạn chế lỗi.
""".trimIndent()

        // Sử dụng 100% Groq API (Llama 3.3 70B / Qwen 3 32B / Qwen 3.8 27B / Llama 3.1 8B) để luôn miễn phí và tiết kiệm chi phí duy trì cho Admin
        val groqKey = getLoadBalancedGroqApiKey(context).ifBlank {
            try { com.example.BuildConfig.GROQ_API_KEY } catch (_: Throwable) { "" }
        }
        if (groqKey.isNotBlank() && groqKey != "GROQ_API_KEY_DEFAULT_VALUE") {
            val groqModels = listOf(
                "openai/gpt-oss-120b",
                "qwen/qwen3.8-27b",
                "llama-3.3-70b-versatile",
                "openai/gpt-oss-20b",
                "llama-3.1-8b-instant"
            )
            for (gModel in groqModels) {
                try {
                    val url = URL("https://api.groq.com/openai/v1/chat/completions")
                    val conn = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 12_000
                        readTimeout = 40_000
                        doOutput = true
                        setRequestProperty("Authorization", "Bearer $groqKey")
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    }
                    val body = org.json.JSONObject().apply {
                        put("model", gModel)
                        put("messages", org.json.JSONArray().apply {
                            put(org.json.JSONObject().apply {
                                put("role", "system")
                                put("content", "Bạn là Chuyên gia Kỹ thuật Hệ thống Android & ADB Shell.")
                            })
                            put(org.json.JSONObject().apply {
                                put("role", "user")
                                put("content", prompt)
                            })
                        })
                        put("temperature", 0.2)
                    }
                    conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                    if (conn.responseCode in 200..299) {
                        val respStr = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                        val json = org.json.JSONObject(respStr)
                        val text = json.optJSONArray("choices")
                            ?.optJSONObject(0)
                            ?.optJSONObject("message")
                            ?.optString("content", "")
                            .orEmpty()
                        if (text.isNotBlank()) {
                            return@withContext text
                        }
                    } else if (conn.responseCode == 429) {
                        markGroqApiKeyCooldown(groqKey)
                    }
                } catch (_: Throwable) {}
            }
        }

        // 3. TẦNG DỰ PHÒNG ZERO-COST VĨNH CỬU: Pollinations AI (Miễn phí 100%, không cần API Key - tương tự Trợ lý Magic)
        try {
            val url = URL("https://text.pollinations.ai/")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 12_000
                readTimeout = 45_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15; MagicTune)")
            }
            val payload = org.json.JSONObject().apply {
                put("messages", org.json.JSONArray().apply {
                    put(org.json.JSONObject().apply {
                        put("role", "system")
                        put("content", "Bạn là Kỹ sư Trưởng Hệ thống Android & ADB Shell.")
                    })
                    put(org.json.JSONObject().apply {
                        put("role", "user")
                        put("content", prompt)
                    })
                })
                put("model", "openai")
                put("code", "beesknees")
            }
            conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode in 200..299) {
                val respStr = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    .replace(Regex("<think>[\\s\\S]*?</think>"), "")
                    .trim()
                if (respStr.isNotBlank()) {
                    return@withContext respStr
                }
            }
        } catch (_: Throwable) {}

        return@withContext "⚠️ Không thể kết nối với dịch vụ AI để chẩn đoán. Vui lòng kiểm tra lại kết nối mạng hoặc thử lại sau giây lát."
    }

    fun isShizukuConnectionDisabled(context: Context): Boolean {
        return try {
            val prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            prefs.getBoolean("disable_shizuku_connection", true)
        } catch (_: Exception) {
            true
        }
    }

    fun setShizukuConnectionDisabled(
        context: Context,
        disabled: Boolean,
        onComplete: ((Boolean, String) -> Unit)? = null
    ) {
        val appCtx = context.applicationContext
        try {
            val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            prefs.edit().putBoolean("disable_shizuku_connection", disabled).apply()
            writeGlobalConfigViaRest(
                appCtx,
                mapOf("disable_shizuku_connection" to disabled, "updatedAt" to System.currentTimeMillis())
            ) { success ->
                val message = if (success) {
                    if (disabled) "🔒 Đã khóa phương thức Shizuku từ xa (Ép 100% dùng Cách 1: Kết nối trực tiếp)"
                    else "🔓 Đã mở lại phương thức Shizuku"
                } else "Lỗi cập nhật cấu hình từ xa"
                onComplete?.invoke(success, message)
            }
        } catch (e: Exception) {
            onComplete?.invoke(false, "Lỗi: ${e.localizedMessage}")
        }
    }
}
