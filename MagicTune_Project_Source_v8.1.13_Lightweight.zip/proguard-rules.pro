# ProGuard / R8 rules for MagicTune Commercial Release (Shizuku + Direct WLAN ADB + System Reflection)
# Retain symbol names to guarantee 100% safety with Android hidden APIs, Binder IPC, and reflection
-dontobfuscate

# Keep Shizuku & Binder IPC
-keep class rikka.shizuku.** { *; }
-keep interface rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }
-keep interface moe.shizuku.** { *; }
-keepclassmembers class rikka.shizuku.Shizuku {
    private static *** newProcess(...);
    <methods>;
    <fields>;
}
-dontwarn rikka.shizuku.**
-dontwarn moe.shizuku.**

# Direct WLAN ADB (libadb-android, sun-security-android X.509, Conscrypt TLS 1.3 / SPAKE2)
-keep class io.github.muntashirakon.adb.** { *; }
-keep interface io.github.muntashirakon.adb.** { *; }
-keep class android.sun.security.** { *; }
-keep class org.conscrypt.** { *; }
-dontwarn io.github.muntashirakon.adb.**
-dontwarn android.sun.security.**
-dontwarn org.conscrypt.**

# Keep MagicTune core, data models, ui state & viewmodels
-keep class com.example.data.** { *; }
-keep class com.example.core.** { *; }
-keep class com.example.ui.MainTab { *; }
-keep class com.example.ui.UiState { *; }
-keep class com.example.ui.MagicTuneViewModel { *; }
-keep class com.example.ui.components.** { *; }
-keep class com.example.ui.screens.** { *; }
-keep class com.example.MainActivity { *; }
-keep class com.example.MagicTuneApplication { *; }

# Compose Runtime
-keep class androidx.compose.** { *; }
-dontwarn androidx.compose.**

# ProfileInstaller
-keep class androidx.profileinstaller.** { *; }
-dontwarn androidx.profileinstaller.**

# Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembers class kotlinx.coroutines.** {
    volatile <fields>;
}

# Firebase & Play Services
-keep class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**
-dontwarn com.google.android.gms.**
