package com.example.core.widget

import android.content.Context
import android.location.Address
import android.location.Geocoder
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.Normalizer
import java.util.Locale
import kotlin.coroutines.resume

object VietnamAdministrativeDataset {

    // Đầy đủ 63 Tỉnh / Thành phố Việt Nam
    val allProvinces: List<String> = listOf(
        "Hà Nội", "TP. Hồ Chí Minh", "Đà Nẵng", "Hải Phòng", "Cần Thơ",
        "Hà Giang", "Cao Bằng", "Lào Cai", "Lai Châu", "Điện Biên", "Sơn La", "Yên Bái",
        "Bắc Kạn", "Lạng Sơn", "Tuyên Quang", "Thái Nguyên", "Phú Thọ", "Bắc Giang",
        "Quảng Ninh", "Hòa Bình", "Vĩnh Phúc", "Bắc Ninh", "Hải Dương", "Hưng Yên",
        "Thái Bình", "Hà Nam", "Nam Định", "Ninh Bình",
        "Thanh Hóa", "Nghệ An", "Hà Tĩnh", "Quảng Bình", "Quảng Trị", "Thừa Thiên Huế",
        "Quảng Nam", "Quảng Ngãi", "Bình Định", "Phú Yên", "Khánh Hòa", "Ninh Thuận", "Bình Thuận",
        "Kon Tum", "Gia Lai", "Đắk Lắk", "Đắk Nông", "Lâm Đồng",
        "Bình Phước", "Tây Ninh", "Bình Dương", "Đồng Nai", "Bà Rịa - Vũng Tàu",
        "Long An", "Tiền Giang", "Bến Tre", "Trà Vinh", "Vĩnh Long", "Đồng Tháp",
        "An Giang", "Kiên Giang", "Hậu Giang", "Sóc Trăng", "Bạc Liêu", "Cà Mau"
    )

    // Danh sách chuyên biệt: Vùng sâu vùng xa, Biên giới, Cửa khẩu, Đèo cao, Đỉnh núi & Cao nguyên Việt Nam
    val remoteAndHighlandLocations: List<String> = listOf(
        // Hà Giang - Cao nguyên đá & Biên giới cực Bắc
        "Xã Lũng Cú (Cột cờ Cực Bắc), Huyện Đồng Văn, Hà Giang",
        "Phố cổ Đồng Văn - Thị trấn Đồng Văn, Huyện Đồng Văn, Hà Giang",
        "Thị trấn Phố Bảng (Cửa khẩu Phó Bảng), Huyện Đồng Văn, Hà Giang",
        "Xã Sủng Là (Thung lũng Sủng Là), Huyện Đồng Văn, Hà Giang",
        "Xã Lũng Táo - Mã Lé, Huyện Đồng Văn, Hà Giang",
        "Xã Vần Chải - Lũng Phìn, Huyện Đồng Văn, Hà Giang",
        "Đèo Mã Pí Lèng - Xã Pải Lủng, Huyện Mèo Vạc, Hà Giang",
        "Thị trấn Mèo Vạc, Huyện Mèo Vạc, Hà Giang",
        "Xã Xín Cái (Biên giới Thượng Phùng), Huyện Mèo Vạc, Hà Giang",
        "Xã Sơn Vĩ (Biên giới cực Đông Bắc Hà Giang), Huyện Mèo Vạc, Hà Giang",
        "Xã Thượng Phùng - Săm Pun (Cửa khẩu Săm Pun), Huyện Mèo Vạc, Hà Giang",
        "Xã Khâu Vai (Chợ tình Khâu Vai), Huyện Mèo Vạc, Hà Giang",
        "Xã Bản Phùng (Ruộng bậc thang La Chí), Huyện Hoàng Su Phì, Hà Giang",
        "Đỉnh Chiêu Lầu Thi - Xã Hồ Thầu, Huyện Hoàng Su Phì, Hà Giang",
        "Xã Thông Nguyên - Bản Luốc - Nậm Ty, Huyện Hoàng Su Phì, Hà Giang",
        "Thảo nguyên Suôi Thầu - Thị trấn Cốc Pài, Huyện Xín Mần, Hà Giang",
        "Cửa khẩu Xín Mần - Xã Xín Mần, Huyện Xín Mần, Hà Giang",
        "Xã Bản Díu - Nấm Dẩn, Huyện Xín Mần, Hà Giang",
        "Đỉnh Tây Côn Lĩnh - Xã Cao Bồ, Huyện Vị Xuyên, Hà Giang",
        "Cửa khẩu Quốc tế Thanh Thủy, Huyện Vị Xuyên, Hà Giang",
        "Xã Lao Chải - Xín Chải (Biên giới Vị Xuyên), Huyện Vị Xuyên, Hà Giang",
        "Cổng trời Quản Bạ - Núi Đôi Cô Tiên, Huyện Quản Bạ, Hà Giang",
        "Xã Cao Mã Pờ - Nghĩa Thuận (Biên giới Quản Bạ), Huyện Quản Bạ, Hà Giang",
        "Rừng thông Yên Minh - Xã Na Khê, Huyện Yên Minh, Hà Giang",
        "Xã Du Già (Vườn Quốc gia Du Già), Huyện Yên Minh, Hà Giang",
        "Xã Bạch Đích - Phú Lũng (Biên giới Yên Minh), Huyện Yên Minh, Hà Giang",
        "Huyện vùng cao Bắc Mê, Hà Giang",

        // Cao Bằng - Non nước biên cương Đông Bắc
        "Khu di tích Pác Bó - Xã Trường Hà, Huyện Hà Quảng, Cao Bằng",
        "Cửa khẩu Sóc Giang, Huyện Hà Quảng, Cao Bằng",
        "Xã Lũng Nặm - Tổng Cọt, Huyện Hà Quảng, Cao Bằng",
        "Thác Bản Giốc - Động Ngườm Ngao (Xã Đàm Thủy), Huyện Trùng Khánh, Cao Bằng",
        "Cửa khẩu Quốc tế Trà Lĩnh (Thị trấn Trà Lĩnh), Huyện Trùng Khánh, Cao Bằng",
        "Cửa khẩu Pò Peo - Xã Ngọc Côn, Huyện Trùng Khánh, Cao Bằng",
        "Hồ Thăng Hen - Xã Quốc Toản, Huyện Quảng Hòa, Cao Bằng",
        "Cửa khẩu Quốc tế Tà Lùng, Huyện Quảng Hòa, Cao Bằng",
        "Đèo Mã Phục, Huyện Quảng Hòa, Cao Bằng",
        "Cửa khẩu Lý Vạn - Xã Minh Long, Huyện Hạ Lang, Cao Bằng",
        "Đèo Mẻ Pia 14 tầng - Xã Xuân Trường, Huyện Bảo Lạc, Cao Bằng",
        "Xã biên giới Cốc Pàng - Thượng Hà, Huyện Bảo Lạc, Cao Bằng",
        "Thị trấn Pác Miầu, Huyện vùng cao Bảo Lâm, Cao Bằng",
        "Đỉnh Phia Oắc - Phia Đén (Xã Thành Công), Huyện Nguyên Bình, Cao Bằng",
        "Khu di tích Rừng Trần Hưng Đạo, Huyện Nguyên Bình, Cao Bằng",
        "Đèo Khau Cốc Chà, Huyện Bảo Lạc, Cao Bằng",

        // Lào Cai - Hoàng Liên Sơn & Biên giới thượng nguồn sông Hồng
        "Đỉnh Fansipan (Nóc nhà Đông Dương) - Thị xã Sa Pa, Lào Cai",
        "Phường Sa Pa - Nhà thờ Đá Sa Pa, Thị xã Sa Pa, Lào Cai",
        "Bản Cát Cát - Xã Hoàng Liên, Thị xã Sa Pa, Lào Cai",
        "Xã Tả Van - Thung lũng Mường Hoa, Thị xã Sa Pa, Lào Cai",
        "Xã Tả Phìn - Bản Hồ - Mường Bo, Thị xã Sa Pa, Lào Cai",
        "Đèo Ô Quy Hồ (Cổng trời Ô Quy Hồ), Thị xã Sa Pa, Lào Cai",
        "Xã Y Tý (Thiên đường săn mây), Huyện Bát Xát, Lào Cai",
        "Đỉnh Lảo Thẩn - Nhìu Cồ San, Xã Y Tý, Huyện Bát Xát, Lào Cai",
        "Xã A Lù - Ngải Thầu (Ruộng bậc thang vùng biên), Huyện Bát Xát, Lào Cai",
        "Xã A Mú Sung - Cột cờ Lũng Pô (Nơi sông Hồng chảy vào đất Việt), Huyện Bát Xát, Lào Cai",
        "Xã Trịnh Tường - Bản Vược - Cốc Mỳ, Huyện Bát Xát, Lào Cai",
        "Xã Mường Hum - Dền Sáng - Sàng Ma Sáo, Huyện Bát Xát, Lào Cai",
        "Đỉnh Ky Quan San (Bạch Mộc Lương Tử), Xã Sàng Ma Sáo, Huyện Bát Xát, Lào Cai",
        "Xã Bản Liền (Đồi chè tuyết san vùng cao), Huyện Bắc Hà, Lào Cai",
        "Thị trấn Bắc Hà (Cao nguyên trắng Bắc Hà), Huyện Bắc Hà, Lào Cai",
        "Xã Lùng Phình - Tả Van Chư - Hoàng Thu Phố, Huyện Bắc Hà, Lào Cai",
        "Thị trấn Si Ma Cai - Chợ phiên Cán Cấu, Huyện Si Ma Cai, Lào Cai",
        "Xã Sín Chéng - Lùng Thẩn - Nàn Sán, Huyện Si Ma Cai, Lào Cai",
        "Xã Pha Long - Dìn Chin - Tả Ngải Chồ, Huyện Mường Khương, Lào Cai",
        "Thị trấn Mường Khương (Cửa khẩu Mường Khương), Huyện Mường Khương, Lào Cai",
        "Xã Lùng Khấu Nhin - Cao Sơn - La Pan Tẩn, Huyện Mường Khương, Lào Cai",
        "Cửa khẩu Quốc tế Lào Cai (Phường Lào Cai), Thành phố Lào Cai, Lào Cai",
        "Xã Nậm Xé - Minh Lương (Đèo Khau Co), Huyện Văn Bàn, Lào Cai",

        // Lai Châu - Biên giới Tây Bắc & Những đỉnh núi hùng vĩ
        "Cao nguyên Sìn Hồ - Thị trấn Sìn Hồ, Huyện Sìn Hồ, Lai Châu",
        "Xã Tả Phìn - Phăng Sô Lin - Pu Sam Cáp, Huyện Sìn Hồ, Lai Châu",
        "Xã Ka Lăng - Thu Lũm (Thượng nguồn sông Đà - Cực Bắc Lai Châu), Huyện Mường Tè, Lai Châu",
        "Xã Mù Cả - Pa Ủ - Pa Vệ Sử (Biên giới Mường Tè), Huyện Mường Tè, Lai Châu",
        "Thị trấn Mường Tè - Xã Bum Tở, Huyện Mường Tè, Lai Châu",
        "Cửa khẩu Quốc tế Ma Lù Thàng, Huyện Phong Thổ, Lai Châu",
        "Xã Dào San - Sì Lở Lầu - Vàng Ma Chải (Biên giới Phong Thổ), Huyện Phong Thổ, Lai Châu",
        "Bản Sin Suối Hồ - Xã Sin Suối Hồ, Huyện Phong Thổ, Lai Châu",
        "Xã Mù Sang - Pa Vây Sử - Tung Qua Lìn, Huyện Phong Thổ, Lai Châu",
        "Bản Sì Thâu Chải - Xã Hồ Thầu, Huyện Tam Đường, Lai Châu",
        "Đỉnh Pu Ta Leng - Đỉnh Tà Liên Sơn, Huyện Tam Đường, Lai Châu",
        "Xã Khun Há - Bản Hon - Bình Lư, Huyện Tam Đường, Lai Châu",
        "Thị trấn Nậm Nhùn - Xã Hua Bum (Biên giới Nậm Nhùn), Huyện Nậm Nhùn, Lai Châu",
        "Xã Lê Lợi - Nậm Hàng - Mường Mô, Huyện Nậm Nhùn, Lai Châu",
        "Cánh đồng Mường Than - Xã Mường Kim, Huyện Than Uyên, Lai Châu",
        "Đồi chè Tân Uyên - Xã Phúc Khoa, Huyện Tân Uyên, Lai Châu",

        // Điện Biên - Cực Tây Tổ Quốc & Biên giới Việt - Lào - Trung
        "Xã Sín Thầu - A Pa Chải (Ngã ba biên giới Cực Tây Tổ Quốc), Huyện Mường Nhé, Điện Biên",
        "Xã Chung Chải - Sen Thượng - Leng Su Sìn, Huyện Mường Nhé, Điện Biên",
        "Khu bảo tồn thiên nhiên Mường Nhé, Huyện Mường Nhé, Điện Biên",
        "Xã Chà Nưa - Phìn Hồ - Si Pa Phìn, Huyện Nậm Pồ, Điện Biên",
        "Xã Nà Hỳ - Nà Bủng - Vàng Đán (Biên giới Nậm Pồ), Huyện Nậm Pồ, Điện Biên",
        "Xã Mường Phăng (Sở chỉ huy Chiến dịch Điện Biên Phủ), TP. Điện Biên Phủ, Điện Biên",
        "Cửa khẩu Quốc tế Tây Trang - Xã Na Ư, Huyện Điện Biên, Điện Biên",
        "Cửa khẩu Huổi Puốc - Xã Mường Nhà, Huyện Điện Biên, Điện Biên",
        "Cao nguyên đá Tủa Chùa - Xã Tả Phìn, Huyện Tủa Chùa, Điện Biên",
        "Xã Sín Chải - Tả Sìn Thàng - Lao Xả Phình (Cây chè Shan tuyết cổ thụ), Huyện Tủa Chùa, Điện Biên",
        "Đèo Pha Đin - Xã Quài Tở, Huyện Tuần Giáo, Điện Biên",
        "Xã Mường Tùng - Huổi Lèng - Ma Thì Hồ, Huyện Mường Chà, Điện Biên",
        "Tháp Mường Luân - Xã Pu Nhi - Keo Lôm, Huyện Điện Biên Đông, Điện Biên",
        "Thị xã Mường Lay (Lòng hồ Thủy điện Sơn La), Điện Biên",

        // Sơn La - Cao nguyên Mộc Châu, Săn mây Tà Xùa & Biên giới Việt - Lào
        "Xã Tà Xùa (Sống lưng khủng long - Săn mây Tà Xùa), Huyện Bắc Yên, Sơn La",
        "Xã Háng Đồng - Xím Vàng - Làng Chếu, Huyện Bắc Yên, Sơn La",
        "Xã Ngọc Chiến (Suối khoáng nóng vùng cao), Huyện Mường La, Sơn La",
        "Thủy điện Sơn La - Thị trấn Ít Ong, Huyện Mường La, Sơn La",
        "Đỉnh Pha Luông - Xã Chiềng Sơn, Thị xã Mộc Châu, Sơn La",
        "Cửa khẩu Quốc tế Lóng Sập, Thị xã Mộc Châu, Sơn La",
        "Phường Mộc Châu - Đồi chè Trái Tim - Thung lũng Nà Ka, Thị xã Mộc Châu, Sơn La",
        "Xã Chiềng Yên - Lóng Luông - Xuân Nha, Huyện Vân Hồ, Sơn La",
        "Huyện biên giới Sốp Cộp (Xã Mường Lạn - Mường Lèo - Sam Kha), Sơn La",
        "Cửa khẩu Chiềng Khương - Thị trấn Sông Mã, Huyện Sông Mã, Sơn La",
        "Cửa khẩu Quốc gia Lóng Sập - Xã Phiêng Khoài, Huyện Yên Châu, Sơn La",
        "Đèo Chiềng Đông - Thị trấn Yên Châu, Huyện Yên Châu, Sơn La",
        "Xã Co Mạ - Long Hẹ (Vùng cao Thuận Châu), Huyện Thuận Châu, Sơn La",
        "Cầu Pá Uôn - Lòng hồ sông Đà, Huyện Quỳnh Nhai, Sơn La",
        "Xã Suối Tọ - Mường Do (Vùng cao Phù Yên), Huyện Phù Yên, Sơn La",

        // Yên Bái - Mù Cang Chải, Trạm Tấu & Tây Bắc
        "Xã La Pán Tẩn (Mâm xôi Mù Cang Chải), Huyện Mù Cang Chải, Yên Bái",
        "Xã Chế Cu Nha - Dế Xu Phình, Huyện Mù Cang Chải, Yên Bái",
        "Đèo Khau Phạ - Xã Cao Phạ (Tứ đại đỉnh đèo), Huyện Mù Cang Chải, Yên Bái",
        "Xã Mồ Dề (Rừng trúc Mồ Dề) - Kim Nọi - Chế Tạo, Huyện Mù Cang Chải, Yên Bái",
        "Đỉnh Tà Chì Nhù - Xã Xà Hồ (Bản Cu Vai), Huyện Trạm Tấu, Yên Bái",
        "Đỉnh Tà Xùa Yên Bái - Xã Bản Công, Huyện Trạm Tấu, Yên Bái",
        "Suối khoáng nóng Trạm Tấu - Xã Hát Lừu, Huyện Trạm Tấu, Yên Bái",
        "Xã Suối Giàng (Chè Shan tuyết cổ thụ), Huyện Văn Chấn, Yên Bái",
        "Xã Tú Lệ (Thung lũng nếp Tú Lệ) - Nậm Búng, Huyện Văn Chấn, Yên Bái",
        "Cánh đồng Mường Lò, Thị xã Nghĩa Lộ, Yên Bái",
        "Khu bảo tồn thiên nhiên Nà Hẩu, Huyện Văn Yên, Yên Bái",
        "Thung lũng Lâm Thượng - Lục Yên, Huyện Lục Yên, Yên Bái",

        // Bắc Kạn - Tuyên Quang - Thái Nguyên - Phú Thọ - Bắc Giang
        "Vườn Quốc gia Hồ Ba Bể - Xã Nam Mẫu, Huyện Ba Bể, Bắc Kạn",
        "Động Puông - Thác Đầu Đẳng - Ao Tiên, Huyện Ba Bể, Bắc Kạn",
        "Huyện vùng cao Pác Nặm (Xã Bộc Bố - Cổ Linh - Cao Tân), Bắc Kạn",
        "Đèo Giàng - Đèo Gió - Thị trấn Vân Tùng, Huyện Ngân Sơn, Bắc Kạn",
        "Khu bảo tồn thiên nhiên Kim Hỷ, Huyện Na Rì, Bắc Kạn",
        "ATK Chợ Đồn - Thị trấn Bằng Lũng, Huyện Chợ Đồn, Bắc Kạn",
        "Khu bảo tồn Na Hang - Hồ sinh thái Na Hang, Huyện Na Hang, Tuyên Quang",
        "Xã Hồng Thái (Săn mây & Hoa lê Hồng Thái), Huyện Na Hang, Tuyên Quang",
        "Xã Thượng Lâm - Lăng Can (Cọc Vài), Huyện Lâm Bình, Tuyên Quang",
        "Khu di tích Quốc gia đặc biệt Tân Trào, Huyện Sơn Dương, Tuyên Quang",
        "Khu bảo tồn Thần Sa - Phượng Hoàng, Huyện vùng cao Võ Nhai, Thái Nguyên",
        "ATK Định Hóa - Đèo De (Xã Phú Đình), Huyện Định Hóa, Thái Nguyên",
        "Vườn Quốc gia Xuân Sơn - Bản Cỏi - Bản Dù, Huyện Tân Sơn, Phú Thọ",
        "Đồi chè Long Cốc, Huyện Tân Sơn, Phú Thọ",
        "Cao nguyên Đồng Cao - Xã Thạch Sơn, Huyện Sơn Động, Bắc Giang",
        "Khu bảo tồn Tây Yên Tử - Thị trấn Tây Yên Tử, Huyện Sơn Động, Bắc Giang",
        "Hồ Cấm Sơn - Hồ Khuôn Thần, Huyện Lục Ngạn, Bắc Giang",

        // Lạng Sơn - Quảng Ninh (Biên giới Đông Bắc)
        "Đỉnh Mẫu Sơn - Xã Mẫu Sơn, Huyện Lộc Bình, Lạng Sơn",
        "Cửa khẩu song phương Chi Ma - Xã Yên Khoái, Huyện Lộc Bình, Lạng Sơn",
        "Cửa khẩu Quốc tế Hữu Nghị - Thị trấn Đồng Đăng, Huyện Cao Lộc, Lạng Sơn",
        "Cửa khẩu Tân Thanh - Cốc Nam, Huyện Văn Lãng, Lạng Sơn",
        "Đồi cỏ lau Bắc Xa - Cột mốc 1297, Huyện Đình Lập, Lạng Sơn",
        "Thung lũng Bắc Sơn - Đỉnh Nà Lay (Xã Quỳnh Sơn), Huyện Bắc Sơn, Lạng Sơn",
        "Thảo nguyên Đồng Lâm - Xã Hữu Liên, Huyện Hữu Lũng, Lạng Sơn",
        "Ải Chi Lăng - Đèo Sài Hồ, Huyện Chi Lăng, Lạng Sơn",
        "Sống lưng khủng long Bình Liêu - Cột mốc 1305 (Xã Hoành Mô), Huyện Bình Liêu, Quảng Ninh",
        "Cửa khẩu Hoành Mô - Xã Đồng Văn - Lục Hồn, Huyện Bình Liêu, Quảng Ninh",
        "Đỉnh Cao Xiêm - Đỉnh Cao Ly, Huyện Bình Liêu, Quảng Ninh",
        "Xã biên giới Pò Hèn - Hải Sơn - Bắc Sơn, Thành phố Móng Cái, Quảng Ninh",
        "Mũi Sa Vĩ - Trà Cổ (Nét vẽ đầu tiên nơi địa đầu Tổ Quốc), TP. Móng Cái, Quảng Ninh",
        "Cửa khẩu Bắc Phong Sinh - Xã Quảng Đức, Huyện Hải Hà, Quảng Ninh",
        "Khu bảo tồn thiên nhiên Đồng Sơn - Kỳ Thượng, Huyện Ba Chẽ, Quảng Ninh",
        "Đỉnh Chùa Đồng Yên Tử - Xã Thượng Yên Công, Thành phố Uông Bí, Quảng Ninh",

        // Hòa Bình - Vĩnh Phúc - Hà Nội (Vùng núi)
        "Xã Lũng Vân (Nóc nhà xứ Mường) - Ngổ Luông - Quyết Chiến, Huyện Tân Lạc, Hòa Bình",
        "Xã Hang Kia - Pà Cò (Săn mây Hang Kia), Huyện Mai Châu, Hòa Bình",
        "Bản Lác - Đèo Thung Khe (Đèo Đá Trắng) - Xã Pù Bin, Huyện Mai Châu, Hòa Bình",
        "Hồ Hòa Bình - Xã Hiền Lương - Cao Sơn - Vầy Nưa, Huyện vùng cao Đà Bắc, Hòa Bình",
        "Thác Mu - Xã Tự Do, Huyện Lạc Sơn, Hòa Bình",
        "Thị trấn Tam Đảo - Đỉnh Rùng Rình - Tây Thiên, Huyện Tam Đảo, Vĩnh Phúc",
        "Đỉnh Vua - Vườn Quốc gia Ba Vì (Cốt 1100m), Huyện Ba Vì, Hà Nội",

        // Thanh Hóa - Nghệ An - Hà Tĩnh (Biên giới Bắc Trung Bộ & Dãy Trường Sơn Bắc)
        "Khu bảo tồn Pù Luông - Xã Thành Sơn - Cổ Lũng - Bản Đôn, Huyện Bá Thước, Thanh Hóa",
        "Bản Son - Bá - Mười (Cao Sơn - Lũng Cao), Huyện Bá Thước, Thanh Hóa",
        "Thị trấn Mường Lát - Xã biên giới Tén Tằn (Cửa khẩu Tén Tằn), Huyện Mường Lát, Thanh Hóa",
        "Bản Sài Khao - Xã Mường Lý - Quang Chiểu - Pù Nhi, Huyện Mường Lát, Thanh Hóa",
        "Cửa khẩu Quốc tế Na Mèo - Xã Sơn Thủy - Mường Mìn, Huyện Quan Sơn, Thanh Hóa",
        "Khu bảo tồn thiên nhiên Nam Động - Hồi Xuân, Huyện Quan Hóa, Thanh Hóa",
        "Xã biên giới Bát Mọt - Yên Nhân - Khu bảo tồn Xuân Liên, Huyện Thường Xuân, Thanh Hóa",
        "Xã biên giới Yên Khương - Thác Ma Hao (Trí Nang), Huyện Lang Chánh, Thanh Hóa",
        "Vườn Quốc gia Bến En, Huyện Như Thanh & Như Xuân, Thanh Hóa",
        "Thị trấn Mường Xén, Huyện biên giới Kỳ Sơn, Nghệ An",
        "Cửa khẩu Quốc tế Nậm Cắn, Huyện Kỳ Sơn, Nghệ An",
        "Xã Mường Lống (Cổng trời Mường Lống - Sa Pa xứ Nghệ), Huyện Kỳ Sơn, Nghệ An",
        "Xã Na Ngoi (Chân đỉnh Puxailaileng) - Tây Sơn - Huồi Tụ - Keng Đu, Huyện Kỳ Sơn, Nghệ An",
        "Thị trấn Thạch Giám - Rừng săng lẻ Tam Đình - Xã Nhôn Mai, Huyện Tương Dương, Nghệ An",
        "Vườn Quốc gia Pù Mát - Thác Kèm - Đập Phà Lài (Môn Sơn), Huyện Con Cuông, Nghệ An",
        "Cửa khẩu Thông Thụ - Xã Tri Lễ - Thác Sao Va (Quế Phong), Huyện Quế Phong, Nghệ An",
        "Khu bảo tồn thiên nhiên Pù Huống - Hang Bua, Huyện Quỳ Châu, Nghệ An",
        "Cửa khẩu Thanh Thủy - Đảo chè Thanh Chương, Huyện Thanh Chương, Nghệ An",
        "Cửa khẩu Quốc tế Cầu Treo - Xã Sơn Kim 1, Huyện Hương Sơn, Hà Tĩnh",
        "Vườn Quốc gia Vũ Quang - Hồ Ngàn Trươi, Huyện Vũ Quang, Hà Tĩnh",
        "Xã biên giới Hương Vĩnh - Phú Gia - Phúc Trạch, Huyện Hương Khê, Hà Tĩnh",
        "Đèo Ngang (Hoành Sơn Quan), Thị xã Kỳ Anh, Hà Tĩnh",

        // Quảng Bình - Quảng Trị - Thừa Thiên Huế (Dãy Trường Sơn & Biên giới Việt - Lào)
        "Vườn Quốc gia Phong Nha - Kẻ Bàng, Huyện Bố Trạch, Quảng Bình",
        "Bản Đoòng - Hang Sơn Đoòng (Xã Tân Trạch - Thượng Trạch), Huyện Bố Trạch, Quảng Bình",
        "Cửa khẩu Quốc tế Cha Lo - Xã Dân Hóa, Huyện Minh Hóa, Quảng Bình",
        "Làng du lịch Tân Hóa - Hệ thống hang Tú Làn, Huyện vùng cao Minh Hóa, Quảng Bình",
        "Xã biên giới Trường Sơn (Hang Sơn Nữ - Thác Tam Lu), Huyện Quảng Ninh, Quảng Bình",
        "Khu dự trữ thiên nhiên Động Châu - Khe Nước Trong (Lâm Thủy), Huyện Lệ Thủy, Quảng Bình",
        "Thị trấn Khe Sanh - Cửa khẩu Quốc tế Lao Bảo, Huyện Hướng Hóa, Quảng Trị",
        "Đèo Sa Mù - Xã Hướng Phùng (Săn mây Hướng Phùng), Huyện Hướng Hóa, Quảng Trị",
        "Xã Hướng Việt - Hướng Lập (Rừng nguyên sinh Bắc Hướng Hóa), Huyện Hướng Hóa, Quảng Trị",
        "Cửa khẩu Quốc tế La Lay - Xã A Ngo - Tà Rụt, Huyện vùng cao Đakrông, Quảng Trị",
        "Thị trấn A Lưới - Đèo Pê Ke - Rừng nguyên sinh A Roàng, Huyện vùng cao A Lưới, Thừa Thiên Huế",
        "Cửa khẩu Hồng Vân - Cửa khẩu A Đớt, Huyện A Lưới, Thừa Thiên Huế",
        "Đỉnh Bạch Mã - Vườn Quốc gia Bạch Mã, Huyện Phú Lộc, Thừa Thiên Huế",
        "Đèo Hải Vân (Thiên hạ đệ nhất hùng quan), Thừa Thiên Huế - Đà Nẵng",
        "Thị trấn Khe Tre - Xã Thượng Nhật, Huyện vùng cao Nam Đông, Thừa Thiên Huế",

        // Đà Nẵng - Quảng Nam - Quảng Ngãi - Bình Định - Phú Yên - Khánh Hòa - Ninh Thuận
        "Đỉnh Bà Nà Hills - Xã Hòa Phú - Hòa Bắc, Huyện Hòa Vang, Đà Nẵng",
        "Đỉnh Quế - Rừng Pơmu (Xã A Nông - Ch'Ơm), Huyện vùng cao Tây Giang, Quảng Nam",
        "Cửa khẩu Quốc tế Nam Giang - Đắc Tôi (Xã La Dêê), Huyện Nam Giang, Quảng Nam",
        "Cổng trời Đông Giang - Đồi chè Đông Giang (Thị trấn Prao), Huyện Đông Giang, Quảng Nam",
        "Xã Trà Linh (Đỉnh Sâm Ngọc Linh), Huyện Nam Trà My, Quảng Nam",
        "Điểm trường Tắk Pổ (Xã Trà Tập) - Trà Don - Trà Vân, Huyện Nam Trà My, Quảng Nam",
        "Thị trấn Khâm Đức - Đèo Lò Xo - Xã Phước Thành, Huyện Phước Sơn, Quảng Nam",
        "Đỉnh Cà Đam - Xã Trà Bùi, Huyện vùng cao Trà Bồng, Quảng Ngãi",
        "Thảo nguyên Bùi Hui (Xã Ba Trang) - Đèo Vi Ô Lắc, Huyện Ba Tơ, Quảng Ngãi",
        "Xã Sơn Mùa - Thị trấn Di Lăng, Huyện vùng cao Sơn Tây & Sơn Hà, Quảng Ngãi",
        "Cao nguyên An Toàn - Khu bảo tồn An Toàn, Huyện vùng cao An Lão, Bình Định",
        "Xã Vĩnh Sơn (Thành cổ Tà Kơn - Thác Hang Dơi), Huyện vùng cao Vĩnh Thạnh, Bình Định",
        "Làng Canh Liên, Huyện vùng cao Vân Canh, Bình Định",
        "Cao nguyên Vân Hòa (Đà Lạt của Phú Yên), Huyện Sơn Hòa, Phú Yên",
        "Huyện vùng cao Sông Hinh & Đồng Xuân, Phú Yên",
        "Đèo Cả - Đèo Cổ Mã, Ranh giới Phú Yên - Khánh Hòa",
        "Đèo Khánh Lê (Đèo Hòn Giao - Xã Sơn Thái), Huyện vùng cao Khánh Vĩnh, Khánh Hòa",
        "Thị trấn Tô Hạp (Sầu riêng Khánh Sơn), Huyện vùng cao Khánh Sơn, Khánh Hòa",
        "Mũi Đôi - Cực Đông Tổ Quốc (Bán đảo Hòn Gốm - Xã Vạn Thạnh), Huyện Vạn Ninh, Khánh Hòa",
        "Vườn Quốc gia Phước Bình, Huyện vùng cao Bác Ái, Ninh Thuận",
        "Đèo Ngoạn Mục (Đèo Sông Pha), Huyện Ninh Sơn, Ninh Thuận",

        // Tây Nguyên: Kon Tum - Gia Lai - Đắk Lắk - Đắk Nông - Lâm Đồng
        "Thị trấn Măng Đen (Hồ Đăk Ke - Thác Pa Sỹ), Huyện Kon Plông, Kon Tum",
        "Xã Măng Cành - Xã Hiếu - Xã Pờ Ê, Huyện Kon Plông, Kon Tum",
        "Cửa khẩu Quốc tế Bờ Y - Cột mốc Ngã ba Đông Dương, Huyện Ngọc Hồi, Kon Tum",
        "Đỉnh Ngọc Linh - Xã Măng Ri - Ngọc Lây, Huyện vùng cao Tu Mơ Rông, Kon Tum",
        "Vườn Quốc gia Chư Mom Ray - Xã Rờ Kơi - Mô Rai, Huyện biên giới Sa Thầy, Kon Tum",
        "Thị trấn Đắk Pék - Xã Đắk Long - Đắk Blô, Huyện vùng cao biên giới Đắk Glei, Kon Tum",
        "Xã Ia Tơi - Ia Đal - Ia Dom, Huyện biên giới Ia H'Drai, Kon Tum",
        "Khu bảo tồn Kon Chư Răng - Thác K50 (Xã Sơn Lang), Huyện vùng cao Kbang, Gia Lai",
        "Núi lửa Chư Đăng Ya - Biển Hồ Chè, Huyện Chư Păh, Gia Lai",
        "Cửa khẩu Quốc tế Lệ Thanh, Huyện biên giới Đức Cơ, Gia Lai",
        "Xã biên giới Ia Mơ - Ia Lâu - Ia Púch, Huyện Chư Prông, Gia Lai",
        "Xã biên giới Ia O - Ia Chia, Huyện Ia Grai, Gia Lai",
        "Vườn Quốc gia Kon Ka Kinh, Huyện Mang Yang, Gia Lai",
        "Vườn Quốc gia Yok Đôn - Xã Krông Na, Huyện biên giới Buôn Đôn, Đắk Lắk",
        "Thị trấn Ea Súp - Tháp Chăm Yang Prong - Cửa khẩu Đắk Ruê, Huyện biên giới Ea Súp, Đắk Lắk",
        "Vườn Quốc gia Chư Yang Sin - Đỉnh Chư Yang Sin, Huyện Krông Bông, Đắk Lắk",
        "Hồ Lắk - Thị trấn Liên Sơn, Huyện Lắk, Đắk Lắk",
        "Đèo Phượng Hoàng - Thảo nguyên M'Drắk, Huyện M'Drắk, Đắk Lắk",
        "Hồ Tà Đùng - Xã Đắk Som (Vịnh Hạ Long trên Tây Nguyên), Huyện Đắk Glong, Đắk Nông",
        "Xã biên giới Quảng Trực - Cửa khẩu Bu Prăng, Huyện Tuy Đức, Đắk Nông",
        "Cửa khẩu Đắk Peur (Thuận An), Huyện biên giới Đắk Mil, Đắk Nông",
        "Xã biên giới Thuận Hạnh - Nâm N'Jang, Huyện Đắk Song, Đắk Nông",
        "Công viên Địa chất Toàn cầu Hang động núi lửa Krông Nô, Huyện Krông Nô, Đắk Nông",
        "Đồi chè Cầu Đất - Xã Xuân Trường - Trại Mát, Thành phố Đà Lạt, Lâm Đồng",
        "Đỉnh Langbiang - Thị trấn Lạc Dương - Xã Đạ Chais, Huyện Lạc Dương, Lâm Đồng",
        "Làng Cù Lần - Suối Vàng (Xã Lát), Huyện Lạc Dương, Lâm Đồng",
        "Suối nước nóng Đạ Long - Xã Rô Men, Huyện vùng cao Đam Rông, Lâm Đồng",
        "Cung đường Tà Năng - Phan Dũng (Xã Tà Năng), Huyện Đức Trọng, Lâm Đồng",
        "Đèo Bảo Lộc - Thác Đamb'ri, Thành phố Bảo Lộc, Lâm Đồng",
        "Đèo Gia Bắc - Xã Sơn Điền, Huyện Di Linh, Lâm Đồng",

        // Nam Bộ: Biên giới, Đỉnh núi & Rừng Quốc gia, Cực Nam Tổ Quốc
        "Vườn Quốc gia Bù Gia Mập - Xã Đắk Ơ, Huyện biên giới Bù Gia Mập, Bình Phước",
        "Cửa khẩu Quốc tế Hoa Lư - Xã Lộc Tấn, Huyện biên giới Lộc Ninh, Bình Phước",
        "Cửa khẩu Hoàng Diệu - Thị trấn Thanh Bình, Huyện biên giới Bù Đốp, Bình Phước",
        "Đỉnh Núi Bà Rá - Thác Mơ, Thị xã Phước Long, Bình Phước",
        "Trảng cỏ Bù Lạch - Sóc Bom Bo, Huyện Bù Đăng, Bình Phước",
        "Đỉnh Núi Bà Đen (Nóc nhà Nam Bộ - 986m), Thành phố Tây Ninh, Tây Ninh",
        "Cửa khẩu Quốc tế Mộc Bài, Huyện biên giới Bến Cầu, Tây Ninh",
        "Cửa khẩu Quốc tế Xa Mát - Vườn Quốc gia Lò Gò - Xa Mát, Huyện biên giới Tân Biên, Tây Ninh",
        "Cửa khẩu Quốc tế Tân Nam, Huyện biên giới Tân Biên, Tây Ninh",
        "Cửa khẩu Kà Tum - Hồ Dầu Tiếng, Huyện biên giới Tân Châu, Tây Ninh",
        "Vườn Quốc gia Cát Tiên, Huyện Tân Phú, Đồng Nai",
        "Đỉnh Núi Chứa Chan (Núi Gia Lào), Huyện Xuân Lộc, Đồng Nai",
        "Cửa khẩu Quốc tế Bình Hiệp, Thị xã biên giới Kiến Tường, Long An",
        "Cửa khẩu Quốc gia Mỹ Quý Tây, Huyện biên giới Đức Huệ, Long An",
        "Làng nổi Tân Lập, Huyện biên giới Mộc Hóa, Long An",
        "Huyện biên giới Tân Hưng & Vĩnh Hưng (Vùng Đồng Tháp Mười), Long An",
        "Cửa khẩu Quốc tế Thường Phước, Huyện biên giới Hồng Ngự, Đồng Tháp",
        "Cửa khẩu Quốc tế Dinh Bà - Thị trấn Sa Rài, Huyện biên giới Tân Hồng, Đồng Tháp",
        "Vườn Quốc gia Tràm Chim, Huyện Tam Nông, Đồng Tháp",
        "Đỉnh Núi Cấm (Thiên Cấm Sơn) - Rừng tràm Trà Sư, Thị xã biên giới Tịnh Biên, An Giang",
        "Cửa khẩu Quốc tế Tịnh Biên, Thị xã Tịnh Biên, An Giang",
        "Núi Cô Tô (Phụng Hoàng Sơn) - Hồ Tà Pạ, Huyện vùng cao Tri Tôn, An Giang",
        "Cửa khẩu Quốc tế Vĩnh Xương, Thị xã Tân Châu, An Giang",
        "Cửa khẩu Khánh Bình - Búng Bình Thiên, Huyện biên giới An Phú, An Giang",
        "Núi Sam - Kênh Vĩnh Tế, Thành phố biên giới Châu Đốc, An Giang",
        "Cửa khẩu Quốc tế Hà Tiên, Thành phố Hà Tiên, Kiên Giang",
        "Huyện biên giới Giang Thành, Kiên Giang",
        "Vườn Quốc gia U Minh Thượng, Huyện U Minh Thượng, Kiên Giang",
        "Vườn Quốc gia U Minh Hạ, Huyện U Minh, Cà Mau",
        "Xã Đất Mũi (Cột mốc Tọa độ GPS 0001 - Cực Nam Tổ Quốc), Huyện Ngọc Hiển, Cà Mau"
    )

    // Danh sách Biển Đảo, Quần Đảo tiền tiêu, Xã Đảo & Bán Đảo Việt Nam (Đầy đủ Bắc - Trung - Nam)
    val islandLocations: List<String> = listOf(
        // Quần đảo Hoàng Sa (Thành phố Đà Nẵng)
        "Quần đảo Hoàng Sa, Thành phố Đà Nẵng",
        "Đảo Hoàng Sa - Quần đảo Hoàng Sa, Thành phố Đà Nẵng",
        "Đảo Phú Lâm - Quần đảo Hoàng Sa, Thành phố Đà Nẵng",
        "Đảo Linh Côn - Quần đảo Hoàng Sa, Thành phố Đà Nẵng",
        "Đảo Tri Tôn - Quần đảo Hoàng Sa, Thành phố Đà Nẵng",
        "Nhóm đảo An Vĩnh - Quần đảo Hoàng Sa, Thành phố Đà Nẵng",
        "Nhóm đảo Lưỡi Liềm (Nguyệt Thiềm) - Quần đảo Hoàng Sa, Thành phố Đà Nẵng",
        "Đảo Duy Mộng - Đảo Quang Hòa - Đảo Bạch Quy, Quần đảo Hoàng Sa, Đà Nẵng",

        // Quần đảo Trường Sa (Huyện Trường Sa, Tỉnh Khánh Hòa) & Nhà giàn DK1
        "Quần đảo Trường Sa - Thị trấn Trường Sa (Đảo Trường Sa Lớn), Huyện Trường Sa, Khánh Hòa",
        "Xã đảo Song Tử Tây, Huyện Trường Sa, Khánh Hòa",
        "Xã đảo Sinh Tồn, Huyện Trường Sa, Khánh Hòa",
        "Đảo Sinh Tồn Đông, Huyện Trường Sa, Khánh Hòa",
        "Đảo Nam Yết, Huyện Trường Sa, Khánh Hòa",
        "Đảo Sơn Ca, Huyện Trường Sa, Khánh Hòa",
        "Đảo Phan Vinh, Huyện Trường Sa, Khánh Hòa",
        "Đảo An Bang, Huyện Trường Sa, Khánh Hòa",
        "Đảo Trường Sa Đông, Huyện Trường Sa, Khánh Hòa",
        "Đảo Đá Tây (A, B, C), Huyện Trường Sa, Khánh Hòa",
        "Đảo Đá Đông (A, B, C), Huyện Trường Sa, Khánh Hòa",
        "Đảo Đá Lát, Huyện Trường Sa, Khánh Hòa",
        "Đảo Đá Thị, Huyện Trường Sa, Khánh Hòa",
        "Đảo Đá Lớn (A, B, C), Huyện Trường Sa, Khánh Hòa",
        "Đảo Cô Lin, Huyện Trường Sa, Khánh Hòa",
        "Đảo Len Đao, Huyện Trường Sa, Khánh Hòa",
        "Đảo Tiên Nữ (Điểm cực Đông trên biển), Huyện Trường Sa, Khánh Hòa",
        "Đảo Thuyền Chài (A, B, C), Huyện Trường Sa, Khánh Hòa",
        "Đảo Tốc Tan (A, B, C), Huyện Trường Sa, Khánh Hòa",
        "Đảo Núi Le (A, B), Huyện Trường Sa, Khánh Hòa",
        "Cụm Nhà giàn DK1 (Tư Chính - Phúc Nguyên - Phúc Tần - Ba Kè - Huyền Trân), Thềm lục địa phía Nam",

        // Biển đảo Đông Bắc: Quảng Ninh - Hải Phòng - Thái Bình - Nam Định
        "Huyện đảo Cô Tô (Thị trấn Cô Tô - Xã Đồng Tiến), Tỉnh Quảng Ninh",
        "Xã đảo Thanh Lân, Huyện Cô Tô, Quảng Ninh",
        "Đảo Cô Tô Con, Huyện Cô Tô, Quảng Ninh",
        "Đảo Trần (Đảo tiền tiêu Đông Bắc - Xã Thanh Lân), Huyện Cô Tô, Quảng Ninh",
        "Huyện đảo Vân Đồn (Thị trấn Cái Rồng), Tỉnh Quảng Ninh",
        "Xã đảo Quan Lạn, Huyện Vân Đồn, Quảng Ninh",
        "Xã đảo Minh Châu, Huyện Vân Đồn, Quảng Ninh",
        "Xã đảo Ngọc Vừng, Huyện Vân Đồn, Quảng Ninh",
        "Xã đảo Thắng Lợi, Huyện Vân Đồn, Quảng Ninh",
        "Xã đảo Bản Sen, Huyện Vân Đồn, Quảng Ninh",
        "Đảo Ba Mùn (Vườn Quốc gia Bái Tử Long), Huyện Vân Đồn, Quảng Ninh",
        "Đảo Tuần Châu (Phường Tuần Châu), Thành phố Hạ Long, Quảng Ninh",
        "Đảo Ti Tốp - Đảo Soi Sim - Hang Sửng Sốt (Vịnh Hạ Long), TP. Hạ Long, Quảng Ninh",
        "Đảo Rều (Bãi Cháy), Thành phố Hạ Long, Quảng Ninh",
        "Xã đảo Cái Chiên, Huyện Hải Hà, Quảng Ninh",
        "Xã đảo Vĩnh Thực - Xã đảo Vĩnh Trung, Thành phố Móng Cái, Quảng Ninh",
        "Bán đảo Trà Cổ - Mũi Sa Vĩ, Thành phố Móng Cái, Quảng Ninh",
        "Huyện đảo Bạch Long Vĩ (Đảo tiền tiêu Vịnh Bắc Bộ), Thành phố Hải Phòng",
        "Đảo Cát Bà - Thị trấn Cát Bà, Huyện Cát Hải, Hải Phòng",
        "Xã Việt Hải - Vịnh Lan Hạ (Vườn Quốc gia Cát Bà), Huyện Cát Hải, Hải Phòng",
        "Đảo Cát Hải - Thị trấn Cát Hải, Huyện Cát Hải, Hải Phòng",
        "Quần đảo Long Châu (Hải đăng Long Châu), Huyện Cát Hải, Hải Phòng",
        "Đảo Hòn Dấu, Quận Đồ Sơn, Hải Phòng",
        "Đảo Vũ Yên, Thành phố Thủy Nguyên, Hải Phòng",
        "Đảo Cồn Vành - Đảo Cồn Đen (Khu dự trữ sinh quyển ven biển), Thái Bình",

        // Biển đảo Bắc Trung Bộ & Duyên hải Miền Trung
        "Đảo Hòn Mê (Thập nhị Tiên Nương), Thị xã Nghi Sơn, Thanh Hóa",
        "Đảo Nghi Sơn (Phường Hải Thượng), Thị xã Nghi Sơn, Thanh Hóa",
        "Đảo Hòn Nẹ, Huyện Hậu Lộc, Thanh Hóa",
        "Đảo Hòn Ngư (Đảo Song Ngư), Thị xã Cửa Lò, Nghệ An",
        "Đảo Hòn Mắt, Thị xã Cửa Lò, Nghệ An",
        "Đảo Sơn Dương (Vũng Áng), Thị xã Kỳ Anh, Hà Tĩnh",
        "Đảo Hòn Én - Đảo Hòn Gió, Huyện Quảng Trạch, Quảng Bình",
        "Vũng Chùa - Đảo Yến (Xã Quảng Đông), Huyện Quảng Trạch, Quảng Bình",
        "Huyện đảo Cồn Cỏ (Đảo tiền tiêu vĩ tuyến 17), Tỉnh Quảng Trị",
        "Đảo Sơn Chà (Đảo Hòn Chảo - Lăng Cô), Huyện Phú Lộc, Thừa Thiên Huế",
        "Bán đảo Sơn Trà (Đỉnh Bàn Cờ - Chùa Linh Ứng), Quận Sơn Trà, Đà Nẵng",
        "Đảo Cù Lao Chàm - Xã đảo Tân Hiệp, Thành phố Hội An, Quảng Nam",
        "Xã đảo Tam Hải (Bàn Than - Hòn Mang - Hòn Dứa), Huyện Núi Thành, Quảng Nam",
        "Huyện đảo Lý Sơn (Đảo Lớn - Cù Lao Ré), Tỉnh Quảng Ngãi",
        "Đảo Bé (Xã đảo An Bình - Cù Lao Bờ Bãi), Huyện Lý Sơn, Quảng Ngãi",
        "Đảo Cù Lao Xanh (Xã đảo Nhơn Châu), Thành phố Quy Nhơn, Bình Định",
        "Đảo Hòn Khô (Xã Nhơn Hải), Thành phố Quy Nhơn, Bình Định",
        "Bán đảo Phương Mai - Kỳ Co - Eo Gió (Xã Nhơn Lý), Thành phố Quy Nhơn, Bình Định",
        "Cù lao Xanh - Đầm Thị Nại - Hòn Đất, Bình Định",
        "Đảo Cù Lao Mái Nhà (Hòn Lao Mái Nhà - Xã An Hải), Huyện Tuy An, Phú Yên",
        "Đảo Hòn Yến - Hòn Sụn (Xã An Hòa Hải), Huyện Tuy An, Phú Yên",
        "Đảo Nhất Tự Sơn (Con đường đi bộ giữa biển), Thị xã Sông Cầu, Phú Yên",
        "Đảo Hòn Nưa (Dưới chân Đèo Cả - Vũng Rô), Thị xã Đông Hòa, Phú Yên",
        "Đảo Hòn Chùa - Hòn Than, Huyện Tuy An, Phú Yên",

        // Biển đảo Nam Trung Bộ: Khánh Hòa - Ninh Thuận - Bình Thuận
        "Đảo Điệp Sơn - Hòn Bịp (Vịnh Vân Phong), Huyện Vạn Ninh, Khánh Hòa",
        "Đảo Hòn Ông (Đảo Cá Voi) - Bán đảo Đầm Môn, Huyện Vạn Ninh, Khánh Hòa",
        "Đảo Hoa Lan (Hòn Hèo) - Đảo Khỉ (Hòn Lao - Vịnh Nha Phu), Thị xã Ninh Hòa, Khánh Hòa",
        "Đảo Hòn Tre (VinWonders Nha Trang), Thành phố Nha Trang, Khánh Hòa",
        "Đảo Hòn Mun (Khu bảo tồn biển) - Hòn Tằm - Hòn Miễu, Thành phố Nha Trang, Khánh Hòa",
        "Đảo Yến - Hòn Nội - Hòn Ngoại (Vịnh Nha Trang), Thành phố Nha Trang, Khánh Hòa",
        "Xã đảo Bích Đầm - Đảo Trí Nguyên (Vịnh Nha Trang), Thành phố Nha Trang, Khánh Hòa",
        "Đảo Bình Ba (Xã đảo Cam Bình - Đảo Tôm Hùm), Thành phố Cam Ranh, Khánh Hòa",
        "Đảo Bình Hưng (Hòn Chút - Xã Cam Bình), Thành phố Cam Ranh, Khánh Hòa",
        "Bán đảo Bình Lập - Bình Tiên, Thành phố Cam Ranh, Khánh Hòa",
        "Vịnh Vĩnh Hy - Mũi Cá Heo, Huyện Ninh Hải, Ninh Thuận",
        "Huyện đảo Phú Quý (Cù Lao Thu - Xã Tam Thanh, Ngũ Phụng, Long Hải), Tỉnh Bình Thuận",
        "Đảo Hòn Tranh - Hòn Đen - Hòn Trứng, Huyện đảo Phú Quý, Bình Thuận",
        "Đảo Cù Lao Câu (Hòn Câu), Huyện Tuy Phong, Bình Thuận",
        "Đảo Hòn Bà (Thị xã La Gi), Bình Thuận",
        "Đảo Hòn Bà - Hải đăng Kê Gà (Xã Tân Thành), Huyện Hàm Thuận Nam, Bình Thuận",

        // Biển đảo Đông Nam Bộ & Tây Nam Bộ (Bà Rịa - Vũng Tàu, TP.HCM, ĐBSCL, Kiên Giang, Cà Mau)
        "Huyện đảo Côn Đảo (Đảo Côn Sơn - Vườn Quốc gia Côn Đảo), Tỉnh Bà Rịa - Vũng Tàu",
        "Đảo Hòn Bảy Cạnh - Hòn Cau - Hòn Bà - Hòn Tài, Huyện Côn Đảo, Bà Rịa - Vũng Tàu",
        "Xã đảo Long Sơn - Đảo Gò Găng, Thành phố Vũng Tàu, Bà Rịa - Vũng Tàu",
        "Hòn Bà Vũng Tàu (Mũi Nghinh Phong), Thành phố Vũng Tàu, Bà Rịa - Vũng Tàu",
        "Xã đảo Thạnh An - Ấp đảo Thiềng Liềng, Huyện Cần Giờ, TP. Hồ Chí Minh",
        "Huyện cù lao Tân Phú Đông, Tỉnh Tiền Giang",
        "Cù lao Thới Sơn (Cồn Lân) - Cồn Phụng, Tiền Giang - Bến Tre",
        "Huyện Cù Lao Dung (Cù lao giữa cửa biển Định An & Trần Đề), Tỉnh Sóc Trăng",
        "Thành phố đảo Phú Quốc (Phường Dương Đông), Tỉnh Kiên Giang",
        "Phường An Thới - Thị trấn Hoàng Hôn (Nam đảo Phú Quốc), TP. Phú Quốc, Kiên Giang",
        "Quần đảo An Thới (Hòn Thơm - Hòn Mây Rút - Hòn Móng Tay - Hòn Gầm Ghì), TP. Phú Quốc, Kiên Giang",
        "Xã Gành Dầu - Bãi Dài - Rạch Vẹm - Hàm Ninh, Thành phố Phú Quốc, Kiên Giang",
        "Quần đảo Thổ Châu (Xã đảo Thổ Châu - Hòn Nhạn), Thành phố Phú Quốc, Kiên Giang",
        "Quần đảo Nam Du (Xã đảo An Sơn - Hòn Củ Tron), Huyện Kiên Hải, Kiên Giang",
        "Xã đảo Nam Du (Hòn Mấu - Hòn Ngang - Hòn Hai Bờ Đập), Huyện Kiên Hải, Kiên Giang",
        "Đảo Hòn Sơn (Xã đảo Lại Sơn - Đỉnh Ma Thiên Lãnh), Huyện Kiên Hải, Kiên Giang",
        "Đảo Hòn Tre (Trung tâm hành chính Huyện Kiên Hải), Tỉnh Kiên Giang",
        "Đảo Hòn Nghệ (Xã đảo Hòn Nghệ), Huyện Kiên Lương, Kiên Giang",
        "Quần đảo Bà Lụa (Xã đảo Sơn Hải - Ba Hòn Đầm), Huyện Kiên Lương, Kiên Giang",
        "Quần đảo Hải Tặc (Xã đảo Tiên Hải - Hòn Đốc), Thành phố Hà Tiên, Kiên Giang",
        "Cụm đảo Hòn Khoai (Đảo Hòn Khoai - Xã Tân Ân), Huyện Ngọc Hiển, Cà Mau",
        "Đảo Hòn Chuối (Đảo tiền tiêu Tây Nam - Thị trấn Sông Đốc), Huyện Trần Văn Thời, Cà Mau",
        "Đảo Hòn Đá Bạc (Xã Khánh Bình Tây), Huyện Trần Văn Thời, Cà Mau"
    )

    // Danh bạ chi tiết Quận / Huyện / Thị xã / Thành phố / Xã / Phường của toàn bộ 63 tỉnh thành
    val locationsByProvince: Map<String, List<String>> = mapOf(
        "Hà Nội" to listOf(
            "Phường Kim Mã, Quận Ba Đình, Hà Nội",
            "Phường Điện Biên (Lăng Bác), Quận Ba Đình, Hà Nội",
            "Phường Tràng Tiền (Hồ Gươm), Quận Hoàn Kiếm, Hà Nội",
            "Phường Hàng Đào (Phố Cổ), Quận Hoàn Kiếm, Hà Nội",
            "Phường Quảng An (Hồ Tây), Quận Tây Hồ, Hà Nội",
            "Phường Nhật Tân, Quận Tây Hồ, Hà Nội",
            "Phường Dịch Vọng, Quận Cầu Giấy, Hà Nội",
            "Phường Trung Hòa, Quận Cầu Giấy, Hà Nội",
            "Phường Ô Chợ Dừa, Quận Đống Đa, Hà Nội",
            "Phường Láng Hạ, Quận Đống Đa, Hà Nội",
            "Phường Bách Khoa, Quận Hai Bà Trưng, Hà Nội",
            "Phường Minh Khai, Quận Hai Bà Trưng, Hà Nội",
            "Phường Giáp Bát, Quận Hoàng Mai, Hà Nội",
            "Phường Hoàng Liệt (Linh Đàm), Quận Hoàng Mai, Hà Nội",
            "Phường Thanh Xuân Bắc, Quận Thanh Xuân, Hà Nội",
            "Phường Nhân Chính, Quận Thanh Xuân, Hà Nội",
            "Phường Bồ Đề, Quận Long Biên, Hà Nội",
            "Phường Việt Hưng, Quận Long Biên, Hà Nội",
            "Phường Mộ Lao, Quận Hà Đông, Hà Nội",
            "Phường Văn Quán, Quận Hà Đông, Hà Nội",
            "Phường Mỹ Đình 1, Quận Nam Từ Liêm, Hà Nội",
            "Phường Tây Mỗ, Quận Nam Từ Liêm, Hà Nội",
            "Phường Cổ Nhuế 1, Quận Bắc Từ Liêm, Hà Nội",
            "Phường Xuân Đỉnh, Quận Bắc Từ Liêm, Hà Nội",
            "Thị xã Sơn Tây (Thành cổ Sơn Tây - Làng cổ Đường Lâm), Hà Nội",
            "Huyện Ba Vì (Vườn Quốc gia Ba Vì - Tản Lĩnh - Khoang Xanh), Hà Nội",
            "Huyện Chương Mỹ (Thị trấn Chúc Sơn - Xuân Mai), Hà Nội",
            "Huyện Đan Phượng (Thị trấn Phùng), Hà Nội",
            "Huyện Đông Anh (Thành Cổ Loa - Thị trấn Đông Anh), Hà Nội",
            "Huyện Gia Lâm (Thị trấn Trâu Quỳ - Bát Tràng - Đa Tốn), Hà Nội",
            "Huyện Hoài Đức (Thị trấn Trạm Trôi - An Khánh), Hà Nội",
            "Huyện Mê Linh (Đền Hai Bà Trưng - Quang Minh), Hà Nội",
            "Huyện Mỹ Đức (Chùa Hương - Xã Hương Sơn), Hà Nội",
            "Huyện Phú Xuyên (Làng nghề Phú Xuyên), Hà Nội",
            "Huyện Phúc Thọ, Hà Nội",
            "Huyện Quốc Oai (Chùa Thầy), Hà Nội",
            "Huyện Sóc Sơn (Sân bay Quốc tế Nội Bài - Đền Gióng), Hà Nội",
            "Huyện Thạch Thất (Khu Công nghệ cao Hòa Lạc - Chùa Tây Phương), Hà Nội",
            "Huyện Thanh Oai (Bình Đà - Kim Bài), Hà Nội",
            "Huyện Thanh Trì (Thị trấn Văn Điển), Hà Nội",
            "Huyện Thường Tín (Nhị Khê - Duyên Thái), Hà Nội",
            "Huyện Ứng Hòa (Thị trấn Vân Đình - Làng hương Quảng Phú Cầu), Hà Nội"
        ),
        "TP. Hồ Chí Minh" to listOf(
            "Phường Bến Nghé (Phố đi bộ Nguyễn Huệ), Quận 1, TP. Hồ Chí Minh",
            "Phường Bến Thành (Chợ Bến Thành), Quận 1, TP. Hồ Chí Minh",
            "Phường Tân Định - Đa Kao, Quận 1, TP. Hồ Chí Minh",
            "Phường Võ Thị Sáu (Hồ Con Rùa), Quận 3, TP. Hồ Chí Minh",
            "Phường Thảo Điền, Thành phố Thủ Đức, TP. Hồ Chí Minh",
            "Phường Thủ Thiêm - An Khánh, Thành phố Thủ Đức, TP. Hồ Chí Minh",
            "Phường Linh Trung (Làng Đại học), Thành phố Thủ Đức, TP. Hồ Chí Minh",
            "Phường Hiệp Bình Chánh, Thành phố Thủ Đức, TP. Hồ Chí Minh",
            "Phường Long Thạnh Mỹ (Vinhomes Grand Park), Thành phố Thủ Đức, TP. Hồ Chí Minh",
            "Phường Cát Lái - Thạnh Mỹ Lợi, Thành phố Thủ Đức, TP. Hồ Chí Minh",
            "Quận 4 (Bến Nhà Rồng - Khánh Hội), TP. Hồ Chí Minh",
            "Quận 5 (Chợ Lớn - Nguyễn Trãi), TP. Hồ Chí Minh",
            "Quận 6 (Chợ Bình Tây - Phú Lâm), TP. Hồ Chí Minh",
            "Phường Tân Phong (Phú Mỹ Hưng), Quận 7, TP. Hồ Chí Minh",
            "Phường Tân Thuận Đông, Quận 7, TP. Hồ Chí Minh",
            "Quận 8 (Bến Bình Đông - Phạm Thế Hiển), TP. Hồ Chí Minh",
            "Quận 10 (Sư Vạn Hạnh - Hòa Hưng), TP. Hồ Chí Minh",
            "Quận 11 (Đầm Sen - Phú Thọ), TP. Hồ Chí Minh",
            "Quận 12 (Tân Thới Nhất - An Phú Đông), TP. Hồ Chí Minh",
            "Quận Bình Tân (Bình Trị Đông - Tên Lửa), TP. Hồ Chí Minh",
            "Phường 25 (Landmark 81), Quận Bình Thạnh, TP. Hồ Chí Minh",
            "Phường 10 (Quang Trung), Quận Gò Vấp, TP. Hồ Chí Minh",
            "Quận Phú Nhuận (Phan Xích Long), TP. Hồ Chí Minh",
            "Phường 2 (Sân bay Quốc tế Tân Sơn Nhất), Quận Tân Bình, TP. Hồ Chí Minh",
            "Quận Tân Phú (Tân Sơn Nhì - Phú Thọ Hòa), TP. Hồ Chí Minh",
            "Huyện Bình Chánh (Thị trấn Tân Túc - Vĩnh Lộc), TP. Hồ Chí Minh",
            "Huyện Cần Giờ (Thị trấn Cần Thạnh - Rừng Sác - Xã đảo Thạnh An), TP. Hồ Chí Minh",
            "Thị trấn Củ Chi (Địa đạo Củ Chi), Huyện Củ Chi, TP. Hồ Chí Minh",
            "Huyện Hóc Môn (Thị trấn Hóc Môn - Bà Điểm), TP. Hồ Chí Minh",
            "Thị trấn Nhà Bè (Phước Kiển - Hiệp Phước), Huyện Nhà Bè, TP. Hồ Chí Minh"
        ),
        "Đà Nẵng" to listOf(
            "Phường Hải Châu 1 (Cầu Rồng - Sông Hàn), Quận Hải Châu, Đà Nẵng",
            "Phường Thạch Thang, Quận Hải Châu, Đà Nẵng",
            "Phường Hòa Cường Bắc, Quận Hải Châu, Đà Nẵng",
            "Phường An Hải Bắc, Quận Sơn Trà, Đà Nẵng",
            "Phường Phước Mỹ (Biển Mỹ Khê), Quận Sơn Trà, Đà Nẵng",
            "Bán đảo Sơn Trà (Chùa Linh Ứng - Đỉnh Bàn Cờ), Quận Sơn Trà, Đà Nẵng",
            "Phường Mỹ An, Quận Ngũ Hành Sơn, Đà Nẵng",
            "Phường Hòa Hải (Danh thắng Ngũ Hành Sơn), Quận Ngũ Hành Sơn, Đà Nẵng",
            "Phường Vĩnh Trung, Quận Thanh Khê, Đà Nẵng",
            "Phường Xuân Hà (Biển Nguyễn Tất Thành), Quận Thanh Khê, Đà Nẵng",
            "Phường Hòa Khánh Bắc, Quận Liên Chiểu, Đà Nẵng",
            "Đèo Hải Vân (Phường Hòa Hiệp Bắc), Quận Liên Chiểu, Đà Nẵng",
            "Quận Cẩm Lệ (Khuê Trung - Hòa Xuân), Đà Nẵng",
            "Xã Hòa Phú (Đỉnh Bà Nà Hills - Núi Chúa), Huyện Hòa Vang, Đà Nẵng",
            "Xã Hòa Bắc - Hòa Ninh, Huyện Hòa Vang, Đà Nẵng",
            "Huyện Hòa Vang (Túy Loan), Đà Nẵng",
            "Quần đảo Hoàng Sa, Thành phố Đà Nẵng"
        ),
        "Hải Phòng" to listOf(
            "Phường Hoàng Văn Thụ (Nhà hát Lớn), Quận Hồng Bàng, Hải Phòng",
            "Phường Máy Tơ, Quận Ngô Quyền, Hải Phòng",
            "Phường Cát Dài, Quận Lê Chân, Hải Phòng",
            "Quận Hải An (Sân bay Quốc tế Cát Bi - Đình Vũ), Hải Phòng",
            "Quận Kiến An (Đồi Thiên Văn), Hải Phòng",
            "Quận Đồ Sơn (Biển Đồ Sơn - Đảo Hòn Dấu), Hải Phòng",
            "Quận Dương Kinh, Hải Phòng",
            "Thành phố Thủy Nguyên (Núi Đèo - Đảo Vũ Yên), Hải Phòng",
            "Quận An Dương, Hải Phòng",
            "Huyện An Lão (Núi Voi), Hải Phòng",
            "Huyện Kiến Thụy, Hải Phòng",
            "Huyện Tiên Lãng (Suối khoáng nóng Tiên Lãng), Hải Phòng",
            "Huyện Vĩnh Bảo (Khu di tích Trạng Trình Nguyễn Bỉnh Khiêm), Hải Phòng",
            "Thị trấn Cát Bà - Vịnh Lan Hạ, Huyện Cát Hải, Hải Phòng",
            "Thị trấn Cát Hải - Đảo Cát Hải, Huyện Cát Hải, Hải Phòng",
            "Huyện đảo Bạch Long Vĩ, Hải Phòng"
        ),
        "Cần Thơ" to listOf(
            "Phường Tân An (Bến Ninh Kiều), Quận Ninh Kiều, Cần Thơ",
            "Phường Cái Khế - Xuân Khánh, Quận Ninh Kiều, Cần Thơ",
            "Quận Bình Thủy (Nhà cổ Bình Thủy - Sân bay Cần Thơ), Cần Thơ",
            "Quận Cái Răng (Chợ nổi Cái Răng), Cần Thơ",
            "Quận Ô Môn, Cần Thơ",
            "Quận Thốt Nốt (Vườn cò Bằng Lăng), Cần Thơ",
            "Huyện Phong Điền (Làng du lịch Mỹ Khánh), Cần Thơ",
            "Huyện Cờ Đỏ, Cần Thơ",
            "Huyện Thới Lai, Cần Thơ",
            "Huyện Vĩnh Thạnh, Cần Thơ"
        ),
        "Hà Giang" to listOf(
            "Thành phố Hà Giang (Km0 Hà Giang), Hà Giang",
            "Xã Lũng Cú (Cột cờ Cực Bắc), Huyện Đồng Văn, Hà Giang",
            "Thị trấn Đồng Văn (Phố cổ Đồng Văn), Huyện Đồng Văn, Hà Giang",
            "Thị trấn Phố Bảng - Xã Sủng Là, Huyện Đồng Văn, Hà Giang",
            "Thị trấn Mèo Vạc - Đèo Mã Pí Lèng, Huyện Mèo Vạc, Hà Giang",
            "Xã Xín Cái - Sơn Vĩ - Thượng Phùng, Huyện Mèo Vạc, Hà Giang",
            "Huyện Yên Minh (Rừng thông Yên Minh - Du Già), Hà Giang",
            "Huyện Quản Bạ (Cổng trời Quản Bạ - Núi Đôi), Hà Giang",
            "Xã Bản Phùng - Đỉnh Chiêu Lầu Thi, Huyện Hoàng Su Phì, Hà Giang",
            "Thị trấn Vinh Quang - Thông Nguyên, Huyện Hoàng Su Phì, Hà Giang",
            "Huyện Xín Mần (Thảo nguyên Suôi Thầu - Cốc Pài), Hà Giang",
            "Huyện Vị Xuyên (Đỉnh Tây Côn Lĩnh - Cửa khẩu Quốc tế Thanh Thủy), Hà Giang",
            "Huyện Bắc Mê, Hà Giang",
            "Huyện Bắc Quang, Hà Giang",
            "Huyện Quang Bình, Hà Giang"
        ),
        "Cao Bằng" to listOf(
            "Thành phố Cao Bằng, Cao Bằng",
            "Khu di tích Pác Bó - Xã Trường Hà, Huyện Hà Quảng, Cao Bằng",
            "Cửa khẩu Sóc Giang - Thị trấn Xuân Hòa, Huyện Hà Quảng, Cao Bằng",
            "Thác Bản Giốc - Động Ngườm Ngao (Xã Đàm Thủy), Huyện Trùng Khánh, Cao Bằng",
            "Cửa khẩu Quốc tế Trà Lĩnh, Huyện Trùng Khánh, Cao Bằng",
            "Huyện Bảo Lạc (Đèo Mẻ Pia 14 tầng - Cốc Pàng), Cao Bằng",
            "Huyện Bảo Lâm (Thị trấn Pác Miầu), Cao Bằng",
            "Huyện Nguyên Bình (Đỉnh Phia Oắc - Phia Đén), Cao Bằng",
            "Huyện Quảng Hòa (Cửa khẩu Quốc tế Tà Lùng - Hồ Thăng Hen), Cao Bằng",
            "Huyện Hạ Lang (Cửa khẩu Lý Vạn), Cao Bằng",
            "Huyện Hòa An (Nước Hai), Cao Bằng",
            "Huyện Thạch An (Đông Khê), Cao Bằng"
        ),
        "Lào Cai" to listOf(
            "Thành phố Lào Cai (Cửa khẩu Quốc tế Lào Cai), Lào Cai",
            "Thị xã Sa Pa (Đỉnh Fansipan - Nhà thờ Đá), Lào Cai",
            "Xã Tả Van - Bản Cát Cát - Đèo Ô Quy Hồ, Thị xã Sa Pa, Lào Cai",
            "Xã Y Tý (Thiên đường săn mây), Huyện Bát Xát, Lào Cai",
            "Xã A Mú Sung - Cột cờ Lũng Pô - Trịnh Tường, Huyện Bát Xát, Lào Cai",
            "Thị trấn Bắc Hà - Xã Bản Liền, Huyện Bắc Hà, Lào Cai",
            "Huyện Si Ma Cai (Chợ Cán Cấu - Sín Chéng), Lào Cai",
            "Huyện Mường Khương (Xã Pha Long - Dìn Chin), Lào Cai",
            "Huyện Bảo Thắng (Thị trấn Phố Lu), Lào Cai",
            "Huyện Bảo Yên (Đền Bảo Hà - Phố Ràng), Lào Cai",
            "Huyện Văn Bàn (Khánh Yên - Nậm Xé), Lào Cai"
        ),
        "Lai Châu" to listOf(
            "Thành phố Lai Châu, Lai Châu",
            "Cao nguyên Sìn Hồ (Thị trấn Sìn Hồ - Tả Phìn), Huyện Sìn Hồ, Lai Châu",
            "Huyện Tam Đường (Đỉnh Pu Ta Leng - Bản Sì Thâu Chải), Lai Châu",
            "Huyện Phong Thổ (Cửa khẩu Ma Lù Thàng - Dào San - Sin Suối Hồ), Lai Châu",
            "Xã Ka Lăng - Thu Lũm (Thượng nguồn sông Đà), Huyện Mường Tè, Lai Châu",
            "Thị trấn Mường Tè - Xã Mù Cả - Pa Ủ, Huyện Mường Tè, Lai Châu",
            "Huyện Nậm Nhùn (Thủy điện Lai Châu - Hua Bum), Lai Châu",
            "Huyện Than Uyên (Cánh đồng Mường Than), Lai Châu",
            "Huyện Tân Uyên (Đồi chè Tân Uyên), Lai Châu"
        ),
        "Điện Biên" to listOf(
            "Thành phố Điện Biên Phủ (Đồi A1 - Hầm Đờ Cát), Điện Biên",
            "Xã Mường Phăng, Thành phố Điện Biên Phủ, Điện Biên",
            "Xã Sín Thầu - A Pa Chải (Ngã ba biên giới Cực Tây), Huyện Mường Nhé, Điện Biên",
            "Huyện Mường Nhé (Chung Chải - Sen Thượng), Điện Biên",
            "Huyện Nậm Pồ (Chà Nưa - Si Pa Phìn - Nà Hỳ), Điện Biên",
            "Huyện Tủa Chùa (Cao nguyên đá Tủa Chùa - Tả Sìn Thàng), Điện Biên",
            "Huyện Tuần Giáo (Đèo Pha Đin), Điện Biên",
            "Huyện Điện Biên (Cửa khẩu Quốc tế Tây Trang - Thanh Luông), Điện Biên",
            "Huyện Điện Biên Đông (Tháp Mường Luân - Keo Lôm), Điện Biên",
            "Huyện Mường Chà (Mường Tùng - Huổi Lèng), Điện Biên",
            "Huyện Mường Ảng (Cà phê Mường Ảng), Điện Biên",
            "Thị xã Mường Lay (Lòng hồ sông Đà), Điện Biên"
        ),
        "Sơn La" to listOf(
            "Thành phố Sơn La (Nhà tù Sơn La - Chiềng Lề), Sơn La",
            "Thị xã Mộc Châu (Đồi chè Mộc Châu - Cửa khẩu Lóng Sập), Sơn La",
            "Đỉnh Pha Luông (Xã Chiềng Sơn), Thị xã Mộc Châu, Sơn La",
            "Huyện Vân Hồ (Chiềng Yên - Lóng Luông), Sơn La",
            "Xã Tà Xùa (Sống lưng khủng long - Háng Đồng), Huyện Bắc Yên, Sơn La",
            "Huyện Bắc Yên, Sơn La",
            "Xã Ngọc Chiến (Suối khoáng nóng Ngọc Chiến), Huyện Mường La, Sơn La",
            "Huyện Mường La (Thủy điện Sơn La - Ít Ong), Sơn La",
            "Huyện Phù Yên (Cánh đồng Mường Tấc - Suối Tọ), Sơn La",
            "Huyện Quỳnh Nhai (Cầu Pá Uôn - Lòng hồ sông Đà), Sơn La",
            "Huyện Thuận Châu (Đèo Pha Đin - Co Mạ), Sơn La",
            "Huyện Mai Sơn (Thị trấn Hát Lót - Cò Nòi), Sơn La",
            "Huyện Yên Châu (Xoài Yên Châu - Phiêng Khoài), Sơn La",
            "Huyện Sông Mã (Cửa khẩu Chiềng Khương), Sơn La",
            "Huyện biên giới Sốp Cộp (Mường Lạn - Mường Lèo), Sơn La"
        ),
        "Yên Bái" to listOf(
            "Thành phố Yên Bái, Yên Bái",
            "Thị xã Nghĩa Lộ (Cánh đồng Mường Lò), Yên Bái",
            "Xã La Pán Tẩn - Chế Cu Nha - Dế Xu Phình, Huyện Mù Cang Chải, Yên Bái",
            "Đèo Khau Phạ - Xã Cao Phạ, Huyện Mù Cang Chải, Yên Bái",
            "Thị trấn Mù Cang Chải, Huyện Mù Cang Chải, Yên Bái",
            "Huyện Trạm Tấu (Đỉnh Tà Chì Nhù - Bản Cu Vai - Suối khoáng nóng), Yên Bái",
            "Xã Suối Giàng - Xã Tú Lệ, Huyện Văn Chấn, Yên Bái",
            "Huyện Lục Yên (Chợ đá quý Lục Yên - Lâm Thượng), Yên Bái",
            "Huyện Văn Yên (Đền Đông Cuông - Quế Văn Yên - Nà Hẩu), Yên Bái",
            "Huyện Trấn Yên (Cổ Phúc), Yên Bái",
            "Huyện Yên Bình (Hồ Thác Bà), Yên Bái"
        ),
        "Bắc Kạn" to listOf(
            "Thành phố Bắc Kạn, Bắc Kạn",
            "Vườn Quốc gia Hồ Ba Bể (Xã Nam Mẫu - Khang Ninh), Huyện Ba Bể, Bắc Kạn",
            "Huyện vùng cao Pác Nặm (Bộc Bố - Cổ Linh), Bắc Kạn",
            "Huyện Ngân Sơn (Đèo Giàng - Đèo Gió - Vân Tùng), Bắc Kạn",
            "Huyện Na Rì (Khu bảo tồn Kim Hỷ - Động Nàng Tiên), Bắc Kạn",
            "Huyện Chợ Đồn (ATK Chợ Đồn - Bằng Lũng), Bắc Kạn",
            "Huyện Chợ Mới (Đồng Tâm), Bắc Kạn",
            "Huyện Bạch Thông (Phủ Thông), Bắc Kạn"
        ),
        "Lạng Sơn" to listOf(
            "Thành phố Lạng Sơn (Động Tam Thanh - Chợ Đông Kinh), Lạng Sơn",
            "Đỉnh Mẫu Sơn - Cửa khẩu Chi Ma, Huyện Lộc Bình, Lạng Sơn",
            "Thị trấn Đồng Đăng (Cửa khẩu Quốc tế Hữu Nghị), Huyện Cao Lộc, Lạng Sơn",
            "Huyện Bắc Sơn (Thung lũng Bắc Sơn - Đỉnh Nà Lay), Lạng Sơn",
            "Huyện Bình Gia, Lạng Sơn",
            "Huyện Đình Lập (Đồi cỏ lau Bắc Xa - Cột mốc 1297), Lạng Sơn",
            "Huyện Hữu Lũng (Thảo nguyên Đồng Lâm - Hữu Liên), Lạng Sơn",
            "Huyện Chi Lăng (Ải Chi Lăng - Đồng Mỏ), Lạng Sơn",
            "Huyện Tràng Định (Thất Khê - Cửa khẩu Bình Nghi), Lạng Sơn",
            "Huyện Văn Lãng (Cửa khẩu Tân Thanh - Cốc Nam), Lạng Sơn",
            "Huyện Văn Quan, Lạng Sơn"
        ),
        "Tuyên Quang" to listOf(
            "Thành phố Tuyên Quang, Tuyên Quang",
            "Huyện Na Hang (Hồ sinh thái Na Hang - Xã Hồng Thái), Tuyên Quang",
            "Huyện Lâm Bình (Xã Thượng Lâm - Lăng Can), Tuyên Quang",
            "Huyện Chiêm Hóa (Vĩnh Lộc - Thác Bản Ba), Tuyên Quang",
            "Huyện Hàm Yên (Cam sành Hàm Yên - Tân Yên), Tuyên Quang",
            "Huyện Yên Sơn (Suối khoáng Mỹ Lâm), Tuyên Quang",
            "Huyện Sơn Dương (Khu di tích Quốc gia đặc biệt Tân Trào), Tuyên Quang"
        ),
        "Thái Nguyên" to listOf(
            "Thành phố Thái Nguyên (Bảo tàng Văn hóa các dân tộc VN), Thái Nguyên",
            "Đồi chè Tân Cương, Thành phố Thái Nguyên, Thái Nguyên",
            "Thành phố Sông Công, Thái Nguyên",
            "Thành phố Phổ Yên, Thái Nguyên",
            "Huyện Đại Từ (Hồ Núi Cốc - Suối Cửa Tử), Thái Nguyên",
            "Huyện Định Hóa (ATK Định Hóa - Chợ Chu), Thái Nguyên",
            "Huyện Đồng Hỷ (Chùa Hang - Hóa Thượng), Thái Nguyên",
            "Huyện Phú Bình, Thái Nguyên",
            "Huyện Phú Lương (Đồi chè Cầu Đá), Thái Nguyên",
            "Huyện vùng cao Võ Nhai (Hang Phượng Hoàng - Thần Sa), Thái Nguyên"
        ),
        "Phú Thọ" to listOf(
            "Thành phố Việt Trì (Khu di tích Đền Hùng), Phú Thọ",
            "Thị xã Phú Thọ, Phú Thọ",
            "Vườn Quốc gia Xuân Sơn - Đồi chè Long Cốc, Huyện Tân Sơn, Phú Thọ",
            "Huyện Thanh Thủy (Khoáng nóng Thanh Thủy - Đảo Ngọc Xanh), Phú Thọ",
            "Huyện Cẩm Khê, Phú Thọ",
            "Huyện Đoan Hùng (Bưởi Đoan Hùng), Phú Thọ",
            "Huyện Hạ Hòa (Đền Mẫu Âu Cơ - Ao Giời Suối Tiên), Phú Thọ",
            "Huyện Lâm Thao (Hùng Sơn), Phú Thọ",
            "Huyện Phù Ninh, Phú Thọ",
            "Huyện Tam Nông, Phú Thọ",
            "Huyện Thanh Ba, Phú Thọ",
            "Huyện Thanh Sơn, Phú Thọ",
            "Huyện Yên Lập, Phú Thọ"
        ),
        "Bắc Giang" to listOf(
            "Thành phố Bắc Giang (Chùa Vĩnh Nghiêm - Yên Dũng), Bắc Giang",
            "Thị xã Việt Yên (Chùa Bổ Đà), Bắc Giang",
            "Thị xã Chũ, Bắc Giang",
            "Huyện Lục Ngạn (Hồ Cấm Sơn - Hồ Khuôn Thần - Phì Điền), Bắc Giang",
            "Cao nguyên Đồng Cao - Tây Yên Tử, Huyện Sơn Động, Bắc Giang",
            "Huyện Lục Nam (Suối Mỡ), Bắc Giang",
            "Huyện Hiệp Hòa, Bắc Giang",
            "Huyện Lạng Giang (Cây Dã Hương nghìn năm), Bắc Giang",
            "Huyện Tân Yên, Bắc Giang",
            "Huyện Yên Thế (Khu di tích Hoàng Hoa Thám - Phồn Xương), Bắc Giang"
        ),
        "Quảng Ninh" to listOf(
            "Phường Bạch Đằng (Hòn Gai), Thành phố Hạ Long, Quảng Ninh",
            "Phường Bãi Cháy - Đảo Tuần Châu, Thành phố Hạ Long, Quảng Ninh",
            "Vịnh Hạ Long (Đảo Ti Tốp - Hang Sửng Sốt), Thành phố Hạ Long, Quảng Ninh",
            "Thành phố Móng Cái (Cửa khẩu Móng Cái - Mũi Sa Vĩ - Trà Cổ - Đảo Vĩnh Thực), Quảng Ninh",
            "Thành phố Cẩm Phả (Đền Cửa Ông - Khoáng nóng Quang Hanh), Quảng Ninh",
            "Thành phố Uông Bí (Đỉnh Chùa Đồng Yên Tử - Chùa Ba Vàng), Quảng Ninh",
            "Thành phố Đông Triều (Khu di tích Nhà Trần - Ngọa Vân), Quảng Ninh",
            "Thị xã Quảng Yên (Bạch Đằng Giang), Quảng Ninh",
            "Huyện đảo Cô Tô (Thị trấn Cô Tô - Đảo Thanh Lân - Đảo Trần), Quảng Ninh",
            "Huyện đảo Vân Đồn (Cái Rồng - Đảo Quan Lạn - Minh Châu - Ngọc Vừng), Quảng Ninh",
            "Huyện Bình Liêu (Sống lưng khủng long - Cột mốc 1305 - Cửa khẩu Hoành Mô), Quảng Ninh",
            "Huyện Tiên Yên, Quảng Ninh",
            "Huyện Ba Chẽ (Khu bảo tồn Đồng Sơn - Kỳ Thượng), Quảng Ninh",
            "Huyện Đầm Hà (Đảo Đá Dựng), Quảng Ninh",
            "Huyện Hải Hà (Xã đảo Cái Chiên - Cửa khẩu Bắc Phong Sinh), Quảng Ninh"
        ),
        "Hòa Bình" to listOf(
            "Thành phố Hòa Bình (Thủy điện Hòa Bình), Hòa Bình",
            "Thị trấn Mai Châu - Bản Lác - Đèo Thung Khe, Huyện Mai Châu, Hòa Bình",
            "Xã Hang Kia - Pà Cò (Săn mây Hang Kia), Huyện Mai Châu, Hòa Bình",
            "Huyện vùng cao Đà Bắc (Xã Hiền Lương - Cao Sơn - Hồ Hòa Bình), Hòa Bình",
            "Huyện Kim Bôi (Suối khoáng nóng Kim Bôi - Serena), Hòa Bình",
            "Huyện Lương Sơn, Hòa Bình",
            "Huyện Cao Phong (Cam Cao Phong - Thung Nai), Hòa Bình",
            "Huyện Tân Lạc (Xã Lũng Vân - Ngổ Luông - Quyết Chiến), Hòa Bình",
            "Huyện Lạc Sơn (Thác Mu - Xã Tự Do - Vụ Bản), Hòa Bình",
            "Huyện Lạc Thủy (Chùa Tiên), Hòa Bình",
            "Huyện Yên Thủy, Hòa Bình"
        ),
        "Vĩnh Phúc" to listOf(
            "Thành phố Vĩnh Yên (Đầm Vạc), Vĩnh Phúc",
            "Thành phố Phúc Yên (Hồ Đại Lải - Xuân Hòa), Vĩnh Phúc",
            "Thị trấn Tam Đảo - Tây Thiên, Huyện Tam Đảo, Vĩnh Phúc",
            "Huyện Bình Xuyên, Vĩnh Phúc",
            "Huyện Lập Thạch, Vĩnh Phúc",
            "Huyện Sông Lô (Tháp Bình Sơn), Vĩnh Phúc",
            "Huyện Tam Dương, Vĩnh Phúc",
            "Huyện Vĩnh Tường (Thổ Tang), Vĩnh Phúc",
            "Huyện Yên Lạc (Tề Lỗ), Vĩnh Phúc"
        ),
        "Bắc Ninh" to listOf(
            "Thành phố Bắc Ninh (Đền Bà Chúa Kho), Bắc Ninh",
            "Thành phố Từ Sơn (Đền Đô - Đồng Kỵ), Bắc Ninh",
            "Thị xã Thuận Thành (Chùa Dâu - Chùa Bút Tháp - Làng tranh Đông Hồ), Bắc Ninh",
            "Thị xã Quế Võ (Phố Mới), Bắc Ninh",
            "Huyện Yên Phong (Đền thờ Lý Thường Kiệt), Bắc Ninh",
            "Huyện Tiên Du (Hội Lim - Chùa Phật Tích), Bắc Ninh",
            "Huyện Gia Bình (Lệ Chi Viên), Bắc Ninh",
            "Huyện Lương Tài, Bắc Ninh"
        ),
        "Hải Dương" to listOf(
            "Thành phố Hải Dương, Hải Dương",
            "Thành phố Chí Linh (Khu di tích Côn Sơn - Kiếp Bạc), Hải Dương",
            "Thị xã Kinh Môn (Động Kính Chủ - Đền Cao An Phụ), Hải Dương",
            "Huyện Bình Giang (Kẻ Sặt), Hải Dương",
            "Huyện Cẩm Giàng (Văn miếu Mao Điền), Hải Dương",
            "Huyện Gia Lộc, Hải Dương",
            "Huyện Kim Thành, Hải Dương",
            "Huyện Nam Sách, Hải Dương",
            "Huyện Ninh Giang (Đền Tranh - Đảo Cò Chi Lăng Nam), Hải Dương",
            "Huyện Thanh Hà (Vải thiều Thanh Hà), Hải Dương",
            "Huyện Thanh Miện, Hải Dương",
            "Huyện Tứ Kỳ, Hải Dương"
        ),
        "Hưng Yên" to listOf(
            "Thành phố Hưng Yên (Phố Hiến), Hưng Yên",
            "Thị xã Mỹ Hào, Hưng Yên",
            "Huyện Văn Giang (Khu đô thị Ecopark - Vinhomes Ocean Park 2 & 3), Hưng Yên",
            "Huyện Văn Lâm (Làng Nôm), Hưng Yên",
            "Huyện Yên Mỹ, Hưng Yên",
            "Huyện Khoái Châu (Chử Đồng Tử - Tiên Dung), Hưng Yên",
            "Huyện Kim Động, Hưng Yên",
            "Huyện Ân Thi, Hưng Yên",
            "Huyện Phù Cừ, Hưng Yên",
            "Huyện Tiên Lữ, Hưng Yên"
        ),
        "Thái Bình" to listOf(
            "Thành phố Thái Bình, Thái Bình",
            "Huyện Tiền Hải (Biển Đồng Châu - Đảo Cồn Vành), Thái Bình",
            "Huyện Thái Thụy (Biển Cồn Đen - Rừng ngập mặn Thụy Trường), Thái Bình",
            "Huyện Đông Hưng (Làng chạm bạc Đồng Xâm), Thái Bình",
            "Huyện Hưng Hà (Đền Trần Thái Bình), Thái Bình",
            "Huyện Kiến Xương, Thái Bình",
            "Huyện Quỳnh Phụ (Đền A Sào), Thái Bình",
            "Huyện Vũ Thư (Chùa Keo), Thái Bình"
        ),
        "Hà Nam" to listOf(
            "Thành phố Phủ Lý (Đền Trần Thương), Hà Nam",
            "Thị xã Duy Tiên (Chùa Long Đọi Sơn - Đồng Văn), Hà Nam",
            "Thị xã Kim Bảng (Khu du lịch Chùa Tam Chúc - Ba Sao), Hà Nam",
            "Huyện Bình Lục, Hà Nam",
            "Huyện Lý Nhân (Làng Vũ Đại - Đền Trần Thương), Hà Nam",
            "Huyện Thanh Liêm (Chùa Địa Tạng Phi Lai Tự), Hà Nam"
        ),
        "Nam Định" to listOf(
            "Thành phố Nam Định (Đền Trần - Chùa Phổ Minh - Mỹ Lộc), Nam Định",
            "Huyện Giao Thủy (Vườn Quốc gia Xuân Thủy - Biển Quất Lâm), Nam Định",
            "Huyện Hải Hậu (Biển Thịnh Long - Nhà thờ đổ Hải Lý), Nam Định",
            "Huyện Nghĩa Hưng (Mũi Rạng Đông), Nam Định",
            "Huyện Nam Trực (Chùa Cổ Lễ), Nam Định",
            "Huyện Trực Ninh, Nam Định",
            "Huyện Vụ Bản (Phủ Dầy - Chợ Viềng), Nam Định",
            "Huyện Xuân Trường (Chùa Keo Hành Thiện - Phú Nhai), Nam Định",
            "Huyện Ý Yên (Làng đúc đồng Tống Xá), Nam Định"
        ),
        "Ninh Bình" to listOf(
            "Thành phố Hoa Lư (TP. Ninh Bình - Cố đô Hoa Lư - Tràng An - Tam Cốc), Ninh Bình",
            "Xã Ninh Xuân (Hang Múa - Tuyệt Tình Cốc), Thành phố Hoa Lư, Ninh Bình",
            "Thành phố Tam Điệp (Đồi Dứa Tam Điệp), Ninh Bình",
            "Huyện Gia Viễn (Chùa Bái Đính - Đầm Vân Long - Khoáng nóng Kênh Gà), Ninh Bình",
            "Huyện Nho Quan (Vườn Quốc gia Cúc Phương - Hồ Đồng Chương), Ninh Bình",
            "Huyện Kim Sơn (Nhà thờ đá Phát Diệm - Biển Cồn Nổi), Ninh Bình",
            "Huyện Yên Khánh, Ninh Bình",
            "Huyện Yên Mô (Hồ Đồng Thái), Ninh Bình"
        ),
        "Thanh Hóa" to listOf(
            "Thành phố Thanh Hóa (Đông Sơn - Hàm Rồng), Thanh Hóa",
            "Thành phố Sầm Sơn (Biển Sầm Sơn), Thanh Hóa",
            "Thị xã Bỉm Sơn (Đèo Ba Dội), Thanh Hóa",
            "Thị xã Nghi Sơn (Biển Hải Hòa - Đảo Hòn Mê), Thanh Hóa",
            "Khu bảo tồn Pù Luông - Bản Son Bá Mười, Huyện Bá Thước, Thanh Hóa",
            "Huyện biên giới Mường Lát (Cửa khẩu Tén Tằn - Sài Khao), Thanh Hóa",
            "Huyện Quan Hóa (Hồi Xuân - Phú Lệ), Thanh Hóa",
            "Huyện Quan Sơn (Cửa khẩu Quốc tế Na Mèo - Động Bo Cúng), Thanh Hóa",
            "Huyện Lang Chánh (Thác Ma Hao - Yên Khương), Thanh Hóa",
            "Huyện Ngọc Lặc, Thanh Hóa",
            "Huyện Cẩm Thủy (Suối cá thần Cẩm Lương), Thanh Hóa",
            "Huyện Thạch Thành (Thác Mây - Thác Voi), Thanh Hóa",
            "Huyện Thường Xuân (Khu bảo tồn Xuân Liên - Bát Mọt - Hồ Cửa Đặt), Thanh Hóa",
            "Huyện Như Xuân (Thác Đồng Quan), Thanh Hóa",
            "Huyện Như Thanh (Vườn Quốc gia Bến En), Thanh Hóa",
            "Huyện Hoằng Hóa (Biển Hải Tiến), Thanh Hóa",
            "Huyện Quảng Xương (Biển Tiên Trang), Thanh Hóa",
            "Huyện Hậu Lộc (Đảo Hòn Nẹ), Thanh Hóa",
            "Huyện Nga Sơn (Động Từ Thức - Chiếu Nga Sơn), Thanh Hóa",
            "Huyện Hà Trung (Đền Hàn Sơn), Thanh Hóa",
            "Huyện Vĩnh Lộc (Di sản Thành nhà Hồ), Thanh Hóa",
            "Huyện Yên Định, Thanh Hóa",
            "Huyện Thiệu Hóa, Thanh Hóa",
            "Huyện Đông Sơn (Di tích Văn hóa Đông Sơn), Thanh Hóa",
            "Huyện Thọ Xuân (Khu di tích Lam Kinh - Sân bay Thọ Xuân), Thanh Hóa",
            "Huyện Triệu Sơn, Thanh Hóa",
            "Huyện Nông Cống, Thanh Hóa"
        ),
        "Nghệ An" to listOf(
            "Thành phố Vinh (Quảng trường Hồ Chí Minh), Nghệ An",
            "Thị xã Cửa Lò (Biển Cửa Lò - Đảo Hòn Ngư), Nghệ An",
            "Thị xã Hoàng Mai (Đền Cờn - Biển Quỳnh Phương), Nghệ An",
            "Thị xã Thái Hòa (Khu di tích Làng Vạc), Nghệ An",
            "Huyện Nam Đàn (Khu di tích Kim Liên - Quê Bác), Nghệ An",
            "Huyện biên giới Kỳ Sơn (Thị trấn Mường Xén - Cửa khẩu Nậm Cắn - Mường Lống), Nghệ An",
            "Huyện Tương Dương (Rừng săng lẻ Tam Đình - Thạch Giám), Nghệ An",
            "Huyện Con Cuông (Vườn Quốc gia Pù Mát - Thác Kèm), Nghệ An",
            "Huyện Quế Phong (Thác Sao Va - Cửa khẩu Thông Thụ - Tri Lễ), Nghệ An",
            "Huyện Quỳ Châu (Hang Bua - Khu bảo tồn Pù Huống), Nghệ An",
            "Huyện Quỳ Hợp, Nghệ An",
            "Huyện Thanh Chương (Đảo chè Thanh Chương - Cửa khẩu Thanh Thủy), Nghệ An",
            "Huyện Anh Sơn, Nghệ An",
            "Huyện Đô Lương (Truông Bồn), Nghệ An",
            "Huyện Tân Kỳ (Cột mốc Km0 Đường mòn Hồ Chí Minh), Nghệ An",
            "Huyện Nghĩa Đàn (Cánh đồng hoa hướng dương Nghĩa Đàn), Nghệ An",
            "Huyện Quỳnh Lưu (Biển Quỳnh), Nghệ An",
            "Huyện Diễn Châu (Biển Diễn Thành - Đền Cuông), Nghệ An",
            "Huyện Yên Thành, Nghệ An",
            "Huyện Nghi Lộc (Biển Bãi Lữ), Nghệ An",
            "Huyện Hưng Nguyên (Đền Ông Hoàng Mười), Nghệ An"
        ),
        "Hà Tĩnh" to listOf(
            "Thành phố Hà Tĩnh, Hà Tĩnh",
            "Thị xã Hồng Lĩnh (Chùa Đại Hùng), Hà Tĩnh",
            "Thị xã Kỳ Anh (Cảng Vũng Áng - Đèo Ngang - Đảo Sơn Dương), Hà Tĩnh",
            "Huyện Hương Sơn (Cửa khẩu Quốc tế Cầu Treo - Nước sốt Sơn Kim), Hà Tĩnh",
            "Huyện Hương Khê (Bưởi Phúc Trạch - Hương Vĩnh), Hà Tĩnh",
            "Huyện Vũ Quang (Vườn Quốc gia Vũ Quang - Hồ Ngàn Trươi), Hà Tĩnh",
            "Huyện Nghi Xuân (Biển Xuân Thành - Khu di tích Nguyễn Du), Hà Tĩnh",
            "Huyện Can Lộc (Chùa Hương Tích - Ngã ba Đồng Lộc), Hà Tĩnh",
            "Huyện Thạch Hà (Biển Thạch Hải - Lộc Hà), Hà Tĩnh",
            "Huyện Cẩm Xuyên (Biển Thiên Cầm - Hồ Kẻ Gỗ), Hà Tĩnh",
            "Huyện Đức Thọ (Bến Tam Soa), Hà Tĩnh",
            "Huyện Kỳ Anh (Biển Kỳ Xuân), Hà Tĩnh",
            "Huyện Lộc Hà (Biển Xuân Hải), Hà Tĩnh"
        ),
        "Quảng Bình" to listOf(
            "Thành phố Đồng Hới (Biển Nhật Lệ - Bảo Ninh - Đồi cát Quang Phú), Quảng Bình",
            "Thị xã Ba Đồn, Quảng Bình",
            "Vườn Quốc gia Phong Nha - Kẻ Bàng (Động Phong Nha - Động Thiên Đường), Huyện Bố Trạch, Quảng Bình",
            "Bản Đoòng - Hang Sơn Đoòng (Xã Tân Trạch), Huyện Bố Trạch, Quảng Bình",
            "Huyện vùng cao Minh Hóa (Làng Tân Hóa - Hệ thống hang Tú Làn - Cửa khẩu Cha Lo), Quảng Bình",
            "Huyện Tuyên Hóa (Đồng Lê), Quảng Bình",
            "Huyện Quảng Trạch (Vũng Chùa - Đảo Yến - Đèo Ngang), Quảng Bình",
            "Huyện Quảng Ninh (Núi Thần Đinh - Xã biên giới Trường Sơn), Quảng Bình",
            "Huyện Lệ Thủy (Suối khoáng nóng Bang - Nhà lưu niệm Đại tướng Võ Nguyên Giáp), Quảng Bình"
        ),
        "Quảng Trị" to listOf(
            "Thành phố Đông Hà, Quảng Trị",
            "Thị xã Quảng Trị (Thành cổ Quảng Trị), Quảng Trị",
            "Huyện đảo Cồn Cỏ, Quảng Trị",
            "Thị trấn Khe Sanh - Cửa khẩu Quốc tế Lao Bảo, Huyện Hướng Hóa, Quảng Trị",
            "Đèo Sa Mù - Xã Hướng Phùng - Hướng Việt, Huyện Hướng Hóa, Quảng Trị",
            "Huyện vùng cao Đakrông (Cửa khẩu Quốc tế La Lay - Cầu treo Đakrông), Quảng Trị",
            "Huyện Vĩnh Linh (Địa đạo Vịnh Mốc - Cầu Hiền Lương - Biển Cửa Tùng), Quảng Trị",
            "Huyện Gio Linh (Biển Cửa Việt - Nghĩa trang Trường Sơn), Quảng Trị",
            "Huyện Cam Lộ, Quảng Trị",
            "Huyện Triệu Phong, Quảng Trị",
            "Huyện Hải Lăng (Thánh địa La Vang - Biển Mỹ Thủy), Quảng Trị"
        ),
        "Thừa Thiên Huế" to listOf(
            "Phường Vĩnh Ninh, Quận Thuận Hóa, Thành phố Huế, Thừa Thiên Huế",
            "Quận Phú Xuân (Kinh thành Đại Nội Huế - Chùa Thiên Mụ), Thành phố Huế, Thừa Thiên Huế",
            "Thị xã Hương Thủy (Sân bay Quốc tế Phú Bài - Cầu ngói Thanh Toàn), Thừa Thiên Huế",
            "Thị xã Hương Trà (Rừng ngập mặn Rú Chá), Thừa Thiên Huế",
            "Thị xã Phong Điền (Làng cổ Phước Tích), Thừa Thiên Huế",
            "Huyện vùng cao A Lưới (Đèo Pê Ke - Rừng A Roàng - Cửa khẩu Hồng Vân), Thừa Thiên Huế",
            "Huyện Phú Lộc (Vịnh Lăng Cô - Vườn Quốc gia Bạch Mã - Đèo Hải Vân), Thừa Thiên Huế",
            "Huyện vùng cao Nam Đông (Khe Tre - Thác Mơ), Thừa Thiên Huế",
            "Huyện Phú Vang (Biển Thuận An - Phá Tam Giang), Thừa Thiên Huế",
            "Huyện Quảng Điền (Đầm Quảng Lợi - Phá Tam Giang), Thừa Thiên Huế"
        ),
        "Quảng Nam" to listOf(
            "Thành phố Tam Kỳ (Biển Tam Thanh - Làng bích họa), Quảng Nam",
            "Phố cổ Hội An (Phường Minh An - Cẩm Châu - Biển An Bàng), Thành phố Hội An, Quảng Nam",
            "Đảo Cù Lao Chàm (Xã đảo Tân Hiệp), Thành phố Hội An, Quảng Nam",
            "Thị xã Điện Bàn (Vĩnh Điện - Điện Dương), Quảng Nam",
            "Huyện vùng cao Tây Giang (Đỉnh Quế - Rừng Pơmu - A Nông), Quảng Nam",
            "Huyện Đông Giang (Cổng trời Đông Giang - Thị trấn Prao), Quảng Nam",
            "Huyện Nam Giang (Cửa khẩu Quốc tế Nam Giang - Thạnh Mỹ), Quảng Nam",
            "Huyện Phước Sơn (Khâm Đức - Đèo Lò Xo), Quảng Nam",
            "Huyện Bắc Trà My (Thủy điện Sông Tranh), Quảng Nam",
            "Huyện Nam Trà My (Xã Trà Linh - Đỉnh Sâm Ngọc Linh - Tắk Pổ), Quảng Nam",
            "Huyện Duy Xuyên (Di sản Thánh địa Mỹ Sơn - Nam Phước), Quảng Nam",
            "Huyện Đại Lộc (Ái Nghĩa - Khe Lim), Quảng Nam",
            "Huyện Thăng Bình (Hà Lam - Biển Bình Minh), Quảng Nam",
            "Huyện Quế Sơn (Đông Phú - Hòn Kẽm Đá Dừng - Nông Sơn), Quảng Nam",
            "Huyện Nông Sơn (Làng Đại Bình - Quế Trung), Quảng Nam",
            "Huyện Hiệp Đức, Quảng Nam",
            "Huyện Tiên Phước (Làng cổ Lộc Yên), Quảng Nam",
            "Huyện Phú Ninh (Hồ Phú Ninh), Quảng Nam",
            "Huyện Núi Thành (Sân bay Chu Lai - Xã đảo Tam Hải - Biển Rạng), Quảng Nam"
        ),
        "Quảng Ngãi" to listOf(
            "Thành phố Quảng Ngãi (Biển Mỹ Khê - Núi Thiên Ấn), Quảng Ngãi",
            "Thị xã Đức Phổ (Biển Sa Huỳnh), Quảng Ngãi",
            "Huyện đảo Lý Sơn (Đảo Lớn & Đảo Bé An Bình), Quảng Ngãi",
            "Huyện Bình Sơn (Khu kinh tế Dung Quất - Gành Yến), Quảng Ngãi",
            "Huyện vùng cao Trà Bồng (Đỉnh Cà Đam - Quế Trà Bồng), Quảng Ngãi",
            "Huyện Sơn Hà (Thị trấn Di Lăng), Quảng Ngãi",
            "Huyện Sơn Tây (Xã Sơn Mùa - Ngàn cần câu), Quảng Ngãi",
            "Huyện Ba Tơ (Thảo nguyên Bùi Hui - Đèo Vi Ô Lắc), Quảng Ngãi",
            "Huyện Minh Long (Thác Trắng Minh Long), Quảng Ngãi",
            "Huyện Sơn Tịnh, Quảng Ngãi",
            "Huyện Tư Nghĩa, Quảng Ngãi",
            "Huyện Nghĩa Hành, Quảng Ngãi",
            "Huyện Mộ Đức (Biển Minh Tân), Quảng Ngãi"
        ),
        "Bình Định" to listOf(
            "Thành phố Quy Nhơn (Ghềnh Ráng - Tháp Đôi), Bình Định",
            "Kỳ Co - Eo Gió (Xã Nhơn Lý), Thành phố Quy Nhơn, Bình Định",
            "Đảo Hòn Khô (Xã Nhơn Hải), Thành phố Quy Nhơn, Bình Định",
            "Đảo Cù Lao Xanh (Xã đảo Nhơn Châu), Thành phố Quy Nhơn, Bình Định",
            "Thị xã An Nhơn (Thành Đồ Bàn - Bầu Đá), Bình Định",
            "Thị xã Hoài Nhơn (Biển Tam Quan - Bồng Sơn), Bình Định",
            "Huyện vùng cao An Lão (Cao nguyên An Toàn), Bình Định",
            "Huyện vùng cao Vĩnh Thạnh (Xã Vĩnh Sơn - Thành cổ Tà Kơn), Bình Định",
            "Huyện vùng cao Vân Canh (Làng Canh Liên), Bình Định",
            "Huyện Tây Sơn (Bảo tàng Quang Trung - Hầm Hô), Bình Định",
            "Huyện Phù Cát (Biển Trung Lương - Chùa Ông Núi - Sân bay Phù Cát), Bình Định",
            "Huyện Phù Mỹ (Mũi Vi Rồng - Đầm Trà Ổ), Bình Định",
            "Huyện Tuy Phước (Tháp Bánh Ít - Tiểu chủng viện Làng Sông), Bình Định",
            "Huyện Hoài Ân, Bình Định"
        ),
        "Phú Yên" to listOf(
            "Thành phố Tuy Hòa (Tháp Nhạn - Tháp Nghinh Phong), Phú Yên",
            "Thị xã Đông Hòa (Mũi Điện Đại Lãnh - Vịnh Vũng Rô - Đảo Hòn Nưa), Phú Yên",
            "Thị xã Sông Cầu (Vịnh Xuân Đài - Đảo Nhất Tự Sơn), Phú Yên",
            "Huyện Tuy An (Gành Đá Đĩa - Bãi Xép - Đảo Hòn Yến - Cù Lao Mái Nhà), Phú Yên",
            "Huyện vùng cao Sơn Hòa (Cao nguyên Vân Hòa), Phú Yên",
            "Huyện vùng cao Sông Hinh (Hồ thủy điện Sông Hinh), Phú Yên",
            "Huyện vùng cao Đồng Xuân (Suối nước nóng Trà Ô), Phú Yên",
            "Huyện Phú Hòa, Phú Yên",
            "Huyện Tây Hòa, Phú Yên"
        ),
        "Khánh Hòa" to listOf(
            "Phường Lộc Thọ (Quảng trường 2/4), Thành phố Nha Trang, Khánh Hòa",
            "Đảo Hòn Tre - Đảo Hòn Mun - Đảo Yến, Thành phố Nha Trang, Khánh Hòa",
            "Thành phố Cam Ranh (Đảo Bình Ba - Đảo Bình Hưng - Bình Lập), Khánh Hòa",
            "Thị xã Ninh Hòa (Biển Dốc Lết - Đảo Hoa Lan - Đảo Khỉ), Khánh Hòa",
            "Huyện đảo Trường Sa (Thị trấn Trường Sa - Sinh Tồn - Song Tử Tây), Khánh Hòa",
            "Huyện Vạn Ninh (Vịnh Vân Phong - Đảo Điệp Sơn - Mũi Đôi Cực Đông), Khánh Hòa",
            "Huyện vùng cao Khánh Sơn (Thị trấn Tô Hạp - Thác Tà Gụ), Khánh Hòa",
            "Huyện vùng cao Khánh Vĩnh (Đèo Khánh Lê - Yang Bay), Khánh Hòa",
            "Huyện Cam Lâm (Bãi Dài Cam Ranh - Đầm Thủy Triều), Khánh Hòa",
            "Huyện Diên Khánh (Thành cổ Diên Khánh), Khánh Hòa"
        ),
        "Ninh Thuận" to listOf(
            "Thành phố Phan Rang - Tháp Chàm (Biển Bình Sơn - Tháp Po Klong Garai), Ninh Thuận",
            "Vịnh Vĩnh Hy - Hang Rái (Xã Vĩnh Hải), Huyện Ninh Hải, Ninh Thuận",
            "Vườn Quốc gia Núi Chúa, Huyện Ninh Hải, Ninh Thuận",
            "Huyện Ninh Phước (Đồi cát Nam Cương - Làng gốm Bàu Trúc), Ninh Thuận",
            "Huyện Thuận Nam (Mũi Dinh - Cà Ná - Cánh đồng điện gió Đầm Nại), Ninh Thuận",
            "Huyện Thuận Bắc (Đồng cừu An Hòa - Suối Tiên), Ninh Thuận",
            "Huyện Ninh Sơn (Đèo Ngoạn Mục - Sông Pha), Ninh Thuận",
            "Huyện vùng cao Bác Ái (Vườn Quốc gia Phước Bình), Ninh Thuận"
        ),
        "Bình Thuận" to listOf(
            "Thành phố Phan Thiết (Mũi Né - Hòn Rơm - Đồi Cát Bay), Bình Thuận",
            "Thị xã La Gi (Dinh Thầy Thím - Đảo Hòn Bà), Bình Thuận",
            "Huyện đảo Phú Quý (Cù Lao Thu - Đảo Hòn Tranh), Bình Thuận",
            "Huyện Bắc Bình (Khu du lịch Bàu Trắng - Chợ Lầu), Bình Thuận",
            "Huyện Tuy Phong (Bãi đá 7 màu Cổ Thạch - Đảo Cù Lao Câu), Bình Thuận",
            "Huyện Hàm Thuận Bắc (Hồ Đa Mi), Bình Thuận",
            "Huyện Hàm Thuận Nam (Hải đăng Mũi Kê Gà - Núi Tà Cú), Bình Thuận",
            "Huyện Hàm Tân (Biển Hồ Cốc - Cam Bình), Bình Thuận",
            "Huyện Tánh Linh (Thác Bà - Hồ Biển Lạc), Bình Thuận",
            "Huyện Đức Linh (Võ Xu - Đức Tài), Bình Thuận"
        ),
        "Kon Tum" to listOf(
            "Thành phố Kon Tum (Nhà thờ Gỗ - Cầu treo Kon Klor), Kon Tum",
            "Thị trấn Măng Đen (Hồ Đăk Ke - Thác Pa Sỹ), Huyện Kon Plông, Kon Tum",
            "Cửa khẩu Quốc tế Bờ Y (Ngã ba Đông Dương), Huyện Ngọc Hồi, Kon Tum",
            "Huyện vùng cao Đắk Glei (Thị trấn Đắk Pék - Đèo Lò Xo), Kon Tum",
            "Huyện vùng cao Tu Mơ Rông (Đỉnh Ngọc Linh - Xã Măng Ri), Kon Tum",
            "Huyện biên giới Ia H'Drai (Lòng hồ Sê San 4), Kon Tum",
            "Huyện biên giới Sa Thầy (Vườn Quốc gia Chư Mom Ray), Kon Tum",
            "Huyện Đắk Hà (Cà phê Đắk Hà), Kon Tum",
            "Huyện Đắk Tô (Chiến thắng Đắk Tô - Tân Cảnh), Kon Tum",
            "Huyện Kon Rẫy, Kon Tum"
        ),
        "Gia Lai" to listOf(
            "Thành phố Pleiku (Biển Hồ T'Nưng - Quảng trường Đại Đoàn Kết), Gia Lai",
            "Thị xã An Khê (Đèo An Khê - Tây Sơn Thượng Đạo), Gia Lai",
            "Thị xã Ayun Pa, Gia Lai",
            "Huyện vùng cao Kbang (Khu bảo tồn Kon Chư Răng - Thác K50), Gia Lai",
            "Huyện Chư Păh (Núi lửa Chư Đăng Ya - Biển Hồ Chè - Thủy điện Ia Ly), Gia Lai",
            "Huyện biên giới Chư Prông (Ia Mơ - Ia Lâu), Gia Lai",
            "Huyện biên giới Đức Cơ (Cửa khẩu Quốc tế Lệ Thanh), Gia Lai",
            "Huyện biên giới Ia Grai (Thác Mơ - Ia O), Gia Lai",
            "Huyện Chư Sê (Thác Phú Cường), Gia Lai",
            "Huyện Chư Pưh, Gia Lai",
            "Huyện Đak Đoa (Đồi thông Đak Đoa - Sân golf Đak Đoa), Gia Lai",
            "Huyện Đak Pơ, Gia Lai",
            "Huyện Ia Pa, Gia Lai",
            "Huyện Krông Pa (Phú Túc), Gia Lai",
            "Huyện Kông Chro, Gia Lai",
            "Huyện Mang Yang (Vườn Quốc gia Kon Ka Kinh - Đèo Mang Yang), Gia Lai",
            "Huyện Phú Thiện (Hồ Ayun Hạ), Gia Lai"
        ),
        "Đắk Lắk" to listOf(
            "Thành phố Buôn Ma Thuột (Ngã Sáu - Bảo tàng Thế giới Cà phê), Đắk Lắk",
            "Thị xã Buôn Hồ, Đắk Lắk",
            "Huyện Buôn Đôn (Vườn Quốc gia Yok Đôn - Cầu treo Buôn Đôn), Đắk Lắk",
            "Huyện biên giới Ea Súp (Tháp Chăm Yang Prong - Cửa khẩu Đắk Ruê), Đắk Lắk",
            "Huyện Lắk (Hồ Lắk - Biệt điện Bảo Đại - Đỉnh Chư Yang Lắk), Đắk Lắk",
            "Huyện Krông Bông (Vườn Quốc gia Chư Yang Sin - Đá Voi Mẹ), Đắk Lắk",
            "Huyện Ea H'leo (Cánh đồng điện gió Ea Nam), Đắk Lắk",
            "Huyện Ea Kar, Đắk Lắk",
            "Huyện Cư M'gar (Chùa Hoa Nghiêm - Quảng Phú), Đắk Lắk",
            "Huyện Cư Kuin, Đắk Lắk",
            "Huyện Krông Ana (Thác Đray Nur - Thác Gia Long), Đắk Lắk",
            "Huyện Krông Búk, Đắk Lắk",
            "Huyện Krông Năng (Thác Thủy Tiên), Đắk Lắk",
            "Huyện Krông Pắc (Thủ phủ Sầu riêng Phước An), Đắk Lắk",
            "Huyện M'Drắk (Đèo Phượng Hoàng - Khu du lịch sinh thái M'Drắk), Đắk Lắk"
        ),
        "Đắk Nông" to listOf(
            "Thành phố Gia Nghĩa, Đắk Nông",
            "Hồ Tà Đùng (Xã Đắk Som - Vịnh Hạ Long Tây Nguyên), Huyện Đắk Glong, Đắk Nông",
            "Huyện biên giới Tuy Đức (Quảng Trực - Thác Đắk G'lun - Cửa khẩu Bu Prăng), Đắk Nông",
            "Huyện biên giới Đắk Mil (Hồ Tây Đắk Mil - Cửa khẩu Thuận An), Đắk Nông",
            "Huyện biên giới Đắk Song (Thác Lưu Ly - Nâm N'Jang), Đắk Nông",
            "Huyện biên giới Cư Jút (Thác Trinh Nữ - Ea T'ling), Đắk Nông",
            "Huyện Krông Nô (Công viên Địa chất Hang động núi lửa Krông Nô - Thác Đray Sáp), Đắk Nông",
            "Huyện Đắk R'lấp (Kiến Đức), Đắk Nông"
        ),
        "Lâm Đồng" to listOf(
            "Phường 1 (Chợ Đà Lạt - Hồ Xuân Hương), Thành phố Đà Lạt, Lâm Đồng",
            "Xã Tà Nung (Đèo Tà Nung), Thành phố Đà Lạt, Lâm Đồng",
            "Đồi chè Cầu Đất (Xã Xuân Trường - Trại Mát), Thành phố Đà Lạt, Lâm Đồng",
            "Thành phố Bảo Lộc (Thác Đamb'ri - Đồi chè Tâm Châu), Lâm Đồng",
            "Huyện Lạc Dương (Đỉnh Langbiang - Hồ Suối Vàng - Đạ Chais), Lâm Đồng",
            "Huyện vùng cao Đam Rông (Suối nước nóng Đạ Long - Rô Men), Lâm Đồng",
            "Huyện Đơn Dương (Đồi thông Châu Sơn - Hồ Đa Nhim), Lâm Đồng",
            "Huyện Đức Trọng (Sân bay Liên Khương - Thác Pongour - Xã Tà Năng), Lâm Đồng",
            "Huyện Lâm Hà (Thác Voi - Chùa Linh Ẩn Nam Ban), Lâm Đồng",
            "Huyện Di Linh (Hồ Kala - Đèo Gia Bắc), Lâm Đồng",
            "Huyện Bảo Lâm (Chùa Linh Quy Pháp Ấn - Lộc Thành), Lâm Đồng",
            "Huyện Đạ Huoai (Đèo Bảo Lộc - Đạ Tẻh - Cát Tiên), Lâm Đồng",
            "Thị trấn Đạ Tẻh (Thác Triệu Hải), Huyện Đạ Huoai, Lâm Đồng",
            "Thị trấn Cát Tiên (Thánh địa Cát Tiên), Huyện Đạ Huoai, Lâm Đồng"
        ),
        "Bình Phước" to listOf(
            "Thành phố Đồng Xoài (Hồ Suối Cam), Bình Phước",
            "Thị xã Phước Long (Đỉnh Núi Bà Rá - Thác Mơ), Bình Phước",
            "Thị xã Bình Long, Bình Phước",
            "Thị xã Chơn Thành, Bình Phước",
            "Vườn Quốc gia Bù Gia Mập (Xã Đắk Ơ), Huyện biên giới Bù Gia Mập, Bình Phước",
            "Huyện biên giới Lộc Ninh (Cửa khẩu Quốc tế Hoa Lư - Căn cứ Tà Thiết), Bình Phước",
            "Huyện biên giới Bù Đốp (Cửa khẩu Hoàng Diệu - Thanh Bình), Bình Phước",
            "Huyện Bù Đăng (Trảng cỏ Bù Lạch - Sóc Bom Bo - Thác Đứng), Bình Phước",
            "Huyện Đồng Phú (Đảo Yến Sơn Hà), Bình Phước",
            "Huyện Hớn Quản, Bình Phước",
            "Huyện Phú Riềng, Bình Phước"
        ),
        "Tây Ninh" to listOf(
            "Thành phố Tây Ninh (Đỉnh Núi Bà Đen - Tòa Thánh Tây Ninh), Tây Ninh",
            "Thị xã Hòa Thành (Báo Quốc Từ), Tây Ninh",
            "Thị xã Trảng Bàng (Bánh canh Trảng Bàng), Tây Ninh",
            "Huyện biên giới Tân Biên (Vườn Quốc gia Lò Gò - Xa Mát - Cửa khẩu Xa Mát), Tây Ninh",
            "Huyện biên giới Tân Châu (Hồ Dầu Tiếng - Cửa khẩu Kà Tum), Tây Ninh",
            "Huyện biên giới Bến Cầu (Cửa khẩu Quốc tế Mộc Bài), Tây Ninh",
            "Huyện biên giới Châu Thành (Cửa khẩu Phước Tân), Tây Ninh",
            "Huyện Dương Minh Châu (Thung lũng Ma Thiên Lãnh), Tây Ninh",
            "Huyện Gò Dầu, Tây Ninh"
        ),
        "Bình Dương" to listOf(
            "Thành phố Thủ Dầu Một (Chùa Bà Thiên Hậu - Phú Cường), Bình Dương",
            "Thành phố Dĩ An (Hồ Đá Làng Đại học), Bình Dương",
            "Thành phố Thuận An (Lái Thiêu - AEON Mall), Bình Dương",
            "Thành phố Tân Uyên (Cù lao Bạch Đằng), Bình Dương",
            "Thành phố Bến Cát (Khu du lịch Đại Nam), Bình Dương",
            "Huyện Bàu Bàng, Bình Dương",
            "Huyện Bắc Tân Uyên (Đập Đá Bàn), Bình Dương",
            "Huyện Dầu Tiếng (Núi Cậu - Hồ Dầu Tiếng), Bình Dương",
            "Huyện Phú Giáo (Phước Vĩnh), Bình Dương"
        ),
        "Đồng Nai" to listOf(
            "Thành phố Biên Hòa (Khu du lịch Bửu Long - Cù lao Phố), Đồng Nai",
            "Thành phố Long Khánh (Vườn trái cây Long Khánh), Đồng Nai",
            "Vườn Quốc gia Cát Tiên (Xã Nam Cát Tiên), Huyện Tân Phú, Đồng Nai",
            "Huyện Vĩnh Cửu (Hồ Trị An - Đảo Ó Đồng Trường - Chiến khu D), Đồng Nai",
            "Huyện Định Quán (Đá Ba Chồng - Thác Mai), Đồng Nai",
            "Huyện Long Thành (Sân bay Quốc tế Long Thành), Đồng Nai",
            "Huyện Nhơn Trạch (Làng du lịch Tre Việt), Đồng Nai",
            "Huyện Trảng Bom (Thác Giang Điền), Đồng Nai",
            "Huyện Thống Nhất (Dầu Giây), Đồng Nai",
            "Huyện Cẩm Mỹ, Đồng Nai",
            "Huyện Xuân Lộc (Đỉnh Núi Chứa Chan - Gia Lào), Đồng Nai"
        ),
        "Bà Rịa - Vũng Tàu" to listOf(
            "Phường Thắng Tam (Bãi Sau), Thành phố Vũng Tàu, Bà Rịa - Vũng Tàu",
            "Phường 1 (Bãi Trước - Mũi Nghinh Phong), Thành phố Vũng Tàu, Bà Rịa - Vũng Tàu",
            "Xã đảo Long Sơn, Thành phố Vũng Tàu, Bà Rịa - Vũng Tàu",
            "Thành phố Bà Rịa, Bà Rịa - Vũng Tàu",
            "Thị xã Phú Mỹ (Cảng Cái Mép - Núi Dinh), Bà Rịa - Vũng Tàu",
            "Huyện đảo Côn Đảo (Đảo Côn Sơn - Hòn Bảy Cạnh), Bà Rịa - Vũng Tàu",
            "Huyện Xuyên Mộc (Biển Hồ Tràm - Hồ Cốc - Suối nước nóng Bình Châu), Bà Rịa - Vũng Tàu",
            "Huyện Long Đất (Biển Long Hải - Phước Hải - Đèo Nước Ngọt - Minh Đạm), Bà Rịa - Vũng Tàu",
            "Huyện Long Điền (Biển Long Hải), Bà Rịa - Vũng Tàu",
            "Huyện Đất Đỏ (Biển Phước Hải), Bà Rịa - Vũng Tàu",
            "Huyện Châu Đức (Đồi cừu Suối Nghệ), Bà Rịa - Vũng Tàu"
        ),
        "Long An" to listOf(
            "Thành phố Tân An, Long An",
            "Thị xã biên giới Kiến Tường (Đồng Tháp Mười - Cửa khẩu Quốc tế Bình Hiệp), Long An",
            "Huyện biên giới Mộc Hóa (Làng nổi Tân Lập), Long An",
            "Huyện biên giới Tân Hưng, Long An",
            "Huyện biên giới Vĩnh Hưng, Long An",
            "Huyện biên giới Đức Huệ (Cửa khẩu Mỹ Quý Tây), Long An",
            "Huyện Đức Hòa (Làng cổ Phước Lộc Thọ), Long An",
            "Huyện Bến Lức (Khu du lịch Happy Land), Long An",
            "Huyện Cần Đước (Đồn Rạch Cát - Gạo Nàng Thơm Chợ Đào), Long An",
            "Huyện Cần Giuộc (Cảng Quốc tế Long An), Long An",
            "Huyện Châu Thành (Thanh long Tầm Vu), Long An",
            "Huyện Tân Trụ (Con đường Hàng Cau Vua), Long An",
            "Huyện Thủ Thừa, Long An",
            "Huyện Thạnh Hóa, Long An",
            "Huyện Tân Thạnh, Long An"
        ),
        "Tiền Giang" to listOf(
            "Thành phố Mỹ Tho (Chùa Vĩnh Tràng - Cù lao Thới Sơn), Tiền Giang",
            "Thành phố Gò Công (Biển Tân Thành - Lăng Hoàng Gia), Tiền Giang",
            "Thị xã Cai Lậy, Tiền Giang",
            "Huyện Cái Bè (Chợ nổi Cái Bè - Làng cổ Đông Hòa Hiệp), Tiền Giang",
            "Huyện Cai Lậy (Cù lao Tân Phong), Tiền Giang",
            "Huyện Châu Thành (Trại rắn Đồng Tâm), Tiền Giang",
            "Huyện Chợ Gạo, Tiền Giang",
            "Huyện Gò Công Tây, Tiền Giang",
            "Huyện Gò Công Đông (Biển Tân Thành), Tiền Giang",
            "Huyện Tân Phú Đông (Huyện cù lao Tân Phú Đông), Tiền Giang",
            "Huyện Tân Phước (Thiền viện Trúc Lâm Chánh Giác), Tiền Giang"
        ),
        "Bến Tre" to listOf(
            "Thành phố Bến Tre, Bến Tre",
            "Huyện biển Bình Đại (Biển Thừa Đức), Bến Tre",
            "Huyện biển Ba Tri (Sân chim Vàm Hồ - Khu mộ Nguyễn Đình Chiểu), Bến Tre",
            "Huyện biển Thạnh Phú (Biển Cồn Bửng), Bến Tre",
            "Huyện Châu Thành (Khu du lịch Cồn Phụng - Cồn Quy), Bến Tre",
            "Huyện Chợ Lách (Làng hoa kiểng Chợ Lách - Cái Mơn), Bến Tre",
            "Huyện Giồng Trôm (Đền thờ Nữ tướng Nguyễn Thị Định), Bến Tre",
            "Huyện Mỏ Cày Bắc, Bến Tre",
            "Huyện Mỏ Cày Nam (Làng nghề Kẹo dừa Mỏ Cày), Bến Tre"
        ),
        "Trà Vinh" to listOf(
            "Thành phố Trà Vinh (Ao Bà Om - Chùa Âng), Trà Vinh",
            "Thị xã Duyên Hải (Biển Ba Động - Điện gió Duyên Hải), Trà Vinh",
            "Huyện Càng Long, Trà Vinh",
            "Huyện Cầu Kè (Cù lao Tân Quy), Trà Vinh",
            "Huyện Cầu Ngang, Trà Vinh",
            "Huyện Châu Thành (Chùa Hang - Cồn Chim), Trà Vinh",
            "Huyện Duyên Hải (Rừng ngập mặn Long Khánh), Trà Vinh",
            "Huyện Tiểu Cần, Trà Vinh",
            "Huyện Trà Cú (Chùa Cò - Đại An), Trà Vinh"
        ),
        "Vĩnh Long" to listOf(
            "Thành phố Vĩnh Long (Cầu Mỹ Thuận), Vĩnh Long",
            "Thị xã Bình Minh (Cầu Cần Thơ), Vĩnh Long",
            "Huyện Long Hồ (Cù lao An Bình), Vĩnh Long",
            "Huyện Mang Thít (Vương quốc Đỏ gạch gốm Mang Thít), Vĩnh Long",
            "Huyện Vũng Liêm (Khu tưởng niệm Võ Văn Kiệt), Vĩnh Long",
            "Huyện Tam Bình, Vĩnh Long",
            "Huyện Trà Ôn (Chợ nổi Trà Ôn - Cù lao Mây), Vĩnh Long",
            "Huyện Bình Tân (Khoai lang Bình Tân), Vĩnh Long"
        ),
        "Đồng Tháp" to listOf(
            "Thành phố Cao Lãnh (Khu di tích Nguyễn Sinh Sắc), Đồng Tháp",
            "Thành phố Sa Đéc (Làng hoa Sa Đéc - Nhà cổ Huỳnh Thủy Lê), Đồng Tháp",
            "Thành phố Hồng Ngự (Tượng đài Cá Tra), Đồng Tháp",
            "Huyện Tam Nông (Vườn Quốc gia Tràm Chim), Đồng Tháp",
            "Huyện Tháp Mười (Khu du lịch Đồng sen Tháp Mười - Gò Tháp), Đồng Tháp",
            "Huyện biên giới Tân Hồng (Cửa khẩu Quốc tế Dinh Bà), Đồng Tháp",
            "Huyện biên giới Hồng Ngự (Cửa khẩu Quốc tế Thường Phước - Làng dệt Long Khánh), Đồng Tháp",
            "Huyện Cao Lãnh (Khu di tích Xẻo Quýt - Chợ quê Tân Thuận Đông), Đồng Tháp",
            "Huyện Châu Thành, Đồng Tháp",
            "Huyện Lai Vung (Vườn quýt hồng Lai Vung), Đồng Tháp",
            "Huyện Lấp Vò (Chợ chiếu Định Yên), Đồng Tháp",
            "Huyện Thanh Bình (Khu du lịch sinh thái Gáo Giồng), Đồng Tháp"
        ),
        "An Giang" to listOf(
            "Thành phố Long Xuyên (Khu lưu niệm Chủ tịch Tôn Đức Thắng - Cù lao Ông Hổ), An Giang",
            "Thành phố biên giới Châu Đốc (Miếu Bà Chúa Xứ Núi Sam - Làng Chăm Châu Phong), An Giang",
            "Thị xã biên giới Tân Châu (Làng lụa Tân Châu - Cửa khẩu Vĩnh Xương), An Giang",
            "Thị xã biên giới Tịnh Biên (Đỉnh Núi Cấm - Rừng tràm Trà Sư - Cửa khẩu Tịnh Biên), An Giang",
            "Huyện vùng cao Tri Tôn (Hồ Tà Pạ - Núi Cô Tô - Cây thốt nốt trái tim), An Giang",
            "Huyện biên giới An Phú (Búng Bình Thiên - Cửa khẩu Khánh Bình), An Giang",
            "Huyện Châu Phú, An Giang",
            "Huyện Châu Thành, An Giang",
            "Huyện Chợ Mới (Cù lao Giêng - Cù lao Ông Chưởng), An Giang",
            "Huyện Phú Tân (Thánh địa Hòa Hảo), An Giang",
            "Huyện Thoại Sơn (Khu di tích văn hóa Óc Eo - Núi Sập), An Giang"
        ),
        "Kiên Giang" to listOf(
            "Thành phố Rạch Giá (Khu lấn biển Rạch Giá - Đền Nguyễn Trung Trực), Kiên Giang",
            "Thành phố đảo Phú Quốc (Dương Đông - An Thới - Gành Dầu - Hàm Ninh), Kiên Giang",
            "Quần đảo Thổ Châu (Xã đảo Thổ Châu), Thành phố Phú Quốc, Kiên Giang",
            "Thành phố biên giới Hà Tiên (Mũi Nai - Thạch Động - Quần đảo Hải Tặc), Kiên Giang",
            "Quần đảo Nam Du (Xã An Sơn - Xã Nam Du), Huyện Kiên Hải, Kiên Giang",
            "Đảo Hòn Sơn (Xã Lại Sơn) - Đảo Hòn Tre, Huyện Kiên Hải, Kiên Giang",
            "Huyện Kiên Lương (Quần đảo Bà Lụa - Hòn Phụ Tử - Đảo Hòn Nghệ), Kiên Giang",
            "Huyện U Minh Thượng (Vườn Quốc gia U Minh Thượng), Kiên Giang",
            "Huyện biên giới Giang Thành, Kiên Giang",
            "Huyện Hòn Đất (Khu di tích Hòn Đất - Mộ Chị Sứ), Kiên Giang",
            "Huyện Châu Thành (Tắc Cậu), Kiên Giang",
            "Huyện Tân Hiệp, Kiên Giang",
            "Huyện Giồng Riềng, Kiên Giang",
            "Huyện Gò Quao, Kiên Giang",
            "Huyện An Biên (Thứ Ba), Kiên Giang",
            "Huyện An Minh (Thứ Mười Một), Kiên Giang",
            "Huyện Vĩnh Thuận, Kiên Giang"
        ),
        "Hậu Giang" to listOf(
            "Thành phố Vị Thanh (Công viên Xà No), Hậu Giang",
            "Thành phố Ngã Bảy (Chợ nổi Ngã Bảy Phụng Hiệp), Hậu Giang",
            "Thị xã Long Mỹ, Hậu Giang",
            "Huyện Phụng Hiệp (Khu bảo tồn thiên nhiên Lung Ngọc Hoàng), Hậu Giang",
            "Huyện Châu Thành, Hậu Giang",
            "Huyện Châu Thành A, Hậu Giang",
            "Huyện Vị Thủy (Rừng tràm Vị Thủy), Hậu Giang",
            "Huyện Long Mỹ (Đền thờ Bác Hồ), Hậu Giang"
        ),
        "Sóc Trăng" to listOf(
            "Thành phố Sóc Trăng (Chùa Dơi - Chùa Som Rong - Chùa Đất Sét), Sóc Trăng",
            "Thị xã Vĩnh Châu (Biển Hồ Bể - Cánh đồng điện gió Vĩnh Châu), Sóc Trăng",
            "Thị xã Ngã Năm (Chợ nổi Ngã Năm), Sóc Trăng",
            "Huyện Trần Đề (Cảng tàu cao tốc đi Côn Đảo - Biển Mỏ Ó), Sóc Trăng",
            "Huyện Cù Lao Dung (Rừng bần Cù Lao Dung), Sóc Trăng",
            "Huyện Châu Thành, Sóc Trăng",
            "Huyện Kế Sách (Cồn Mỹ Phước), Sóc Trăng",
            "Huyện Long Phú (Chùa Săng Kẻ), Sóc Trăng",
            "Huyện Mỹ Tú (Rừng tràm Mỹ Phước), Sóc Trăng",
            "Huyện Mỹ Xuyên (Chùa Chén Kiểu), Sóc Trăng",
            "Huyện Thạnh Trị, Sóc Trăng"
        ),
        "Bạc Liêu" to listOf(
            "Thành phố Bạc Liêu (Nhà Công tử Bạc Liêu - Cánh đồng điện gió Bạc Liêu - Chùa Xiêm Cán), Bạc Liêu",
            "Thị xã Giá Rai (Thánh đường Tắc Sậy), Bạc Liêu",
            "Huyện Đông Hải (Cửa biển Gành Hào), Bạc Liêu",
            "Huyện Hòa Bình (Điện gió Hòa Bình 1), Bạc Liêu",
            "Huyện Vĩnh Lợi (Đền thờ Bác Hồ - Tháp cổ Vĩnh Hưng), Bạc Liêu",
            "Huyện Phước Long, Bạc Liêu",
            "Huyện Hồng Dân (Khu căn cứ Cái Chanh), Bạc Liêu"
        ),
        "Cà Mau" to listOf(
            "Thành phố Cà Mau, Cà Mau",
            "Xã Đất Mũi (Mũi Cà Mau - Cột mốc Tọa độ GPS 0001 Cực Nam Tổ Quốc), Huyện Ngọc Hiển, Cà Mau",
            "Cụm đảo Hòn Khoai (Xã Tân Ân), Huyện Ngọc Hiển, Cà Mau",
            "Huyện Năm Căn (Thị trấn Năm Căn - Rừng ngập mặn Năm Căn), Cà Mau",
            "Huyện U Minh (Vườn Quốc gia U Minh Hạ - Biển Khánh Hội), Cà Mau",
            "Huyện Trần Văn Thời (Hòn Đá Bạc - Đảo Hòn Chuối - Sông Đốc), Cà Mau",
            "Huyện Cái Nước (Đầm Thị Tường), Cà Mau",
            "Huyện Đầm Dơi (Sân chim Đầm Dơi), Cà Mau",
            "Huyện Phú Tân (Cửa biển Cái Đôi Vàm), Cà Mau",
            "Huyện Thới Bình, Cà Mau"
        )
    )

    // Danh bạ tổng hợp toàn quốc (> 950 địa điểm từ thành thị tới vùng sâu vùng xa, biên giới & hải đảo)
    val standardLocations: List<String> by lazy {
        (remoteAndHighlandLocations + islandLocations + locationsByProvince.values.flatten()).distinct()
    }

    fun stripAccents(s: String): String {
        val normalized = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
        return normalized.replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace('đ', 'd')
    }

    /**
     * Lấy danh sách địa điểm theo bộ lọc Tỉnh/Vùng miền ("ALL", "REMOTE", "REMOTE_HIGHLAND", "ISLAND", "ISLANDS", hoặc tên Tỉnh/Thành phố)
     */
    fun getLocationsByCategory(category: String): List<String> {
        return when (category) {
            "ALL", "" -> standardLocations
            "REMOTE", "REMOTE_HIGHLAND" -> remoteAndHighlandLocations
            "ISLAND", "ISLANDS" -> islandLocations
            else -> {
                val provBase = locationsByProvince[category].orEmpty()
                val provNorm = stripAccents(category)
                val provRemote = remoteAndHighlandLocations.filter { loc ->
                    val afterLastComma = loc.substringAfterLast(",").trim()
                    stripAccents(afterLastComma).contains(provNorm)
                }
                val provIslands = islandLocations.filter { loc ->
                    val afterLastComma = loc.substringAfterLast(",").trim()
                    stripAccents(afterLastComma).contains(provNorm)
                }
                val combined = (provBase + provRemote + provIslands).distinct()
                if (combined.isNotEmpty()) combined else listOf("Thành phố / Tỉnh $category")
            }
        }
    }

    val featuredTopLocations: List<String> = listOf(
        "Phường Kim Mã, Quận Ba Đình, Hà Nội",
        "Phường Bến Nghé (Phố đi bộ Nguyễn Huệ), Quận 1, TP. Hồ Chí Minh",
        "Phường Hải Châu 1 (Cầu Rồng - Sông Hàn), Quận Hải Châu, Đà Nẵng",
        "Xã Lũng Cú (Cột cờ Cực Bắc), Huyện Đồng Văn, Hà Giang",
        "Đỉnh Fansipan (Nóc nhà Đông Dương) - Thị xã Sa Pa, Lào Cai",
        "Xã Y Tý (Thiên đường săn mây), Huyện Bát Xát, Lào Cai",
        "Xã Sín Thầu - A Pa Chải (Ngã ba biên giới Cực Tây Tổ Quốc), Huyện Mường Nhé, Điện Biên",
        "Xã Tà Xùa (Sống lưng khủng long - Săn mây Tà Xùa), Huyện Bắc Yên, Sơn La",
        "Xã La Pán Tẩn (Mâm xôi Mù Cang Chải), Huyện Mù Cang Chải, Yên Bái",
        "Thác Bản Giốc - Động Ngườm Ngao (Xã Đàm Thủy), Huyện Trùng Khánh, Cao Bằng",
        "Đỉnh Mẫu Sơn - Xã Mẫu Sơn, Huyện Lộc Bình, Lạng Sơn",
        "Thị trấn Măng Đen (Hồ Đăk Ke - Thác Pa Sỹ), Huyện Kon Plông, Kon Tum",
        "Phường 1 (Chợ Đà Lạt - Hồ Xuân Hương), Thành phố Đà Lạt, Lâm Đồng",
        "Quần đảo Hoàng Sa, Thành phố Đà Nẵng",
        "Quần đảo Trường Sa - Thị trấn Trường Sa (Đảo Trường Sa Lớn), Huyện Trường Sa, Khánh Hòa",
        "Huyện đảo Bạch Long Vĩ (Đảo tiền tiêu Vịnh Bắc Bộ), Thành phố Hải Phòng",
        "Huyện đảo Cô Tô (Thị trấn Cô Tô - Xã Đồng Tiến), Tỉnh Quảng Ninh",
        "Huyện đảo Cồn Cỏ (Đảo tiền tiêu vĩ tuyến 17), Tỉnh Quảng Trị",
        "Huyện đảo Lý Sơn (Đảo Lớn - Cù Lao Ré), Tỉnh Quảng Ngãi",
        "Huyện đảo Phú Quý (Cù Lao Thu - Xã Tam Thanh, Ngũ Phụng, Long Hải), Tỉnh Bình Thuận",
        "Huyện đảo Côn Đảo (Đảo Côn Sơn - Vườn Quốc gia Côn Đảo), Tỉnh Bà Rịa - Vũng Tàu",
        "Thành phố đảo Phú Quốc (Phường Dương Đông), Tỉnh Kiên Giang",
        "Quần đảo Thổ Châu (Xã đảo Thổ Châu - Hòn Nhạn), Thành phố Phú Quốc, Kiên Giang",
        "Xã Đất Mũi (Cột mốc Tọa độ GPS 0001 - Cực Nam Tổ Quốc), Huyện Ngọc Hiển, Cà Mau"
    )

    private val normalizedLocationsMap: Map<String, String> by lazy {
        val all = (remoteAndHighlandLocations + islandLocations + locationsByProvince.values.flatten() + featuredTopLocations).distinct()
        val map = HashMap<String, String>(all.size)
        for (loc in all) {
            map[loc] = stripAccents(loc)
        }
        map
    }

    /**
     * Tìm kiếm OFFLINE bộ nhớ tức thì 0ms, hỗ trợ lọc theo Tỉnh/Vùng miền, không chặn UI Main Thread.
     */
    fun searchOffline(query: String, categoryFilter: String = "ALL"): List<String> {
        val q = query.trim()
        val basePool = getLocationsByCategory(categoryFilter)
        if (q.isBlank()) {
            return if (categoryFilter == "ALL" || categoryFilter.isBlank()) {
                featuredTopLocations
            } else {
                basePool.take(40)
            }
        }

        val qNorm = stripAccents(q)
        val qWords = qNorm.split(Regex("\\s+")).filter { it.isNotBlank() }
        val results = LinkedHashSet<String>()
        val normMap = normalizedLocationsMap

        // 1. Tìm trong danh mục đang chọn trước (tối đa 40 kết quả)
        for (item in basePool) {
            val itemNorm = normMap[item] ?: stripAccents(item)
            val match = if (qWords.size > 1) {
                qWords.all { itemNorm.contains(it) }
            } else {
                itemNorm.contains(qNorm)
            }
            if (match) {
                results.add(item)
                if (results.size >= 40) return results.toList()
            }
        }

        // 2. Nếu đang chọn một tỉnh cụ thể nhưng từ khóa nằm ở toàn quốc, tìm mở rộng toàn quốc
        if (categoryFilter != "ALL" && results.size < 15) {
            for (item in standardLocations) {
                val itemNorm = normMap[item] ?: stripAccents(item)
                val match = if (qWords.size > 1) {
                    qWords.all { itemNorm.contains(it) }
                } else {
                    itemNorm.contains(qNorm)
                }
                if (match) {
                    results.add(item)
                    if (results.size >= 40) return results.toList()
                }
            }
        }

        // 3. Khớp tên Tỉnh / Thành phố để gợi ý
        for (province in allProvinces) {
            val provNorm = normMap[province] ?: stripAccents(province)
            if (provNorm.contains(qNorm)) {
                results.add("Thành phố / Tỉnh $province")
                val provItems = getLocationsByCategory(province)
                for (pi in provItems) {
                    results.add(pi)
                    if (results.size >= 40) return results.toList()
                }
            }
        }

        return results.take(40)
    }

    /**
     * Tìm kiếm ĐỊA CHÍNH ĐA TẦNG ONLINE (Bản làng, Thôn, Ấp, Xã, Phường, Thị trấn, Đảo, Đèo, Huyện, Tỉnh):
     * Kết hợp song song 3 nguồn:
     * 1. OpenStreetMap Nominatim Vietnam (`countrycodes=vn` — bao phủ 100% hơn 10.600 Xã/Phường/Thị trấn và hàng chục nghìn Thôn/Bản/Ấp Việt Nam)
     * 2. Open-Meteo Geocoding API
     * 3. Google Android Geocoder
     * Đồng thời lưu trước tọa độ chính xác `(lat, lon)` vào bộ nhớ đệm của `VietnamClimateEngine` để chọn xong nạp thời tiết 0ms!
     */
    suspend fun searchOnlineGeocoder(context: Context, query: String): List<String> = withContext(Dispatchers.IO) {
        val q = query.trim()
        if (q.length < 2) return@withContext emptyList()

        coroutineScope {
            val nominatimDef = async { queryNominatimVietnam(context, q) }
            val openMeteoDef = async { queryOpenMeteoSearch(context, q) }
            val androidGeoDef = async { queryAndroidGeocoderList(context, q) }

            val combined = buildList {
                addAll(nominatimDef.await())
                addAll(openMeteoDef.await())
                addAll(androidGeoDef.await())
            }
            combined.distinct().take(35)
        }
    }

    private fun queryNominatimVietnam(context: Context, query: String): List<String> {
        var conn: HttpURLConnection? = null
        return try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url =
                "https://nominatim.openstreetmap.org/search?q=$encoded&countrycodes=vn&format=json&addressdetails=1&limit=15&accept-language=vi"
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 3200
                readTimeout = 3200
                requestMethod = "GET"
                setRequestProperty("User-Agent", "MagictuneWeather/6.9 (https://magictune.app)")
                setRequestProperty("Accept", "application/json")
            }
            if (conn.responseCode != 200) return emptyList()
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONArray(body)
            val list = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val lat = obj.optString("lat", "").toDoubleOrNull()
                val lon = obj.optString("lon", "").toDoubleOrNull()
                val addr = obj.optJSONObject("address")
                val displayName = obj.optString("display_name", "")

                val formatted = if (addr != null) {
                    val parts = mutableListOf<String>()
                    val name = obj.optString("name", "").trim()
                    val village = addr.optString("village", "")
                        .ifBlank { addr.optString("hamlet", "") }
                        .ifBlank { addr.optString("suburb", "") }
                        .ifBlank { addr.optString("quarter", "") }
                        .ifBlank { addr.optString("neighbourhood", "") }
                        .ifBlank { addr.optString("town", "") }
                    val district = addr.optString("county", "")
                        .ifBlank { addr.optString("city_district", "") }
                        .ifBlank { addr.optString("municipality", "") }
                        .ifBlank { addr.optString("city", "") }
                    val state = addr.optString("state", "")
                        .ifBlank { addr.optString("province", "") }
                        .ifBlank { addr.optString("city", "") }

                    if (name.isNotBlank() && name != village && name != district && name != state) {
                        parts.add(name)
                    }
                    if (village.isNotBlank() && !parts.contains(village) && village != district && village != state) {
                        parts.add(village)
                    }
                    if (district.isNotBlank() && !parts.contains(district) && district != state) {
                        parts.add(district)
                    }
                    if (state.isNotBlank() && !parts.contains(state)) {
                        parts.add(state)
                    }
                    if (parts.isNotEmpty()) parts.joinToString(", ") else displayName.substringBeforeLast(", Việt Nam").trim()
                } else {
                    displayName.substringBeforeLast(", Việt Nam").trim()
                }

                if (formatted.length >= 3) {
                    list.add(formatted)
                    if (lat != null && lon != null) {
                        VietnamClimateEngine.cacheExactCoordinates(context, formatted, lat, lon)
                    }
                }
            }
            list
        } catch (_: Throwable) {
            emptyList()
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }

    private fun queryOpenMeteoSearch(context: Context, query: String): List<String> {
        var conn: HttpURLConnection? = null
        return try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = "https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=12&language=vi&format=json"
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 2800
                readTimeout = 2800
                requestMethod = "GET"
                setRequestProperty("User-Agent", "MagictuneWeather/6.9")
                setRequestProperty("Accept", "application/json")
            }
            if (conn.responseCode != 200) return emptyList()
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val results = JSONObject(body).optJSONArray("results") ?: return emptyList()
            val list = mutableListOf<String>()
            for (i in 0 until results.length()) {
                val obj = results.optJSONObject(i) ?: continue
                val cc = obj.optString("country_code", "")
                val lat = obj.optDouble("latitude", Double.NaN)
                val lon = obj.optDouble("longitude", Double.NaN)
                if (!cc.equals("VN", ignoreCase = true) && !(lat in 6.0..24.0 && lon in 102.0..118.0)) continue

                val name = obj.optString("name", "").trim()
                val admin3 = obj.optString("admin3", "").trim()
                val admin2 = obj.optString("admin2", "").trim()
                val admin1 = obj.optString("admin1", "").trim()

                val parts = mutableListOf<String>()
                if (name.isNotBlank()) parts.add(name)
                if (admin3.isNotBlank() && !parts.contains(admin3)) parts.add(admin3)
                if (admin2.isNotBlank() && !parts.contains(admin2) && admin2 != admin1) parts.add(admin2)
                if (admin1.isNotBlank() && !parts.contains(admin1)) parts.add(admin1)

                val formatted = parts.joinToString(", ")
                if (formatted.length >= 3) {
                    list.add(formatted)
                    if (!lat.isNaN() && !lon.isNaN()) {
                        VietnamClimateEngine.cacheExactCoordinates(context, formatted, lat, lon)
                    }
                }
            }
            list
        } catch (_: Throwable) {
            emptyList()
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }

    private suspend fun queryAndroidGeocoderList(context: Context, query: String): List<String> {
        return try {
            if (!Geocoder.isPresent()) return emptyList()
            val geocoder = Geocoder(context, Locale("vi", "VN"))
            val fullQuery = if (query.contains("Việt Nam", ignoreCase = true)) query else "$query, Việt Nam"
            val addresses: List<Address>? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                withTimeoutOrNull(2500L) {
                    suspendCancellableCoroutine { cont ->
                        try {
                            geocoder.getFromLocationName(fullQuery, 8, object : Geocoder.GeocodeListener {
                                override fun onGeocode(results: MutableList<Address>) {
                                    if (cont.isActive) cont.resume(results)
                                }
                                override fun onError(errorMessage: String?) {
                                    if (cont.isActive) cont.resume(null)
                                }
                            })
                        } catch (_: Throwable) {
                            if (cont.isActive) cont.resume(null)
                        }
                    }
                }
            } else {
                @Suppress("DEPRECATION")
                geocoder.getFromLocationName(fullQuery, 8)
            }

            val results = mutableListOf<String>()
            if (!addresses.isNullOrEmpty()) {
                for (addr in addresses) {
                    val country = addr.countryCode ?: addr.countryName ?: ""
                    if (country.contains("VN", ignoreCase = true) ||
                        country.contains("Việt", ignoreCase = true) ||
                        country.contains("Vietnam", ignoreCase = true) ||
                        country.isBlank()
                    ) {
                        val parts = mutableListOf<String>()
                        val subLoc = addr.subLocality ?: addr.thoroughfare ?: addr.featureName
                        val dist = addr.subAdminArea ?: addr.locality
                        val prov = addr.adminArea

                        if (!subLoc.isNullOrBlank() && subLoc != dist && subLoc != prov) parts.add(subLoc)
                        if (!dist.isNullOrBlank() && dist != prov) parts.add(dist)
                        if (!prov.isNullOrBlank()) parts.add(prov)

                        if (parts.isNotEmpty()) {
                            val formatted = parts.joinToString(", ")
                            if (formatted.length >= 4) {
                                results.add(formatted)
                                if (addr.hasLatitude() && addr.hasLongitude()) {
                                    VietnamClimateEngine.cacheExactCoordinates(context, formatted, addr.latitude, addr.longitude)
                                }
                            }
                        }
                    }
                }
            }
            results
        } catch (_: Throwable) {
            emptyList()
        }
    }

    /**
     * Xác định chính xác địa chỉ người dùng theo cấp Xã/Phường/Thị trấn, Huyện/Thị xã, Tỉnh/Thành phố
     * từ tọa độ GPS thực tế của thiết bị, hỗ trợ đầy đủ các vùng sâu vùng xa, biên giới, hải đảo.
     * Đồng thời tự động lưu tọa độ GPS chuẩn xác vào bộ nhớ đệm thời tiết để Widget và màn hình hiển thị tức thì.
     */
    suspend fun resolvePreciseLocationFromCoordinates(
        context: Context,
        latitude: Double,
        longitude: Double
    ): String = withContext(Dispatchers.IO) {
        try {
            val geocoder = Geocoder(context, Locale("vi", "VN"))
            val address: Address? = if (Build.VERSION.SDK_INT >= 33) {
                suspendCancellableCoroutine { continuation ->
                    geocoder.getFromLocation(latitude, longitude, 1) { addresses ->
                        if (continuation.isActive) {
                            continuation.resume(addresses.firstOrNull())
                        }
                    }
                }
            } else {
                @Suppress("DEPRECATION")
                geocoder.getFromLocation(latitude, longitude, 1)?.firstOrNull()
            }

            if (address != null) {
                val parts = mutableListOf<String>()
                val subLoc = address.subLocality ?: address.thoroughfare ?: address.featureName
                val dist = address.subAdminArea ?: address.locality
                val prov = address.adminArea

                if (!subLoc.isNullOrBlank() && subLoc != dist && subLoc != prov) {
                    parts.add(subLoc)
                }
                if (!dist.isNullOrBlank() && dist != prov && !parts.contains(dist)) {
                    parts.add(dist)
                }
                if (!prov.isNullOrBlank() && !parts.contains(prov)) {
                    parts.add(prov)
                }

                if (parts.isNotEmpty()) {
                    val formatted = parts.joinToString(", ")
                    VietnamClimateEngine.cacheExactCoordinates(context, formatted, latitude, longitude)
                    return@withContext formatted
                }
            }
        } catch (_: Throwable) {}

        // Fallback: Nếu Geocoder gặp lỗi mạng/máy chủ Google, gọi dự phòng dịch vụ Reverse Geocoding
        var conn: HttpURLConnection? = null
        try {
            val latStr = String.format(Locale.US, "%.5f", latitude)
            val lonStr = String.format(Locale.US, "%.5f", longitude)
            val url = "https://nominatim.openstreetmap.org/reverse?lat=$latStr&lon=$lonStr&countrycodes=vn&format=json&accept-language=vi"
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 3000
                readTimeout = 3000
                requestMethod = "GET"
                setRequestProperty("User-Agent", "MagictuneWeather/6.9 (https://magictune.app)")
                setRequestProperty("Accept", "application/json")
            }
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                val addrObj = json.optJSONObject("address")
                if (addrObj != null) {
                    val parts = mutableListOf<String>()
                    val hamlet = addrObj.optString("hamlet", "").ifBlank {
                        addrObj.optString("village", "").ifBlank {
                            addrObj.optString("quarter", "").ifBlank {
                                addrObj.optString("suburb", "")
                            }
                        }
                    }
                    val district = addrObj.optString("district", "").ifBlank {
                        addrObj.optString("county", "").ifBlank {
                            addrObj.optString("town", "")
                        }
                    }
                    val province = addrObj.optString("province", "").ifBlank {
                        addrObj.optString("state", "").ifBlank {
                            addrObj.optString("city", "")
                        }
                    }

                    if (hamlet.isNotBlank()) parts.add(hamlet)
                    if (district.isNotBlank() && !parts.contains(district)) parts.add(district)
                    if (province.isNotBlank() && !parts.contains(province)) parts.add(province)

                    if (parts.isNotEmpty()) {
                        val formatted = parts.joinToString(", ")
                        VietnamClimateEngine.cacheExactCoordinates(context, formatted, latitude, longitude)
                        return@withContext formatted
                    }
                }
            }
        } catch (_: Throwable) {
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }

        // Tự động gán tọa độ GPS chính xác cho khu vực fallback
        val fallbackCity = "Hà Nội"
        VietnamClimateEngine.cacheExactCoordinates(context, fallbackCity, latitude, longitude)
        fallbackCity
    }
}
