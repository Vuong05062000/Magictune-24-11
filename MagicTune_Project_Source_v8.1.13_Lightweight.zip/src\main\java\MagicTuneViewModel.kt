package com.example.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.permission.AppPermissionChecker
import com.example.core.permission.AppSelfPermissionStatus
import com.example.core.shell.ShellEngine
import com.example.data.DebloatApp
import com.example.data.DeviceInfo
import com.example.data.DiagnosticScanResult
import com.example.data.FloatingMiniWindowState
import com.example.data.LogItem
import com.example.data.LogType
import com.example.data.MagicTuneRepository
import com.example.data.NewDeviceSetupStatus
import com.example.data.ShizukuInfo
import com.example.data.TuneStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class MainTab {
    SETUP,
    NOTIFICATIONS,
    APPS,
    TUNE,
    SHIZUKU,
    SHELL,
    PRINTER,
    LOGIN,
    ADMIN,
    ACCOUNT,
    SHELL_TAB,
    APP_STORE,
    CHAT_SUPPORT,
    UNIVERSAL_TUNE,
    GESTURE_SETTINGS,
    WEATHER,
    BG_DRAIN_MONITOR
}

@androidx.compose.runtime.Immutable
data class UiState(
    val currentTab: MainTab = MainTab.SETUP,
    val isSimpleMode: Boolean = false,
    val isBusy: Boolean = false,
    val busyTitle: String = "",
    val showRevertModal: Boolean = false,
    val showWlanDialog: Boolean = false,
    val showFeaturesModal: Boolean = false,
    val showPushTesterModal: Boolean = false,
    val showTerminalBottomSheet: Boolean = false,
    val searchQuery: String = "",
    val globalSearchFocusTick: Int = 0,
    val selectedAppLevelFilter: Int = 0, // 0: All, 4: User Apps, 1: Safe Bloat, 2: System, 3: Frozen
    val sharedPrintUri: Uri? = null,
    val isPrinting: Boolean = false,
    val printStatusMessage: String = "",
    val isAutoWakeupPatrolEnabled: Boolean = false,
    val isChargingNotificationEnabled: Boolean = false,
    val isSearchNotificationEnabled: Boolean = false,
    val isAutoCoolingEnabled: Boolean = false,
    val selfPermissionStatus: AppSelfPermissionStatus = AppSelfPermissionStatus(
        hasNotificationPermission = true,
        hasOverlayPermission = true,
        hasUsageStatsPermission = true,
        hasWriteSecureSettings = false,
        isShizukuGranted = false
    ),
    val showPermissionDialog: Boolean = false,
    val showUpgradeProDialog: Boolean = false,
    val upgradeDialogReason: String = "",
    val isInitialCloudCheckActive: Boolean = false,
    val cloudCheckStatus: String = "",
    val cloudCheckProgress: Float = 0f,
    val cloudCheckResult: String = "", // "PRO", "FREE", "ERROR"
    val showCloudCheckOverlay: Boolean = false,
    val crashReportToDisplay: String? = null,
    val performanceReportToDisplay: String? = null
)

@androidx.compose.runtime.Stable
class MagicTuneViewModel(application: Application) : AndroidViewModel(application) {

    private val shellEngine = ShellEngine.getInstance(application.applicationContext)
    val repository = MagicTuneRepository(application.applicationContext, shellEngine)

    val shellState = shellEngine.state
    val adbTelemetry: StateFlow<com.example.core.adb.AdbTelemetrySnapshot> = shellEngine.adbTelemetry
    val logs: StateFlow<List<LogItem>> = repository.logs
    val errorLogCount: StateFlow<Int> = repository.errorLogCount
    private val _globalSearchQuery = MutableStateFlow("")
    val globalSearchQuery: StateFlow<String> = _globalSearchQuery
    val deviceInfo: StateFlow<DeviceInfo> = repository.deviceInfo
    val setupStatus: StateFlow<NewDeviceSetupStatus> = repository.setupStatus
    val shizukuInfo: StateFlow<ShizukuInfo> = repository.shizukuInfo
    val appsList: StateFlow<List<DebloatApp>> = repository.appsList
    val diagnosticScan: StateFlow<DiagnosticScanResult> = repository.diagnosticScan
    val floatingWindowState: StateFlow<FloatingMiniWindowState> = repository.floatingWindowState
    val tuneStatus: StateFlow<TuneStatus> = repository.tuneStatus

    private val _adbDiagnosticReport = MutableStateFlow<com.example.core.adb.AdbDiagnosticReport?>(null)
    val adbDiagnosticReport: StateFlow<com.example.core.adb.AdbDiagnosticReport?> = _adbDiagnosticReport

    private val _isRunningAdbDiagnostics = MutableStateFlow(false)
    val isRunningAdbDiagnostics: StateFlow<Boolean> = _isRunningAdbDiagnostics

    private val _isFloatingKeypadEnabled = MutableStateFlow(
        com.example.core.adb.AdbPairingNotificationManager.isFloatingKeypadEnabled(application)
    )
    val isFloatingKeypadEnabled: StateFlow<Boolean> = _isFloatingKeypadEnabled

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState

    @Volatile
    private var lastFullResumeRefreshMs: Long = android.os.SystemClock.elapsedRealtime()

    @Volatile
    private var hasLoadedAppsOnce = false
    @Volatile
    private var hasRunNotifDiagOnce = false

    init {
        // 0. Lắng nghe luồng phản ứng Pro Flow thời gian thực từ LicenseManager (Zero-Touch Pro Restore)
        viewModelScope.launch {
            com.example.core.license.LicenseManager.isProFlow.collect { isPro ->
                if (isPro) {
                    android.util.Log.d("ProRestore", "MagicTuneViewModel: isProFlow emitted true -> Automatically unlocking Pro UI state.")
                    _uiState.value = _uiState.value.copy(
                        showCloudCheckOverlay = false,
                        cloudCheckResult = "PRO"
                    )
                }
            }
        }

        // 1. Khởi chạy luồng Xác thực Pro từ Cloud Độc lập (Cold Start / Fresh Install) sau khi khung hình đầu đã vẽ xong
        viewModelScope.launch(Dispatchers.IO) {
            delay(800L)
            performInitialCloudProVerification()
        }

        // 1b. Hộp đen: Kiểm tra sự cố lần chạy trước (last_crash.txt / exit reasons)
        viewModelScope.launch(Dispatchers.IO) {
            delay(1200L)
            checkCrashReportOnStartup()
        }
        try {
            observeConnectionState()
            observeNsdAutoConnect()

            // 2. Phân tầng khởi động nền (Staggered Warmup) để khung hình mở app đầu tiên (Cold Start)
            // hoàn tất đồng bộ WindowManager (SurfaceSyncGroup) mượt mà tuyệt đối, không cạnh tranh CPU/IPC!
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    val autoWake = com.example.core.service.AutoWakeupPatrolManager.isAutoWakeupEnabled(application)
                    val chargeNotif = com.example.core.service.MagicTuneKeepAliveService.isChargingNotificationEnabled(application)
                    val searchNotif = com.example.core.service.MagicTuneKeepAliveService.isSearchNotificationEnabled(application)
                    val autoCool = com.example.core.service.MagicTuneKeepAliveService.isAutoCoolingEnabled(application)
                    _uiState.update {
                        it.copy(
                            isAutoWakeupPatrolEnabled = autoWake,
                            isChargingNotificationEnabled = chargeNotif,
                            isSearchNotificationEnabled = searchNotif,
                            isAutoCoolingEnabled = autoCool
                        )
                    }
                } catch (_: Throwable) {}

                // Nhường 800ms đầu tiên cho MainActivity hoàn tất SurfaceSyncGroup (wmsSync-VRI[MainActivity])
                delay(800L)
                try {
                    checkSelfPermissions()
                    shellEngine.refreshStatus()
                    repository.refreshShizukuInfo()
                    com.example.core.perf.MagicTuneSelfPowerGovernor.restoreAdaptiveRefreshSettingsIfPending(application)
                } catch (_: Throwable) {}

                // Giai đoạn 2: Sau 1300ms khi giao diện chính đã ổn định (refreshDeviceInfo đã tự cập nhật luôn TuneStatus & FloatingPermissions)
                delay(500L)
                try {
                    repository.refreshDeviceInfo()
                    repository.refreshSetupStatus()
                    shellEngine.startKeepAliveServiceIfNeeded()
                    com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(application)
                } catch (_: Throwable) {}

                // Danh sách ứng dụng được nạp lười khi người dùng mở tab tương ứng.
            }

            startLiveHardwareAndFeatureMonitor()
        } catch (_: Throwable) {}
    }

    private suspend fun performInitialCloudProVerification() = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val context = getApplication<Application>().applicationContext

        // 1. Kiểm tra nhanh trạng thái Pro cục bộ (Settings.Secure / SharedPreferences) ngay trong 0ms
        val isAlreadyProLocally = com.example.core.license.LicenseManager.isProActivated(context)

        if (isAlreadyProLocally) {
            _uiState.update {
                it.copy(
                    isInitialCloudCheckActive = false,
                    showCloudCheckOverlay = false,
                    cloudCheckStatus = "🎉 Tuyệt vời! Đã nhận diện máy Pro quen thuộc.",
                    cloudCheckProgress = 1.0f,
                    cloudCheckResult = "PRO"
                )
            }
            return@withContext
        }

        // Skip the cloud check if the user left during cold start; retry on the next visible resume.
        if (!isAppInForeground) return@withContext

        // 2. Chạy xác minh Cloud ngầm 100% (showCloudCheckOverlay = false) nhẹ nhàng (chỉ truy vấn ID mục tiêu, không tải toàn bộ bảng)
        _uiState.update {
            it.copy(
                isInitialCloudCheckActive = false,
                showCloudCheckOverlay = false,
                cloudCheckStatus = "Đang đồng bộ bản quyền ngầm...",
                cloudCheckProgress = 0.5f,
                cloudCheckResult = ""
            )
        }

        try {
            val result = kotlinx.coroutines.withTimeoutOrNull(8000L) {
                com.example.core.license.LicenseManager.checkDeviceRecognizedProInCloud(
                    context = context,
                    forceRefresh = false,
                    allowFullCollectionScan = false
                ) || com.example.core.license.LicenseManager.checkOnlinePaymentStatusRemote(context)
            } ?: com.example.core.license.LicenseManager.isProActivated(context)

            if (result || com.example.core.license.LicenseManager.isProActivated(context)) {
                _uiState.update {
                    it.copy(
                        isInitialCloudCheckActive = false,
                        showCloudCheckOverlay = false,
                        cloudCheckStatus = "🎉 Tuyệt vời! Đã nhận diện máy Pro quen thuộc từ đám mây.",
                        cloudCheckProgress = 1.0f,
                        cloudCheckResult = "PRO"
                    )
                }
                com.example.core.license.LicenseManager.showRecognizedProToastOnce(
                    context,
                    "🎉 Đã tự động nhận diện máy Pro quen thuộc và kích hoạt bản quyền vĩnh viễn!"
                )
            } else {
                _uiState.update {
                    it.copy(
                        isInitialCloudCheckActive = false,
                        showCloudCheckOverlay = false,
                        cloudCheckStatus = "Thiết bị hiện tại đang ở chế độ Miễn phí.",
                        cloudCheckProgress = 1.0f,
                        cloudCheckResult = "FREE"
                    )
                }
            }
        } catch (e: Exception) {
            _uiState.update {
                it.copy(
                    isInitialCloudCheckActive = false,
                    showCloudCheckOverlay = false,
                    cloudCheckStatus = "Đang hoạt động ở chế độ ngoại tuyến / miễn phí.",
                    cloudCheckProgress = 1.0f,
                    cloudCheckResult = "FREE"
                )
            }
        }
    }

    fun dismissCloudCheckOverlay() {
        _uiState.value = _uiState.value.copy(showCloudCheckOverlay = false, isInitialCloudCheckActive = false)
    }

    private val isAutoConnectingWlan = java.util.concurrent.atomic.AtomicBoolean(false)

    private fun scheduleNsdAutoStopIfIdle() {
        com.example.core.adb.AdbNsdScanner.getInstance(getApplication()).scheduleAutoStop(15_000L)
    }

    private fun tryAutoConnectWlan(port: Int, tag: String) {
        if (port !in 1..65535 || shellState.value.isWirelessAdbConnected) return
        if (shellEngine.isUserWlanDisconnected()) return
        if (!shellEngine.hasPairedBefore()) return
        if (!isAutoConnectingWlan.compareAndSet(false, true)) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (!shellState.value.isWirelessAdbConnected && !shellEngine.isUserWlanDisconnected()) {
                    val connected = shellEngine.connectWirelessAdb(port)
                    if (connected) {
                        try {
                            com.example.core.adb.AdbPairingNotificationManager.stopInteractivePairingNotification(getApplication())
                        } catch (_: Throwable) {}
                        _uiState.update { it.copy(showWlanDialog = false) }
                        repository.log("🎉 [$tag] Đã tự động kết nối Direct WLAN ADB (Cổng $port • UID 2000)!", LogType.SUCCESS)
                        autoGrantEverythingAfterWlan()
                        refreshAll()
                    }
                }
            } catch (_: Throwable) {
            } finally {
                isAutoConnectingWlan.set(false)
            }
        }
    }

    private fun observeNsdAutoConnect() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                delay(1500L)
                val scanner = com.example.core.adb.AdbNsdScanner.getInstance(getApplication())
                val isAdbWifiSwitchOn = shellEngine.checkAdbWifiSystemSetting().first
                // Chỉ bật quét mDNS Multicast khi công tắc Gỡ lỗi không dây trong Cài đặt thực sự đang BẬT
                if (isAdbWifiSwitchOn &&
                    !shellState.value.isWirelessAdbConnected &&
                    !shellEngine.isUserWlanDisconnected() &&
                    shellEngine.hasPairedBefore()
                ) {
                    scanner.startConnectDiscoveryOnly()
                    scheduleNsdAutoStopIfIdle()
                }
                scanner.state.collect { nsdState ->
                    val port = nsdState.connectPort ?: scanner.lastKnownConnectPort
                    if (port != null &&
                        port in 1..65535 &&
                        !shellState.value.isWirelessAdbConnected &&
                        !shellEngine.isUserWlanDisconnected() &&
                        shellEngine.hasPairedBefore()
                    ) {
                        tryAutoConnectWlan(port, "Auto-Connect NSD")
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    private var hasAutoPromptedPermissionDialog = false

    private fun observeConnectionState() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                var previousAdbReady = shellState.value.isAdbReady
                var previousMode = shellState.value.mode
                var previousShizukuRunning = shellState.value.isShizukuRunning
                var previousShizukuGranted = shellState.value.isShizukuPermissionGranted
                if (previousAdbReady) {
                    launch(Dispatchers.IO) {
                        try {
                            repository.applyOneTimeBatteryThermalRecoveryIfNeeded()
                            com.example.core.perf.MagicTuneSelfPowerGovernor.restoreAdaptiveRefreshSettingsIfPending(getApplication())
                            _uiState.update {
                                it.copy(
                                    isAutoWakeupPatrolEnabled = com.example.core.service.AutoWakeupPatrolManager.isAutoWakeupEnabled(getApplication()),
                                    isAutoCoolingEnabled = com.example.core.service.MagicTuneKeepAliveService.isAutoCoolingEnabled(getApplication())
                                )
                            }
                        } catch (_: Throwable) {}
                    }
                }
                shellState.collect { state ->
                    try {
                        val currentAdbReady = state.isAdbReady
                        val shizukuChanged = state.mode != previousMode ||
                            state.isShizukuRunning != previousShizukuRunning ||
                            state.isShizukuPermissionGranted != previousShizukuGranted ||
                            previousAdbReady != currentAdbReady
                        if (shizukuChanged) {
                            repository.refreshShizukuInfo()
                        }
                        if (!previousAdbReady && currentAdbReady) {
                            // Ngừng quét mDNS ngay khi ADB đã sẵn sàng (trừ lúc đang mở ghép đôi thêm thiết bị)
                            if (!com.example.core.adb.AdbPairingNotificationManager.isNotificationPairingActive &&
                                !_uiState.value.showWlanDialog
                            ) {
                                try {
                                    com.example.core.adb.AdbNsdScanner.getInstance(getApplication()).stopDiscovery(updateStatusText = false)
                                } catch (_: Throwable) {}
                            }
                            launch(Dispatchers.IO) {
                                try {
                                    repository.applyOneTimeBatteryThermalRecoveryIfNeeded()
                                    com.example.core.perf.MagicTuneSelfPowerGovernor.restoreAdaptiveRefreshSettingsIfPending(getApplication())
                                    _uiState.update {
                                        it.copy(
                                            isAutoWakeupPatrolEnabled = com.example.core.service.AutoWakeupPatrolManager.isAutoWakeupEnabled(getApplication()),
                                            isAutoCoolingEnabled = com.example.core.service.MagicTuneKeepAliveService.isAutoCoolingEnabled(getApplication())
                                        )
                                    }
                                } catch (_: Throwable) {}
                            }
                            autoGrantEverythingAfterWlan()
                            refreshAll()
                        }
                        if (previousAdbReady && !currentAdbReady) {
                            repository.log("ℹ️ Kết nối ADB/WLAN tạm ngắt — các thiết lập đã tối ưu vẫn được bảo toàn.", LogType.INFO)
                        }
                        previousAdbReady = currentAdbReady
                        previousMode = state.mode
                        previousShizukuRunning = state.isShizukuRunning
                        previousShizukuGranted = state.isShizukuPermissionGranted
                    } catch (_: Throwable) {}
                }
            } catch (_: Throwable) {}
        }
    }

    @Volatile
    private var isAppInForeground: Boolean = true
    private var hardwareMonitorJob: kotlinx.coroutines.Job? = null

    fun setAppInForeground(inForeground: Boolean) {
        isAppInForeground = inForeground
        if (!inForeground) {
            hardwareMonitorJob?.cancel()
            hardwareMonitorJob = null
            if (!com.example.core.adb.AdbPairingNotificationManager.isNotificationPairingActive) {
                try {
                    com.example.core.adb.AdbNsdScanner.getInstance(getApplication()).stopDiscovery()
                } catch (_: Throwable) {}
            }
        } else {
            startLiveHardwareAndFeatureMonitor()
        }
    }

    private fun startLiveHardwareAndFeatureMonitor() {
        if (hardwareMonitorJob?.isActive == true) return
        hardwareMonitorJob = viewModelScope.launch(Dispatchers.IO) {
            var lastHeartbeatMs = android.os.SystemClock.elapsedRealtime()
            while (isActive && isAppInForeground) {
                // Chỉ kiểm tra phần cứng khi đang ở tab Thiết lập, tối đa một lần mỗi 10 phút.
                delay(600_000L)
                if (!isActive || !isAppInForeground) break
                try {
                    // Nếu người dùng đang chạm/cuộn màn hình, nhường 4 giây để tuyệt đối không gây khựng khung hình
                    if (com.example.core.perf.MagicTuneSelfPowerGovernor.isUserActivelyInteractingInApp()) {
                        delay(4_000L)
                        if (!isActive || !isAppInForeground) break
                    }
                    val tab = _uiState.value.currentTab
                    // Chỉ đọc thông số phần cứng khi người dùng đang ở trực tiếp trên tab Thiết Lập (Ô #01)
                    if (tab == MainTab.SETUP) {
                        repository.refreshDeviceInfo()
                    }
                    val nowElapsed = android.os.SystemClock.elapsedRealtime()
                    // Giãn nhịp Cloud Heartbeat lên 30 phút (thay vì 3 phút) để không giữ modem 4G/5G/Wi-Fi thức liên tục (tiết kiệm 50mA)
                    if (nowElapsed - lastHeartbeatMs >= 1_800_000L) {
                        lastHeartbeatMs = nowElapsed
                        com.example.core.auth.FirebaseAuthManager.updateUserHeartbeat(getApplication())
                    }
                } catch (_: Throwable) {}
            }
        }
    }

    fun onAppResumed() {
        isAppInForeground = true
        viewModelScope.launch(Dispatchers.IO) {
            // Đợi chuyển cảnh cửa sổ Activity hoàn tất trước khi cập nhật System Overlay / Service
            delay(450L)
            if (!isAppInForeground) return@launch
            try {
                shellEngine.startKeepAliveServiceIfNeeded()
                com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(getApplication())
            } catch (_: Throwable) {}
            try {
                val nowElapsed = android.os.SystemClock.elapsedRealtime()
                // Chống quét trùng lặp khi vừa khởi động app (init đã chạy) hoặc khi đóng mở nhanh hộp thoại (< 25 giây)
                if (nowElapsed - lastFullResumeRefreshMs < 25_000L) {
                    repository.refreshFloatingPermissionsState()
                    return@launch
                }
                lastFullResumeRefreshMs = nowElapsed

                // Làm mới token Firebase ngầm để đảm bảo currentUser không bao giờ null sau thời gian dài nền
                try {
                    com.example.core.auth.FirebaseAuthManager.refreshFirebaseTokenSilentlyIfNeeded(getApplication())
                } catch (_: Throwable) {}
                // Gửi nhịp tim nhẹ khi ứng dụng quay trở lại màn hình (có giãn cách chống trùng lặp)
                com.example.core.auth.FirebaseAuthManager.updateUserHeartbeat(getApplication(), force = false)
                if (!com.example.core.license.LicenseManager.isProActivated(getApplication())) {
                    launch(Dispatchers.IO) {
                        try {
                            val restored = com.example.core.license.LicenseManager.checkDeviceRecognizedProInCloud(
                                context = getApplication(),
                                forceRefresh = false,
                                allowFullCollectionScan = false
                            ) || com.example.core.license.LicenseManager.checkOnlinePaymentStatusRemote(getApplication())
                            if (restored) {
                                com.example.core.license.LicenseManager.showRecognizedProToastOnce(
                                    getApplication(),
                                    "🎉 Đã tự động nhận diện thiết bị Pro và khôi phục bản quyền vĩnh viễn!"
                                )
                            }
                        } catch (_: Throwable) {}
                    }
                }
                shellEngine.refreshStatus()
                repository.refreshShizukuInfo()
                repository.refreshDeviceInfo() // Đã bao gồm refreshTuneStatus() & refreshFloatingPermissionsState()
                checkSelfPermissions()

                // Chỉ quét mDNS ngắn hạn khi công tắc Gỡ lỗi không dây đang BẬT, chưa kết nối và máy đã ghép nối trước đó
                val isAdbWifiSwitchOn = shellEngine.checkAdbWifiSystemSetting().first
                if (isAdbWifiSwitchOn &&
                    !shellState.value.isWirelessAdbConnected &&
                    !shellEngine.isUserWlanDisconnected() &&
                    shellEngine.hasPairedBefore()
                ) {
                    val scanner = com.example.core.adb.AdbNsdScanner.getInstance(getApplication())
                    scanner.refreshConnectDiscovery()
                    scheduleNsdAutoStopIfIdle()
                    val immediatePort = scanner.getBestConnectPort()
                    if (immediatePort != null && immediatePort in 1..65535) {
                        tryAutoConnectWlan(immediatePort, "Auto-Connect Resumed")
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    fun checkSelfPermissions(forceShowIfMissing: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val isShizukuReady = shellState.value.isAdbReady || (shizukuInfo.value.isRunning && shizukuInfo.value.isPermissionGranted)
                val status = AppPermissionChecker.checkSelfPermissions(getApplication(), isShizukuReady)

                val shouldAutoShowDialog = (!status.isFullyGranted) && (!hasAutoPromptedPermissionDialog || forceShowIfMissing)
                if (shouldAutoShowDialog) {
                    hasAutoPromptedPermissionDialog = true
                }

                _uiState.update { current ->
                    current.copy(
                        selfPermissionStatus = status,
                        showPermissionDialog = when {
                            shouldAutoShowDialog -> true
                            status.isFullyGranted && status.hasWriteSecureSettings -> false
                            else -> current.showPermissionDialog
                        }
                    )
                }
            } catch (_: Throwable) {}
        }
    }

    fun setShowPermissionDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showPermissionDialog = show)
    }

    fun grantAllSelfPermissionsViaShell() {
        viewModelScope.launch {
            if (!ensureAdbReadyOrPrompt("Tự động cấp full quyền cho MagicTune")) {
                return@launch
            }
            _uiState.value = _uiState.value.copy(isBusy = true, busyTitle = "Đang tự động cấp full quyền cho MagicTune...")
            try {
                withContext(Dispatchers.IO) {
                    repository.grantSelfControlAndOverlayPermissions()
                }
                kotlinx.coroutines.delay(1200)
                val isShizukuReady = shellState.value.isAdbReady || (shizukuInfo.value.isRunning && shizukuInfo.value.isPermissionGranted)
                val status = withContext(Dispatchers.IO) {
                    AppPermissionChecker.checkSelfPermissions(getApplication(), isShizukuReady)
                }
                _uiState.value = _uiState.value.copy(
                    selfPermissionStatus = status,
                    showPermissionDialog = !status.isFullyGranted
                )
            } finally {
                _uiState.value = _uiState.value.copy(isBusy = false)
            }
        }
    }

    /**
     * Bấm ô "Trợ Năng Ngầm & Đọc Màn Hình" trong dialog Kiểm Tra Quyền Hệ Thống.
     * - Chưa kết nối Gỡ lỗi WLAN: cảnh báo + tự mở bảng ghép nối 6 số (bấm cấp lúc này là vô dụng).
     * - Đã kết nối: tự cấp trợ năng ngầm + auto-grant FULL toàn bộ quyền có thể cấp qua ADB.
     */
    fun grantSilentAccessibilityWithFullAuto() {
        val app = getApplication<Application>()
        val isAdbReady = shellState.value.isAdbReady || (shizukuInfo.value.isRunning && shizukuInfo.value.isPermissionGranted)
        if (!isAdbReady) {
            _uiState.update {
                it.copy(
                    showPermissionDialog = false,
                    currentTab = MainTab.SHIZUKU,
                    showWlanDialog = true
                )
            }
            try {
                android.widget.Toast.makeText(
                    app,
                    "⚠️ Trợ Năng chỉ tự cấp được sau khi kết nối Gỡ lỗi WLAN. Hãy ghép nối mã 6 số trước!",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            } catch (_: Throwable) {}
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyTitle = "Đang tự động cấp quyền Trợ Năng & toàn bộ quyền qua WLAN ADB..."
                )
            }
            try {
                repository.grantSelfControlAndOverlayPermissions()
                try {
                    com.example.core.service.MagicTuneCtsAccessibilityService.autoGrantAndEnableSilently(app)
                } catch (_: Throwable) {}
                delay(600)
                val status = AppPermissionChecker.checkSelfPermissions(app, true)
                _uiState.update {
                    it.copy(
                        selfPermissionStatus = status,
                        showPermissionDialog = !status.isFullyGranted
                    )
                }
                try {
                    android.widget.Toast.makeText(
                        app,
                        "✅ Đã tự động cấp quyền Trợ Năng & Đọc Màn Hình + toàn bộ quyền có thể cấp!",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                } catch (_: Throwable) {}
            } finally {
                _uiState.update { it.copy(isBusy = false) }
            }
        }
    }

    /**
     * Bấm ô "Quyền Trợ Lý Kỹ Thuật Số (Digital Assistant)" trong dialog Kiểm Tra Quyền Hệ Thống.
     * - Chưa kết nối Gỡ lỗi WLAN: mở cài đặt chọn ứng dụng trợ lý mặc định của máy.
     * - Đã kết nối: tự động gán ROLE_ASSISTANT & VoiceInteractionService qua shell không cần vào Cài đặt!
     */
    fun grantAssistantPermission() {
        val app = getApplication<Application>()
        val isAdbReady = shellState.value.isAdbReady || (shizukuInfo.value.isRunning && shizukuInfo.value.isPermissionGranted)
        if (!isAdbReady) {
            AppPermissionChecker.requestAssistantPermission(app)
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyTitle = "Đang tự động cấp Quyền Trợ Lý Kỹ Thuật Số qua WLAN ADB..."
                )
            }
            try {
                repository.grantAssistantRoleAndSettings()
                delay(400)
                val status = AppPermissionChecker.checkSelfPermissions(app, true)
                _uiState.update {
                    it.copy(
                        selfPermissionStatus = status,
                        showPermissionDialog = !status.isFullyGranted
                    )
                }
                try {
                    android.widget.Toast.makeText(
                        app,
                        "✅ Đã tự động cấp Quyền Trợ Lý Kỹ Thuật Số (ROLE_ASSISTANT) thành công!",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                } catch (_: Throwable) {}
            } finally {
                _uiState.update { it.copy(isBusy = false) }
            }
        }
    }

    private val isAutoGrantingAfterWlan = java.util.concurrent.atomic.AtomicBoolean(false)

    @Volatile
    private var lastAutoGrantAfterWlanMs: Long = 0L

    /** Refresh permission state after ADB connects; connection alone must not change system settings. */
    fun autoGrantEverythingAfterWlan() {
        val now = android.os.SystemClock.elapsedRealtime()
        if (lastAutoGrantAfterWlanMs != 0L && (now - lastAutoGrantAfterWlanMs) < 20_000L) return
        if (!isAutoGrantingAfterWlan.compareAndSet(false, true)) return
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            try {
                val status = AppPermissionChecker.checkSelfPermissions(app, true)
                _uiState.update { it.copy(selfPermissionStatus = status) }
                lastAutoGrantAfterWlanMs = android.os.SystemClock.elapsedRealtime()
            } finally {
                isAutoGrantingAfterWlan.set(false)
            }
        }
    }

    fun fixMagicOSSystemUpdate() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isBusy = true, busyTitle = "Đang khôi phục & mở trang Cập nhật phần mềm MagicOS...")
            try {
                repository.fixMagicOSSystemUpdate()
            } finally {
                _uiState.value = _uiState.value.copy(isBusy = false)
            }
        }
    }


    override fun onCleared() {
        super.onCleared()
        try {
            if (!com.example.core.adb.AdbPairingNotificationManager.isNotificationPairingActive) {
                com.example.core.adb.AdbNsdScanner.getInstance(getApplication()).stopDiscovery()
            }
        } catch (_: Throwable) {}
        shellEngine.cleanup()
    }

    @Volatile
    private var returnTabFromBgDrain: MainTab = MainTab.SETUP

    fun openBackgroundDrainMonitor(fromTab: MainTab? = null) {
        val current = _uiState.value.currentTab
        val resolvedOrigin = when {
            fromTab != null && fromTab != MainTab.BG_DRAIN_MONITOR -> fromTab
            current != MainTab.BG_DRAIN_MONITOR -> current
            else -> returnTabFromBgDrain
        }
        returnTabFromBgDrain = resolvedOrigin
        setTab(MainTab.BG_DRAIN_MONITOR)
    }

    fun navigateBackFromBgDrain() {
        val target = returnTabFromBgDrain.takeIf { it != MainTab.BG_DRAIN_MONITOR } ?: MainTab.SETUP
        setTab(target)
    }

    private var tabRefreshJob: kotlinx.coroutines.Job? = null

    fun setTab(tab: MainTab) {
        val current = _uiState.value.currentTab
        if (tab == current) return
        _globalSearchQuery.value = ""
        if (tab == MainTab.BG_DRAIN_MONITOR && current != MainTab.BG_DRAIN_MONITOR) {
            returnTabFromBgDrain = current
        }
        _uiState.value = _uiState.value.copy(currentTab = tab)
        tabRefreshJob?.cancel()
        tabRefreshJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                if (tab == MainTab.APPS || tab == MainTab.GESTURE_SETTINGS) {
                    if (!hasLoadedAppsOnce) {
                        hasLoadedAppsOnce = true
                        repository.loadUserAppsImmediately()
                    }
                    if (repository.appsList.value.isEmpty()) {
                        repository.refreshAppsList()
                    }
                } else {
                    com.example.core.widget.AppIconMemoryCache.trimMemory(android.content.ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN)
                }
                if (tab == MainTab.NOTIFICATIONS) {
                    if (!hasLoadedAppsOnce) {
                        hasLoadedAppsOnce = true
                        repository.loadUserAppsImmediately()
                    }
                    if (!hasRunNotifDiagOnce) {
                        hasRunNotifDiagOnce = true
                        repository.runDiagnosticScan(skipAppsAndSetupRefresh = true, silentLog = true)
                    }
                } else if (tab == MainTab.TUNE) {
                    repository.refreshTuneStatus()
                }
            } catch (_: Throwable) {}
        }
    }

    fun refreshAppsList() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.refreshAppsList()
            } catch (_: Throwable) {}
        }
    }

    fun setSimpleMode(enabled: Boolean) {
        _uiState.value = _uiState.value.copy(isSimpleMode = enabled)
    }

    fun setSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun setGlobalSearchQuery(query: String) {
        _globalSearchQuery.value = query
    }

    fun requestGlobalSearchFocus() {
        _globalSearchQuery.value = ""
        _uiState.update {
            it.copy(
                globalSearchFocusTick = it.globalSearchFocusTick + 1
            )
        }
    }

    fun setAppLevelFilter(level: Int) {
        _uiState.value = _uiState.value.copy(selectedAppLevelFilter = level)
    }

    fun setShowRevertModal(show: Boolean) {
        _uiState.value = _uiState.value.copy(showRevertModal = show)
    }

    fun setShowWlanDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showWlanDialog = show)
    }

    fun setShowFeaturesModal(show: Boolean) {
        _uiState.value = _uiState.value.copy(showFeaturesModal = show)
    }

    fun setShowPushTesterModal(show: Boolean) {
        _uiState.value = _uiState.value.copy(showPushTesterModal = show)
    }

    fun setShowTerminalBottomSheet(show: Boolean) {
        _uiState.value = _uiState.value.copy(showTerminalBottomSheet = show)
    }

    fun setShowUpgradeProDialog(show: Boolean, reason: String = "") {
        _uiState.value = _uiState.value.copy(
            showUpgradeProDialog = show,
            upgradeDialogReason = reason
        )
    }

    fun checkCrashReportOnStartup() {
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            try {
                com.example.core.crash.CrashBlackBox.checkAndRecordHistoricalExitReasons(app)
            } catch (_: Throwable) {}
            // Hộp đen vẫn ghi log ngầm 100% trên mọi máy, nhưng CHỈ tự động hiện popup hộp thoại
            // trên thiết bị Admin để tránh gây phiền hà hoặc hoang mang cho người dùng phổ thông.
            val isAdmin = com.example.core.license.LicenseManager.isCurrentUserAdmin(app)
            if (isAdmin && com.example.core.crash.CrashBlackBox.hasUnreadCrash(app)) {
                val report = com.example.core.crash.CrashBlackBox.readCrashLog(app)
                if (!report.isNullOrBlank()) {
                    _uiState.update { it.copy(crashReportToDisplay = report) }
                } else {
                    com.example.core.crash.CrashBlackBox.setUnreadStatus(app, false)
                }
            }
        }
    }

    fun dismissCrashReportDialog() {
        com.example.core.crash.CrashBlackBox.setUnreadStatus(getApplication(), false)
        _uiState.update { it.copy(crashReportToDisplay = null) }
    }

    fun clearCrashReport() {
        viewModelScope.launch(Dispatchers.IO) {
            com.example.core.crash.CrashBlackBox.clearCrashLog(getApplication())
            _uiState.update { it.copy(crashReportToDisplay = null) }
        }
    }

    fun openCrashReportManual() {
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            val report = com.example.core.crash.CrashBlackBox.readCrashLog(app)
            if (!report.isNullOrBlank()) {
                _uiState.update { it.copy(crashReportToDisplay = report) }
            } else {
                kotlinx.coroutines.withContext(Dispatchers.Main) {
                    android.widget.Toast.makeText(app, "Hôm nay chưa có báo cáo sự cố.", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun openPerformanceReportManual() {
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            val report = com.example.core.crash.CrashBlackBox.readPerformanceLog(app)
            if (!report.isNullOrBlank()) {
                _uiState.update { it.copy(performanceReportToDisplay = report) }
            } else {
                withContext(Dispatchers.Main) {
                    android.widget.Toast.makeText(app, "Hôm nay chưa có cảnh báo nhiệt độ hoặc pin.", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun dismissPerformanceReportDialog() {
        _uiState.update { it.copy(performanceReportToDisplay = null) }
    }

    fun clearPerformanceReport() {
        viewModelScope.launch(Dispatchers.IO) {
            com.example.core.crash.CrashBlackBox.clearPerformanceLog(getApplication())
            _uiState.update { it.copy(performanceReportToDisplay = null) }
        }
    }

    fun setFloatingMiniWindowVisible(visible: Boolean) {
        repository.setFloatingMiniWindowVisible(visible)
    }

    fun setFloatingMiniWindowMinimized(minimized: Boolean) {
        repository.setFloatingMiniWindowMinimized(minimized)
    }

    fun clearLogs() {
        repository.clearLogs()
    }

    private val isRefreshingAll = java.util.concurrent.atomic.AtomicBoolean(false)

    fun refreshAll() {
        if (!isRefreshingAll.compareAndSet(false, true)) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                try { shellEngine.refreshStatus() } catch (_: Throwable) {}
                kotlinx.coroutines.supervisorScope {
                    launch { try { repository.refreshDeviceInfo() } catch (_: Throwable) {} }
                    launch { try { repository.refreshSetupStatus() } catch (_: Throwable) {} }
                    launch { try { repository.refreshTuneStatus() } catch (_: Throwable) {} }
                    launch { try { repository.refreshShizukuInfo() } catch (_: Throwable) {} }
                    launch { try { repository.refreshAppsList() } catch (_: Throwable) {} }
                }
            } catch (_: Throwable) {
            } finally {
                isRefreshingAll.set(false)
            }
        }
    }

    fun requestShizukuPermission() {
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            if (!shellEngine.isShizukuInstalled()) {
                repository.log("⚠️ Thiết bị chưa cài đặt ứng dụng Shizuku (moe.shizuku.privileged.api). Đang mở trang tải Shizuku...", LogType.INFO)
                withContext(Dispatchers.Main) {
                    try {
                        android.widget.Toast.makeText(
                            app,
                            "📲 Máy chưa cài ứng dụng Shizuku. Đang mở trang tải Shizuku...",
                            android.widget.Toast.LENGTH_LONG
                        ).show()
                    } catch (_: Throwable) {}
                    openPlayStore("moe.shizuku.privileged.api")
                }
                return@launch
            }

            if (!shellEngine.isShizukuServerTrulyAlive()) {
                // Thử tự động kích hoạt Shizuku Server trực tiếp từ MagicTune nếu đã có ADB/cổng kết nối
                val (autoStarted, startMsg) = com.example.core.shell.ShizukuStarterModule.startShizukuServerViaAdb(app, shellEngine)
                if (autoStarted && shellEngine.isShizukuServerTrulyAlive()) {
                    repository.log("✅ Đã tự động kích hoạt Shizuku Server: $startMsg", LogType.SUCCESS)
                } else {
                    repository.log("ℹ️ Shizuku Server chưa chạy. Đang mở ứng dụng Shizuku để bạn bấm 'Bắt đầu'...", LogType.INFO)
                    withContext(Dispatchers.Main) {
                        try {
                            android.widget.Toast.makeText(
                                app,
                                "⚡ Dịch vụ Shizuku chưa chạy. Hãy bấm 'Bắt đầu' trong app Shizuku hoặc dùng Kết Nối Trực Tiếp (Mã 6 số)!",
                                android.widget.Toast.LENGTH_LONG
                            ).show()
                        } catch (_: Throwable) {}
                        openShizukuApp()
                    }
                    return@launch
                }
            }

            try {
                shellEngine.requestShizukuPermission()
            } catch (_: Throwable) {}
            kotlinx.coroutines.delay(350)
            try {
                repository.refreshShizukuInfo()
                repository.refreshDeviceInfo()
                if (shellEngine.state.value.isShizukuPermissionGranted) {
                    repository.log("🟢 Đã kết nối và cấp quyền Shizuku (UID 2000) thành công!", LogType.SUCCESS)
                    autoGrantEverythingAfterWlan()
                }
            } catch (_: Throwable) {}
        }
    }

    fun forceResetShizuku() {
        viewModelScope.launch(Dispatchers.IO) {
            shellEngine.forceResetBinder()
            repository.log("⚡ Đã cưỡng bức làm mới kết nối Shizuku. Nếu vẫn lỗi, hãy khởi động lại app Shizuku.", LogType.INFO)
            try {
                repository.refreshShizukuInfo()
            } catch (_: Throwable) {}
        }
    }

    fun testShizukuDiagnostic(onResult: (Boolean, String) -> Unit = { _, _ -> }) {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyTitle = "Đang kiểm tra toàn diện Shizuku..."
                )
            }
            try {
                repository.log("🔍 Đang chạy chẩn đoán toàn diện kết nối & quyền Shizuku...", LogType.COMMAND)
                val diagResult = kotlinx.coroutines.withTimeoutOrNull(10000L) {
                    shellEngine.runComprehensiveShizukuDiagnostic()
                }
                val (ok, details) = diagResult ?: Pair(false, "⚠️ Hết thời gian chờ (10s): Shizuku Binder không phản hồi.")
                repository.refreshShizukuInfo()
                repository.log("Kết quả kiểm tra Shizuku:\n$details", if (ok) LogType.SUCCESS else LogType.ERROR)
                withContext(Dispatchers.Main) {
                    onResult(ok, details)
                }
            } catch (t: Throwable) {
                repository.log("❌ Lỗi chẩn đoán: ${t.localizedMessage ?: t.message}", LogType.ERROR)
            } finally {
                _uiState.value = _uiState.value.copy(isBusy = false, busyTitle = "")
            }
        }
    }

    fun startNotificationPairingMode() {
        val app = getApplication<Application>()
        com.example.core.adb.AdbPairingNotificationManager.startInteractiveNotificationPairing(app)
        repository.log(
            "🔔 Đã bật chế độ Ghép nối trên Thanh thông báo (NSD _adb-tls-pairing._tcp). Hãy mở 'Ghép nối bằng mã ghép đôi' và nhập 6 số PIN ngay trên thông báo!",
            LogType.INFO
        )
        openDeveloperSettings()
    }

    fun startShizukuServerDirectly() {
        viewModelScope.launch {
            val app = getApplication<Application>()
            val shizukuAlive = try { rikka.shizuku.Shizuku.pingBinder() } catch (_: Throwable) { false }
            val nsdPort = try { com.example.core.adb.AdbNsdScanner.getInstance(app).state.value.connectPort } catch (_: Throwable) { null }
            if (!shizukuAlive && !shellState.value.isAdbReady && (nsdPort == null || nsdPort <= 0)) {
                repository.log("⚠️ Cần kết nối Gỡ lỗi WLAN (mã 6 số) trước để kích hoạt chéo Shizuku Server!", LogType.ERROR)
                showSafeToast("⚠️ Cần ghép nối Gỡ lỗi WLAN (mã 6 số) trước khi kích hoạt Shizuku!", long = true)
                _uiState.update { it.copy(showWlanDialog = true) }
                return@launch
            }
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyTitle = "Đang khởi chạy trực tiếp Shizuku Server..."
                )
            }
            try {
                withContext(Dispatchers.IO) {
                    repository.log("🚀 Đang kích hoạt trực tiếp Shizuku Server Daemon từ MagicTune...", LogType.COMMAND)
                    val startResult = kotlinx.coroutines.withTimeoutOrNull(15000L) {
                        com.example.core.shell.ShizukuStarterModule.startShizukuServerViaAdb(
                            app,
                            shellEngine
                        )
                    }
                    val (ok, msg) = startResult ?: Pair(false, "⚠️ Hết thời gian chờ (15s) khi khởi chạy Shizuku Daemon.")
                    repository.refreshShizukuInfo()
                    repository.log(msg, if (ok) LogType.SUCCESS else LogType.ERROR)
                    if (ok) {
                        shellEngine.requestShizukuPermission()
                        autoGrantEverythingAfterWlan()
                    } else {
                        showSafeToast(msg, long = true)
                    }
                }
            } catch (t: Throwable) {
                repository.log("❌ Lỗi khởi chạy: ${t.localizedMessage ?: t.message}", LogType.ERROR)
            } finally {
                _uiState.value = _uiState.value.copy(isBusy = false, busyTitle = "")
            }
        }
    }

    fun unlockRestrictedSettingsAllApps() = runAction("Đang mở khóa 'Cài đặt bị hạn chế' (Android 13-17)...") {
        repository.log("🔓 Đang mở khóa ACCESS_RESTRICTED_SETTINGS cho toàn bộ ứng dụng...", LogType.COMMAND)
        val (unlocked, total) = com.example.core.shell.ShizukuStarterModule.unlockRestrictedSettingsAllApps(
            getApplication(),
            shellEngine
        )
        com.example.core.shell.ShizukuStarterModule.keepWirelessDebuggingImmortal(shellEngine)
        repository.log(
            "✅ Đã mở khóa 'Cài đặt bị hạn chế' cho $unlocked/$total ứng dụng & kích hoạt giữ sống Gỡ lỗi Wi-Fi!",
            LogType.SUCCESS
        )
    }

    fun pairWirelessAdb(port: Int, pairingCode: String, onFinished: (Boolean, String) -> Unit = { _, _ -> }) {
        viewModelScope.launch {
            repository.log("🔑 Bắt đầu ghép nối mã PIN $pairingCode tới cổng $port...", LogType.COMMAND)
            val result = withContext(Dispatchers.IO) {
                shellEngine.pairWirelessAdb(port, pairingCode)
            }
            val success = result.isSuccess && result.getOrDefault(false)
            val msg = if (success) {
                "Ghép nối thành công! Đang tự động kết nối..."
            } else {
                result.exceptionOrNull()?.localizedMessage
                    ?: "Ghép nối thất bại. Vui lòng kiểm tra lại 6 số PIN và 5 số cổng (đảm bảo cửa sổ ghép nối vẫn đang mở)."
            }

            // Gọi ngay callback để WirelessAdbDialog cập nhật phản hồi UI lập tức cho người dùng
            onFinished(success, msg)

            if (success) {
                repository.log("✅ WLAN: Ghép nối mã PIN thành công!", LogType.SUCCESS)
                // Chạy tự động tìm kiếm cổng connect và kết nối ngầm không che lấp giao diện
                val scanner = com.example.core.adb.AdbNsdScanner.getInstance(getApplication())
                scanner.refreshConnectDiscovery()
                var targetPort = scanner.getBestConnectPort()
                var connected = false
                val immediatePort = targetPort
                if (immediatePort != null && immediatePort in 1..65535) {
                    repository.log("⚡ Tìm thấy cổng kết nối $immediatePort, đang tự động kết nối...", LogType.INFO)
                    connected = withContext(Dispatchers.IO) { shellEngine.connectWirelessAdb(immediatePort) }
                } else {
                    for (i in 1..10) {
                        kotlinx.coroutines.delay(400)
                        val discovered = scanner.getBestConnectPort()
                        if (discovered != null && discovered in 1..65535) {
                            targetPort = discovered
                            connected = withContext(Dispatchers.IO) { shellEngine.connectWirelessAdb(discovered) }
                            break
                        }
                    }
                }
                if (connected && targetPort != null) {
                    repository.log("🎉 ĐÃ TỰ ĐỘNG KẾT NỐI DIRECT WLAN ADB THÀNH CÔNG! (Cổng: $targetPort • UID 2000)", LogType.SUCCESS)
                    _uiState.update { it.copy(showWlanDialog = false) }
                    try {
                        com.example.core.adb.AdbPairingNotificationManager.stopInteractivePairingNotification(getApplication())
                    } catch (_: Throwable) {}
                    refreshAll()
                    autoGrantEverythingAfterWlan()
                }
            } else {
                repository.log("❌ WLAN: Lỗi ghép nối - $msg", LogType.ERROR)
            }
        }
    }

    fun connectWirelessAdb(port: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyTitle = "Đang kết nối WLAN 127.0.0.1:$port..."
                )
            }
            try {
                val success = shellEngine.connectWirelessAdb(port)
                if (success) {
                    repository.log("WLAN: Đang kết nối thành công tại 127.0.0.1:$port! Đã kết nối Direct ADB (UID 2000 Độc Lập).", LogType.SUCCESS)
                    _uiState.update { it.copy(showWlanDialog = false) }
                    try {
                        com.example.core.adb.AdbPairingNotificationManager.stopInteractivePairingNotification(getApplication())
                    } catch (_: Throwable) {}
                    refreshAll()
                    autoGrantEverythingAfterWlan()
                } else {
                    repository.log("Không thể kết nối 127.0.0.1:$port. Hãy kiểm tra lại cổng gỡ lỗi hoặc ghép đôi nếu chưa ghép nối.", LogType.ERROR)
                }
            } finally {
                _uiState.update { it.copy(isBusy = false, busyTitle = "") }
            }
        }
    }

    fun disconnectWirelessAdb() {
        viewModelScope.launch(Dispatchers.IO) {
            shellEngine.disconnectWirelessAdb()
            repository.log("Đã ngắt kết nối gỡ lỗi WLAN • Giữ nguyên 100% trạng thái đã Fix trên máy!", LogType.SUCCESS)
            try {
                repository.refreshDeviceInfo()
                repository.refreshSetupStatus()
                repository.refreshTuneStatus()
            } catch (_: Throwable) {}
        }
    }

    fun autoConnectWlanAdb() {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyTitle = "Đang tự dò cổng Gỡ lỗi Wi-Fi & kết nối..."
                )
            }
            try {
                val (ok, port) = shellEngine.autoConnectBestWirelessAdb()
                if (ok && port != null) {
                    repository.log("⚡ [Tự Dò Đa Tầng] Kết nối Direct WLAN ADB thành công (Cổng $port • UID 2000)!", LogType.SUCCESS)
                    _uiState.update { it.copy(showWlanDialog = false) }
                    try {
                        com.example.core.adb.AdbPairingNotificationManager.finalizePairingSuccessUi(getApplication())
                    } catch (_: Throwable) {}
                    refreshAll()
                    autoGrantEverythingAfterWlan()
                } else {
                    val report = shellEngine.runWirelessAdbDiagnostics()
                    _adbDiagnosticReport.value = report
                    repository.log("⚠️ Tự dò WLAN thất bại: ${report.recommendedAction}", LogType.ERROR)
                    showSafeToast(report.recommendedAction, long = true)
                }
            } finally {
                _uiState.update { it.copy(isBusy = false, busyTitle = "") }
            }
        }
    }

    fun pingWlanAdb() {
        viewModelScope.launch(Dispatchers.IO) {
            val ms = shellEngine.pingWirelessAdbLatency()
            if (ms != null) {
                repository.log("⚡ Ping Direct ADB (${adbTelemetry.value.activeHost}:${adbTelemetry.value.activePort}): ${ms}ms • ${adbTelemetry.value.uidIdentity}", LogType.SUCCESS)
                showSafeToast("⚡ Ping ADB: ${ms}ms (${adbTelemetry.value.uidIdentity})")
            } else {
                repository.log("⚠️ Ping Direct ADB thất bại — hãy kiểm tra hoặc kết nối lại.", LogType.ERROR)
                showSafeToast("⚠️ Chưa có kết nối Direct ADB để đo Ping")
            }
        }
    }

    fun runWlanAdbDiagnostics() {
        viewModelScope.launch(Dispatchers.IO) {
            if (_isRunningAdbDiagnostics.value) return@launch
            _isRunningAdbDiagnostics.value = true
            try {
                val report = shellEngine.runWirelessAdbDiagnostics()
                _adbDiagnosticReport.value = report
                repository.log("🩺 Chẩn đoán WLAN ADB: ${report.recommendedAction}", if (report.overallReady) LogType.SUCCESS else LogType.INFO)
            } finally {
                _isRunningAdbDiagnostics.value = false
            }
        }
    }

    fun setFloatingKeypadEnabled(enabled: Boolean) {
        val app = getApplication<Application>()
        com.example.core.adb.AdbPairingNotificationManager.setFloatingKeypadEnabled(app, enabled)
        _isFloatingKeypadEnabled.value = enabled
        if (enabled && !android.provider.Settings.canDrawOverlays(app)) {
            showSafeToast("Cần bật quyền 'Hiển thị trên ứng dụng khác' để dùng Bảng Phím Nổi 6 Số.", long = true)
            AppPermissionChecker.requestOverlayPermission(app)
        }
    }

    fun resetWirelessAdbKeysAndCache() {
        viewModelScope.launch(Dispatchers.IO) {
            val success = com.example.core.adb.DirectAdbManager.getInstance(getApplication()).resetAdbKeys()
            if (success) {
                repository.log("🔄 Đã tạo mới cặp khóa RSA ADB & reset chứng chỉ TLS thành công! Hãy thực hiện lại kết nối hoặc ghép đôi.", LogType.SUCCESS)
                runWlanAdbDiagnostics()
            } else {
                repository.log("⚠️ Không thể tạo mới khóa RSA ADB.", LogType.ERROR)
            }
        }
    }

    fun setPermanentRefreshRateLock(rate: Int, lock: Boolean) {
        viewModelScope.launch {
            if (lock && !ensureAdbReadyOrPrompt("Khóa cứng tần số quét ${rate}Hz")) {
                return@launch
            }
            withContext(Dispatchers.IO) {
                repository.setPermanentRefreshRateLock(rate, lock)
            }
        }
    }

    fun setPermanentResolutionLock(mode: String, lock: Boolean) {
        viewModelScope.launch {
            if (!ensureAdbReadyOrPrompt("Khóa cứng độ phân giải màn hình")) {
                return@launch
            }
            withContext(Dispatchers.IO) {
                repository.setPermanentResolutionLock(mode, lock)
            }
        }
    }

    fun disableSafeConflictingOemFeatures() {
        viewModelScope.launch {
            val app = getApplication<Application>()
            val hasOfflineShieldGrant = try {
                shellEngine.state.value.hasPersistentGrant ||
                    com.example.core.permission.AppPermissionChecker.checkSelfPermissions(app).hasWriteSecureSettings
            } catch (_: Throwable) { false }

            if (!shellEngine.state.value.isAdbReady && !hasOfflineShieldGrant) {
                if (!ensureAdbReadyOrPrompt("Vô hiệu hóa xung đột hãng")) {
                    return@launch
                }
            }
            _uiState.update { it.copy(isBusy = true, busyTitle = "Đang khóa xung đột vĩnh viễn 7 tầng & hạ nhiệt máy...") }
            try {
                withContext(Dispatchers.IO) {
                    repository.disableSafeConflictingOemFeatures()
                }
            } finally {
                _uiState.update { it.copy(isBusy = false, busyTitle = "") }
            }
        }
    }

    fun restoreSafeConflictingOemFeatures() {
        viewModelScope.launch {
            if (!ensureAdbReadyOrPrompt("Khôi phục tính năng mặc định của hãng")) {
                return@launch
            }
            _uiState.update { it.copy(isBusy = true, busyTitle = "Đang khôi phục tính năng mặc định của hãng...") }
            try {
                withContext(Dispatchers.IO) {
                    repository.restoreSafeConflictingOemFeatures()
                }
            } finally {
                _uiState.update { it.copy(isBusy = false, busyTitle = "") }
            }
        }
    }

    fun disconnectSession() {
        viewModelScope.launch(Dispatchers.IO) {
            shellEngine.disconnectSession()
            repository.log("Đã chủ động ngắt phiên kết nối (Shizuku & WLAN) • Các thiết lập đã tối ưu vẫn được bảo toàn nguyên vẹn!", LogType.INFO)
            try {
                repository.refreshDeviceInfo()
                repository.refreshSetupStatus()
                repository.refreshTuneStatus()
                repository.refreshShizukuInfo()
            } catch (_: Throwable) {}
        }
    }

    fun openDeveloperSettings() {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            getApplication<Application>().startActivity(intent)
            repository.log("Đã mở Tùy chọn nhà phát triển. Hãy bật 'Gỡ lỗi qua Wi-Fi'.", LogType.INFO)
        } catch (_: Exception) {
            try {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                getApplication<Application>().startActivity(intent)
            } catch (_: Exception) {}
        }
    }

    fun openOverlayPermissionSettings() {
        try {
            val app = getApplication<Application>()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${app.packageName}")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                app.startActivity(intent)
                repository.log("Đã mở Cài đặt 'Hiển thị trên ứng dụng khác' cho MagicTune.", LogType.INFO)
            }
        } catch (_: Exception) {}
    }

    fun openSpecialAppAccess() {
        AppPermissionChecker.openSpecialAppAccess(getApplication())
        repository.log("Đã mở trang 'Quyền truy cập đặc biệt'. Hãy tìm MagicTune và cấp quyền 'Truy cập sử dụng' & 'Thay đổi cài đặt hệ thống'.", LogType.INFO)
    }

    fun repairHonorPermissions() = runAction("Đang sửa lỗi quyền Honor/MagicOS chuyên sâu...") {
        repository.log("🛠️ Đang thực thi kịch bản sửa lỗi quyền cho MagicOS...", LogType.COMMAND)
        shellEngine.autoGrantSelfPermissions()
        // Force repair Restricted Settings specifically
        val pkg = getApplication<Application>().packageName
        shellEngine.execute("cmd appops set $pkg ACCESS_RESTRICTED_SETTINGS allow || cmd appops set --user 0 $pkg ACCESS_RESTRICTED_SETTINGS allow || true")
        repository.log("✅ Đã hoàn tất sửa lỗi quyền Honor! Nếu vẫn chưa thấy MagicTune trong danh sách, hãy bấm 'Quyền đặc biệt' và tìm thủ công.", LogType.SUCCESS)
        checkSelfPermissions()
    }

    fun openAppDetailsSettings(pkg: String) {
        try {
            val app = getApplication<Application>()
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            app.startActivity(intent)
        } catch (_: Exception) {}
    }

    fun openAppNotificationSettings(pkg: String) {
        try {
            val app = getApplication<Application>()
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                    putExtra(Settings.EXTRA_APP_PACKAGE, pkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            } else {
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
            app.startActivity(intent)
        } catch (_: Exception) {}
    }

    fun openShizukuApp() {
        val app = getApplication<Application>()
        val shizukuPkg = "moe.shizuku.privileged.api"
        try {
            val launchIntent = app.packageManager.getLaunchIntentForPackage(shizukuPkg)?.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            } ?: Intent().apply {
                setClassName(shizukuPkg, "moe.shizuku.manager.MainActivity")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            app.startActivity(launchIntent)
            repository.log("Đã mở ứng dụng Shizuku. Hãy bấm 'Bắt đầu' (Start) hoặc cấp quyền cho MagicTune.", LogType.INFO)
        } catch (_: Exception) {
            try {
                android.widget.Toast.makeText(
                    app,
                    "📲 Máy chưa cài ứng dụng Shizuku. Đang mở trang tải Shizuku...",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            } catch (_: Throwable) {}
            openPlayStore(shizukuPkg)
        }
    }

    fun openPlayStore(pkg: String) {
        val app = getApplication<Application>()
        val pm = app.packageManager

        // CHỈ DUY NHẤT NÚT TẢI GOOGLE PLAY THÌ MỚI MỞ APP MARKET CỦA HONOR
        if (pkg == "com.android.vending") {
            val honorMarketPkgs = listOf("com.hihonor.appmarket", "com.huawei.appmarket")
            for (marketPkg in honorMarketPkgs) {
                // 1. Thử mở chi tiết com.android.vending trên App Market của Honor
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("appmarket://details?id=com.android.vending")).apply {
                        setPackage(marketPkg)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    app.startActivity(intent)
                    return
                } catch (_: Exception) {}

                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.android.vending")).apply {
                        setPackage(marketPkg)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    app.startActivity(intent)
                    return
                } catch (_: Exception) {}

                // 2. Thử tìm kiếm "Google Play" trong App Market của Honor
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=Google Play")).apply {
                        setPackage(marketPkg)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    app.startActivity(intent)
                    return
                } catch (_: Exception) {}

                // 3. Mở thẳng ứng dụng App Market của Honor
                try {
                    val launchIntent = pm.getLaunchIntentForPackage(marketPkg)?.apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (launchIntent != null) {
                        app.startActivity(launchIntent)
                        return
                    }
                } catch (_: Exception) {}
            }

            // Fallback nếu máy không có cả Honor App Market: mở trang web Google Play
            try {
                val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.android.vending")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                app.startActivity(fallbackIntent)
            } catch (_: Exception) {}
            return
        }

        // ƯU TIÊN TẤT CẢ CÁC NÚT TẢI KHÁC (ĐẶC BIỆT LÀ TRỢ LÝ GEMINI, GOOGLE LENS, YOUTUBE, ZALO...): MỞ THẲNG CH PLAY
        val playStorePackage = "com.android.vending"
        try {
            // 1. Ép mở trực tiếp Google Play Store (CH Play) bằng setPackage để App Market của Honor không cướp liên kết
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")).apply {
                setPackage(playStorePackage)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            app.startActivity(intent)
        } catch (_: Exception) {
            try {
                // 2. Nếu không mở được qua market://, mở URL play.google.com qua CH Play
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg")).apply {
                    setPackage(playStorePackage)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                app.startActivity(intent)
            } catch (_: Exception) {
                // 3. Fallback khi máy hoàn toàn chưa cài CH Play: Mở web Play Store qua trình duyệt
                try {
                    val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    app.startActivity(fallbackIntent)
                } catch (_: Exception) {}
            }
        }
    }

    fun openYouTubeChannel() {
        try {
            val url = com.example.core.license.LicenseManager.getCustomYouTubeUrl(getApplication())
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            getApplication<Application>().startActivity(intent)
            repository.log("Đang mở liên kết YouTube: $url", LogType.INFO)
        } catch (_: Exception) {}
    }

    private val activeActionCount = java.util.concurrent.atomic.AtomicInteger(0)
    @Volatile
    private var currentPriorityJob: kotlinx.coroutines.Job? = null

    /**
     * Ngắt ngay các lệnh cũ chưa xong và giải phóng tiến trình để ưu tiên lệnh mới nhất.
     */
    fun cancelOldCommandsAndFreeTerminal() {
        currentPriorityJob?.cancel()
        activeActionCount.set(0)
        _uiState.value = _uiState.value.copy(isBusy = false, busyTitle = "")
        viewModelScope.launch(Dispatchers.IO) {
            val killed = shellEngine.preemptRunningProcesses()
            if (killed > 0) {
                repository.log("⚡ Đã ngắt $killed tiến trình lệnh cũ đang chạy dở để giải phóng màn hình lệnh ADB ngay lập tức!", LogType.INFO)
            }
        }
    }

    private fun showSafeToast(message: String, long: Boolean = false) {
        val app = getApplication<Application>()
        val duration = if (long) android.widget.Toast.LENGTH_LONG else android.widget.Toast.LENGTH_SHORT
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            try { android.widget.Toast.makeText(app, message, duration).show() } catch (_: Throwable) {}
        } else {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                try { android.widget.Toast.makeText(app, message, duration).show() } catch (_: Throwable) {}
            }
        }
    }

    private suspend fun ensureAdbReadyOrPrompt(
        featureLabel: String,
        openWlanDialogOnFail: Boolean = true
    ): Boolean {
        if (!shellState.value.isAdbReady) {
            val shizukuPing = try { rikka.shizuku.Shizuku.pingBinder() } catch (_: Throwable) { false }
            if (shellEngine.directAdbManager.isConnected || shizukuPing) {
                withContext(Dispatchers.IO) {
                    try { shellEngine.refreshStatus() } catch (_: Throwable) {}
                }
            }
        }
        val isReady = shellState.value.isAdbReady ||
            (shizukuInfo.value.isRunning && shizukuInfo.value.isPermissionGranted)
        if (!isReady) {
            repository.log(
                "⚠️ CHƯA KẾT NỐI GỠ LỖI WLAN: Vui lòng kết nối Gỡ lỗi Wi-Fi (hoặc Shizuku) trước khi chạy: $featureLabel",
                LogType.ERROR
            )
            showSafeToast(
                "⚠️ Chưa kết nối Gỡ lỗi WLAN! Vui lòng kết nối Gỡ lỗi Wi-Fi trước khi chạy.",
                long = true
            )
            if (openWlanDialogOnFail) {
                _uiState.update { it.copy(showWlanDialog = true) }
            }
        }
        return isReady
    }

    private fun runAction(
        title: String,
        openTerminal: Boolean = true,
        preemptOld: Boolean = true,
        timeoutMs: Long = 600000L, // Cho phép các đợt lệnh chạy nối tiếp dài (VD: 29 đợt x 80 lệnh = 2320 lệnh) chạy trọn vẹn 100% không bị ngắt giữa chừng
        requireProOrTrial: Boolean = true,
        requireAdb: Boolean = true,
        block: suspend () -> Unit
    ) {
        val app = getApplication<Application>()
        val previousJob = currentPriorityJob
        val job = viewModelScope.launch {
            if (requireAdb && !ensureAdbReadyOrPrompt(title, openWlanDialogOnFail = true)) {
                return@launch
            }

            if (requireProOrTrial) {
                val (allowed, gateMessage) = withContext(Dispatchers.IO) {
                    com.example.core.license.LicenseManager.checkAndConsumeProOrTrial(app, title)
                }
                if (!allowed) {
                    repository.log(gateMessage, LogType.ERROR)
                    _uiState.value = _uiState.value.copy(
                        showUpgradeProDialog = true,
                        upgradeDialogReason = gateMessage,
                        showTerminalBottomSheet = true
                    )
                    showSafeToast("🔒 Đã hết lượt miễn phí! Vui lòng nâng cấp Bản PRO.", long = true)
                    return@launch
                } else {
                    repository.log(gateMessage, LogType.SUCCESS)
                }
            }

            if (preemptOld && (previousJob?.isActive == true || activeActionCount.get() > 0)) {
                previousJob?.cancel()
                withContext(Dispatchers.IO) {
                    val preempted = shellEngine.preemptRunningProcesses()
                    if (preempted > 0) {
                        repository.log("⚡ [Ưu tiên lệnh mới] Đã ngắt $preempted tiến trình cũ chưa xong để ưu tiên chạy ngay: $title", LogType.INFO)
                    }
                }
            }

            activeActionCount.incrementAndGet()
            _uiState.value = _uiState.value.copy(
                isBusy = true,
                busyTitle = title,
                showTerminalBottomSheet = if (openTerminal) true else _uiState.value.showTerminalBottomSheet
            )
            try {
                // Đảm bảo toàn bộ danh sách lệnh chạy nối tiếp tới đợt cuối cùng (29/29) không bao giờ bị giới hạn 25s
                kotlinx.coroutines.withTimeout(timeoutMs) {
                    withContext(Dispatchers.IO) {
                        block()
                    }
                }
            } catch (e: kotlinx.coroutines.TimeoutCancellationException) {
                withContext(Dispatchers.IO) {
                    shellEngine.preemptRunningProcesses()
                }
                repository.log("⏱️ Tiến trình đã chạy tối đa thời hạn ${timeoutMs / 1000}s.", LogType.INFO)
            } catch (_: kotlinx.coroutines.CancellationException) {
                // Đã nhường quyền ưu tiên cho lệnh mới nhất
            } catch (t: Throwable) {
                repository.log("❌ Tiến trình hoàn tất: ${t.localizedMessage ?: t.message}", LogType.INFO)
            } finally {
                val remaining = activeActionCount.decrementAndGet().coerceAtLeast(0)
                if (remaining == 0) {
                    _uiState.value = _uiState.value.copy(isBusy = false, busyTitle = "")
                }
                refreshAll()
            }
        }
        currentPriorityJob = job
    }

    fun runDiagnosticScan() = runAction("Đang quét kiểm tra thực tế kênh thông báo (dumpsys) & quyền app...", openTerminal = false, timeoutMs = 45000L, requireProOrTrial = false) {
        repository.runDiagnosticScan()
    }

    fun resetAndRescanNotifications() = runAction("Đang xóa bộ đệm cũ & quét lại thực tế toàn bộ ứng dụng...", openTerminal = false, timeoutMs = 45000L, requireProOrTrial = false) {
        repository.resetAndRescanNotifications()
    }

    fun fixSingleAppNotificationAndPerm(pkg: String, appName: String) =
        runAction("Đang mở Cài đặt Thông báo của $appName & tự động gạt công tắc tận mắt...", openTerminal = false, timeoutMs = 60000L) {
            repository.fixSingleAppGentleAndPermissions(pkg, appName)
        }

    fun grantSelfControlAndOverlayPermissions() =
        runAction("Đang cấp quyền điều khiển & hiển thị trên app khác...", requireProOrTrial = false) {
            repository.grantSelfControlAndOverlayPermissions()
        }

    fun stopLiveFloatingAutomation() {
        repository.stopLiveFloatingAutomation()
    }

    fun startLiveFloatingMiniWindowAutomation() {
        val app = getApplication<Application>()
        viewModelScope.launch {
            if (!ensureAdbReadyOrPrompt("Tự động mở Cài đặt & gạt công tắc tận mắt", openWlanDialogOnFail = true)) {
                return@launch
            }

            val (allowed, gateMessage) = withContext(Dispatchers.IO) {
                com.example.core.license.LicenseManager.checkAndConsumeProOrTrial(
                    app,
                    "Tự động mở Cài đặt & gạt công tắc tận mắt"
                )
            }
            if (!allowed) {
                repository.log(gateMessage, LogType.ERROR)
                _uiState.value = _uiState.value.copy(
                    showUpgradeProDialog = true,
                    upgradeDialogReason = gateMessage,
                    showTerminalBottomSheet = true
                )
                showSafeToast("🔒 Đã hết lượt miễn phí! Vui lòng kích hoạt Bản PRO để sử dụng tính năng này.", long = true)
                return@launch
            } else {
                repository.log(gateMessage, LogType.SUCCESS)
            }

            activeActionCount.incrementAndGet()
            _uiState.value = _uiState.value.copy(isBusy = true, busyTitle = "Đang tự động mở Cài đặt & gạt công tắc tận mắt...")
            try {
                withContext(Dispatchers.IO) {
                    repository.runLiveFloatingMiniWindowAutomation()
                }
            } catch (t: Throwable) {
                repository.log("❌ Lỗi cửa sổ nổi: ${t.localizedMessage ?: t.message}", LogType.ERROR)
            } finally {
                val remaining = activeActionCount.decrementAndGet().coerceAtLeast(0)
                if (remaining == 0) {
                    _uiState.value = _uiState.value.copy(isBusy = false, busyTitle = "")
                }
            }
        }
    }

    fun runOneClickSetup() = runAction("⚡ Đang chạy Siêu Thiết Lập 8-trong-1 Turbo (Chỉ các mục chưa đạt)...", timeoutMs = 90000L) {
        repository.runOneClickSetupMaster(onlyPending = true)
    }

    fun runOneClickSetupForceFull() = runAction("🔄 Đang chạy lại Toàn Diện 8/8 hạng mục Siêu Thiết Lập...", timeoutMs = 90000L) {
        repository.runOneClickSetupMaster(onlyPending = false)
    }

    fun setupVietnameseLanguage() = runAction("Đang cài Tiếng Việt & Giờ GMT+7...") {
        repository.setupVietnameseLanguage()
    }

    fun setupGoogleAndSync() = runAction("Đang bật Google & Đồng bộ danh bạ...") {
        repository.setupGoogleAndSync()
    }

    fun fixCallerIdAndWifi() = runAction("Đang sửa danh bạ +84 & Wi-Fi...") {
        repository.fixCallerIdAndWifi()
    }

    fun cleanChineseUi() = runAction("Đang dọn sạch chữ Trung & tắt YOYO...") {
        repository.cleanChineseUi()
    }

    fun replaceHonorSearch(disable: Boolean) = runAction(if (disable) "Đang thay thế Honor Search..." else "Đang khôi phục Honor Search...") {
        repository.replaceHonorSearch(disable)
    }

    fun blockHonorMarket() = runAction("Đang chặn Chợ App Honor tự cập nhật...") {
        repository.blockHonorMarket()
    }

    fun unblockHonorMarket() = runAction("Đang mở lại Tự động cập nhật App...") {
        repository.unblockHonorMarket()
    }

    fun toggleAppMarketUpdateBlock(currentBlocked: Boolean) {
        if (currentBlocked) {
            unblockHonorMarket()
        } else {
            blockHonorMarket()
        }
    }

    fun applyThermalCooling() = runAction("Đang bật Tiết kiệm pin Android qua ADB...") {
        repository.applyThermalCooling()
    }

    fun setupKeyboard() = runAction("Đang cài đặt bàn phím...") {
        repository.setupKeyboard()
    }

    fun setupGpsVietnam() = runAction("Đang cấu hình GPS nhạy...") {
        repository.setupGpsVietnam()
    }

    fun refreshGpsSatellites() = runAction("Đang xóa bộ đệm & nạp lại vệ tinh A-GPS...") {
        repository.refreshGpsSatellites()
    }

    fun fixAllNotifications() = runAction("Đang kiểm tra & chỉ sửa các app gặp lỗi thông báo / quyền...", timeoutMs = 90000L) {
        repository.optimizeAllApps()
    }

    fun batchGrantAllSystemPermissions() = runAction("Đang tự động cấp toàn bộ quyền hệ thống, chạy ngầm & pin hàng loạt (Chạy ngầm)...", timeoutMs = 90000L) {
        repository.optimizeAllApps()
    }

    fun fixFacebook() = runAction("Đang đặc trị thông báo Gmail & Các App Meta (trừ Facebook chính)...") {
        repository.fixGmailAndFacebookNuclear()
    }

    fun fixGmailAndFacebookNuclear() = runAction("Đang đặc trị thông báo Gmail & Các App Meta (trừ Facebook chính)...") {
        repository.fixGmailAndFacebookNuclear()
    }

    fun restoreGmailAndFacebookDefault() = runAction("Đang khôi phục cài đặt mặc định gốc cho Gmail & Meta...") {
        repository.restoreGmailAndFacebookDefault()
    }

    fun toggleSearchNotification(enable: Boolean) {
        com.example.core.service.MagicTuneKeepAliveService.setSearchNotificationEnabled(getApplication(), enable)
        com.example.core.service.MagicTuneKeepAliveService.syncServiceNeed(getApplication(), "MagicTune Pinned Search")
        _uiState.value = _uiState.value.copy(isSearchNotificationEnabled = enable)
    }

    fun toggleChargingNotification(enable: Boolean) {
        com.example.core.service.MagicTuneKeepAliveService.setChargingNotificationEnabled(getApplication(), enable)
        com.example.core.service.MagicTuneKeepAliveService.syncServiceNeed(getApplication(), "Charging Notif Toggle")
        _uiState.value = _uiState.value.copy(isChargingNotificationEnabled = enable)
    }

    fun toggleAutoCooling(enable: Boolean) {
        com.example.core.service.MagicTuneKeepAliveService.setAutoCoolingEnabled(getApplication(), false)
        com.example.core.service.MagicTuneKeepAliveService.syncServiceNeed(getApplication(), "Disable background thermal polling")
        _uiState.value = _uiState.value.copy(isAutoCoolingEnabled = false)
    }

    fun fixNotificationSettingsOnly() = runAction("Đang sửa riêng cài đặt Thông báo Màn hình khóa & Biểu ngữ...") {
        repository.fixNotificationSettingsOnly()
    }

    fun fixAppPermissionsOnly() = runAction("Đang sửa riêng Quyền hạn Chạy ngầm & Đánh thức App...") {
        repository.fixAppPermissionsOnly()
    }

    fun boostGmailAndFacebookBatching() = runAction("Đang phá gom cụm 0s cho Gmail & Các App Meta (Messenger, Instagram, Threads, WhatsApp)...") {
        repository.boostGmailAndFacebookBatching()
    }

    fun prioritizeAppCustomSounds() = runAction("Đang ưu tiên chuông riêng & chống câm...") {
        repository.prioritizeAppCustomSounds()
    }

    fun removePowerGenius() = runAction("Đang tắt diệt ngầm PowerGenius...") {
        repository.removePowerGeniusAndIaware()
    }

    fun testPushNotification(pkg: String = "com.facebook.orca", appName: String = "Messenger") =
        runAction("Đang bắn thử thông báo test...") {
            repository.testPushNotification(pkg, appName)
        }

    fun debloatSafeApps() = runAction("Đang gỡ bỏ app rác cấp 1...") {
        repository.batchDebloatLevel1()
    }

    fun uninstallApp(pkg: String) = runAction("Đang gỡ $pkg...") {
        repository.uninstallApp(pkg)
    }

    fun restoreApp(pkg: String) = runAction("Đang khôi phục $pkg...") {
        repository.restoreApp(pkg)
    }

    fun applySmartBatterySaver() = runAction("Đang kích hoạt Siêu Tiết Kiệm Pin Thông Minh...") {
        repository.applySmartBatterySaver()
    }

    fun enhanceBottomGestureSensitivity() = runAction("Đang tăng độ nhạy vuốt mép đáy & fix kính cường lực...") {
        repository.enhanceBottomGestureSensitivity()
    }

    fun boostTouchAndFingerprintSensitivity() = runAction("⚡ Đang kích hoạt Tối Ưu Cảm Ứng & Vân Tay Cường Lực Dày (>0.45mm)...") {
        repository.boostTouchAndFingerprintSensitivity()
    }

    fun revertTouchAndFingerprintSensitivity() = runAction("🔄 Đang khôi phục cài đặt cảm ứng mặc định...") {
        repository.revertTouchAndFingerprintSensitivity()
    }

    fun boostWifiSpeedAndLatency() = runAction("🚀 Đang tăng tốc độ Wi-Fi & giảm độ trễ...") {
        repository.boostWifiSpeedAndLatency()
    }

    fun boostDualWifiAndLinkTurbo() = runAction("📶 Đang kích hoạt Wi-Fi kép & tăng tốc Link Turbo...") {
        repository.boostDualWifiAndLinkTurbo()
    }

    fun applyAlwaysOnNetworkBatterySaver() = runAction("🔋 Đang kích hoạt siêu tiết kiệm pin kết nối luôn bật...") {
        repository.applyAlwaysOnNetworkBatterySaver()
    }

    fun restoreDefaultNetworkAndBatterySettings() = runAction("🔄 Đang khôi phục cài đặt mạng mặc định...") {
        repository.restoreDefaultNetworkAndBatterySettings()
    }

    fun applyVaporChamberCooling() = runAction("⚡ Đang bật/khôi phục chế độ Tiết kiệm pin Android qua ADB...") {
        repository.applyVaporChamberCooling()
    }

    fun applyIosFluidSmoothness() = runAction("⚡ Đang kích hoạt độ mượt mà & cảm ứng MagicOS...") {
        repository.applyIosFluidSmoothness()
    }

    fun restoreDefaultSmoothnessAndThermal() = runAction("🔄 Đang khôi phục cài đặt mượt mà & tản nhiệt...") {
        repository.restoreDefaultSmoothnessAndThermal()
    }

    fun applyIosBatteryEngine() = runAction("🔋 Đang kích hoạt động cơ pin trâu thông minh Honor (20H SOT & 100% full thông báo)...") {
        repository.applyIosBatteryEngine()
    }

    fun restoreDefaultBatteryEngine() = runAction("🔄 Đang khôi phục cài đặt pin về mặc định...") {
        repository.restoreDefaultBatteryEngine()
    }

    fun applyMaxSettings() = runAction("Đang kích hoạt Max Setting 120/144Hz...") {
        repository.applyMaxSettings()
    }

    fun setRefreshRate(hz: Int) = runAction("Đang đặt tần số quét ${hz}Hz...") {
        repository.setRefreshRate(hz)
    }

    fun setAnimationScale(scale: Float) = runAction("Đang chỉnh Animation ${scale}x...") {
        repository.setAnimationScale(scale)
    }

    fun disableYoyoNavigationWake() = runAction("Đang tắt công tắc nhấn thanh điều hướng đánh thức YOYO...") {
        repository.disableYoyoNavigationWake()
    }

    fun remapNavBarToGoogleAssistant() = runAction("Đang chuyển đổi thanh điều hướng sang Google/Trợ lý Magic...") {
        repository.remapNavBarToGoogleAssistant()
    }

    fun modNavBarToCircleToSearch() = runAction(
        title = "Đang kích hoạt Khoanh tròn hỏi AI & Trợ lý Magic (Giữ nguyên YOYO • Không cần ADB)...",
        requireProOrTrial = false,
        requireAdb = false
    ) {
        repository.modNavBarToCircleToSearch()
    }

    fun modNavBarToMagicLive() = runAction(
        title = "Đang kích hoạt Magic Live AI & Khoanh tròn hỏi AI (Giữ nguyên YOYO • Không cần ADB)...",
        requireProOrTrial = false,
        requireAdb = false
    ) {
        repository.modNavBarToMagicLive()
    }

    fun toggleMagicLive() = runAction(
        title = "Đang Bật / Tắt tính năng Gọi Trợ lý Magic & Micro...",
        requireProOrTrial = false,
        requireAdb = false
    ) {
        val currentMode = com.example.core.service.SystemFloatingHudOverlay.getActiveNavModMode(getApplication())
        if (tuneStatus.value.isMagicLiveEnabled && currentMode == "MAGIC_LIVE") {
            repository.disableMagicLiveMod()
        } else {
            repository.modNavBarToMagicLive()
        }
    }

    fun setMagicTuneAsDefaultAssistant() = runAction(
        title = "Đang mở thiết lập Trợ lý ảo mặc định...",
        requireProOrTrial = false,
        requireAdb = false
    ) {
        repository.setMagicTuneAsDefaultAssistant()
    }

    fun testTriggerNavAssistantNow() {
        viewModelScope.launch(Dispatchers.Main) {
            try {
                com.example.core.service.SystemFloatingHudOverlay.triggerRightGestureLauncherNow(getApplication())
            } catch (e: Throwable) {
                android.util.Log.e("MagicTune", "Lỗi mở bảng vẽ ứng dụng: ${e.message}", e)
            }
        }
    }

    fun testCircleToSearchNow() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                com.example.core.service.SystemFloatingHudOverlay.triggerConfiguredAssistantNow(
                    getApplication(),
                    explicitMode = "CIRCLE_TO_SEARCH"
                )
            } catch (e: Throwable) {
                android.util.Log.e("MagicTune", "Lỗi gọi thử khoanh tròn: ${e.message}", e)
            }
        }
    }

    fun restoreYoyoOriginal() = runAction("Đang trả 2 phím về 2 mép & khôi phục YOYO Agent gốc của Honor...") {
        repository.restoreYoyoOriginal()
    }

    fun setNavPillsCenteredAndSyncYoyo(centered: Boolean) = runAction(
        title = if (centered) "🎯 Đang đẩy 2 phím điều hướng vào GIỮA màn hình & vô hiệu hóa YOYO..."
        else "↔️ Đang trả 2 phím điều hướng về 2 MÉP màn hình & khôi phục YOYO...",
        requireProOrTrial = false,
        requireAdb = false
    ) {
        repository.setNavPillsCenteredAndSyncYoyo(centered)
    }

    fun toggleNavigationBarPill(hide: Boolean) = runAction(if (hide) "Đang ẩn thanh kim..." else "Đang hiện thanh kim...") {
        repository.toggleNavigationBarPill(hide)
    }

    fun toggleDeviceFeature(featureId: String, currentEnabled: Boolean) = runAction(
        "Đang cập nhật tính năng thiết bị...",
        requireAdb = false
    ) {
        repository.toggleDeviceFeature(featureId, currentEnabled)
    }

    fun hideNavigationBar() = runAction("Đang ẩn thanh kim & tắt gọi YOYO...") {
        repository.hideNavigationBarPill()
    }

    fun fixAudio() = runAction("Đang sửa rè âm thanh 48kHz...") {
        repository.fixAudioDistortion()
    }

    fun fixAndroidAuto() = runAction("Đang tối ưu & Cấp full quyền Android Auto...") {
        repository.fixAndroidAuto()
    }

    fun setFontBoldLarge(enabled: Boolean) = runAction("Đang điều chỉnh font chữ...") {
        repository.setFontBoldLarge(enabled)
    }

    fun setDarkModeOled(enabled: Boolean) = runAction("Đang chuyển đổi Dark Mode...") {
        repository.setDarkModeOled(enabled)
    }

    fun unlockSecureScreenshot() = runAction("Đang mở khóa chụp màn hình...") {
        repository.unlockSecureScreenshot()
    }

    fun enableAdBlocker() = runAction("Đang kích hoạt Chặn Quảng Cáo Toàn Diện...") {
        repository.enableAdBlocker()
    }

    fun disableAdBlocker() = runAction("Đang tắt Chặn Quảng Cáo...") {
        repository.disableAdBlocker()
    }

    fun grantAllPermissions() = runAction("Đang kiểm tra & cấp quyền cho các app còn thiếu...", timeoutMs = 90000L) {
        repository.grantAllPermissionsAllApps()
    }

    fun protectShizukuImmortal() = runAction("Đang bật Khiên Bất Tử Shizuku...") {
        repository.protectShizukuImmortal()
    }

    fun authorizeShizukuCompanions() = runAction("Đang cấp quyền hệ sinh thái Shizuku...") {
        repository.authorizeShizukuCompanions()
    }

    fun revertSingleCategory(categoryId: String) = runAction("Đang hoàn tác hạng mục đã chọn...", requireProOrTrial = false, requireAdb = false) {
        repository.revertCategory(categoryId)
    }

    fun revertSelectedCategories(categoryIds: List<String>) = runAction("Đang hoàn tác ${categoryIds.size} hạng mục đã chọn...", timeoutMs = 60000L, requireProOrTrial = false, requireAdb = false) {
        repository.revertSelectedCategories(categoryIds)
        _uiState.value = _uiState.value.copy(showRevertModal = false)
    }

    fun restoreFactoryDefault() = runAction("Đang khôi phục toàn bộ 100% cài đặt gốc...", timeoutMs = 90000L, requireProOrTrial = false, requireAdb = false) {
        repository.restoreAllToFactoryDefault()
        _uiState.value = _uiState.value.copy(showRevertModal = false)
    }

    fun runCustomShellCommand(cmd: String) {
        // Luôn ưu tiên thực thi ngay lập tức lệnh mới nhất do người dùng nhập/bấm trong màn hình lệnh ADB!
        runAction("⚡ Đang chạy ưu tiên lệnh Shell: $cmd", openTerminal = true, preemptOld = true) {
            repository.runShell(cmd, true)
        }
    }

    // -------------------------------------------------------------
    // 5 QUYỀN NĂNG HỆ THỐNG CHUYÊN SÂU v2.5 (ANDROID 11 -> ANDROID 17)
    // -------------------------------------------------------------
    fun enableStealthDeveloperModeBypass() = runAction("🛡️ Đang tắt sạch cờ ADB/Gỡ lỗi Wi-Fi & ẩn Chế độ nhà phát triển...") {
        repository.enableStealthDeveloperModeBypass(silent = false, deepCleanAllAdb = true)
    }

    fun restoreDeveloperModeVisibility() = runAction("🔓 Đang hiển thị lại menu Tùy chọn nhà phát triển...") {
        repository.restoreDeveloperModeVisibility()
    }

    fun unlockAndInspectRestrictedStorage() = runAction("📂 Đang mở khóa & đọc trực tiếp Android/data và Android/obb...") {
        repository.unlockAndInspectRestrictedStorage()
    }

    fun extractAndSyncRestrictedObbAndData() = runAction("📦 Đang giải nén & đồng bộ dữ liệu vào Android/data & Android/obb...") {
        repository.extractAndSyncRestrictedObbAndData()
    }

    fun cleanRestrictedAppCaches() = runAction("🧹 Đang dọn sạch bộ nhớ đệm sâu trong Android/data/*/cache...") {
        repository.cleanRestrictedAppCaches()
    }

    fun freezeAppPackage(pkg: String, freeze: Boolean) = runAction(if (freeze) "❄️ Đang đóng băng $pkg..." else "🔥 Đang mở băng $pkg...") {
        repository.freezeAppPackage(pkg, freeze)
    }

    fun revokeSensitivePermissionsFromApp(pkg: String) = runAction("🔒 Đang thu hồi quyền nhạy cảm của $pkg...") {
        repository.revokeSensitivePermissionsFromApp(pkg)
    }

    fun toggleDeepPrivacySensor(sensorType: String, block: Boolean) = runAction("🛡️ Đang cập nhật khóa cảm biến quyền riêng tư ($sensorType)...") {
        repository.toggleDeepPrivacySensor(sensorType, block)
    }

    fun runSystemAutomationMacro(macroType: String) = runAction("🤖 Đang thực thi kịch bản tự động hóa: $macroType...") {
        repository.runSystemAutomationMacro(macroType)
    }

    fun setSharedPrintUri(uri: Uri?) {
        _uiState.value = _uiState.value.copy(
            sharedPrintUri = uri,
            currentTab = if (uri != null) MainTab.PRINTER else _uiState.value.currentTab
        )
    }

    fun setPrintStatusMessage(msg: String) {
        _uiState.value = _uiState.value.copy(printStatusMessage = msg)
    }

    fun setIsPrinting(printing: Boolean) {
        _uiState.value = _uiState.value.copy(isPrinting = printing)
    }

    fun applyUniversalOemNotificationFix() = runAction("🌐 Đang kích hoạt chế độ Fix Trễ Thông Báo Tổng Lực Đa Hãng...") {
        repository.applyUniversalOemNotificationFix()
    }

    fun fixXiaomiMiuiNotificationLag() = runAction("📱 Đang can thiệp MIUI & HyperOS (Tắt Joyose/PowerKeeper)...") {
        repository.fixXiaomiMiuiNotificationLag()
    }

    fun fixOppoRealmeNotificationLag() = runAction("📱 Đang vô hiệu hóa Athena & Deep Sleep trên ColorOS...") {
        repository.fixOppoRealmeNotificationLag()
    }

    fun fixVivoIqooNotificationLag() = runAction("📱 Đang ngắt iManager & Night Idle Sleep trên OriginOS...") {
        repository.fixVivoIqooNotificationLag()
    }

    fun fixHuaweiHarmonyNotificationLag() = runAction("📱 Đang ngắt PowerGenie trên EMUI / HarmonyOS...") {
        repository.fixHuaweiHarmonyNotificationLag()
    }

    fun fixSamsungOneUiLag() = runAction("📱 Đang tối ưu One UI, ngắt Device Care Sleep & RAM Plus...") {
        repository.fixSamsungOneUiLag()
    }

    fun fixMeizuFlymeLag() = runAction("📱 Đang ngắt OneMind ngủ đông & cấp quyền Flyme OS...") {
        repository.fixMeizuFlymeLag()
    }

    fun fixAsusRogLag() = runAction("📱 Đang ngắt PowerMaster & Doze trên Asus ROG / Sony...") {
        repository.fixAsusRogLag()
    }

    fun revertOemOptimization() = runAction("🔄 Đang khôi phục cài đặt OEM về mặc định...") {
        repository.revertOemOptimization()
    }
}
