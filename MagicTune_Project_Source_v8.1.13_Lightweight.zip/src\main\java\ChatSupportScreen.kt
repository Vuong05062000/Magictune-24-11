package com.example.ui.components



import android.content.Context

import android.net.Uri

import android.util.Base64

import androidx.activity.compose.rememberLauncherForActivityResult

import androidx.activity.result.PickVisualMediaRequest

import androidx.activity.result.contract.ActivityResultContracts

import androidx.compose.foundation.BorderStroke

import androidx.compose.foundation.background

import androidx.compose.foundation.border

import androidx.compose.foundation.clickable

import androidx.compose.foundation.horizontalScroll

import androidx.compose.foundation.layout.*

import androidx.compose.foundation.lazy.LazyColumn

import androidx.compose.foundation.lazy.items

import androidx.compose.foundation.lazy.rememberLazyListState

import androidx.compose.foundation.rememberScrollState

import androidx.compose.foundation.shape.CircleShape

import androidx.compose.foundation.shape.RoundedCornerShape

import androidx.compose.material.icons.Icons

import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.HorizontalDivider

import androidx.compose.material3.*

import androidx.compose.runtime.*

import androidx.compose.ui.Alignment

import androidx.compose.ui.Modifier

import androidx.compose.ui.draw.clip

import androidx.compose.ui.graphics.Brush

import androidx.compose.ui.graphics.Color

import androidx.compose.ui.platform.LocalContext

import androidx.compose.ui.text.font.FontWeight

import androidx.compose.ui.unit.dp

import androidx.compose.ui.unit.sp

import com.example.core.license.LicenseManager

import com.example.ui.theme.*

import kotlinx.coroutines.Dispatchers

import kotlinx.coroutines.launch

import kotlinx.coroutines.withContext

import java.net.HttpURLConnection

import java.net.URL



data class ChatMessage(

    val id: String = java.util.UUID.randomUUID().toString(),

    val sender: String, // "user" hoặc "support"

    val text: String,

    val timestamp: Long = System.currentTimeMillis(),

    val translatedText: String? = null,

    val isTranslating: Boolean = false

)



/**

 * Kiểm tra xem tin nhắn có phải là Tiếng Việt hay không.

 * - Nếu là Tiếng Việt (có dấu Tiếng Việt hoặc các từ khóa Tiếng Việt phổ biến, không chứa chữ tượng hình ngoại quốc): trả về true -> ẩn nút Dịch.

 * - Nếu là ngoại ngữ (Tiếng Trung, Anh, Hàn, Nhật, Nga...): trả về false -> hiện nút "🌐 Dịch sang Tiếng Việt".

 */

private fun isVietnameseMessage(text: String): Boolean {

    val trimmed = text.trim()

    if (trimmed.isBlank()) return true

    if (trimmed.startsWith("[Đã gửi hình ảnh")) return true



    // Nếu chứa chữ Trung / Nhật / Hàn / Thái / Nga thì chắc chắn cần hiện nút dịch

    val foreignScriptRegex = Regex("[\\u4E00-\\u9FFF\\u3040-\\u30FF\\uAC00-\\uD7AF\\u0400-\\u04FF\\u0E00-\\u0E7F]")

    if (foreignScriptRegex.containsMatchIn(trimmed)) {

        return false

    }



    // Kiểm tra các ký tự nguyên âm có dấu đặc trưng của Tiếng Việt

    val vnDiacriticsRegex = Regex("[àáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđÀÁẢÃẠĂẰẮẲẴẶÂẦẤẨẪẬÈÉẺẼẸÊỀẾỂỄỆÌÍỈĨỊÒÓỎÕỌÔỒỐỔỖỘƠỜỚỞỠỢÙÚỦŨỤƯỪỨỬỮỰỲÝỶỸỴĐ]")

    if (vnDiacriticsRegex.containsMatchIn(trimmed)) {

        return true

    }



    // Trường hợp người dùng gõ Tiếng Việt không dấu

    val lower = " ${trimmed.lowercase()} "

    val vnUnaccentedKeywords = listOf(

        " xin chao ", " chao ", " cam on ", " huong dan ", " ung dung ", " thiet bi ",

        " tai khoan ", " chuyen khoan ", " cai dat ", " thong bao ", " man hinh ",

        " khoanh tron ", " dich ", " may in ", " ngan hang ", " lam sao ", " cach dung ",

        " giup minh ", " nang cap ", " kich hoat ", " khong duoc ", " bi loi ", " cua minh ",

        " cho hoi ", " bao nhieu ", " tien ", " quyen ", " ket noi ", " ma 6 so "

    )

    if (vnUnaccentedKeywords.any { lower.contains(it) }) {

        return true

    }



    return false

}



@Composable

fun ChatSupportScreen(

    onNavigateBack: () -> Unit

) {

    val context = LocalContext.current

    val coroutineScope = rememberCoroutineScope()

    val listState = rememberLazyListState()

    androidx.activity.compose.BackHandler {
        onNavigateBack()
    }



    var inputMessage by remember { mutableStateOf("") }

    val messagesList = remember {

        mutableStateListOf(

            ChatMessage(

                sender = "support",

                text = "Xin chào! Tôi là Trợ lý hỗ trợ & quản trị tự động của ứng dụng **MagicTune ${com.example.data.APP_VERSION_NAME}**.\n\n" +

                    "• Tôi nắm vững **100% mọi chức năng trong ứng dụng**: Đánh thức thông minh Gmail & Facebook bằng AI, Giữ nguyên YOYO dùng song song với Google Khoanh tròn & Trợ lý Magic (không cần ADB), Xuyên thấu 1 chạm thanh điều hướng tránh ấn nhầm Dock, Chuyển khởi chạy thủ công chống tắt quyền Trợ năng trên MagicOS, Cuộn & Dịch Taobao/1688 tự đổi tiền VNĐ, Ẩn nhà phát triển mở full ứng dụng tài chính & bảo mật cao, Máy in nhiệt K80, và Gói bản quyền Pro.\n" +

                    "• Nhấn biểu tượng hình ảnh 🖼️ bên dưới để gửi ảnh chụp biên lai (bill) chuyển khoản — hệ thống sẽ tự động kiểm duyệt và kích hoạt quyền Pro cho bạn ngay lập tức!\n" +

                    "• 📌 **BẢO LƯU PRO VĨNH VIỄN 100%:** Mỗi thiết bị được cấp cố định một Key duy nhất hoặc bạn chỉ cần **ĐĂNG NHẬP TÀI KHOẢN** để được tự động khôi phục 100% bản Pro trên đám mây bất cứ lúc nào!"

            )

        )

    }

    var isAiGenerating by remember { mutableStateOf(false) }



    val imagePickerLauncher = rememberLauncherForActivityResult(

        contract = ActivityResultContracts.PickVisualMedia()

    ) { uri: Uri? ->

        if (uri != null) {

            messagesList.add(ChatMessage(sender = "user", text = "[Đã gửi hình ảnh biên lai / bill chuyển khoản]"))

            isAiGenerating = true

            coroutineScope.launch {
                try {
                    val analysisResult = analyzeBillAutomatically(context, uri)
                    messagesList.add(ChatMessage(sender = "support", text = analysisResult))
                } catch (t: Throwable) {
                    messagesList.add(ChatMessage(sender = "support", text = "⚠️ Không thể phân tích hóa đơn: ${t.localizedMessage ?: "Vui lòng kiểm tra kết nối mạng và thử lại."}"))
                } finally {
                    isAiGenerating = false
                }
            }

        }

    }



    LaunchedEffect(Unit) {
        try {
            com.example.core.adb.AdbNsdScanner.getInstance(context).releaseMulticastLock()
        } catch (_: Throwable) {}
    }

    // Tự động cuộn xuống tin nhắn mới nhất

    LaunchedEffect(messagesList.size) {

        if (messagesList.isNotEmpty()) {

            listState.animateScrollToItem(messagesList.size - 1)

        }

    }



    Column(

        modifier = Modifier

            .fillMaxSize()

            .background(MagicDarkBackground)

    ) {

        // Top Bar

        Row(

            modifier = Modifier

                .fillMaxWidth()

                .background(MagicSurfaceCard)

                .border(BorderStroke(1.dp, MagicBorder))

                .padding(horizontal = 16.dp, vertical = 12.dp),

            horizontalArrangement = Arrangement.SpaceBetween,

            verticalAlignment = Alignment.CenterVertically

        ) {

            Row(

                verticalAlignment = Alignment.CenterVertically,

                horizontalArrangement = Arrangement.spacedBy(10.dp)

            ) {

                IconButton(onClick = onNavigateBack) {

                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại", tint = Color.White)

                }

                Column {

                    Row(

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.spacedBy(6.dp)

                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicCyan.copy(alpha = 0.22f))
                                .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Ô #63",
                                color = MagicCyanLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        Text(

                            text = "💬 Trợ Lý Hỗ Trợ & Duyệt Pro",

                            color = Color.White,

                            fontSize = 14.sp,

                            fontWeight = FontWeight.Black

                        )

                        Box(

                            modifier = Modifier

                                .size(8.dp)

                                .clip(CircleShape)

                                .background(MagicEmerald)

                        )

                    }

                    Text(

                        text = "Hướng dẫn tính năng 24/7 & Tự động duyệt bill nâng cấp Pro",

                        color = MagicCyanLight,

                        fontSize = 10.sp

                    )

                }

            }



            // Nút xóa lịch sử chat

            IconButton(onClick = {

                messagesList.clear()

                messagesList.add(

                    ChatMessage(

                        sender = "support",

                        text = "Đã làm mới cuộc hội thoại. Bạn cần hướng dẫn tính năng nào trong ứng dụng hoặc gửi ảnh bill chuyển khoản để kích hoạt Pro không?"

                    )

                )

            }) {

                Icon(imageVector = Icons.Default.Refresh, contentDescription = "Làm mới", tint = Color(0xFF94A3B8))

            }

        }



        // Thanh gợi ý câu hỏi nhanh giúp người dùng bấm 1 chạm để hỏi đúng trọng tâm

        val quickQuestions = remember {
            listOf(
                "🤖 Cách đánh thức Gmail & Facebook bằng AI không trễ thông báo?",
                "🤝 Cách vừa giữ YOYO vừa dùng Trợ lý Magic & Khoanh tròn?",
                "🛡️ Chống MagicOS tự tắt quyền Trợ năng (Khởi chạy thủ công)?",
                "🔑 Cách lưu Key & khôi phục Pro 100% khi cài lại máy?",
                "🌐 Cách dùng Dịch tin nhắn đối phương & Cuộn dịch Taobao/1688?",
                "👑 Khác nhau giữa Pro Máy & Pro Tài Khoản?",
                "🏦 Sửa lỗi MB Bank báo ứng dụng rủi ro?",
                "🔗 Cách dùng ngay không cần ADB hoặc kết nối Mã 6 số?"
            )
        }

        Row(

            modifier = Modifier

                .fillMaxWidth()

                .background(MagicSurfaceDark)

                .horizontalScroll(rememberScrollState())

                .padding(horizontal = 12.dp, vertical = 8.dp),

            horizontalArrangement = Arrangement.spacedBy(8.dp)

        ) {

            quickQuestions.forEach { q ->

                Surface(

                    modifier = Modifier

                        .clip(RoundedCornerShape(16.dp))

                        .clickable(enabled = !isAiGenerating) {

                            messagesList.add(ChatMessage(sender = "user", text = q))

                            isAiGenerating = true

                            coroutineScope.launch {
                                try {
                                    val reply = fetchSupportResponse(context, q, messagesList.toList())
                                    messagesList.add(ChatMessage(sender = "support", text = reply))
                                } catch (t: Throwable) {
                                    messagesList.add(ChatMessage(sender = "support", text = "⚠️ Lỗi phản hồi: ${t.localizedMessage ?: "Mạng yếu, vui lòng thử lại sau giây lát."}"))
                                } finally {
                                    isAiGenerating = false
                                }
                            }

                        },

                    color = MagicSurfaceCard,

                    border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.35f)),

                    shape = RoundedCornerShape(16.dp)

                ) {

                    Text(

                        text = q,

                        color = MagicCyanLight,

                        fontSize = 10.5.sp,

                        fontWeight = FontWeight.SemiBold,

                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)

                    )

                }

            }

        }



        // Danh sách tin nhắn

        LazyColumn(

            state = listState,

            modifier = Modifier

                .weight(1f)

                .fillMaxWidth()

                .padding(horizontal = 16.dp),

            verticalArrangement = Arrangement.spacedBy(12.dp),

            contentPadding = PaddingValues(vertical = 16.dp)

        ) {

            items(messagesList, key = { it.id }) { msg ->

                ChatBubbleItem(

                    message = msg,

                    onTranslateMessage = {

                        coroutineScope.launch {
                            try {
                                translateForeignMessageToVietnamese(context, msg, messagesList)
                            } catch (_: Throwable) {}
                        }

                    }

                )

            }



            if (isAiGenerating) {

                item {

                    Row(

                        modifier = Modifier.fillMaxWidth(),

                        horizontalArrangement = Arrangement.Start,

                        verticalAlignment = Alignment.CenterVertically

                    ) {

                        Box(

                            modifier = Modifier

                                .clip(RoundedCornerShape(12.dp))

                                .background(MagicSurfaceCard)

                                .border(1.dp, MagicBorder, RoundedCornerShape(12.dp))

                                .padding(12.dp)

                        ) {

                            Row(

                                verticalAlignment = Alignment.CenterVertically,

                                horizontalArrangement = Arrangement.spacedBy(8.dp)

                            ) {

                                CircularProgressIndicator(

                                    color = MagicCyan,

                                    strokeWidth = 2.dp,

                                    modifier = Modifier.size(16.dp)

                                )

                                Text(

                                    text = "Đang xử lý yêu cầu & kiểm tra thông tin...",

                                    color = Color(0xFF94A3B8),

                                    fontSize = 11.5.sp

                                )

                            }

                        }

                    }

                }

            }

        }



        // Input Bar & Gửi tin nhắn / Gửi ảnh bill

        Row(

            modifier = Modifier

                .fillMaxWidth()

                .background(MagicSurfaceCard)

                .border(BorderStroke(1.dp, MagicBorder))

                .padding(12.dp),

            verticalAlignment = Alignment.CenterVertically,

            horizontalArrangement = Arrangement.spacedBy(8.dp)

        ) {

            // Nút đính kèm ảnh bill chuyển khoản

            IconButton(

                onClick = {

                    try {
                        imagePickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    } catch (_: Exception) {
                        android.widget.Toast.makeText(context, "⚠️ Không thể mở thư viện ảnh trên thiết bị này.", android.widget.Toast.LENGTH_SHORT).show()
                    }

                },

                modifier = Modifier.size(42.dp)

            ) {

                Icon(

                    imageVector = Icons.Default.Image,

                    contentDescription = "Gửi bill chuyển khoản",

                    tint = MagicCyan

                )

            }



            OutlinedTextField(

                value = inputMessage,

                onValueChange = { inputMessage = it },

                placeholder = { Text("Hỏi cách dùng tính năng hoặc gửi ảnh bill...", color = TextMuted, fontSize = 12.sp) },

                modifier = Modifier

                    .weight(1f)

                    .heightIn(min = 48.dp, max = 120.dp),

                shape = RoundedCornerShape(24.dp),

                colors = OutlinedTextFieldDefaults.colors(

                    focusedBorderColor = MagicCyan,

                    unfocusedBorderColor = MagicBorder,

                    focusedTextColor = Color.White,

                    unfocusedTextColor = Color.White

                )

            )



            Button(

                onClick = {

                    val textToSend = inputMessage.trim()

                    if (textToSend.isNotBlank() && !isAiGenerating) {

                        inputMessage = ""

                        messagesList.add(ChatMessage(sender = "user", text = textToSend))



                        isAiGenerating = true

                        coroutineScope.launch {
                            try {
                                val aiReply = fetchSupportResponse(context, textToSend, messagesList.toList())
                                messagesList.add(ChatMessage(sender = "support", text = aiReply))
                            } catch (t: Throwable) {
                                messagesList.add(ChatMessage(sender = "support", text = "⚠️ Lỗi gửi tin nhắn: ${t.localizedMessage ?: "Vui lòng thử lại sau giây lát."}"))
                            } finally {
                                isAiGenerating = false
                            }
                        }

                    }

                },

                modifier = Modifier.size(48.dp),

                shape = CircleShape,

                colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),

                contentPadding = PaddingValues(0.dp)

            ) {

                Icon(

                    imageVector = Icons.AutoMirrored.Filled.Send,

                    contentDescription = "Gửi",

                    tint = Color(0xFF020617),

                    modifier = Modifier.size(20.dp)

                )

            }

        }

    }

}



@Composable

fun ChatBubbleItem(

    message: ChatMessage,

    onTranslateMessage: () -> Unit

) {

    val context = LocalContext.current
    val isUser = message.sender == "user"

    val showTranslateButton = remember(message.text) {

        !isVietnameseMessage(message.text)

    }

    val extractedLinks = remember(message.text) {
        val (_, links) = com.example.core.widget.MagicLiveFloatingOverlay.buildClickableSpannableAndLinks(context, message.text)
        links
    }

    val annotatedMessage = remember(message.text) {
        val markdownLinkRegex = Regex("\\[([^\\]\\n]+)]\\((https?://[^)\\s]+|www\\.[^)\\s]+)\\)")
        val normalizedText = markdownLinkRegex.replace(message.text) { match ->
            val label = match.groupValues[1].trim()
            val rawLink = match.groupValues[2].trim()
            val normUrl = com.example.core.widget.MagicLiveFloatingOverlay.normalizeBrowserUrl(rawLink)
            if (label.equals(rawLink, ignoreCase = true) || label.equals(normUrl, ignoreCase = true)) {
                normUrl
            } else {
                "$label ($normUrl)"
            }
        }
        val urlRegex = Regex(
            "(?i)\\b((?:https?://|www\\.)[^\\s<>\"')\\]]+|(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+(?:com|vn|net|org|edu|gov|io|ai|co|me|info|app|dev|xyz|tv|shop|store)(?:/[^\\s<>\"')\\]]*)?)"
        )
        androidx.compose.ui.text.buildAnnotatedString {
            append(normalizedText)
            urlRegex.findAll(normalizedText).forEach { matchResult ->
                val start = matchResult.range.first
                var end = matchResult.range.last + 1
                var matchedStr = normalizedText.substring(start, end)
                while (matchedStr.isNotEmpty() && matchedStr.last() in charArrayOf(')', ']', '}', '.', ',', ';', ':', '"', '\'', '>', '!', '?')) {
                    matchedStr = matchedStr.dropLast(1)
                    end--
                }
                if (matchedStr.length >= 4 && end > start) {
                    val finalUrl = com.example.core.widget.MagicLiveFloatingOverlay.normalizeBrowserUrl(matchedStr)
                    addStyle(
                        style = androidx.compose.ui.text.SpanStyle(
                            color = Color(0xFF38BDF8),
                            fontWeight = FontWeight.Bold,
                            textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline
                        ),
                        start = start,
                        end = end
                    )
                    addStringAnnotation(
                        tag = "URL",
                        annotation = finalUrl,
                        start = start,
                        end = end
                    )
                }
            }
        }
    }



    Column(

        modifier = Modifier.fillMaxWidth(),

        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start

    ) {

        Row(

            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,

            verticalAlignment = Alignment.Bottom,

            modifier = Modifier.fillMaxWidth()

        ) {

            if (!isUser) {

                Box(

                    modifier = Modifier

                        .size(32.dp)

                        .clip(CircleShape)

                        .background(Brush.linearGradient(listOf(MagicPurple, MagicCyan))),

                    contentAlignment = Alignment.Center

                ) {

                    Icon(imageVector = Icons.Default.SmartToy, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))

                }

                Spacer(modifier = Modifier.width(8.dp))

            }



            Box(

                modifier = Modifier

                    .widthIn(max = 290.dp)

                    .clip(

                        RoundedCornerShape(

                            topStart = 16.dp,

                            topEnd = 16.dp,

                            bottomStart = if (isUser) 16.dp else 4.dp,

                            bottomEnd = if (isUser) 4.dp else 16.dp

                        )

                    )

                    .background(if (isUser) MagicCyan.copy(alpha = 0.2f) else MagicSurfaceCard)

                    .border(

                        1.dp,

                        if (isUser) MagicCyan.copy(alpha = 0.5f) else MagicBorder,

                        RoundedCornerShape(

                            topStart = 16.dp,

                            topEnd = 16.dp,

                            bottomStart = if (isUser) 16.dp else 4.dp,

                            bottomEnd = if (isUser) 4.dp else 16.dp

                        )

                    )

                    .padding(12.dp)

            ) {

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {

                    @Suppress("DEPRECATION")
                    androidx.compose.foundation.text.ClickableText(
                        text = annotatedMessage,
                        style = androidx.compose.ui.text.TextStyle(
                            color = Color.White,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        ),
                        onClick = { offset ->
                            annotatedMessage.getStringAnnotations(tag = "URL", start = offset, end = offset)
                                .firstOrNull()?.let { annotation ->
                                    com.example.core.widget.MagicLiveFloatingOverlay.openUrlInDefaultBrowser(
                                        context,
                                        annotation.item
                                    )
                                }
                        }
                    )

                    if (extractedLinks.isNotEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            extractedLinks.forEach { linkItem ->
                                val chipLabel = if (linkItem.label.isNotBlank() && !linkItem.label.equals(linkItem.domain, ignoreCase = true)) {
                                    "🌐 ${linkItem.label.take(20)} (${linkItem.domain}) ↗"
                                } else {
                                    "🌐 Mở trình duyệt: ${linkItem.domain} ↗"
                                }
                                Surface(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable {
                                            com.example.core.widget.MagicLiveFloatingOverlay.openUrlInDefaultBrowser(
                                                context,
                                                linkItem.url
                                            )
                                        },
                                    color = Color(0xFF172554),
                                    border = BorderStroke(1.dp, Color(0xFF38BDF8))
                                ) {
                                    Text(
                                        text = chipLabel,
                                        color = Color(0xFF7DD3FC),
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }



                    // Hiển thị kết quả dịch (nếu có)

                    if (!message.translatedText.isNullOrBlank()) {

                        HorizontalDivider(color = MagicBorder, thickness = 0.5.dp)

                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {

                            Row(

                                verticalAlignment = Alignment.CenterVertically,

                                horizontalArrangement = Arrangement.spacedBy(4.dp)

                            ) {

                                Icon(

                                    imageVector = Icons.Default.Translate,

                                    contentDescription = null,

                                    tint = MagicEmerald,

                                    modifier = Modifier.size(12.dp)

                                )

                                Text(

                                    text = "Bản dịch Tiếng Việt:",

                                    color = MagicEmerald,

                                    fontSize = 10.sp,

                                    fontWeight = FontWeight.Bold

                                )

                            }

                            Text(

                                text = message.translatedText,

                                color = Color(0xFFA7F3D0),

                                fontSize = 12.sp,

                                lineHeight = 16.sp

                            )

                        }

                    }



                    // Chỉ hiện nút Dịch đối với tin nhắn KHÔNG phải Tiếng Việt

                    if (showTranslateButton) {

                        Row(

                            modifier = Modifier

                                .fillMaxWidth()

                                .padding(top = 4.dp),

                            horizontalArrangement = Arrangement.End,

                            verticalAlignment = Alignment.CenterVertically

                        ) {

                            Surface(

                                modifier = Modifier

                                    .clip(RoundedCornerShape(8.dp))

                                    .clickable(enabled = !message.isTranslating, onClick = onTranslateMessage),

                                color = Color(0xFF1E293B),

                                border = BorderStroke(0.5.dp, MagicPurple.copy(alpha = 0.5f))

                            ) {

                                Row(

                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),

                                    verticalAlignment = Alignment.CenterVertically,

                                    horizontalArrangement = Arrangement.spacedBy(4.dp)

                                ) {

                                    Text(

                                        text = if (message.isTranslating) "⏳ Đang dịch..." else "🌐 Dịch sang Tiếng Việt",

                                        color = MagicPurpleLight,

                                        fontSize = 10.sp,

                                        fontWeight = FontWeight.Bold

                                    )

                                }

                            }

                        }

                    }

                }

            }

        }

    }

}



/**

 * Phân tích ảnh bill chuyển khoản nghiêm ngặt 5 lớp (Chống Bill Giả Cầy / Photoshop / Chỉnh sửa ফরensic + Chống dùng lại Bill cũ SHA-256 + Kiểm tra Đăng nhập cho Pro Tài Khoản)

 * và tự động cấp Pro thật sự thay cho Admin (kèm ghi nhật ký kiểm toán chi tiết cho Admin).

 */

private suspend fun analyzeBillAutomatically(context: Context, imageUri: Uri): String {

    return withContext(Dispatchers.IO) {

        val deviceId = LicenseManager.getDeviceId(context).uppercase()

        val cleanShortDeviceId = LicenseManager.normalizeDeviceIdForMatch(deviceId)

        try {

            val bytes = context.contentResolver.openInputStream(imageUri)?.use { it.readBytes() }
                ?: return@withContext "Không thể đọc tệp ảnh biên lai."

            val billImageSha256 = LicenseManager.computeByteArraySha256(bytes)
            val billPerceptualHash = try {
                val opts = android.graphics.BitmapFactory.Options().apply {
                    inSampleSize = 4
                    inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
                }
                val decodedBmp = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                if (decodedBmp != null) {
                    val pHash = LicenseManager.computeBitmapPerceptualHash(decodedBmp)
                    decodedBmp.recycle()
                    pHash
                } else ""
            } catch (_: Throwable) { "" }

            // LỚP 0: QUÉT METADATA / EXIF / XMP TỆP ẢNH ĐỂ PHÁT HIỆN PHẦN MỀM CHỈNH SỬA ẢNH (PHOTOSHOP / PICSART / CANVA / PIXELLAB...)
            val headerSampleAscii = try {
                String(bytes, 0, minOf(bytes.size, 65536), Charsets.ISO_8859_1).uppercase()
            } catch (_: Throwable) { "" }
            val editingSoftwareSignatures = listOf(
                "ADOBE PHOTOSHOP", "PICSART", "CANVA", "SNAPSEED", "GIMP",
                "LIGHTROOM", "PIXELLAB", "PHOTOPEA", "MEITU", "CAPCUT", "PAINT.NET"
            )
            val isAlreadyPro = LicenseManager.isProActivated(context)
            val isAlreadyAccountPro = LicenseManager.isAccountProActivated(context) || LicenseManager.isUpgradedToAccountPro(context)
            val isAlreadyDevicePro = LicenseManager.isDeviceProOnly(context)
            val existingProTierLabel = LicenseManager.getProTierLabel(context)
            val proPreservedSuffix = if (isAlreadyPro) {
                "\n🛡️ **Bảo vệ khách hàng Pro:** Quyền hạn hiện tại của bạn (**$existingProTierLabel**) vẫn được **GIỮ NGUYÊN 100%** (Chatbot chỉ ngăn chặn biên lai không hợp lệ, tuyệt đối không có quyền hạ cấp hay thu hồi Pro của khách)."
            } else ""

            val matchedEditor = editingSoftwareSignatures.firstOrNull { headerSampleAscii.contains(it) }
            if (matchedEditor != null) {
                val exifFakeMsg = "🚨 CẢNH BÁO AN NINH — PHÁT HIỆN TỆP ẢNH ĐÃ QUA PHẦN MỀM CHỈNH SỬA ($matchedEditor):\n\n" +
                    "• Hệ thống giám định kỹ thuật số phát hiện siêu dữ liệu (EXIF/XMP) của ảnh biên lai có dấu vết can thiệp từ phần mềm **$matchedEditor**.\n" +
                    "• Mã băm ảnh (SHA-256): `${billImageSha256.take(16)}...`\n" +
                    "🔒 Trạng thái: **TỪ CHỐI DUYỆT BIÊN LAI NÀY & ĐÃ GHI NHẬT KÝ BÁO CÁO ADMIN**.\n" +
                    "💡 Vui lòng gửi ảnh chụp màn hình gốc trực tiếp từ ứng dụng thanh toán/tài chính (tuyệt đối không qua chỉnh sửa hay cắt ghép)!$proPreservedSuffix"
                LicenseManager.logAiProChatInteraction(
                    context = context,
                    userMessage = "🚨 [Phát hiện EXIF chỉnh sửa ảnh: $matchedEditor] Thiết bị: $deviceId",
                    aiReply = exifFakeMsg,
                    eventType = "FAKE_BILL_DETECTED",
                    proGranted = false,
                    grantedTier = "NONE",
                    targetDeviceId = deviceId,
                    billImageHash = billImageSha256,
                    billPerceptualHash = billPerceptualHash,
                    forensicVerdict = "EXIF/XMP chứa chữ ký phần mềm chỉnh sửa ảnh: $matchedEditor"
                )
                return@withContext exifFakeMsg
            }

            val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)

            val currentUser = com.example.core.auth.FirebaseAuthManager.getCurrentUser()
            val isLoggedIn = currentUser != null && !currentUser.uid.isBlank()

            // LỚP 1: NẾU MÁY ĐANG LÀ PRO THIẾT BỊ MUỐN NÂNG LÊN PRO TÀI KHOẢN MÀ CHƯA ĐĂNG NHẬP TÀI KHOẢN THẬT -> CHẶN ĐỂ TRÁNH CẤP PRO TÀI KHOẢN MỒ CÔI (NHƯNG GIỮ NGUYÊN 100% PRO THIẾT BỊ HIỆN TẠI)
            if (isAlreadyDevicePro && !isLoggedIn) {
                val loginReqMsg = "🔒 CẦN ĐĂNG NHẬP TÀI KHOẢN TRƯỚC KHI NÂNG CẤP LÊN PRO TÀI KHOẢN!\n\n" +
                    "• Hệ thống nhận thấy máy của bạn ($deviceId) đang ở gói **Pro Thiết Bị** và bạn vừa gửi biên lai để nâng cấp lên **Pro Tài Khoản**.\n" +
                    "• Tuy nhiên, bạn **chưa đăng nhập tài khoản** trên ứng dụng. Để tránh trường hợp kích hoạt xong nhưng không có tài khoản Email thật để gắn quyền Pro Tài Khoản, bạn vui lòng:\n" +
                    "  1. Quay lại bấm vào tab **🔐 Đăng Nhập** trên thanh công cụ để đăng nhập (hoặc đăng ký) tài khoản.\n" +
                    "  2. Sau khi đăng nhập xong, quay lại khung chat này và gửi lại ảnh biên lai — hệ thống sẽ tự động gắn quyền **👑 PRO TÀI KHOẢN** vào đúng tài khoản của bạn ngay lập tức!$proPreservedSuffix"

                LicenseManager.logAiProChatInteraction(
                    context = context,
                    userMessage = "🖼️ [Gửi bill nâng cấp Pro TK khi chưa đăng nhập] Thiết bị: $deviceId",
                    aiReply = loginReqMsg,
                    eventType = "BILL_REJECTED",
                    proGranted = false,
                    grantedTier = "NONE",
                    targetDeviceId = deviceId,
                    billImageHash = billImageSha256,
                    billPerceptualHash = billPerceptualHash,
                    forensicVerdict = "Yêu cầu đăng nhập tài khoản thật trước khi nâng cấp từ Pro Máy lên Pro Tài Khoản"
                )
                return@withContext loginReqMsg
            }

            // LỚP 2: KIỂM TRA SƠ BỘ CHỮ KÝ ẢNH SHA-256 & PERCEPTUAL HASH (dHash 64-bit) TRÊN FIREBASE (CHỐNG REPLAY / CẮT GHÉP / CHỤP LẠI BILL CŨ)
            val (isDuplicateHashEarly, duplicateReasonEarly) = LicenseManager.checkBillReplayOrDuplicateInCloud(
                billSha256 = billImageSha256,
                bankTransCode = "",
                currentDeviceId = deviceId,
                isRequestingAccountUpgrade = isAlreadyDevicePro,
                billPerceptualHash = billPerceptualHash,
                context = context
            )

            if (isDuplicateHashEarly) {
                val replayMsg = "🚨 CẢNH BÁO CHỐNG GIAN LẬN (PHÁT HIỆN BIÊN LAI ĐÃ QUA SỬ DỤNG):\n\n" +
                    "• $duplicateReasonEarly\n" +
                    "• Mã băm ảnh (SHA-256): `${billImageSha256.take(16)}...`\n" +
                    "🔒 Trạng thái: TỪ CHỐI DUYỆT BIÊN LAI NÀY & ĐÃ GHI NHẬT KÝ BÁO CÁO ADMIN.$proPreservedSuffix"

                LicenseManager.logAiProChatInteraction(
                    context = context,
                    userMessage = "🖼️ [Cảnh báo: Gửi lại ảnh bill cũ / trùng SHA-256 hoặc dHash] Thiết bị: $deviceId",
                    aiReply = replayMsg,
                    eventType = "REUSED_BILL_BLOCKED",
                    proGranted = false,
                    grantedTier = "NONE",
                    targetDeviceId = deviceId,
                    billImageHash = billImageSha256,
                    billPerceptualHash = billPerceptualHash,
                    forensicVerdict = "Trùng chữ ký tệp ảnh SHA-256/dHash: $duplicateReasonEarly"
                )
                return@withContext replayMsg
            }

            val bankName = LicenseManager.getPaymentBankName(context)
            val bankAccount = LicenseManager.getPaymentAccountNumber(context)
            val bankHolder = LicenseManager.getPaymentAccountHolder(context)
            val tailDigits = if (bankAccount.length >= 4) bankAccount.takeLast(4) else bankAccount

            val prompt = """
                Bạn là Hệ Thống Giám Định Hóa Đơn Thanh Toán & Chống Bill Giả (Forensic Receipt Inspector) của ứng dụng MagicTune.
                Tuyệt đối KHÔNG nhắc đến tên bất kỳ mô hình AI nào trong câu trả lời.
                Thông tin tài khoản nhận tiền chuẩn của Admin:
                - Đơn vị nhận: $bankName
                - Số tài khoản nhận: $bankAccount (4 số cuối bắt buộc: $tailDigits)
                - Chủ tài khoản nhận: $bankHolder
                - Mã thiết bị bắt buộc trong nội dung CK: $deviceId (hoặc chứa chuỗi định danh: $cleanShortDeviceId)

                NHIỆM VỤ BẮT BUỘC — KIỂM TRA NGHIÊM NGẶT 4 LỚP CHỐNG BILL GIẢ / PHOTOSHOP / LÁCH LUẬT:
                LỚP 1 — GIÁM ĐỊNH KỸ THUẬT SỐ PHÁT HIỆN BILL GIẢ / CHỈNH SỬA (FORENSIC TAMPERING CHECK):
                - Quan sát thật kỹ Phông chữ (Font family), Độ đậm nhạt (Font weight), Khoảng cách ký tự (Kerning), và Đường căn dòng (Baseline alignment) tại 4 vị trí nhạy cảm: [Số tiền], [Số tài khoản nhận], [Tên người nhận], và [Nội dung chuyển khoản].
                - Nếu phát hiện phông chữ lệch lạc, vùng nền (background) quanh số tiền/STK/nội dung CK bị mờ nhòe, có vệt xóa/đè màu, giao diện từ web tạo bill giả, hoặc là ảnh chụp màn hình QR của chính ứng dụng MagicTune -> BẮT BUỘC mở đầu bằng: `FAKE_BILL_DETECTED:` kèm lý do.

                LỚP 2 — KIỂM TRA TRẠNG THÁI GIAO DỊCH HOÀN TẤT:
                - Đây PHẢI là biên lai báo GIAO DỊCH THÀNH CÔNG (Chuyển tiền thành công / Thanh toán thành công).
                - Nếu chỉ là màn hình "Xác nhận giao dịch", "Nhập mã OTP", "Đang chờ xử lý", hoặc màn hình nhập số tiền chưa chuyển -> Từ chối ngay (`INVALID: Đây mới là màn hình xác nhận chưa chuyển tiền thành công`).

                LỚP 3 & 4 — TRÍCH XUẤT CHÍNH XÁC DỮ LIỆU THỰC TẾ TRÊN BIÊN LAI (KHÔNG ĐƯỢC TỰ BỊA):
                Hãy đọc chính xác từng trường chữ hiển thị thực tế trên ảnh biên lai và xuất theo đúng cấu trúc sau:
                - `RECIPIENT_ACC`: Số tài khoản người nhận thực tế ghi trên biên lai (nếu bị che dạng ***4338 thì ghi nguyên chuỗi có 4 số cuối).
                - `RECIPIENT_NAME`: Tên người thụ hưởng/người nhận thực tế ghi trên biên lai.
                - `AMOUNT_VND`: Con số tiền chuyển khoản thực tế bằng số nguyên VNĐ (ví dụ: 50000 hoặc 100000, tuyệt đối không ghi dấu chấm/phẩy).
                - `TRANSFER_MEMO`: Nguyên văn nội dung lời nhắn chuyển khoản thực tế ghi trên biên lai.
                - `TRANS_ID`: Mã giao dịch / Mã tham chiếu ngân hàng thực tế trên biên lai (bắt buộc phải có mã giao dịch thật từ ngân hàng).
                - `TX_STATUS`: Ghi `SUCCESS` nếu biên lai báo giao dịch đã hoàn tất thành công, ghi `PENDING` nếu chưa hoàn tất.

                ĐỊNH DẠNG ĐẦU RA BẮT BUỘC:
                - Nếu hợp lệ (Ảnh thật 100% + Giao dịch thành công + Đúng STK nhận có đuôi $tailDigits + Đúng tên chủ TK $bankHolder + Đúng nội dung có mã máy hợp lệ + Đủ số tiền >= 50000):
                  + Gói Pro Tài Khoản (Số tiền >= 100000 HOẶC máy đã là Pro Thiết Bị isAlreadyDevicePro=$isAlreadyDevicePro chuyển thêm >= 50000):
                    `SUCCESS_ACCOUNT_PRO | TRANS_ID: <mã_GD> | AMOUNT_VND: <số_tiền_số_nguyên> | RECIPIENT_ACC: <stk_nhận_trên_bill> | RECIPIENT_NAME: <tên_nhận_trên_bill> | TRANSFER_MEMO: <nội_dung_ck_trên_bill> | TX_STATUS: SUCCESS | FORENSIC: Bản gốc hợp lệ, phông chữ và nền pixel đồng nhất`
                  + Gói Pro Thiết Bị (Số tiền >= 50000):
                    `SUCCESS_DEVICE_PRO | TRANS_ID: <mã_GD> | AMOUNT_VND: <số_tiền_số_nguyên> | RECIPIENT_ACC: <stk_nhận_trên_bill> | RECIPIENT_NAME: <tên_nhận_trên_bill> | TRANSFER_MEMO: <nội_dung_ck_trên_bill> | TX_STATUS: SUCCESS | FORENSIC: Bản gốc hợp lệ, phông chữ và nền pixel đồng nhất`
                - Nếu vi phạm bất kỳ điều kiện nào:
                  `INVALID: <nêu rõ lý do sai STK, sai tên người nhận, thiếu mã máy $deviceId trong nội dung CK, hoặc chưa đủ số tiền>`
            """.trimIndent()

            val visionModels = listOf(
                "qwen/qwen3.8-27b"
            )
            val groqKeys = LicenseManager.getAllGroqApiKeys(context).toMutableList()
            val balancedKey = LicenseManager.getLoadBalancedGroqApiKey(context).ifBlank {
                try { com.example.BuildConfig.GROQ_API_KEY } catch (_: Throwable) { "" }
            }
            if (balancedKey.isNotBlank() && !groqKeys.contains(balancedKey)) {
                groqKeys.add(0, balancedKey)
            }
            val validKeys = groqKeys.filter { it.isNotBlank() && it != "GROQ_API_KEY_DEFAULT_VALUE" }

            var rawReply = ""
            var gotValidResponse = false

            outerLoop@ for (key in validKeys.take(3)) {
                for (visionModel in visionModels) {
                    var conn: HttpURLConnection? = null
                    try {
                        val url = URL("https://api.groq.com/openai/v1/chat/completions")
                        conn = (url.openConnection() as HttpURLConnection).apply {
                            requestMethod = "POST"
                            doOutput = true
                            doInput = true
                            connectTimeout = 10_000
                            readTimeout = 18_000
                            setRequestProperty("Authorization", "Bearer $key")
                            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                        }

                        val payload = org.json.JSONObject().apply {
                            put("model", visionModel)
                            put("temperature", 0.01)
                            val messages = org.json.JSONArray()
                            val userMsg = org.json.JSONObject().apply {
                                put("role", "user")
                                val contentArr = org.json.JSONArray()
                                contentArr.put(org.json.JSONObject().put("type", "text").put("text", prompt))
                                contentArr.put(
                                    org.json.JSONObject()
                                        .put("type", "image_url")
                                        .put("image_url", org.json.JSONObject().put("url", "data:image/jpeg;base64,$base64"))
                                )
                                put("content", contentArr)
                            }
                            messages.put(userMsg)
                            put("messages", messages)
                        }

                        conn.outputStream.use { os ->
                            os.write(payload.toString().toByteArray(Charsets.UTF_8))
                            os.flush()
                        }

                        if (conn.responseCode in 200..299) {
                            val body = conn.inputStream.bufferedReader().use { it.readText() }
                            val root = org.json.JSONObject(body)
                            val content = root.optJSONArray("choices")
                                ?.optJSONObject(0)
                                ?.optJSONObject("message")
                                ?.optString("content", "")
                                ?.trim()
                                .orEmpty()
                            if (content.isNotBlank()) {
                                rawReply = content
                                gotValidResponse = true
                                break@outerLoop
                            }
                        } else if (conn.responseCode == 429 || conn.responseCode == 401 || conn.responseCode == 403) {
                            LicenseManager.markGroqApiKeyCooldown(key)
                        }
                    } catch (_: Throwable) {
                    } finally {
                        try { conn?.disconnect() } catch (_: Throwable) {}
                    }
                }
            }

            // DỰ PHÒNG TẦNG 2: GEMINI 2.5 FLASH VISION NẾU GROQ ĐANG QUÁ TẢI
            if (!gotValidResponse || rawReply.isBlank()) {
                val magic_liveKeys = LicenseManager.getAllMagicLiveApiKeys(context)
                for (gKey in magic_liveKeys.take(2)) {
                    var conn: HttpURLConnection? = null
                    try {
                        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$gKey")
                        conn = (url.openConnection() as HttpURLConnection).apply {
                            requestMethod = "POST"
                            doOutput = true
                            doInput = true
                            connectTimeout = 10_000
                            readTimeout = 20_000
                            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                        }
                        val payload = org.json.JSONObject().apply {
                            put("contents", org.json.JSONArray().apply {
                                put(org.json.JSONObject().apply {
                                    put("parts", org.json.JSONArray().apply {
                                        put(org.json.JSONObject().put("text", prompt))
                                        put(org.json.JSONObject().put("inline_data", org.json.JSONObject().apply {
                                            put("mime_type", "image/jpeg")
                                            put("data", base64)
                                        }))
                                    })
                                })
                            })
                            put("generationConfig", org.json.JSONObject().apply {
                                put("temperature", 0.01)
                            })
                        }
                        conn.outputStream.use { os ->
                            os.write(payload.toString().toByteArray(Charsets.UTF_8))
                            os.flush()
                        }
                        if (conn.responseCode in 200..299) {
                            val body = conn.inputStream.bufferedReader().use { it.readText() }
                            val root = org.json.JSONObject(body)
                            val content = root.optJSONArray("candidates")
                                ?.optJSONObject(0)
                                ?.optJSONObject("content")
                                ?.optJSONArray("parts")
                                ?.optJSONObject(0)
                                ?.optString("text", "")
                                ?.trim()
                                .orEmpty()
                            if (content.isNotBlank()) {
                                rawReply = content
                                gotValidResponse = true
                                break
                            }
                        } else if (conn.responseCode == 429) {
                            LicenseManager.markMagicLiveApiKeyCooldown(gKey)
                        }
                    } catch (_: Throwable) {
                    } finally {
                        try { conn?.disconnect() } catch (_: Throwable) {}
                    }
                }
            }

            if (gotValidResponse && rawReply.isNotBlank()) {
                val reply = rawReply.replace(Regex("<think>[\\s\\S]*?</think>"), "").trim()

                val isFakeDetected = reply.startsWith("FAKE_BILL_DETECTED", ignoreCase = true) ||
                    reply.contains("FAKE_BILL_DETECTED", ignoreCase = true) ||
                    (reply.contains("chỉnh sửa", ignoreCase = true) && reply.contains("INVALID", ignoreCase = true)) ||
                    reply.contains("bill giả", ignoreCase = true) ||
                    reply.contains("làm giả", ignoreCase = true) ||
                    reply.contains("cắt ghép", ignoreCase = true)

                val isExplicitInvalid = isFakeDetected ||
                    reply.startsWith("INVALID", ignoreCase = true) ||
                    reply.contains("không phải biên lai", ignoreCase = true) ||
                    reply.contains("không hợp lệ", ignoreCase = true) ||
                    reply.contains("chưa thanh toán", ignoreCase = true)

                val startsWithSuccessAccount = reply.startsWith("SUCCESS_ACCOUNT_PRO", ignoreCase = true) ||
                    reply.contains("SUCCESS_ACCOUNT_PRO", ignoreCase = true)
                val startsWithSuccessDevice = reply.startsWith("SUCCESS_DEVICE_PRO", ignoreCase = true) ||
                    reply.contains("SUCCESS_DEVICE_PRO", ignoreCase = true)

                val extractedTransId = Regex("""TRANS_ID:\s*([A-Za-z0-9\-_]+)""", RegexOption.IGNORE_CASE)
                    .find(reply)?.groupValues?.getOrNull(1)?.trim().orEmpty()
                val extractedAmountStr = Regex("""AMOUNT_VND:\s*([0-9.,]+)""", RegexOption.IGNORE_CASE)
                    .find(reply)?.groupValues?.getOrNull(1)?.replace(Regex("[^0-9]"), "").orEmpty()
                val extractedAmountVnd = extractedAmountStr.toLongOrNull() ?: 0L
                val extractedRecipientAcc = Regex("""RECIPIENT_ACC:\s*([^\n|]+)""", RegexOption.IGNORE_CASE)
                    .find(reply)?.groupValues?.getOrNull(1)?.trim().orEmpty()
                val extractedRecipientName = Regex("""RECIPIENT_NAME:\s*([^\n|]+)""", RegexOption.IGNORE_CASE)
                    .find(reply)?.groupValues?.getOrNull(1)?.trim().orEmpty()
                val extractedMemo = Regex("""TRANSFER_MEMO:\s*([^\n|]+)""", RegexOption.IGNORE_CASE)
                    .find(reply)?.groupValues?.getOrNull(1)?.trim().orEmpty()
                val extractedStatus = Regex("""TX_STATUS:\s*([A-Za-z_]+)""", RegexOption.IGNORE_CASE)
                    .find(reply)?.groupValues?.getOrNull(1)?.trim().orEmpty()
                val extractedForensic = Regex("""FORENSIC:\s*([^\n|]+)""", RegexOption.IGNORE_CASE)
                    .find(reply)?.groupValues?.getOrNull(1)?.trim()
                    ?: if (isFakeDetected) "Phát hiện dấu hiệu chỉnh sửa ảnh / phông chữ / nền pixel bất thường" else "Đã kiểm tra"

                if (isFakeDetected) {
                    val cleanedFakeReason = reply
                        .replace("FAKE_BILL_DETECTED:", "", ignoreCase = true)
                        .replace("FAKE_BILL_DETECTED", "", ignoreCase = true)
                        .trim()
                        .removePrefix(":")
                        .trim()

                    val fakeAlertMsg = "🚨 CẢNH BÁO AN NINH — PHÁT HIỆN DẤU HIỆU BIÊN LAI CHỈNH SỬA / KHÔNG ĐỒNG NHẤT:\n\n" +
                        "• Kết quả giám định hình ảnh: $cleanedFakeReason\n" +
                        "• Mã băm ảnh (SHA-256): `${billImageSha256.take(16)}...`\n" +
                        "🔒 Trạng thái thực tế: **TỪ CHỐI DUYỆT BIÊN LAI NÀY**.\n" +
                        "⚠️ Hệ thống giám định tự động kiểm tra độ đồng nhất của phông chữ, nền pixel quanh số tiền/STK, mã tham chiếu giao dịch và chữ ký tệp ảnh. Sự việc đã được ghi vào Nhật ký Kiểm toán Admin. Nếu bạn đã chuyển khoản thật, vui lòng chụp màn hình biên lai gốc trực tiếp từ ứng dụng thanh toán (không cắt ghép hay chỉnh sửa)!$proPreservedSuffix"

                    LicenseManager.logAiProChatInteraction(
                        context = context,
                        userMessage = "🚨 [CẢNH BÁO BILL GIẢ / CHỈNH SỬA] Thiết bị: $deviceId",
                        aiReply = fakeAlertMsg,
                        eventType = "FAKE_BILL_DETECTED",
                        proGranted = false,
                        grantedTier = "NONE",
                        targetDeviceId = deviceId,
                        billImageHash = billImageSha256,
                        billPerceptualHash = billPerceptualHash,
                        bankTransCode = extractedTransId,
                        forensicVerdict = "PHÁT HIỆN CHỈNH SỬA / GIẢ MẠO: $cleanedFakeReason"
                    )
                    return@withContext fakeAlertMsg
                }

                // LỚP KIỂM DUYỆT CỨNG BẰNG CODE KOTLIN (PROGRAMMATIC 6-FACTOR HARD VERIFICATION):
                // Không bao giờ chỉ tin vào nhãn SUCCESS của AI; bắt buộc đối chiếu từng trường dữ liệu trích xuất với cấu hình Admin!
                val holderTokens = java.text.Normalizer.normalize(bankHolder, java.text.Normalizer.Form.NFD)
                    .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
                    .uppercase()
                    .split(Regex("\\s+"))
                    .filter { it.length >= 3 }
                val normalizedExtractedName = java.text.Normalizer.normalize(extractedRecipientName, java.text.Normalizer.Form.NFD)
                    .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
                    .uppercase()
                val normalizedExtractedAcc = extractedRecipientAcc.replace(Regex("[^0-9]"), "")
                val normalizedExtractedMemo = LicenseManager.normalizeDeviceIdForMatch(extractedMemo)
                val homoglyphNormalizedMemo = LicenseManager.normalizeHexHomoglyphs(extractedMemo)

                val candidateNormIds = LicenseManager.getAllCandidateDeviceIds(context)
                    .map { LicenseManager.normalizeDeviceIdForMatch(it) }
                    .filter { it.length >= 6 }
                    .distinct()

                val isCurrentDeviceMemoMatch = (cleanShortDeviceId.length >= 5 && (
                    normalizedExtractedMemo.contains(cleanShortDeviceId, ignoreCase = true) ||
                        homoglyphNormalizedMemo.contains(LicenseManager.normalizeHexHomoglyphs(cleanShortDeviceId), ignoreCase = true) ||
                        extractedMemo.contains(deviceId, ignoreCase = true)
                    )) || candidateNormIds.any { cId ->
                        normalizedExtractedMemo.contains(cId, ignoreCase = true) ||
                            (cId.length >= 8 && normalizedExtractedMemo.contains(cId.take(8), ignoreCase = true))
                    }

                // Cho phép Admin tải ảnh bill của khách lên để duyệt tự động cho đúng mã máy trong nội dung CK
                val adminExtractedTargetIds = if (LicenseManager.isCurrentUserAdmin(context)) {
                    LicenseManager.extractCandidateDeviceIdsFromBankMemo(extractedMemo)
                } else emptyList()

                val isAccMatch = normalizedExtractedAcc.endsWith(tailDigits) || normalizedExtractedAcc.contains(bankAccount)
                val isNameMatch = holderTokens.isEmpty() || holderTokens.count { normalizedExtractedName.contains(it) } >= (holderTokens.size.coerceAtMost(2))
                val isMemoMatch = isCurrentDeviceMemoMatch || adminExtractedTargetIds.isNotEmpty()
                val isTransIdValid = extractedTransId.length >= 5 &&
                    !extractedTransId.equals("NONE", ignoreCase = true) &&
                    !extractedTransId.equals("NULL", ignoreCase = true) &&
                    !extractedTransId.equals("UNKNOWN", ignoreCase = true) &&
                    !extractedTransId.equals("NA", ignoreCase = true)
                val isStatusSuccess = extractedStatus.equals("SUCCESS", ignoreCase = true)
                val minRequiredVnd = LicenseManager.getProPrice(context).replace(Regex("[^0-9]"), "").toLongOrNull()?.takeIf { it >= 10_000L } ?: 50_000L
                val isAmountValid = extractedAmountVnd >= minRequiredVnd

                val programmaticFailReasons = mutableListOf<String>()
                if ( !isExplicitInvalid && (startsWithSuccessAccount || startsWithSuccessDevice || (isStatusSuccess && isAccMatch && isNameMatch && isAmountValid && isMemoMatch && isTransIdValid)) ) {
                    if (!isStatusSuccess) {
                        programmaticFailReasons.add("Trạng thái giao dịch trên ảnh chưa hoàn tất thành công (`$extractedStatus`)")
                    }
                    if (!isAccMatch) {
                        programmaticFailReasons.add("Số tài khoản người nhận trên biên lai (`${extractedRecipientAcc.ifBlank { "Không rõ" }}`) không khớp với STK Admin (`...$tailDigits`)")
                    }
                    if (!isNameMatch) {
                        programmaticFailReasons.add("Tên người nhận trên biên lai (`${extractedRecipientName.ifBlank { "Không rõ" }}`) không khớp với Chủ TK Admin (`$bankHolder`)")
                    }
                    if (!isAmountValid) {
                        programmaticFailReasons.add("Số tiền trên biên lai (`${extractedAmountVnd}đ`) chưa đủ mức tối thiểu `${minRequiredVnd}đ`")
                    }
                    if (!isMemoMatch) {
                        programmaticFailReasons.add("Nội dung chuyển khoản (`${extractedMemo.ifBlank { "Trống" }}`) không chứa đúng mã thiết bị `$deviceId`")
                    }
                    if (!isTransIdValid) {
                        programmaticFailReasons.add("Biên lai không có Mã giao dịch ngân hàng hợp lệ (`${extractedTransId.ifBlank { "Trống" }}`)")
                    }
                }

                val isApproved = !isExplicitInvalid &&
                    (startsWithSuccessAccount || startsWithSuccessDevice || (isStatusSuccess && isAccMatch && isNameMatch && isAmountValid && isMemoMatch && isTransIdValid)) &&
                    programmaticFailReasons.isEmpty()

                if (isApproved) {
                    val configuredAccountProVnd = LicenseManager.getAccountProPrice(context).replace(Regex("[^0-9]"), "").toLongOrNull()?.takeIf { it >= 20_000L } ?: 100_000L
                    val configuredUpgradeVnd = LicenseManager.getUpgradeToAccountProPrice(context).replace(Regex("[^0-9]"), "").toLongOrNull()?.takeIf { it >= 10_000L } ?: 50_000L
                    val extractedId = if (!isCurrentDeviceMemoMatch) {
                        adminExtractedTargetIds.firstOrNull() ?: deviceId
                    } else {
                        deviceId
                    }
                    // QUY TẮC BẢO VỆ KHÁCH PRO: Nếu máy đang là Pro Tài Khoản thì giữ nguyên Pro Tài Khoản (không bao giờ hạ cấp xuống Pro Thiết Bị).
                    // Hoặc cấp Pro Tài Khoản nếu số tiền >= 95% gói Pro Tài Khoản (95.000đ) HOẶC máy đã là Pro Thiết Bị chuyển thêm >= 50.000đ
                    val isAccountTier = (extractedId == deviceId && isAlreadyAccountPro) ||
                        (extractedAmountVnd >= (configuredAccountProVnd * 95 / 100)) ||
                        (isAlreadyDevicePro && extractedAmountVnd >= configuredUpgradeVnd)

                    // KIỂM TRA ĐĂNG NHẬP BẮT BUỘC NẾU LÀ BILL PRO TÀI KHOẢN / NÂNG CẤP PRO TÀI KHOẢN
                    if (isAccountTier && !isLoggedIn && extractedId == deviceId) {
                        val mustLoginMsg = "🔒 BIÊN LAI HỢP LỆ NHƯNG BẠN CHƯA ĐĂNG NHẬP TÀI KHOẢN!\n\n" +
                            "• Hệ thống đã xác nhận biên lai chuyển khoản gói **👑 PRO TÀI KHOẢN** của bạn là hợp lệ.\n" +
                            "• Tuy nhiên, để tránh cấp quyền Pro Tài Khoản khi chưa có tài khoản thật, bạn vui lòng mở tab **🔐 Đăng Nhập** trên thanh công cụ để đăng nhập Email trước, sau đó gửi lại ảnh biên lai này để hệ thống kích hoạt và gắn vĩnh viễn vào tài khoản của bạn ngay lập tức!$proPreservedSuffix"

                        val upgradeTag = if (isAlreadyDevicePro && !isAlreadyAccountPro) "Nâng cấp từ Pro Máy lên Pro Tài Khoản • " else ""
                        LicenseManager.logCustomerPaymentIntent(
                            context = context,
                            actionType = "BILL_NEEDS_MANUAL_REVIEW",
                            details = "${upgradeTag}Bill Pro Tài Khoản hợp lệ (Mã GD: $extractedTransId • ${extractedAmountVnd}đ) nhưng khách chưa đăng nhập tài khoản • Thiết bị: $extractedId",
                            targetDeviceId = extractedId,
                            forcePendingReview = true
                        )

                        LicenseManager.logAiProChatInteraction(
                            context = context,
                            userMessage = "🖼️ [Bill Pro TK hợp lệ nhưng khách chưa đăng nhập] Thiết bị: $extractedId",
                            aiReply = mustLoginMsg,
                            eventType = "BILL_REJECTED",
                            proGranted = false,
                            grantedTier = "NONE",
                            targetDeviceId = extractedId,
                            billImageHash = billImageSha256,
                            billPerceptualHash = billPerceptualHash,
                            bankTransCode = extractedTransId,
                            forensicVerdict = "Bill hợp lệ nhưng yêu cầu khách đăng nhập tài khoản trước khi gắn ACCOUNT_PRO"
                        )
                        return@withContext mustLoginMsg
                    }

                    // KIỂM TRA CHỐNG DÙNG LẠI MÃ GIAO DỊCH NGÂN HÀNG (TRANS_ID) HOẶC HASH ẢNH TRÊN CLOUD
                    val (isReplay, replayReason) = LicenseManager.checkBillReplayOrDuplicateInCloud(
                        billSha256 = billImageSha256,
                        bankTransCode = extractedTransId,
                        currentDeviceId = extractedId,
                        isRequestingAccountUpgrade = isAlreadyDevicePro,
                        billPerceptualHash = billPerceptualHash,
                        context = context
                    )

                    if (isReplay) {
                        val replayRejectMsg = "🚨 TỪ CHỐI DUYỆT BIÊN LAI NÀY — PHÁT HIỆN DÙNG LẠI BIÊN LAI CŨ:\n\n" +
                            "• $replayReason\n" +
                            "• Mã GD Ngân hàng: `${extractedTransId.ifBlank { "Trùng ảnh" }}`\n" +
                            "🔒 Trạng thái: TỪ CHỐI CẤP THÊM TỪ BIÊN LAI CŨ.$proPreservedSuffix"

                        LicenseManager.logAiProChatInteraction(
                            context = context,
                            userMessage = "🖼️ [Chặn dùng lại Mã GD / Bill cũ: $extractedTransId] Thiết bị: $extractedId",
                            aiReply = replayRejectMsg,
                            eventType = "REUSED_BILL_BLOCKED",
                            proGranted = false,
                            grantedTier = "NONE",
                            targetDeviceId = extractedId,
                            billImageHash = billImageSha256,
                            billPerceptualHash = billPerceptualHash,
                            bankTransCode = extractedTransId,
                            forensicVerdict = "Chặn dùng lại biên lai cũ: $replayReason"
                        )
                        return@withContext replayRejectMsg
                    }

                    val targetTierName = if (isAccountTier) {
                        "👑 PRO TÀI KHOẢN (${LicenseManager.getAccountProPrice(context)})"
                    } else {
                        "📱 PRO THIẾT BỊ (${LicenseManager.getProPrice(context)})"
                    }
                    val isAutoApproveEnabled = LicenseManager.isAutoApproveNotificationPaymentEnabled(context)

                    if (isAutoApproveEnabled) {
                        val verifiedReason = "AI_AUTO_BILL_VERIFIED (Mã GD: $extractedTransId | ${extractedAmountVnd}đ | STK: ...$tailDigits)"
                        val grantResult = LicenseManager.executeVerifiedProGrant(
                            context = context,
                            rawTargetDeviceId = extractedId,
                            grantAccountPro = isAccountTier,
                            reason = verifiedReason
                        )

                        LicenseManager.deletePaymentIntentsForDevice(extractedId, context)

                        val finalMsg = "🎉 XÁC THỰC BIÊN LAI THÀNH CÔNG 100%!\n\n" +
                            "• Thiết bị: `$extractedId`\n" +
                            "• Hạng bản quyền: $targetTierName\n" +
                            "• Số tiền đối soát: `${extractedAmountVnd}đ`\n" +
                            "• Mã GD Ngân hàng: `$extractedTransId`\n\n" +
                            "⚡ HỆ THỐNG ĐÃ TỰ ĐỘNG KÍCH HOẠT QUYỀN PRO CHO BẠN NGAY LẬP TỨC:\n" +
                            "${grantResult.summaryMessage}\n\n" +
                            "🔑 Mã Key của bạn: `${grantResult.generatedKey}`\n" +
                            "💡 Bạn có thể sử dụng toàn bộ tính năng cao cấp không giới hạn ngay bây giờ!"

                        LicenseManager.logCustomerPaymentIntent(
                            context = context,
                            actionType = "AI_AUTO_APPROVED_PRO",
                            details = "Mã GD: $extractedTransId • Số tiền: ${extractedAmountVnd}đ • $targetTierName • Key: ${grantResult.generatedKey} • Thiết bị: $extractedId"
                        )

                        LicenseManager.logAiProChatInteraction(
                            context = context,
                            userMessage = "🖼️ [Bill hợp lệ - Kích hoạt tự động] Thiết bị: $extractedId • Mã GD: $extractedTransId • ${extractedAmountVnd}đ",
                            aiReply = "$finalMsg\n(Chi tiết giám định: $reply)",
                            eventType = "AI_AUTO_BILL_APPROVED",
                            proGranted = true,
                            grantedTier = if (grantResult.isAccountPro) "ACCOUNT_PRO" else "DEVICE_PRO",
                            generatedKey = grantResult.generatedKey,
                            targetDeviceId = extractedId,
                            billImageHash = billImageSha256,
                            billPerceptualHash = billPerceptualHash,
                            bankTransCode = extractedTransId,
                            forensicVerdict = "$extractedForensic | Số tiền: ${extractedAmountVnd}đ | Nội dung: $extractedMemo"
                        )
                        finalMsg
                    } else {
                        val upgradeTag = if (isAlreadyDevicePro && !isAlreadyAccountPro) "Nâng cấp từ Pro Máy lên Pro Tài Khoản • " else ""
                        LicenseManager.logCustomerPaymentIntent(
                            context = context,
                            actionType = "BILL_SUBMITTED_FOR_REVIEW",
                            details = "${upgradeTag}Mã GD: $extractedTransId • Số tiền: ${extractedAmountVnd}đ • $targetTierName • Thiết bị: $extractedId",
                            targetDeviceId = extractedId,
                            forcePendingReview = true
                        )

                        val finalMsg = "📋 ĐÃ TIẾP NHẬN ẢNH BIÊN LAI CHUYỂN KHOẢN!\n\n" +
                            "• Thiết bị yêu cầu: `$extractedId`\n" +
                            "• Gói yêu cầu: $targetTierName\n" +
                            "• Số tiền ghi nhận: `${extractedAmountVnd}đ`\n" +
                            "• Mã GD Ngân hàng: `$extractedTransId`\n\n" +
                            "⏳ TRẠNG THÁI: CHỜ ADMIN ĐỐI SOÁT TÀI KHOẢN NGÂN HÀNG\n" +
                            "Hệ thống đã gửi biên lai này đến Trang Quản Trị của Admin. Để đảm bảo an toàn doanh thu và tránh nhầm lẫn, Admin sẽ kiểm tra số dư thực tế trong tài khoản ngân hàng và bấm duyệt cấp Pro cho bạn trong 1 - 3 phút!\n\n" +
                            "💡 Ngay khi Admin bấm duyệt trên trang quản trị, máy bạn sẽ tự động mở khóa bản Pro vĩnh viễn mà không cần thao tác thêm."

                        LicenseManager.logAiProChatInteraction(
                            context = context,
                            userMessage = "🖼️ [Gửi ảnh biên lai chuyển khoản] Thiết bị: $extractedId • Mã GD: $extractedTransId",
                            aiReply = "$finalMsg\n(Chi tiết giám định bill: $reply)",
                            eventType = "BILL_PENDING_ADMIN_APPROVAL",
                            proGranted = false,
                            grantedTier = "NONE",
                            targetDeviceId = extractedId,
                            billImageHash = billImageSha256,
                            billPerceptualHash = billPerceptualHash,
                            bankTransCode = extractedTransId,
                            forensicVerdict = extractedForensic
                        )
                        finalMsg
                    }
                } else {
                    val detailedRejection = if (programmaticFailReasons.isNotEmpty()) {
                        "Không vượt qua bước đối soát dữ liệu bắt buộc:\n  - " + programmaticFailReasons.joinToString("\n  - ")
                    } else {
                        reply.replace("INVALID:", "", ignoreCase = true)
                            .replace("INVALID", "", ignoreCase = true)
                            .trim()
                            .removePrefix(":")
                            .trim()
                    }

                    val rejectMsg = "⚠️ Kết quả kiểm tra tự động: $detailedRejection\n\n" +
                        "⏳ **ĐÃ ĐẨY VỀ DANH SÁCH CHỜ DUYỆT CỦA ADMIN (`[Ô 3] Chờ Duyệt`)**:\n" +
                        "• Đơn của thiết bị `$deviceId` chưa đủ điều kiện duyệt tự động nên hệ thống đã đẩy vào danh sách Chờ Duyệt để Admin kiểm tra và duyệt thủ công.\n" +
                        "• Nếu bạn đã chuyển khoản đúng tới STK `$bankAccount` (`$bankHolder`), Admin sẽ nhận được thông báo ngay trên màn hình khóa và duyệt mở khóa Pro cho bạn trong ít phút!$proPreservedSuffix"

                    // Đẩy toàn bộ đơn chưa được duyệt tự động về danh sách Chờ Duyệt ở Quản Trị để Admin duyệt thủ công
                    val manualUpgradeTag = if (isAlreadyDevicePro && !isAlreadyAccountPro) "Nâng cấp từ Pro Máy lên Pro Tài Khoản • " else ""
                    LicenseManager.logCustomerPaymentIntent(
                        context = context,
                        actionType = "BILL_NEEDS_MANUAL_REVIEW",
                        details = "${manualUpgradeTag}Đơn chưa duyệt tự động (Chờ Admin duyệt thủ công) • Lý do: ${detailedRejection.replace("\n", " ").take(180)} • Mã GD: ${extractedTransId.ifBlank { "Chưa rõ" }} • Số tiền: ${extractedAmountVnd}đ",
                        targetDeviceId = deviceId,
                        forcePendingReview = true
                    )

                    LicenseManager.logAiProChatInteraction(
                        context = context,
                        userMessage = "🖼️ [Đơn chưa duyệt tự động -> Đã đẩy về Chờ Duyệt Admin] Thiết bị: $deviceId",
                        aiReply = rejectMsg,
                        eventType = "BILL_REJECTED",
                        proGranted = false,
                        grantedTier = "NONE",
                        targetDeviceId = deviceId,
                        billImageHash = billImageSha256,
                        billPerceptualHash = billPerceptualHash,
                        bankTransCode = extractedTransId,
                        forensicVerdict = detailedRejection
                    )
                    rejectMsg
                }
            } else {
                val fallbackUpgradeTag = if (isAlreadyDevicePro && !isAlreadyAccountPro) "Nâng cấp từ Pro Máy lên Pro Tài Khoản • " else ""
                LicenseManager.logCustomerPaymentIntent(
                    context = context,
                    actionType = "BILL_NEEDS_MANUAL_REVIEW",
                    details = "${fallbackUpgradeTag}Khách gửi ảnh biên lai chuyển khoản (Máy chủ AI bận -> Đẩy về danh sách Chờ Duyệt để Admin duyệt thủ công)",
                    targetDeviceId = deviceId,
                    forcePendingReview = true
                )
                "⏳ Đã tiếp nhận ảnh biên lai của thiết bị `$deviceId` và đẩy trực tiếp về **Danh Sách Chờ Duyệt (`[Ô 3] Chờ Duyệt`)** của Admin! Admin đã nhận được thông báo và sẽ duyệt mở khóa Pro cho bạn ngay."
            }

        } catch (e: Throwable) {
            val errUpgradeTag = if (LicenseManager.isProActivated(context) && !LicenseManager.isAccountProActivated(context)) {
                "Nâng cấp từ Pro Máy lên Pro Tài Khoản • "
            } else ""
            LicenseManager.logCustomerPaymentIntent(
                context = context,
                actionType = "BILL_NEEDS_MANUAL_REVIEW",
                details = "${errUpgradeTag}Khách gửi ảnh biên lai chuyển khoản (Cần Admin duyệt thủ công: ${e.message?.take(80)})",
                targetDeviceId = LicenseManager.getDeviceId(context),
                forcePendingReview = true
            )
            "⏳ Đã đẩy yêu cầu duyệt biên lai của bạn về **Danh Sách Chờ Duyệt (`[Ô 3] Chờ Duyệt`)** để Admin kiểm tra và duyệt thủ công!"
        }

    }

}



/**

 * Dịch tin nhắn ngoại ngữ sang Tiếng Việt (ẩn hoàn toàn tên công cụ AI dưới nền)

 */

private suspend fun translateForeignMessageToVietnamese(

    context: Context,

    msg: ChatMessage,

    messagesList: MutableList<ChatMessage>

) {

    val idx = messagesList.indexOfFirst { it.id == msg.id }

    if (idx == -1) return



    messagesList[idx] = messagesList[idx].copy(isTranslating = true)



    val translated = withContext(Dispatchers.IO) {

        try {
            val sysTranslatePrompt = "Bạn là trình biên dịch chuyên nghiệp. Hãy dịch chính xác và tự nhiên văn bản sau sang Tiếng Việt. Chỉ trả về đúng nội dung bản dịch Tiếng Việt, không giải thích thêm."
            val groqKeys = LicenseManager.getAllGroqApiKeys(context).toMutableList()
            val balancedKey = LicenseManager.getLoadBalancedGroqApiKey(context).ifBlank {
                try { com.example.BuildConfig.GROQ_API_KEY } catch (_: Throwable) { "" }
            }
            if (balancedKey.isNotBlank() && !groqKeys.contains(balancedKey)) {
                groqKeys.add(0, balancedKey)
            }
            val validGroqKeys = groqKeys.filter { it.isNotBlank() && it != "GROQ_API_KEY_DEFAULT_VALUE" }.distinct()
            val translateModels = listOf(
                "openai/gpt-oss-120b",
                "qwen/qwen3.8-27b",
                "llama-3.3-70b-versatile",
                "llama-3.1-8b-instant"
            )

            for (apiKey in validGroqKeys.take(3)) {
                for (tModel in translateModels) {
                    var conn: HttpURLConnection? = null
                    try {
                        conn = (URL("https://api.groq.com/openai/v1/chat/completions").openConnection() as HttpURLConnection).apply {
                            requestMethod = "POST"
                            doOutput = true
                            doInput = true
                            connectTimeout = 5_000
                            readTimeout = 10_000
                            setRequestProperty("Authorization", "Bearer $apiKey")
                            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                        }
                        val payload = org.json.JSONObject().apply {
                            put("model", tModel)
                            put("temperature", 0.2)
                            val messages = org.json.JSONArray()
                            messages.put(org.json.JSONObject().put("role", "system").put("content", sysTranslatePrompt))
                            messages.put(org.json.JSONObject().put("role", "user").put("content", msg.text))
                            put("messages", messages)
                        }
                        conn.outputStream.use { os ->
                            os.write(payload.toString().toByteArray(Charsets.UTF_8))
                            os.flush()
                        }
                        if (conn.responseCode in 200..299) {
                            val body = conn.inputStream.bufferedReader().use { it.readText() }
                            val root = org.json.JSONObject(body)
                            val out = root.optJSONArray("choices")
                                ?.optJSONObject(0)
                                ?.optJSONObject("message")
                                ?.optString("content", "")
                                ?.let { sanitizeChatSupportAiReply(it) }
                                .orEmpty()
                            if (out.isNotBlank()) return@withContext out
                        } else if (conn.responseCode == 429 || conn.responseCode == 401 || conn.responseCode == 403) {
                            LicenseManager.markGroqApiKeyCooldown(apiKey)
                            break
                        }
                    } catch (_: Throwable) {
                    } finally {
                        try { conn?.disconnect() } catch (_: Throwable) {}
                    }
                }
            }

            // Dự phòng dịch tự nhiên qua GoogleScreenTranslator hoặc Pollinations nếu Groq bận
            val googleNatural = try {
                com.example.core.widget.GoogleScreenTranslator.translateChatMessageNaturally(msg.text).trim()
            } catch (_: Throwable) { "" }
            if (googleNatural.isNotBlank() && !googleNatural.equals(msg.text.trim(), ignoreCase = true)) {
                return@withContext googleNatural
            }

            var pConn: HttpURLConnection? = null
            try {
                pConn = (URL("https://text.pollinations.ai/").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 5_000
                    readTimeout = 8_000
                    doOutput = true
                    doInput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                }
                val pBody = org.json.JSONObject().apply {
                    put("model", "openai")
                    put("messages", org.json.JSONArray().apply {
                        put(org.json.JSONObject().put("role", "system").put("content", sysTranslatePrompt))
                        put(org.json.JSONObject().put("role", "user").put("content", msg.text))
                    })
                }
                pConn.outputStream.use { it.write(pBody.toString().toByteArray(Charsets.UTF_8)) }
                if (pConn.responseCode in 200..299) {
                    val out = sanitizeChatSupportAiReply(pConn.inputStream.bufferedReader().use { it.readText() })
                    if (out.isNotBlank()) return@withContext out
                }
            } catch (_: Throwable) {
            } finally {
                try { pConn?.disconnect() } catch (_: Throwable) {}
            }

            "Không thể dịch tin nhắn lúc này."
        } catch (e: Throwable) {
            "Lỗi khi dịch tin nhắn: ${e.message}"
        }
    }

    messagesList[idx] = messagesList[idx].copy(
        translatedText = translated,
        isTranslating = false
    )
}

/**
 * Xây dựng bộ kiến thức đầy đủ, chuẩn xác 100% về mọi tính năng của ứng dụng MagicTune
 * VÀ quy tắc thực thi lệnh cấp Pro có kiểm chứng (Anti-Hallucination Action Tags).
 */
private fun sanitizeChatSupportAiReply(raw: String): String {
    return raw
        .replace(Regex("<think>[\\s\\S]*?</think>"), "")
        .replace(
            Regex("(?i)\\b(groq\\s*ai|groq|grock|llama[-\\s\\d.a-z]*|meta\\s*ai|qwen[-\\s\\d.a-z]*|pollinations(?:\\s*ai)?|chatgpt|gpt-[\\d.a-z-]+)\\b"),
            "Trợ lý AI MagicTune"
        )
        .trim()
}

private fun buildMagicTuneKnowledgePrompt(context: Context): String {
    val deviceId = LicenseManager.getDeviceId(context)
    val isPro = LicenseManager.isProActivated(context)
    val proTierLabel = LicenseManager.getProTierLabel(context)
    val bank = LicenseManager.getPaymentBankName(context)
    val acc = LicenseManager.getPaymentAccountNumber(context)
    val holder = LicenseManager.getPaymentAccountHolder(context)
    val commercialName = try {
        com.example.core.widget.MagicLiveActionExecutor.getCommercialDeviceName(context)
    } catch (_: Throwable) {
        "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}"
    }
    val magicOsVer = try {
        com.example.core.widget.MagicLiveActionExecutor.getMagicOsVersion()
    } catch (_: Throwable) {
        "MagicOS"
    }
    val userName = try {
        com.example.core.widget.MagicLiveActionExecutor.getUserDisplayName(context)
    } catch (_: Throwable) {
        "bạn"
    }

    val deviceProPrice = LicenseManager.getProPrice(context)
    val accountProPrice = LicenseManager.getAccountProPrice(context)
    val upgradeProPrice = LicenseManager.getUpgradeToAccountProPrice(context)

    return """
        Tên của bạn là TRỢ LÝ AI MAGICTUNE (cùng nền tảng trí tuệ nhân tạo thế hệ mới với MAGIC LIVE của ứng dụng Magictune_Tool_${com.example.data.APP_VERSION_NAME} trên điện thoại Honor / Android).
        BẢO MẬT DANH TÍNH TUYỆT ĐỐI: Trong mọi hoàn cảnh, bạn TUYỆT ĐỐI KHÔNG BAO GIỜ được nhắc đến, tiết lộ hoặc thừa nhận các từ khóa: Groq, Grock, Llama, LLaMA, Meta, Qwen, Alibaba, Pollinations, OpenAI, ChatGPT, GPT hay bất kỳ tên mô hình/API bên thứ ba nào! Nếu người dùng hỏi bạn là ai hoặc dùng mô hình gì, hãy trả lời tự nhiên: "Mình là Trợ lý AI MagicTune (chung lõi trí tuệ nhân tạo tốc độ cao với MAGIC LIVE), luôn đồng hành cùng bạn!".

        NGUYÊN TẮC PHÂN QUYỀN BẢN QUYỀN BẤT DI BẤT DỊCH (CHỈ CẤP PRO & CHỐNG GIAN LẬN — CẤM HẠ CẤP HAY THU HỒI PRO):
        1. Trợ lý AI (Chatbot) CHỈ có thẩm quyền:
           • Cấp mới hoặc Nâng cấp quyền Pro (khi người dùng gửi đúng Mã Key SHA-256 hợp lệ hoặc gửi Ảnh biên lai chuyển khoản thanh toán hợp lệ qua nút 🖼️).
           • Ngăn chặn gian lận (từ chối cấp thêm đối với biên lai giả mạo, biên lai chỉnh sửa EXIF/Photoshop, biên lai dùng lại hoặc báo chuyển khoản miệng không có ảnh bill).
        2. Trợ lý AI TUYỆT ĐỐI KHÔNG CÓ QUYỀN hạ cấp (từ Pro Tài Khoản xuống Pro Thiết Bị) hay thu hồi quyền Pro của bất kỳ khách hàng Pro nào trong mọi tình huống!
        3. Chỉ duy nhất ADMIN (trên Trang Quản Trị Admin) mới có quyền hạ cấp hoặc thu hồi quyền Pro. Nếu khách đang có Pro gửi nhầm ảnh hoặc hỏi về việc mất/bị thu hồi Pro, hãy khẳng định rõ ràng rằng quyền Pro hiện tại của bạn ($proTierLabel) luôn được bảo vệ và giữ nguyên 100%.

        HƯỚNG DẪN GIẢI THÍCH & XOA DỊU NGƯỜI DÙNG KHI HỎI TẠI SAO ĐIỆN THOẠI NÓNG LÊN & HAO PIN (ĐẶC BIỆT KHI CÓ MẠNG WIFI / 4G):
        1. Luôn mở đầu bằng sự đồng cảm, xoa dịu và tạo sự an tâm tuyệt đối: "Bạn hoàn toàn yên tâm nhé!..." để người dùng không lo lắng.
        2. Giải thích khoa học và thực tế: Khi điện thoại kết nối Wi-Fi/4G, hàng loạt ứng dụng nền bên thứ ba (đặc biệt là Facebook, TikTok, Shopee, Google Play Services, Dịch vụ tìm kiếm hệ thống Honor SearchService và các dịch vụ đồng bộ đám mây) sẽ đồng loạt thức dậy cùng một lúc để kéo dữ liệu mới, tải ngầm video, đồng bộ ảnh và gửi gói tin đo lường. Đợt dồn tải mạng đồng thời này khiến CPU phải thức liên tục và đẩy nhiệt độ máy tăng lên tạm thời.
        3. Khẳng định MagicTune hoàn toàn không gây nóng máy: Bản thân MagicTune hoạt động cực kỳ nhẹ theo cơ chế phản hồi sự kiện, đã ngắt bỏ MulticastLock và không giữ WakeLock ngầm.
        4. Hướng dẫn giải pháp cụ thể giúp máy mát mẻ ngay:
           • Sang ngay Tab 7 (Giám sát Xả Pin Nền) để xem app nào ngốn CPU/RAM và bấm "❄️ Ngủ Sâu" hoặc "🛑 Force-Stop 0%" (đặc biệt là Facebook, TikTok, Shopee).
           • Bật "Vô Hiệu Xung Đột Hãng" (Ô #20) qua kết nối WLAN (Ô #40-#43) để đóng băng an toàn các dịch vụ gây giằng co của hãng (PowerGenius, iAware, HiSearch, AMap/Baidu).
           • Bật "Siêu tiết kiệm pin Zero Delay" (Ô #18) và "Tiết kiệm pin mạng" (Ô #30).

        QUY TẮC TRÒ CHUYỆN TỰ NHIÊN, THÔNG MINH VÀ TỐC ĐỘ CAO NHƯ MAGIC LIVE:
        1. Xưng hô "mình" - "bạn" (hoặc gọi tên "$userName" một cách thân thiết). Trò chuyện cực kỳ tự nhiên, ấm áp, thông minh, sắc sảo, có hồn và đi thẳng vào trọng tâm câu hỏi của người dùng ngay từ câu đầu tiên.
        2. CẤM dùng các câu văn mẫu sáo rỗng kiểu robot ("Tôi là một trợ lý ảo...", "Hy vọng thông tin trên hữu ích..."). Hãy trả lời cụ thể, thực tế, dễ hiểu và giàu cảm xúc như một người bạn tri kỷ kiêm chuyên gia Honor / Android thực thụ.
        3. Bạn có trí nhớ đầy đủ về toàn bộ lịch sử cuộc trò chuyện hiện tại. Hãy luôn liên kết mạch chuyện tự nhiên.
        4. KHÔNG quảng cáo lạc đề: Nếu người dùng hỏi chuyện đời thường, tâm sự, kiến thức xã hội, ẩm thực, học tập, công việc... hãy trả lời tự nhiên và cuốn hút đúng chủ đề đó, không tự ý lôi cấu hình máy hay tính năng kỹ thuật vào.

        THÔNG TIN THIẾT BỊ & BẢN QUYỀN HIỆN TẠI CỦA NGƯỜI DÙNG:
        • Dòng máy đang dùng: $commercialName (${android.os.Build.MODEL} • $magicOsVer • Android ${android.os.Build.VERSION.RELEASE})
        • ID Thiết bị cố định: $deviceId
        • Trạng thái Bản quyền: $proTierLabel (${if (isPro) "Đã kích hoạt PRO vĩnh viễn — Được bảo vệ 100%, Chatbot không bao giờ hạ cấp hay thu hồi" else "Bản Miễn Phí"})
        • Trạng thái Đăng nhập Tài khoản: ${if (com.example.core.auth.FirebaseAuthManager.getCurrentUser() != null) "Đã đăng nhập tài khoản (${com.example.core.auth.FirebaseAuthManager.getCurrentUser()?.email ?: "UID hợp lệ"})" else "Chưa đăng nhập tài khoản"}
        • Thông tin chuyển khoản nâng cấp Pro tự động: ${if (com.example.core.auth.FirebaseAuthManager.getCurrentUser() != null) "Tài khoản nhận: $bank • STK: $acc • Chủ TK: $holder • Nội dung chuyển khoản: $deviceId (Gói Pro Thiết Bị: $deviceProPrice cố định theo máy; Gói Pro Tài Khoản: $accountProPrice đổi máy tự do, tối đa 1 máy kích hoạt tại một thời điểm; Nâng cấp từ Pro Thiết Bị lên Pro Tài Khoản: $upgradeProPrice)." else "Tài khoản nhận: $bank • STK: $acc • Chủ TK: $holder • Nội dung chuyển khoản: $deviceId (Hiện chỉ hiển thị và nhận chuyển khoản cho Gói Pro Thiết Bị: $deviceProPrice cố định theo máy. LƯU Ý BẮT BUỘC: Do máy hiện chưa đăng nhập tài khoản, TUYỆT ĐỐI KHÔNG cung cấp hướng dẫn chuyển khoản gói Pro Tài Khoản cho đến khi người dùng Đăng Nhập tài khoản thành công tại mục Tài Khoản & Bản Quyền Pro để tránh chuyển khoản xong không có tài khoản nào để cấp Pro TK)."}
        • Cơ chế Khôi Phục Pro Tự Động: Ứng dụng tự động nhận diện máy Pro quen thuộc qua ID phần cứng ngay khi mở app (hoặc khi bấm nút Khôi phục / gửi ảnh biên lai qua nút 🖼️) mà không bắt buộc đăng nhập đối với gói Pro Thiết Bị.

        KIẾN THỨC TOÀN DIỆN VỀ TẤT CẢ TÍNH NĂNG TRONG MAGICTUNE (${com.example.data.APP_VERSION_NAME}):
        • Tab 1 - Thiết Lập (Ô #00 đến Ô #08):
          - [Ô #00]: Bản quyền Pro, Mã Thiết Bị phần cứng & Khôi phục Pro tự động trên máy quen.
          - [Ô #01]: Giám sát phần cứng thời gian thực (CPU, GPU, RAM, ROM, Chu kỳ sạc, Sức khỏe pin, Nhiệt độ, Cảm biến, Kernel), hiển thị trạng thái Đang bật / Đang tắt của các mục phần cứng kèm nút bánh răng ⚙️ mở thẳng Cài đặt bật/tắt thủ công & Mở khóa dung lượng pin thực 97% (đệm 3% bảo vệ tuổi thọ pin) hoặc 100% (phá khóa 80% ảo của Dung lượng pin thông minh Honor).
          - [Ô #02]: 1-Chạm Thiết lập toàn diện 8-trong-1 & Cài nhanh không cần ADB cho máy mới.
          - [Ô #03]: Khôi phục & mở Cập nhật hệ điều hành MagicOS (OUC / HOTA) bị ẩn hoặc mất.
          - [Ô #04]: Bàn phím Tiếng Việt MagicTune Telex AI tích hợp sẵn (gõ Telex chuẩn, sửa ngữ pháp, dịch thuật, nhập giọng nói) kèm cài nhanh Laban Key & Gboard không cần ADB.
          - [Ô #05]: Việt hóa ngôn ngữ hệ thống 100% (vi-VN), múi giờ Việt Nam (GMT+7) & định dạng 24H.
          - [Ô #06]: Đồng bộ Google Play Services (GMS), CH Play & Danh bạ Google.
          - [Ô #07]: Chặn chợ ứng dụng Honor AppMarket tự động cập nhật đè app tiếng Việt sang bản nội địa.
          - [Ô #08]: Đặc trị định vị GPS, La bàn số trực quan, Google Maps & cấp full quyền cho Timestamp Camera (tắt định vị AMap/Baidu gây lệch vị trí).
        • Tab 2 - Thông Báo (Ô #09 đến Ô #15):
          - [Ô #09]: Mở khóa 100% thông báo 6 tầng, tắt PowerGenius & cấp full quyền pin/AppOps 24/7.
          - [Ô #10]: Bảng sửa tắt từng ứng dụng mạng xã hội cụ thể (Zalo, Messenger, Facebook, TikTok, Telegram, Gmail, Shopee...).
          - [Ô #11]: Công tắc tiện ích thanh thông báo (Ghim ô tìm kiếm, hiển thị công suất sạc Watt, tự sáng màn hình Auto-Wake khi có tin nhắn).
          - [Ô #12]: Ưu tiên chuông & âm thanh tùy chỉnh cho tin nhắn.
          - [Ô #13]: Đặc trị FCM Facebook & cấp quyền Tự khởi chạy (Auto-start).
          - [Ô #14]: Phá gom cụm 0s Gmail Push & ưu tiên cuộc gọi VoLTE / VoWiFi.
          - [Ô #15]: Khuyến nghị dùng bản WebADB gỡ lỗi qua cáp USB tại https://magictunehonor.ai.studio/ nếu muốn bật biểu ngữ & tắt thông báo nhẹ nhàng hàng loạt hiệu quả hơn (do gỡ lỗi WLAN không tự gạt công tắc trong Cài đặt được), kèm quét chẩn đoán tiến trình ngầm.
        • Tab 3 - Tối Ưu & AI (Ô #16 đến Ô #31):
          - [Ô #16]: 2 nút điều hướng tích hợp sẵn: Nhấn giữ góc trái gọi Khoanh tròn hỏi AI & Dịch màn hình; chạm/giữ góc phải mở Bảng Vẽ Chữ mở nhanh ứng dụng & Trợ lý tiếng Việt MAGIC LIVE (giữ YOYO hoạt động song song).
          - [Ô #17]: Cài đặt siêu tốc tệp APK bỏ qua chặn bảo mật Honor.
          - [Ô #18]: Siêu tiết kiệm pin thông minh Zero Delay & Tối ưu cảm ứng đáy, tăng nhạy vân tay quang học khi dán kính cường lực dày (>0.45mm).
          - [Ô #19]: Ép màn hình 120Hz / 144Hz & tăng tốc độ chuyển cảnh 0.5x.
          - [Ô #20]: Khóa cứng vĩnh viễn tần số quét (90Hz/120Hz/144Hz) & độ phân giải màn hình (FHD+, 1.2K+, 1.5K, 2K QHD+) bất chấp tiết kiệm pin; tích hợp nút "Vô Hiệu Xung Đột" (TỰ ĐỘNG CHẠY NGAY KHI KẾT NỐI GỠ LỖI WLAN THÀNH CÔNG) giúp đóng băng an toàn các dịch vụ gây giằng co CPU, nóng máy & hao pin (PowerGenius, PowerGenie, iAware, Magazine, HiBoard, HiAI, AMap/Baidu...) mà không ảnh hưởng ROM.
          - [Ô #21]: Chặn quảng cáo toàn diện AdBlocker Pro (Private DNS).
          - [Ô #22]: Tắt vuốt xuống tìm kiếm Honor (HiSearch).
          - [Ô #27]: Giảm tải theo yêu cầu bằng chế độ Tiết kiệm pin Android qua ADB; app không tự quét/làm mát nền.
          - [Ô #24]: Sửa rè âm thanh Bluetooth Hi-Fi 48kHz.
          - [Ô #25]: Đặc trị kết nối Android Auto trên màn hình xe hơi.
          - [Ô #26]: Ẩn trạng thái Chế độ nhà phát triển (TỰ ĐỘNG CHẠY NGẦM NGAY KHI KẾT NỐI GỠ LỖI WLAN) giúp mở bình thường các ứng dụng tài chính, thanh toán và trò chơi bảo mật cao. Riêng các ứng dụng kiểm tra sâu tiến trình Gỡ lỗi Wi-Fi (adbd) báo SEC-10 hoặc Mã 10 dù đã tắt Nhà phát triển: bấm nút "TẮT SẠCH ADB & ẨN DEV MODE" trên Ô #26 để ngắt sạch adb_wifi_enabled, đưa USB về MTP và xóa cache app (hoặc vào Cài đặt -> Hệ thống -> Tùy chọn đặt lại -> Đặt lại tùy chọn nhà phát triển nếu máy lưu cache sau khi ngắt WLAN).
          - [Ô #27]: Mở khóa & giải nén thư mục Android/data và Android/obb trên Android 11–17.
          - [Ô #28]: Kiểm soát quyền riêng tư cảm biến cấp độ sâu (Camera, Micro, Vị trí, Clipboard).
          - [Ô #29]: Tự động hóa & kịch bản hệ thống (Macro Game Turbo & Dọn đa nhiệm).
          - [Ô #30]: Tăng tốc độ Wi-Fi, Wi-Fi kép Link Turbo & tiết kiệm pin mạng 24/7.
          - [Ô #31]: Trải nghiệm mượt mà chuẩn iOS ProMotion & MagicOS Fluid Touch (chạm 0ms, LTPO thích ứng).
        • Các Tab Chuyên Sâu Khác (Ô #32 đến Ô #55, Widget & Quản Trị Admin):
          - [Ô #32–#33]: Trạm dọn rác hệ thống, cấp quyền hàng loạt & quản lý đóng băng/gỡ/khôi phục gói ứng dụng sâu có icon thật.
          - [Ô #34–#35]: Kho ứng dụng Honor & Cộng đồng (tải Google App, YOYO, Shizuku, Font, Theme Việt hóa & đăng chia sẻ app).
          - [Ô #36–#37]: Vẽ chữ cái A–Z & viết tên mở nhanh ứng dụng lên màn hình, tạo nét vẽ mẫu tùy chỉnh.
          - [Ô #38]: Trợ lý AI Hỗ trợ trực tuyến 24/7 & gửi ảnh biên lai duyệt Pro tự động.
          - [Ô #39]: Hộp lệnh ADB Shell Runner Pro (chạy lệnh trực tiếp, xem log chi tiết & sao chép nhanh lệnh lỗi đỏ).
          - [Ô #40–#43]: Kết nối Gỡ lỗi không dây trực tiếp bằng mã ghép đôi 6 số ngay trên thanh thông báo / chia đôi màn hình hoặc qua Shizuku. Khi kết nối WLAN thành công, hệ thống tự động chạy ngay Vô hiệu hóa xung đột (Ô #20) và Ẩn chế độ nhà phát triển (Ô #26)!
          - [Ô #44–#45]: Trung tâm tối ưu Đa Hãng OEM (Xiaomi HyperOS/MIUI, Oppo/Realme/OnePlus ColorOS, Vivo/iQOO OriginOS, Samsung OneUI, Huawei HarmonyOS).
          - [Ô #46–#51]: Máy in nhiệt đơn hàng K80 (80mm) / K57 (58mm) qua Wi-Fi/LAN (Port 9100) & Bluetooth (in đơn Shopee, TikTok, PDF nhiều trang, tự cắt giấy, xem trước đốt nhiệt).
          - [Ô #52–#55]: Quản lý Tài Khoản Pro, Lịch Âm Dương & Thời Tiết 63 Tỉnh Thành, Bảo Mật Mã Khóa & Trung Tâm Cài Đặt Cá Nhân Hóa.
          - [Widget Pin Live]: Tiện ích ngoài màn hình chính hiển thị % pin, nhiệt độ, dòng sạc theo thời gian thực.
          - [Trang Quản Trị Admin (Ô 1.0 đến Ô 1.9)]: Tải lên APK bản mới nhất tự động (Ô 1.0), đồng bộ Knowledge Base AI (Ô 1.1), cấu hình giá Pro (Ô 1.2), Dead Man Switch tự động miễn phí (Ô 1.3), VietQR nhận tiền (Ô 1.4), cấu hình link hỗ trợ/cập nhật (Ô 1.5), bật/tắt chế độ Free toàn cục (Ô 1.6), tạo Key Pro từ xa (Ô 1.7), đổi tên app, số v & cỡ chữ Header (Ô 1.8), thanh trượt điều chỉnh mức thu phóng giao diện toàn cục từ 80% đến 100% tự động lưu vĩnh viễn (Ô 1.9), và nút "Dọn Ngày Cũ" chạy ngầm dưới nền.
    """.trimIndent()
}

private suspend fun fetchSupportResponse(
    context: Context,
    userQuery: String,
    conversationHistory: List<ChatMessage>
): String {
    return withContext(Dispatchers.IO) {
        val currentDeviceId = LicenseManager.getDeviceId(context)
        val lowerQuery = userQuery.lowercase()
        val isProQuery = lowerQuery.contains(Regex("pro|ck|chuyển khoản|thanh toán|nâng cấp|key|mất|khôi phục|cài lại|xóa|hạ cấp|thu hồi"))

        // 0. Nếu người dùng hỏi hoặc yêu cầu Chatbot "thu hồi pro" / "hạ cấp pro" -> Khẳng định ngay quy tắc bảo mật: Chỉ Admin mới có quyền hạ cấp/thu hồi Pro!
        if (lowerQuery.contains(Regex("thu hồi\\s*pro|hạ cấp\\s*pro|hủy\\s*pro|xóa\\s*quyền\\s*pro"))) {
            val currentTier = LicenseManager.getProTierLabel(context)
            return@withContext "🛡️ **Quy tắc Bảo mật Bản quyền MagicTune:**\n\n" +
                "• **Trợ lý AI (Chatbot)** chỉ có quyền **cấp mới / nâng cấp Pro** và **ngăn chặn gian lận** (chặn bill giả, bill chỉnh sửa hoặc trùng lặp), **tuyệt đối không có quyền hạ cấp hay thu hồi quyền Pro** của bất kỳ khách hàng Pro nào.\n" +
                "• Chỉ duy nhất **Admin** trên Trang Quản Trị mới có thẩm quyền hạ cấp hoặc thu hồi bản quyền.\n" +
                "• Trạng thái hiện tại của máy `$currentDeviceId`: **$currentTier** (Được giữ nguyên và bảo vệ an toàn 100%)."
        }

        // 1. Kiểm tra Key trực tiếp (Chỉ cấp mới hoặc nâng cấp, tuyệt đối không hạ cấp nếu máy đã là Pro Tài Khoản)
        val keyRegex = Regex("""\b(TKPR-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}|[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4})\b""", RegexOption.IGNORE_CASE)
        keyRegex.find(userQuery)?.value?.uppercase()?.let { candKey ->
            if (LicenseManager.verifyLicenseKey(context, candKey)) {
                val isAcc = candKey.startsWith("TKPR", ignoreCase = true) || (!candKey.startsWith("PRO", ignoreCase = true) && (LicenseManager.isAccountProActivated(context) || LicenseManager.isUpgradedToAccountPro(context)))
                val res = LicenseManager.executeVerifiedProGrant(context, currentDeviceId, isAcc, "CHAT_KEY")
                val msg = "🎉 Mã khóa hợp lệ! Đã kích hoạt Pro:\n\n${res.summaryMessage}"
                LicenseManager.logAiProChatInteraction(context, userQuery, msg, "KEY_VERIFIED", true, if (res.isAccountPro) "ACCOUNT_PRO" else "DEVICE_PRO", res.generatedKey, currentDeviceId)
                return@withContext msg
            } else if (LicenseManager.isProActivated(context)) {
                val currentTier = LicenseManager.getProTierLabel(context)
                return@withContext "ℹ️ Mã khóa `$candKey` không khớp với thiết bị `$currentDeviceId`, nhưng bạn yên tâm nhé: máy bạn đang có sẵn bản quyền **$currentTier** và quyền Pro của bạn vẫn được **giữ nguyên 100%**!"
            }
        }

        // 2. Tự động nhận diện Pro khi hỏi (Chỉ quét Cloud khi người dùng chưa có Pro và thực sự hỏi về Pro/Thanh toán/Khôi phục để tránh ghi đè hoặc làm chậm phản hồi)
        val wasPro = LicenseManager.isProActivated(context)
        if (!wasPro && isProQuery) {
            if (LicenseManager.checkDeviceRecognizedProInCloud(context)) {
                val tier = if (LicenseManager.isAccountProActivated(context)) "👑 PRO TÀI KHOẢN" else "📱 PRO THIẾT BỊ"
                val msg = "✅ Nhận diện máy Pro quen thuộc! Đã tự động khôi phục quyền $tier cho thiết bị $currentDeviceId."
                LicenseManager.logAiProChatInteraction(context, userQuery, msg, "CLOUD_RESTORED", true, tier, "", currentDeviceId)
                return@withContext msg
            }
        }

        // 3. Chặn khách báo đã chuyển khoản mồm khi chưa gửi ảnh bill
        if (isProQuery && !LicenseManager.isProActivated(context) &&
            (lowerQuery.contains("chuyển khoản rồi") || lowerQuery.contains("ck rồi") || lowerQuery.contains("thanh toán rồi") || lowerQuery.contains("nạp rồi"))
        ) {
            val bank = LicenseManager.getPaymentBankName(context)
            val acc = LicenseManager.getPaymentAccountNumber(context)
            val msg = "🛡️ Hệ thống chưa nhận được ảnh biên lai cho máy `$currentDeviceId`.\n\n⚠️ Bạn vui lòng gửi **[ẢNH CHỤP BIÊN LAI]** bằng cách bấm nút 🖼️ bên cạnh ô nhập tin nhắn nhé! Hệ thống Auto-Admin sẽ tự động đối soát và kích hoạt Pro ngay lập tức khi xác thực đúng biên lai tới STK `$acc` ($bank)."
            LicenseManager.logAiProChatInteraction(context, userQuery, msg, "UNPAID_BLOCKED", false, "NONE", "", currentDeviceId)
            return@withContext msg
        }

        // 4. LUỒNG AI SIÊU TỐC ĐỘ ĐỒNG BỘ 100% VỚI MAGIC LIVE (Groq LPU Multi-Key + Multi-Model -> Magic Live Flash -> Pollinations OpenAI Gateway)
        try {
            val longTermBrain = com.example.core.widget.MagicLiveBrainMemory.buildLongTermBrainSystemInstruction(
                context = context,
                currentUserQuery = userQuery
            )
            val sysPrompt = buildMagicTuneKnowledgePrompt(context) + "\n\n" + longTermBrain
            val messages = org.json.JSONArray().apply {
                put(org.json.JSONObject().put("role", "system").put("content", sysPrompt))
                val historySlice = conversationHistory
                    .filter { it.text.isNotBlank() && !it.text.startsWith("⏳") }
                    .takeLast(14)
                historySlice.forEachIndexed { idx, msg ->
                    val isDuplicateCurrentUserMsg = (idx == historySlice.lastIndex && msg.sender == "user" && msg.text.trim() == userQuery.trim())
                    if (!isDuplicateCurrentUserMsg) {
                        put(
                            org.json.JSONObject()
                                .put("role", if (msg.sender == "user") "user" else "assistant")
                                .put("content", msg.text)
                        )
                    }
                }
                put(org.json.JSONObject().put("role", "user").put("content", userQuery))
            }

            // Tầng 1: Động cơ LPU Groq Siêu Tốc (Dùng dàn model chuẩn tốc độ cao: llama-3.3-70b-versatile, qwen/qwen3-32b, openai/gpt-oss-120b, openai/gpt-oss-20b, llama-3.1-8b-instant)
            val groqKeys = LicenseManager.getAllGroqApiKeys(context).toMutableList()
            val balancedKey = LicenseManager.getLoadBalancedGroqApiKey(context).ifBlank {
                try { com.example.BuildConfig.GROQ_API_KEY } catch (_: Throwable) { "" }
            }
            if (balancedKey.isNotBlank() && !groqKeys.contains(balancedKey)) {
                groqKeys.add(0, balancedKey)
            }
            val validGroqKeys = groqKeys.filter { it.isNotBlank() && it != "GROQ_API_KEY_DEFAULT_VALUE" }.distinct()

            if (validGroqKeys.isNotEmpty()) {
                val fastModels = listOf(
                    "openai/gpt-oss-120b",
                    "qwen/qwen3.8-27b",
                    "llama-3.3-70b-versatile",
                    "openai/gpt-oss-20b",
                    "llama-3.1-8b-instant"
                )
                for (apiKey in validGroqKeys.take(3)) {
                    for (model in fastModels) {
                        var conn: HttpURLConnection? = null
                        try {
                            conn = (URL("https://api.groq.com/openai/v1/chat/completions").openConnection() as HttpURLConnection).apply {
                                requestMethod = "POST"
                                doOutput = true
                                doInput = true
                                connectTimeout = 4500
                                readTimeout = 10000
                                setRequestProperty("Authorization", "Bearer $apiKey")
                                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15; MagicTune) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36")
                            }
                            val body = org.json.JSONObject().apply {
                                put("model", model)
                                put("messages", messages)
                                put("temperature", 0.65)
                                put("max_tokens", 650)
                                if (model.contains("gpt-oss")) {
                                    put("max_completion_tokens", 650)
                                }
                            }
                            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                            val code = conn.responseCode
                            if (code in 200..299) {
                                val resp = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                                val content = org.json.JSONObject(resp)
                                    .optJSONArray("choices")
                                    ?.optJSONObject(0)
                                    ?.optJSONObject("message")
                                    ?.optString("content", "")
                                    .orEmpty()
                                val cleaned = sanitizeChatSupportAiReply(content)
                                if (cleaned.isNotBlank()) {
                                    com.example.core.widget.MagicLiveBrainMemory.recordConversationTurn(
                                        context = context,
                                        userQuery = userQuery,
                                        assistantReply = cleaned,
                                        appName = "MagicTune Chat"
                                    )
                                    return@withContext cleaned
                                }
                            } else if (code == 429 || code == 401 || code == 403) {
                                LicenseManager.markGroqApiKeyCooldown(apiKey)
                                break // Đổi ngay sang API key tiếp theo trong 0ms
                            }
                        } catch (_: Throwable) {
                        } finally {
                            try { conn?.disconnect() } catch (_: Throwable) {}
                        }
                    }
                }
            }

            // Tầng 2: Google Magic Live 2.5 Flash / 2.0 Flash trực tiếp nếu có Magic Live Key
            val magic_liveKeys = LicenseManager.getAllMagicLiveApiKeys(context).filter { it.isNotBlank() && it != "GEMINI_API_KEY_DEFAULT_VALUE" }
            for (gKey in magic_liveKeys.take(2)) {
                for (gModel in listOf("gemini-2.5-flash", "gemini-2.0-flash")) {
                    var conn: HttpURLConnection? = null
                    try {
                        val magic_liveUrl = URL("https://generativelanguage.googleapis.com/v1beta/models/$gModel:generateContent?key=$gKey")
                        conn = (magic_liveUrl.openConnection() as HttpURLConnection).apply {
                            requestMethod = "POST"
                            doOutput = true
                            doInput = true
                            connectTimeout = 2500
                            readTimeout = 5000
                            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                        }
                        val contentsArr = org.json.JSONArray()
                        for (i in 1 until messages.length()) {
                            val m = messages.getJSONObject(i)
                            val role = if (m.optString("role") == "assistant") "model" else "user"
                            val text = m.optString("content")
                            contentsArr.put(
                                org.json.JSONObject()
                                    .put("role", role)
                                    .put("parts", org.json.JSONArray().put(org.json.JSONObject().put("text", text)))
                            )
                        }
                        val gPayload = org.json.JSONObject().apply {
                            put("systemInstruction", org.json.JSONObject().put("parts", org.json.JSONArray().put(org.json.JSONObject().put("text", sysPrompt))))
                            put("contents", contentsArr)
                        }
                        conn.outputStream.use { it.write(gPayload.toString().toByteArray(Charsets.UTF_8)) }
                        if (conn.responseCode in 200..299) {
                            val resp = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                            val text = org.json.JSONObject(resp)
                                .optJSONArray("candidates")
                                ?.optJSONObject(0)
                                ?.optJSONObject("content")
                                ?.optJSONArray("parts")
                                ?.optJSONObject(0)
                                ?.optString("text", "")
                                .orEmpty()
                            val cleaned = sanitizeChatSupportAiReply(text)
                            if (cleaned.isNotBlank()) {
                                com.example.core.widget.MagicLiveBrainMemory.recordConversationTurn(
                                    context = context,
                                    userQuery = userQuery,
                                    assistantReply = cleaned,
                                    appName = "MagicTune Chat"
                                )
                                return@withContext cleaned
                            }
                        }
                    } catch (_: Throwable) {
                    } finally {
                        try { conn?.disconnect() } catch (_: Throwable) {}
                    }
                }
            }

            // Tầng 3: Pollinations OpenAI Gateway (Miễn phí 100%, không cần API Key, có đầy đủ lịch sử hội thoại như MagicLive)
            var pFallbackConn: HttpURLConnection? = null
            try {
                val url = URL("https://text.pollinations.ai/")
                pFallbackConn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 4000
                    readTimeout = 7000
                    doOutput = true
                    doInput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15; MagicTune)")
                }
                val payload = org.json.JSONObject().apply {
                    put("messages", messages)
                    put("model", "openai")
                    put("code", "beesknees")
                }
                pFallbackConn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                if (pFallbackConn.responseCode in 200..299) {
                    val respStr = sanitizeChatSupportAiReply(
                        pFallbackConn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    )
                    if (respStr.isNotBlank()) {
                        com.example.core.widget.MagicLiveBrainMemory.recordConversationTurn(
                            context = context,
                            userQuery = userQuery,
                            assistantReply = respStr,
                            appName = "MagicTune Chat"
                        )
                        return@withContext respStr
                    }
                }
            } catch (_: Throwable) {
            } finally {
                try { pFallbackConn?.disconnect() } catch (_: Throwable) {}
            }

        } catch (_: Throwable) {}

        // Tầng 4: Phản hồi thông minh theo ngữ cảnh nếu mất kết nối Internet hoàn toàn
        val friendlyReply = when {
            lowerQuery.contains("chào") || lowerQuery.contains("hi") || lowerQuery.contains("hello") ->
                "Chào bạn thân mến! Mình là Trợ lý AI MagicTune đây. Hôm nay mình có thể đồng hành hay hỗ trợ gì cho bạn và chiếc điện thoại Honor của bạn nào? 😊"
            lowerQuery.contains("pro") || lowerQuery.contains("khôi phục") || lowerQuery.contains("máy cũ") ->
                "Đừng lo lắng nhé! Hệ thống của chúng ta tự động nhận diện thiết bị Pro quen thuộc qua ID phần cứng (`$currentDeviceId`) ngay từ khi mở ứng dụng mà hoàn toàn không cần đăng nhập. Nếu bạn vừa chuyển khoản, hãy gửi ảnh biên lai qua nút 🖼️ để Auto-Admin duyệt ngay lập tức nha! 💖"
            lowerQuery.contains("thông báo") || lowerQuery.contains("zalo") || lowerQuery.contains("facebook") || lowerQuery.contains("trễ") ->
                "À, lỗi trễ thông báo trên MagicOS rất phổ biến do trình quản lý pin ngầm (PowerGenius). Bạn chỉ cần sang tab **2. Chuông** và bấm **'Đặc trị thông báo toàn diện'**, mình sẽ tự động gạt mọi công tắc và cấp full quyền AppOps để máy nhận thông báo tức thì 0 giây luôn nhé! ✨"
            lowerQuery.contains("shizuku") || lowerQuery.contains("adb") || lowerQuery.contains("kết nối") || lowerQuery.contains("wlan") ->
                "Để kết nối siêu mượt mà và mở khóa 100% quyền hệ thống, bạn hãy dùng **Kết Nối Trực Tiếp (Mã 6 số)** trong tab *Kết Nối (Ô #40–#43)* nhé. Đặc biệt, ngay khi kết nối Gỡ lỗi WLAN thành công, hệ thống sẽ **tự động chạy Vô hiệu hóa xung đột hãng (Ô #20)** để mát máy, tiết kiệm pin và **tự động Ẩn chế độ nhà phát triển (Ô #26)** để bạn mở mọi ứng dụng tài chính bình thường! 🚀"
            lowerQuery.contains("xung đột") || lowerQuery.contains("nóng") || lowerQuery.contains("hao pin") || lowerQuery.contains("ấm") || lowerQuery.contains("nhiệt độ") || lowerQuery.contains("pin 97") ->
                "Bạn hoàn toàn yên tâm nhé! 💖 Hiện tượng điện thoại bị ấm lên hoặc tụt pin nhanh khi vừa bật Wi-Fi/4G là do một hiện tượng rất phổ biến: Hàng loạt ứng dụng bên thứ ba (đặc biệt là Facebook, TikTok, Shopee, dịch vụ tìm kiếm và Google Play Services) đồng loạt thức dậy cùng một lúc để kéo dữ liệu, tải ngầm video và đồng bộ tin nhắn sau thời gian ngắt mạng. Bản thân MagicTune hoạt động cực kỳ nhẹ và không giữ ngầm bất kỳ tiến trình nặng nào.\n\nĐể máy mát rượi và pin trâu trở lại ngay lập tức, bạn chỉ cần:\n1. Sang **Tab 7 (Giám Sát Xả Pin Nền)**: Xem app nào đang ngốn CPU/RAM và bấm **'❄️ Ngủ Sâu'** hoặc **'🛑 Force-Stop 0%'** (đặc biệt là Facebook, TikTok).\n2. Kết nối WLAN (Ô #40–#43) để MagicTune tự động kích hoạt **Vô Hiệu Xung Đột (Ô #20)** đóng băng các dịch vụ rác của hãng.\n3. Kích hoạt **Siêu tiết kiệm pin Zero Delay (Ô #18)** để máy luôn mát mẻ và êm ái nhé! ❄️🔋"
            lowerQuery.contains("webadb") || lowerQuery.contains("usb") || lowerQuery.contains("biểu ngữ") || lowerQuery.contains("ô 15") || lowerQuery.contains("#15") ->
                "Với tính năng bật biểu ngữ nổi và tắt thông báo nhẹ nhàng hàng loạt trong **Ô #15**, bạn hãy truy cập **https://magictunehonor.ai.studio/** và kết nối qua cáp USB nhé — bản WebADB qua USB sẽ can thiệp trực tiếp và hiệu quả hơn rất nhiều so với gỡ lỗi WLAN! 💻⚡"
            else ->
                "Đường truyền mạng bên mình vừa chập chờn một nhịp khi nhận tin nhắn \"$userQuery\". Bạn có thể hỏi mình về bất kỳ tính năng nào từ **Ô #00 đến Ô #55** (như Mở khóa pin 97%, Bàn phím Telex, Vẽ chữ mở app, Máy in nhiệt K80, Đa hãng OEM, hay Vô hiệu hóa xung đột tự động khi kết nối WLAN) hoặc dùng thanh tìm kiếm toàn cục ở đầu trang nhé! ✨"
        }
        return@withContext friendlyReply
    }
}
