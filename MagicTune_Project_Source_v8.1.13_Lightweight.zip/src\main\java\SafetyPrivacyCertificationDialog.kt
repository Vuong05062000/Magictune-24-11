package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

/**
 * Hộp thoại "Chứng Nhận An Toàn & Quyền Riêng Tư" hiển thị giữa màn hình khi bấm nút Khiên Xanh trên Header.
 * Cam kết minh bạch 100% Offline, Zero-Drain, bảo vệ phần cứng và trợ lực công nghệ màn hình Honor.
 */
@Composable
fun SafetyPrivacyCertificationDialog(
    onDismiss: () -> Unit
) {
    val scrollState = rememberScrollState()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = true,
            usePlatformDefaultWidth = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(vertical = 20.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        BorderStroke(
                            1.2.dp,
                            Brush.linearGradient(
                                listOf(MagicEmerald, MagicCyan.copy(alpha = 0.7f), MagicEmerald)
                            )
                        ),
                        RoundedCornerShape(22.dp)
                    ),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF090D16)),
                elevation = CardDefaults.cardElevation(defaultElevation = 14.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Header Row: Khiên xanh có dấu tích + Tiêu đề + Nút đóng X
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(
                                            listOf(
                                                MagicEmerald.copy(alpha = 0.25f),
                                                MagicCyan.copy(alpha = 0.25f)
                                            )
                                        )
                                    )
                                    .border(1.dp, MagicEmerald, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VerifiedUser,
                                    contentDescription = "Chứng nhận An toàn",
                                    tint = MagicEmerald,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "AN TOÀN & QUYỀN RIÊNG TƯ",
                                    color = Color.White,
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = "Chứng nhận minh bạch • 100% Offline",
                                    color = MagicEmeraldLight,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF1E293B))
                                .border(1.dp, MagicBorder, RoundedCornerShape(8.dp))
                                .clickable { onDismiss() }
                                .testTag("close_safety_cert_dialog_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Đóng",
                                tint = TextMuted,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // Thân nội dung cuộn được
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 380.dp)
                            .verticalScroll(scrollState),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SafetyCommitmentCard(
                            icon = Icons.Default.Lock,
                            iconColor = MagicEmerald,
                            title = "1. Bảo Mật Quyền Riêng Tư 100% Offline",
                            content = "MagicTune hoạt động hoàn toàn cục bộ trên thiết bị của bạn (Local-First). Ứng dụng tuyệt đối KHÔNG thu thập, không phân tích và không gửi bất kỳ dữ liệu cá nhân, danh bạ, tin nhắn, ảnh, mật khẩu hay tài khoản ngân hàng nào ra ngoài Internet."
                        )

                        SafetyCommitmentCard(
                            icon = Icons.Default.CheckCircle,
                            iconColor = MagicCyan,
                            title = "2. Nguyên Tắc Zero-Drain & Không Kết Nối Ngầm",
                            content = "Tôn trọng tuyệt đối thao tác của người dùng: Khi bạn tắt Chế độ nhà phát triển hoặc Gỡ lỗi Wi-Fi trong Cài đặt hệ thống, MagicTune lập tức đóng toàn bộ socket TCP, dừng hẳn radar mDNS và giải phóng MulticastLock. Không giữ tiến trình ngầm, cho phép máy ngủ sâu (Deep Sleep) hoàn toàn, đảm bảo mức ăn pin chỉ 0.1% – 1%/giờ trên viên pin 7200mAh của Honor GT Pro."
                        )

                        SafetyCommitmentCard(
                            icon = Icons.Default.Shield,
                            iconColor = MagicEmeraldLight,
                            title = "3. Trợ Lực Toàn Diện Công Nghệ Màn Hình Honor",
                            content = "Tương thích chuyên sâu với công nghệ 8T LTPO, Tandem OLED, Dynamic Dimming (điều biến xung ánh sáng 4320Hz PWM bảo vệ mắt), Smart Resolution và Panel Power Optimization. Khi khung hình đứng yên, hệ thống cho phép tấm nền tự hạ xung về 1Hz, giảm tải GPU SurfaceFlinger và loại bỏ hoàn toàn nguy cơ lưu ảnh (Burn-in)."
                        )

                        SafetyCommitmentCard(
                            icon = Icons.Default.Info,
                            iconColor = Color(0xFF38BDF8),
                            title = "4. Quyền Hạn Minh Bạch & Kiểm Soát Chủ Động",
                            content = "Mọi quyền hạn như Gỡ lỗi (ADB), Lớp phủ (Overlay) hay Hỗ trợ tiếp cận (Accessibility) đều được giải thích rõ ràng lý do sử dụng. Bạn có toàn quyền bật/tắt hoặc thu hồi bất kỳ lúc nào trong Cài đặt hệ thống mà không làm ảnh hưởng đến tính ổn định của máy."
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    // Hàng nút hành động: Chiều cao chuẩn, cân đối, đồng đều, không cao quá so với tên nút
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(IntrinsicSize.Min),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Button(
                            onClick = onDismiss,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 40.dp, max = 44.dp)
                                .testTag("safety_cert_confirm_btn"),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MagicEmerald,
                                contentColor = Color(0xFF020617)
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.VerifiedUser,
                                contentDescription = null,
                                modifier = Modifier.size(17.dp),
                                tint = Color(0xFF020617)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "✓ ĐÃ HIỂU & HOÀN TOÀN AN TÂM",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SafetyCommitmentCard(
    icon: ImageVector,
    iconColor: Color,
    title: String,
    content: String
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0F172A))
            .border(1.dp, iconColor.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .padding(11.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 11.8.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = content,
                color = Color(0xFFCBD5E1),
                fontSize = 10.5.sp,
                lineHeight = 14.5.sp
            )
        }
    }
}
