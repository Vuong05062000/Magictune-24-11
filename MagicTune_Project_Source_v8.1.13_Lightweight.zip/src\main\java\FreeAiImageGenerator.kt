package com.example.core.widget

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Mô hình tạo ảnh miễn phí 100% không giới hạn (Zero-Cost Free AI Image Generation):
 * - Sử dụng Pollinations AI (Flux.1 / Turbo) chất lượng cao, hoàn toàn miễn phí.
 * - Không yêu cầu API Key, không tốn bất kỳ chi phí duy trì nào cho Admin.
 * - Cho phép người dùng tạo ảnh tức thì và lưu ảnh về máy (Bộ sưu tập / Gallery) bất cứ lúc nào.
 */
object FreeAiImageGenerator {

    private const val TAG = "FreeAiImageGenerator"

    private val IMAGE_GEN_REGEXES = listOf(
        Regex("""(?i)^(?:hãy\s+)?(?:tạo|vẽ|làm|sinh)\s+(?:cho\s+tôi\s+)?(?:bức\s+|tấm\s+|hình\s+)?(?:ảnh|tranh|hình|image|photo)\s+(.+)$"""),
        Regex("""(?i)^(?:tạo\s+ảnh|vẽ\s+tranh|vẽ\s+ảnh|vẽ\s+hình|tạo\s+hình\s+ảnh|tạo\s+hình|generate\s+image|draw\s+image|draw)\s*[:：]?\s*(.+)$"""),
        Regex("""(?i)^(?:vẽ|draw)\s+(?:cho\s+tôi\s+)?(?:một\s+)?(?:bức\s+|tấm\s+)?(?:ảnh|tranh|hình)?\s*[:：]?\s*(.+)$""")
    )

    /**
     * Nhận diện xem câu truy vấn có phải là yêu cầu tạo ảnh không.
     */
    fun isImageGenerationRequest(query: String): Boolean {
        val trimmed = query.trim()
        if (trimmed.length < 3) return false
        for (regex in IMAGE_GEN_REGEXES) {
            if (regex.containsMatchIn(trimmed)) return true
        }
        val lower = trimmed.lowercase()
        return lower.startsWith("tạo ảnh") ||
            lower.startsWith("tao anh") ||
            lower.startsWith("vẽ tranh") ||
            lower.startsWith("ve tranh") ||
            lower.startsWith("vẽ ảnh") ||
            lower.startsWith("ve anh") ||
            lower.startsWith("vẽ hình") ||
            lower.startsWith("tạo hình ảnh") ||
            lower.startsWith("vẽ cho tôi") ||
            lower.startsWith("generate image")
    }

    /**
     * Trích xuất prompt mô tả hình ảnh từ câu của người dùng.
     */
    fun extractImagePrompt(query: String): String {
        val trimmed = query.trim()
        for (regex in IMAGE_GEN_REGEXES) {
            val m = regex.find(trimmed)
            if (m != null && m.groupValues.size > 1) {
                val extracted = m.groupValues[1].trim()
                if (extracted.isNotEmpty()) return extracted
            }
        }

        var clean = trimmed
        val prefixes = listOf(
            "tạo ảnh cho tôi", "tao anh cho toi", "vẽ cho tôi", "ve cho toi",
            "tạo hình ảnh", "tao hinh anh", "tạo ảnh", "tao anh",
            "vẽ tranh", "ve tranh", "vẽ ảnh", "ve anh", "vẽ hình", "ve hinh",
            "vẽ", "ve", "tạo", "tao", "generate image", "draw image", "draw"
        )
        for (p in prefixes) {
            if (clean.lowercase().startsWith(p)) {
                clean = clean.substring(p.length).trim()
                break
            }
        }
        clean = clean.removePrefix(":").removePrefix("：").trim()
        return if (clean.isNotBlank()) clean else "Bức tranh phong cảnh nghệ thuật tuyệt đẹp"
    }

    /**
     * Gọi mô hình tạo ảnh miễn phí (Pollinations Flux / Turbo).
     * Trả về Bitmap nếu tạo thành công, null nếu thất bại.
     */
    suspend fun generateImage(
        context: Context,
        rawPrompt: String,
        width: Int = 1024,
        height: Int = 1024
    ): Bitmap? = withContext(Dispatchers.IO) {
        val cleanPrompt = extractImagePrompt(rawPrompt)
        Log.d(TAG, "Generating image with prompt: $cleanPrompt")

        val seed = (System.currentTimeMillis() % 1000000).toInt()
        val encodedPrompt = try {
            URLEncoder.encode(cleanPrompt, "UTF-8")
        } catch (_: Throwable) {
            cleanPrompt.replace(" ", "%20")
        }

        // Danh sách các endpoint tạo ảnh miễn phí 100% (không cần API key, không tốn phí admin)
        val endpoints = listOf(
            // 1. Pollinations Flux (Chất lượng sắc nét nhất)
            "https://image.pollinations.ai/prompt/$encodedPrompt?width=$width&height=$height&nologo=true&seed=$seed&model=flux",
            // 2. Pollinations Turbo (Tốc độ cao nhất)
            "https://image.pollinations.ai/prompt/$encodedPrompt?width=$width&height=$height&nologo=true&seed=$seed&model=turbo",
            // 3. Unified Gen endpoint
            "https://gen.pollinations.ai/image/$encodedPrompt?width=$width&height=$height&nologo=true&seed=$seed"
        )

        for (endpoint in endpoints) {
            try {
                val url = URL(endpoint)
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 30000
                    readTimeout = 50000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "MagicTune/8.1.13 (Android; Mobile; FreeAi)")
                    setRequestProperty("Accept", "image/*")
                }

                val code = conn.responseCode
                if (code == 200) {
                    val bmp = conn.inputStream.use { input ->
                        BitmapFactory.decodeStream(input)
                    }
                    if (bmp != null) {
                        Log.d(TAG, "Successfully generated image from: $endpoint (${bmp.width}x${bmp.height})")
                        return@withContext bmp
                    }
                } else {
                    Log.w(TAG, "Endpoint $endpoint returned HTTP $code")
                }
            } catch (e: Throwable) {
                Log.w(TAG, "Failed on endpoint $endpoint: ${e.message}")
            }
        }

        Log.e(TAG, "All free image generation endpoints failed for prompt: $cleanPrompt")
        return@withContext null
    }

    /**
     * Lưu ảnh vào Thư viện ảnh của thiết bị (Gallery / DCIM / Pictures/MagicTune_AI)
     * để người dùng có thể lưu ảnh về máy bất cứ lúc nào.
     */
    fun saveImageToGallery(context: Context, bitmap: Bitmap, promptTitle: String): Uri? {
        val appCtx = context.applicationContext
        try {
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val filename = "MagicTune_AI_${timestamp}.jpg"

            var outputUri: Uri? = null

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/MagicTune_AI")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }

                val resolver = appCtx.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
                    }
                    contentValues.clear()
                    contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    resolver.update(uri, contentValues, null, null)
                    outputUri = uri
                }
            } else {
                val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                val targetDir = File(picturesDir, "MagicTune_AI")
                if (!targetDir.exists()) targetDir.mkdirs()

                val file = File(targetDir, filename)
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
                }
                MediaScannerConnection.scanFile(appCtx, arrayOf(file.absolutePath), arrayOf("image/jpeg"), null)
                outputUri = Uri.fromFile(file)
            }

            Handler(Looper.getMainLooper()).post {
                Toast.makeText(
                    appCtx,
                    "💾 Đã lưu ảnh thành công vào Bộ sưu tập (MagicTune_AI)!",
                    Toast.LENGTH_LONG
                ).show()
            }

            Log.d(TAG, "Successfully saved image to gallery: $outputUri")
            return outputUri
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to save image to gallery: ${e.message}", e)
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(
                    appCtx,
                    "❌ Không thể lưu ảnh: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
            return null
        }
    }
}
