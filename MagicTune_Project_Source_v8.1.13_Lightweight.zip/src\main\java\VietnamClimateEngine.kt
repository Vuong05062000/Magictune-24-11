package com.example.core.widget

import android.content.Context
import android.location.Address
import android.location.Geocoder
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Động Cơ Thời Tiết Thực Tế Thời Gian Thực Việt Nam (100% Miễn Phí - Không dùng Key trả phí)
 *
 * Nguồn dữ liệu:
 * 1. Định vị tọa độ chính xác tới từng Xã/Phường/Quận/Huyện/Tỉnh qua Google Android Geocoder
 *    và Open-Meteo Geocoding API.
 * 2. Thời tiết thực tế theo thời gian thực từ Open-Meteo Forecast + Air Quality API (chuẩn WMO, 1-3km).
 * 3. Dự phòng tự động MET Norway (Yr.no Locationforecast 2.0) và wttr.in nếu nguồn chính gián đoạn.
 * 4. Lưu cache JSON đầy đủ theo từng địa điểm để App & Widget đồng bộ tức thì 0ms và dùng khi ngoại tuyến.
 */
object VietnamClimateEngine {

    const val PREFS_NAME = "magictune_widget_weather_prefs"
    const val KEY_LOCATION = "selected_full_location"
    const val KEY_CACHED_TEMP = "cached_weather_temp"
    const val KEY_CACHED_DESC = "cached_weather_desc"
    const val KEY_CACHED_ICON = "cached_weather_icon"
    const val KEY_CACHED_JSON = "cached_weather_full_json"

    private const val KEY_WEATHER_JSON_PREFIX = "weather_json_v2_"
    private const val KEY_COORD_PREFIX = "coord_v2_"

    data class GeoProfile(
        val province: String,
        val lat: Double,
        val lon: Double,
        val dayTempBase: Int,
        val nightTempBase: Int,
        val typicalHumidity: Int,
        val typicalWind: Int,
        val climateDesc: String
    )

    // Bảng tọa độ chính xác & dự phòng ngoại tuyến cho Vùng sâu vùng xa, Hải đảo và 63 tỉnh thành Việt Nam
    private val provinceProfiles = mapOf(
        // Hải đảo & Quần đảo tiền tiêu
        "Hoàng Sa" to GeoProfile("Quần đảo Hoàng Sa", 16.5322, 111.6156, 29, 25, 80, 22, "Gió biển khơi, nắng ấm"),
        "Trường Sa" to GeoProfile("Quần đảo Trường Sa", 8.6442, 111.9197, 30, 26, 82, 24, "Nắng gió biển đảo Trường Sa"),
        "Sinh Tồn" to GeoProfile("Đảo Sinh Tồn", 9.8869, 114.3292, 30, 26, 82, 24, "Khí hậu biển đảo Trường Sa"),
        "Song Tử Tây" to GeoProfile("Đảo Song Tử Tây", 11.4292, 114.3319, 30, 26, 81, 23, "Khí hậu biển đảo Trường Sa"),
        "Nam Yết" to GeoProfile("Đảo Nam Yết", 10.1794, 114.3653, 30, 26, 82, 24, "Khí hậu biển đảo Trường Sa"),
        "Sơn Ca" to GeoProfile("Đảo Sơn Ca", 10.3767, 114.4797, 30, 26, 82, 23, "Khí hậu biển đảo Trường Sa"),
        "An Bang" to GeoProfile("Đảo An Bang", 7.8906, 112.9211, 30, 26, 83, 24, "Khí hậu biển đảo Trường Sa"),
        "Bạch Long Vĩ" to GeoProfile("Đảo Bạch Long Vĩ", 20.1328, 107.7289, 25, 20, 82, 22, "Gió biển Vịnh Bắc Bộ mát mẻ"),
        "Cô Tô" to GeoProfile("Đảo Cô Tô", 20.9708, 107.7644, 24, 19, 81, 20, "Nắng dịu biển đảo Đông Bắc"),
        "Cát Bà" to GeoProfile("Đảo Cát Bà", 20.7278, 107.0481, 25, 19, 80, 18, "Gió biển mát lành"),
        "Cồn Cỏ" to GeoProfile("Đảo Cồn Cỏ", 17.1592, 107.3408, 27, 22, 80, 20, "Gió biển miền Trung thoáng mát"),
        "Cù Lao Chàm" to GeoProfile("Đảo Cù Lao Chàm", 15.9558, 108.5089, 28, 23, 79, 18, "Nắng ấm biển đảo"),
        "Lý Sơn" to GeoProfile("Đảo Lý Sơn", 15.3806, 109.1167, 29, 24, 79, 20, "Nắng vàng biển đảo Lý Sơn"),
        "Phú Quý" to GeoProfile("Đảo Phú Quý", 10.5319, 108.9483, 30, 25, 78, 22, "Nắng đẹp, gió biển trong lành"),
        "Côn Đảo" to GeoProfile("Côn Đảo", 8.6853, 106.6083, 30, 25, 79, 20, "Biển xanh nắng ấm quanh năm"),
        "Phú Quốc" to GeoProfile("Đảo Phú Quốc", 10.2270, 103.9632, 31, 25, 78, 16, "Đảo Ngọc nắng ấm biển êm"),
        "Thổ Châu" to GeoProfile("Quần đảo Thổ Châu", 9.2986, 103.4814, 30, 25, 80, 19, "Gió biển Tây Nam ôn hòa"),
        "Nam Du" to GeoProfile("Quần đảo Nam Du", 9.6825, 104.3519, 31, 25, 79, 18, "Biển xanh nắng dịu"),
        "Hòn Khoai" to GeoProfile("Đảo Hòn Khoai", 8.4317, 104.8319, 30, 25, 80, 19, "Gió biển cực Nam Tổ Quốc"),

        // Vùng cao, biên giới & đỉnh núi nổi tiếng
        "Lũng Cú" to GeoProfile("Lũng Cú", 23.3636, 105.3164, 16, 10, 86, 11, "Se lạnh cực Bắc Tổ Quốc"),
        "Đồng Văn" to GeoProfile("Đồng Văn", 23.2778, 105.3619, 17, 11, 85, 10, "Cao nguyên đá se lạnh"),
        "Mèo Vạc" to GeoProfile("Mèo Vạc", 23.1625, 105.4053, 18, 12, 84, 10, "Đèo Mã Pí Lèng mây phủ"),
        "Hoàng Su Phì" to GeoProfile("Hoàng Su Phì", 22.7419, 104.6797, 18, 12, 86, 9, "Sương mù ruộng bậc thang"),
        "Xín Mần" to GeoProfile("Xín Mần", 22.6819, 104.4847, 18, 12, 85, 9, "Thảo nguyên vùng cao mát lạnh"),
        "Y Tý" to GeoProfile("Y Tý", 22.6289, 103.6194, 15, 9, 90, 10, "Biển mây vùng cao se lạnh"),
        "Fansipan" to GeoProfile("Đỉnh Fansipan", 22.3033, 103.7750, 10, 4, 92, 18, "Đỉnh Đông Dương lạnh giá, mây mù"),
        "Sa Pa" to GeoProfile("Sa Pa", 22.3364, 103.8438, 17, 11, 88, 8, "Se lạnh vùng cao, sương mù nhẹ"),
        "Bắc Hà" to GeoProfile("Bắc Hà", 22.5367, 104.2917, 19, 13, 85, 9, "Cao nguyên trắng mát lạnh"),
        "A Pa Chải" to GeoProfile("A Pa Chải", 22.3886, 102.1869, 20, 13, 82, 9, "Ngã ba biên giới cực Tây mát lành"),
        "Mường Nhé" to GeoProfile("Mường Nhé", 22.1828, 102.4636, 22, 15, 80, 9, "Nắng nhẹ vùng biên viễn"),
        "Tủa Chùa" to GeoProfile("Tủa Chùa", 21.9964, 103.3328, 19, 13, 82, 9, "Cao nguyên đá mát mẻ"),
        "Sìn Hồ" to GeoProfile("Sìn Hồ", 22.3619, 103.2494, 17, 11, 87, 9, "Cao nguyên Sìn Hồ sương sớm"),
        "Mường Tè" to GeoProfile("Mường Tè", 22.3822, 102.8047, 22, 15, 82, 8, "Thượng nguồn sông Đà mát mẻ"),
        "Tà Xùa" to GeoProfile("Tà Xùa", 21.3183, 104.4556, 16, 10, 89, 11, "Thiên đường săn mây se lạnh"),
        "Mộc Châu" to GeoProfile("Mộc Châu", 20.8442, 104.6392, 19, 13, 84, 9, "Cao nguyên Mộc Châu mát lành"),
        "Mù Cang Chải" to GeoProfile("Mù Cang Chải", 21.8506, 104.0869, 18, 12, 85, 9, "Đèo Khau Phạ mát lạnh"),
        "Trạm Tấu" to GeoProfile("Trạm Tấu", 21.4847, 104.3917, 18, 12, 85, 9, "Vùng cao se lạnh"),
        "Pác Bó" to GeoProfile("Pác Bó", 22.9775, 106.0511, 20, 14, 83, 8, "Suối Lê Nin trong lành mát mẻ"),
        "Bản Giốc" to GeoProfile("Thác Bản Giốc", 22.8556, 106.7225, 20, 14, 84, 9, "Biên viễn mát lành"),
        "Mẫu Sơn" to GeoProfile("Đỉnh Mẫu Sơn", 21.8486, 106.9178, 14, 8, 90, 16, "Đỉnh núi sương mù, gió lạnh"),
        "Ba Bể" to GeoProfile("Hồ Ba Bể", 22.4167, 105.6167, 21, 15, 85, 8, "Hồ trên núi mát lành"),
        "Na Hang" to GeoProfile("Na Hang", 22.3536, 105.3881, 22, 16, 84, 8, "Rừng nguyên sinh dịu mát"),
        "Tam Đảo" to GeoProfile("Tam Đảo", 21.4567, 105.6439, 18, 13, 87, 10, "Thị trấn trong mây se lạnh"),
        "Pù Luông" to GeoProfile("Pù Luông", 20.4536, 105.1619, 21, 15, 85, 9, "Khu bảo tồn thiên nhiên mát mẻ"),
        "Mường Lát" to GeoProfile("Mường Lát", 20.5256, 104.5889, 22, 15, 82, 9, "Vùng biên xứ Thanh mát mẻ"),
        "Kỳ Sơn" to GeoProfile("Kỳ Sơn", 19.3986, 104.1558, 21, 15, 83, 10, "Biên giới Tây Nghệ An se lạnh"),
        "Phong Nha" to GeoProfile("Phong Nha - Kẻ Bàng", 17.5906, 106.2833, 25, 19, 82, 10, "Rừng di sản mát lành"),
        "Khe Sanh" to GeoProfile("Khe Sanh - Hướng Hóa", 16.6267, 106.7317, 23, 17, 84, 12, "Cao nguyên gió Lào - sương nhẹ"),
        "A Lưới" to GeoProfile("A Lưới", 16.2719, 107.2325, 22, 16, 86, 10, "Thung lũng Trường Sơn mát mẻ"),
        "Bạch Mã" to GeoProfile("Đỉnh Bạch Mã", 16.1950, 107.8558, 17, 12, 90, 14, "Đỉnh núi mây mù, se lạnh"),
        "Tây Giang" to GeoProfile("Tây Giang", 15.8950, 107.4569, 20, 14, 87, 10, "Đỉnh Quế sương mây"),
        "Ngọc Linh" to GeoProfile("Đỉnh Ngọc Linh", 15.0750, 107.9833, 15, 10, 90, 12, "Nóc nhà Tây Nguyên se lạnh"),
        "Măng Đen" to GeoProfile("Măng Đen", 14.6025, 108.2903, 19, 13, 86, 10, "Đà Lạt thứ hai se lạnh, rừng thông"),
        "Bờ Y" to GeoProfile("Cửa khẩu Bờ Y", 14.7008, 107.5586, 25, 18, 78, 11, "Ngã ba Đông Dương nắng dịu"),
        "Buôn Đôn" to GeoProfile("Buôn Đôn", 12.8894, 107.7922, 28, 20, 74, 12, "Nắng gió đại ngàn Tây Nguyên"),
        "Tà Đùng" to GeoProfile("Hồ Tà Đùng", 11.8556, 107.9917, 22, 16, 84, 11, "Vịnh Hạ Long trên cao nguyên mát mẻ"),
        "Đất Mũi" to GeoProfile("Mũi Cà Mau - Đất Mũi", 8.6094, 104.7250, 30, 25, 80, 18, "Cực Nam Tổ Quốc gió biển lộng"),

        // 63 Tỉnh / Thành phố
        "Lào Cai" to GeoProfile("Lào Cai", 22.4856, 103.9707, 22, 16, 82, 10, "Mát mẻ vùng cao, mây thoảng"),
        "Lai Châu" to GeoProfile("Lai Châu", 22.3963, 103.4682, 21, 15, 80, 9, "Nhiều mây, se lạnh vùng núi"),
        "Điện Biên" to GeoProfile("Điện Biên", 21.3860, 103.0205, 24, 17, 75, 11, "Thung lũng nắng nhẹ, đêm mát"),
        "Sơn La" to GeoProfile("Sơn La", 21.3283, 103.9148, 22, 15, 78, 10, "Mộc Châu mát lành, sương sớm"),
        "Hà Giang" to GeoProfile("Hà Giang", 22.8233, 104.9839, 21, 15, 84, 8, "Cao nguyên đá mát lạnh"),
        "Cao Bằng" to GeoProfile("Cao Bằng", 22.6666, 106.2639, 21, 15, 80, 9, "Mát mẻ trong lành vùng biên viễn"),
        "Lạng Sơn" to GeoProfile("Lạng Sơn", 21.8537, 106.7615, 21, 15, 79, 12, "Gió mùa se lạnh, mây mỏng"),
        "Bắc Kạn" to GeoProfile("Bắc Kạn", 22.1470, 105.8348, 22, 16, 82, 8, "Mát mẻ hồ Ba Bể"),
        "Tuyên Quang" to GeoProfile("Tuyên Quang", 21.8236, 105.2180, 24, 18, 80, 10, "Trời mát, nắng nhẹ xen kẽ"),
        "Yên Bái" to GeoProfile("Yên Bái", 21.7168, 104.9113, 23, 17, 81, 9, "Trời dịu mát, thoáng đãng"),

        "Hà Nội" to GeoProfile("Hà Nội", 21.0285, 105.8542, 26, 20, 72, 14, "Nắng nhẹ, thoáng mát"),
        "Hải Phòng" to GeoProfile("Hải Phòng", 20.8449, 106.6881, 25, 19, 78, 18, "Gió biển mát mẻ, trời quang"),
        "Quảng Ninh" to GeoProfile("Quảng Ninh", 20.9505, 107.0734, 24, 18, 77, 16, "Vịnh Hạ Long gió nhẹ, nắng đẹp"),
        "Bắc Ninh" to GeoProfile("Bắc Ninh", 21.1861, 106.0763, 25, 19, 74, 12, "Nắng ấm nhẹ, trời thoáng"),
        "Hải Dương" to GeoProfile("Hải Dương", 20.9373, 106.3146, 25, 19, 75, 12, "Trời mát mẻ, ít mây"),
        "Hưng Yên" to GeoProfile("Hưng Yên", 20.6464, 106.0511, 25, 19, 74, 11, "Khí hậu đồng bằng dễ chịu"),
        "Hà Nam" to GeoProfile("Hà Nam", 20.5453, 105.9122, 25, 19, 76, 11, "Trời thanh mát, nắng hanh"),
        "Nam Định" to GeoProfile("Nam Định", 20.4343, 106.1782, 25, 20, 78, 15, "Gió cửa biển ôn hòa"),
        "Thái Bình" to GeoProfile("Thái Bình", 20.4463, 106.3366, 25, 20, 78, 15, "Nắng dịu, gió đồng nội"),
        "Ninh Bình" to GeoProfile("Ninh Bình", 20.2506, 105.9745, 25, 19, 75, 12, "Tràng An mây nhẹ, mát lành"),
        "Vĩnh Phúc" to GeoProfile("Vĩnh Phúc", 21.3089, 105.6049, 24, 18, 76, 11, "Trung du dịu mát"),
        "Phú Thọ" to GeoProfile("Phú Thọ", 21.3228, 105.4019, 24, 18, 77, 10, "Đất Tổ trung du dịu mát"),
        "Bắc Giang" to GeoProfile("Bắc Giang", 21.2731, 106.1946, 24, 18, 76, 11, "Trời nắng êm, mát mẻ"),
        "Thái Nguyên" to GeoProfile("Thái Nguyên", 21.5928, 105.8442, 24, 18, 77, 10, "Vùng chè xanh mát, nắng nhẹ"),
        "Hòa Bình" to GeoProfile("Hòa Bình", 20.8171, 105.3376, 23, 17, 80, 10, "Thung lũng Mai Châu mát mẻ"),

        "Thanh Hóa" to GeoProfile("Thanh Hóa", 19.8067, 105.7852, 26, 20, 75, 13, "Nắng ấm, gió nhẹ ven biển"),
        "Nghệ An" to GeoProfile("Nghệ An", 18.6734, 105.6813, 26, 21, 76, 14, "Trời quang, nắng ấm áp"),
        "Hà Tĩnh" to GeoProfile("Hà Tĩnh", 18.3560, 105.9000, 26, 21, 77, 14, "Nắng nhẹ, gió mát"),
        "Quảng Bình" to GeoProfile("Quảng Bình", 17.4690, 106.6225, 27, 21, 78, 15, "Nắng đẹp ven biển Nhật Lệ"),
        "Quảng Trị" to GeoProfile("Quảng Trị", 16.7500, 107.1855, 27, 22, 79, 14, "Ấm áp, có mây thoảng"),
        "Thừa Thiên Huế" to GeoProfile("Thừa Thiên Huế", 16.4637, 107.5909, 27, 22, 82, 12, "Cố đô mây lãng đãng"),

        "Đà Nẵng" to GeoProfile("Đà Nẵng", 16.0544, 108.2022, 29, 23, 76, 16, "Nắng vàng biển xanh, gió lộng"),
        "Quảng Nam" to GeoProfile("Quảng Nam", 15.5394, 108.0191, 29, 23, 77, 15, "Hội An nắng ấm rực rỡ"),
        "Quảng Ngãi" to GeoProfile("Quảng Ngãi", 15.1205, 108.7923, 29, 23, 78, 15, "Nắng đẹp, gió biển trong lành"),
        "Bình Định" to GeoProfile("Bình Định", 13.7830, 109.2197, 30, 24, 76, 16, "Quy Nhơn nắng rực rỡ, gió mát"),
        "Phú Yên" to GeoProfile("Phú Yên", 13.0882, 109.3082, 30, 24, 76, 17, "Tuy Hòa nắng vàng, biển biếc"),
        "Khánh Hòa" to GeoProfile("Khánh Hòa", 12.2388, 109.1967, 30, 24, 75, 16, "Nha Trang nắng ấm chan hòa"),
        "Ninh Thuận" to GeoProfile("Ninh Thuận", 11.5649, 108.9880, 32, 25, 68, 20, "Phan Rang nhiều nắng, gió biển mát"),
        "Bình Thuận" to GeoProfile("Bình Thuận", 10.9333, 108.1000, 31, 24, 72, 18, "Mũi Né nắng ấm, biển lặng"),

        "Đà Lạt" to GeoProfile("Đà Lạt", 11.9404, 108.4583, 19, 13, 85, 9, "Thành phố sương mù, se lạnh"),
        "Lâm Đồng" to GeoProfile("Lâm Đồng", 11.5564, 107.8083, 24, 17, 80, 11, "Cao nguyên mát rượi"),
        "Đắk Lắk" to GeoProfile("Đắk Lắk", 12.6667, 108.0500, 27, 19, 74, 14, "Buôn Ma Thuột nắng dịu cao nguyên"),
        "Gia Lai" to GeoProfile("Gia Lai", 13.9833, 108.0000, 26, 18, 75, 13, "Pleiku phố núi mây bay"),
        "Kon Tum" to GeoProfile("Kon Tum", 14.3500, 108.0000, 27, 19, 74, 12, "Nắng nhẹ, khí hậu cao nguyên"),
        "Đắk Nông" to GeoProfile("Đắk Nông", 12.0000, 107.6833, 26, 19, 78, 12, "Gió mát hồ Tà Đùng"),

        "TP. Hồ Chí Minh" to GeoProfile("TP. Hồ Chí Minh", 10.8231, 106.6297, 33, 25, 69, 13, "Nắng vàng nhiệt đới, ấm áp"),
        "Bình Dương" to GeoProfile("Bình Dương", 11.1603, 106.6575, 33, 24, 68, 12, "Trời nắng ráo, ấm áp"),
        "Đồng Nai" to GeoProfile("Đồng Nai", 10.9574, 106.8427, 33, 24, 70, 12, "Nắng đẹp chan hòa"),
        "Bà Rịa - Vũng Tàu" to GeoProfile("Bà Rịa - Vũng Tàu", 10.3460, 107.0843, 31, 25, 75, 18, "Gió biển mát rượi, nắng rực rỡ"),
        "Tây Ninh" to GeoProfile("Tây Ninh", 11.3103, 106.0983, 34, 24, 66, 11, "Nắng sáng, hanh ráo"),
        "Bình Phước" to GeoProfile("Bình Phước", 11.7511, 106.9067, 33, 23, 71, 11, "Nắng ấm nhiệt đới miền Đông"),

        "Long An" to GeoProfile("Long An", 10.5333, 106.4167, 32, 25, 73, 12, "Nắng ấm đồng bằng"),
        "Cần Thơ" to GeoProfile("Cần Thơ", 10.0452, 105.7469, 32, 25, 74, 12, "Sông nước hiền hòa, nắng ấm dịu"),
        "An Giang" to GeoProfile("An Giang", 10.5216, 105.1259, 32, 25, 73, 12, "Thất Sơn nắng ấm, trời trong"),
        "Đồng Tháp" to GeoProfile("Đồng Tháp", 10.4578, 105.6339, 32, 25, 74, 12, "Nắng ấm đồng sen"),
        "Tiền Giang" to GeoProfile("Tiền Giang", 10.4284, 106.3409, 32, 25, 74, 13, "Mỹ Tho nắng ấm miệt vườn"),
        "Bến Tre" to GeoProfile("Bến Tre", 10.2433, 106.3756, 31, 24, 76, 14, "Xứ dừa gió mát, nắng êm"),
        "Vĩnh Long" to GeoProfile("Vĩnh Long", 10.2537, 105.9722, 32, 25, 75, 12, "Khí hậu sông Tiền thoáng đãng"),
        "Trà Vinh" to GeoProfile("Trà Vinh", 9.9347, 106.3455, 31, 24, 77, 15, "Gió biển Ba Động mát mẻ"),
        "Hậu Giang" to GeoProfile("Hậu Giang", 9.7844, 105.4701, 32, 25, 75, 12, "Nắng ấm phù sa"),
        "Sóc Trăng" to GeoProfile("Sóc Trăng", 9.6033, 105.9800, 31, 25, 76, 14, "Nắng ấm, gió lộng đồng bằng"),
        "Bạc Liêu" to GeoProfile("Bạc Liêu", 9.2941, 105.7278, 31, 25, 77, 16, "Gió cánh đồng điện gió trong lành"),
        "Cà Mau" to GeoProfile("Cà Mau", 9.1769, 105.1500, 31, 25, 78, 16, "Đất Mũi cực Nam, gió biển chan hòa"),
        "Kiên Giang" to GeoProfile("Kiên Giang", 10.0125, 105.0809, 31, 25, 76, 15, "Phú Quốc - Rạch Giá nắng biển tuyệt đẹp")
    )

    data class WeatherResult(
        val fullLocation: String,
        val currentTemp: Int,
        val tempDisplay: String,
        val condition: String,
        val icon: String,
        val humidity: Int,
        val windSpeed: Int,
        val uvIndex: String,
        val airQuality: String,
        val hourlyForecast: List<HourlySlot>,
        val dailyForecast: List<DailySlot>,
        val isLiveData: Boolean = false,
        val sourceLabel: String = "Chờ đồng bộ mạng...",
        val updatedAtMillis: Long = 0L,
        val lat: Double = 0.0,
        val lon: Double = 0.0,
        val rainProbability: Int = estimateRainProbability(icon, condition, humidity)
    )

    data class HourlySlot(
        val hourLabel: String,
        val icon: String,
        val temp: String
    )

    data class DailySlot(
        val dayName: String,
        val dateStr: String,
        val icon: String,
        val condition: String,
        val minTemp: Int,
        val maxTemp: Int,
        val humidity: Int,
        val windSpeed: Int,
        val uvIndex: String,
        val airQuality: String,
        val rainProbability: Int = estimateRainProbability(icon, condition, humidity)
    )

    fun estimateRainProbability(icon: String, condition: String, humidity: Int): Int {
        val condLower = condition.lowercase(Locale("vi", "VN"))
        return when {
            icon == "⛈️" || condLower.contains("mưa dông") || condLower.contains("mưa to") ->
                maxOf(85, humidity.coerceIn(78, 98))
            icon == "🌧️" || condLower.contains("mưa rào") || condLower.contains("mưa vừa") ->
                maxOf(68, (humidity * 0.85).roundToInt().coerceIn(65, 92))
            icon == "🌦️" || condLower.contains("mưa phùn") || condLower.contains("mưa nhẹ") || condLower.contains("mưa") ->
                maxOf(52, (humidity * 0.72).roundToInt().coerceIn(48, 82))
            icon == "🌫️" || condLower.contains("sương mù") ->
                (humidity * 0.42).roundToInt().coerceIn(25, 48)
            icon == "☁️" || condLower.contains("nhiều mây") ->
                (humidity * 0.35).roundToInt().coerceIn(20, 42)
            icon == "⛅" || condLower.contains("mây") ->
                (humidity * 0.25).roundToInt().coerceIn(12, 30)
            icon == "🌤️" ->
                (humidity * 0.16).roundToInt().coerceIn(8, 20)
            else ->
                ((humidity - 40).coerceAtLeast(5) * 0.22).roundToInt().coerceIn(5, 16)
        }
    }

    private fun normalizeLocationKey(locationName: String): String {
        val cleaned = VietnamAdministrativeDataset.stripAccents(locationName.trim())
            .replace(Regex("[^a-z0-9]+"), "_")
            .trim('_')
        return if (cleaned.isNotEmpty()) cleaned else "default_vn"
    }

    private fun isInsideVietnam(lat: Double, lon: Double): Boolean {
        // Bao phủ toàn bộ đất liền Việt Nam và vùng biển đảo Hoàng Sa, Trường Sa, Thổ Châu, Bạch Long Vĩ
        return lat in 6.0..24.0 && lon in 102.0..118.0
    }

    fun cacheExactCoordinates(context: Context, locationName: String, lat: Double, lon: Double) {
        if (!isInsideVietnam(lat, lon)) return
        try {
            val normKey = normalizeLocationKey(locationName)
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_COORD_PREFIX + normKey, "$lat,$lon")
                .apply()
        } catch (_: Throwable) {}
    }

    fun resolveGeoProfile(locationName: String): GeoProfile {
        for ((key, profile) in provinceProfiles) {
            if (locationName.contains(key, ignoreCase = true)) {
                return profile
            }
        }
        return provinceProfiles["Hà Nội"]
            ?: provinceProfiles.values.firstOrNull()
            ?: GeoProfile("Hà Nội", 21.0285, 105.8542, 28, 22, 75, 10, "Thủ đô Hà Nội")
    }

    private fun getMicroclimateVariation(locationName: String): Int {
        val hash = abs(locationName.hashCode())
        val isUrbanCenter = locationName.contains("Quận 1", true) ||
            locationName.contains("Quận 3", true) ||
            locationName.contains("Hoàn Kiếm", true) ||
            locationName.contains("Ba Đình", true) ||
            locationName.contains("Đống Đa", true) ||
            locationName.contains("Hải Châu", true)

        val isRuralOrMountain = locationName.contains("Ba Vì", true) ||
            locationName.contains("Sóc Sơn", true) ||
            locationName.contains("Củ Chi", true) ||
            locationName.contains("Cần Giờ", true) ||
            locationName.contains("Mộc Châu", true) ||
            locationName.contains("Tam Đảo", true)

        return when {
            isUrbanCenter -> 1
            isRuralOrMountain -> -2
            else -> (hash % 3) - 1
        }
    }

    /**
     * Khung dự phòng ngoại tuyến khi thiết bị chưa có mạng hoặc chưa từng tải vùng này.
     * Luôn gắn nhãn rõ `isLiveData = false` để không bao giờ giả mạo là dữ liệu trực tuyến.
     */
    fun getLocalWeather(locationName: String): WeatherResult {
        val profile = resolveGeoProfile(locationName)
        val microOffset = getMicroclimateVariation(locationName)

        val cal = Calendar.getInstance()
        val currentHour = cal.get(Calendar.HOUR_OF_DAY)

        val hourNormalized = (currentHour - 5 + 24) % 24
        val tempSwing = profile.dayTempBase - profile.nightTempBase
        val hourCurve = sin((hourNormalized / 24.0) * Math.PI)
        val currentTemp = (profile.nightTempBase + (tempSwing * hourCurve).roundToInt() + microOffset).coerceIn(5, 45)

        val isDay = currentHour in 6..18
        val icon = if (isDay) {
            if (profile.province in listOf("Sa Pa", "Lào Cai", "Lai Châu")) "⛅" else "☀️"
        } else {
            "🌙"
        }

        val condition = if (isDay) profile.climateDesc else "Đêm quang đãng, mát mẻ"
        val tempDisplay = "$icon ${currentTemp}°C"

        val humidity = (profile.typicalHumidity + (if (!isDay) 10 else -5) - (microOffset * 3)).coerceIn(40, 95)
        val windSpeed = (profile.typicalWind + microOffset).coerceIn(5, 40)
        val uv = if (isDay) {
            if (currentTemp >= 32) "9 (Rất cao)" else if (currentTemp >= 27) "6 (Cao)" else "4 (Trung bình)"
        } else {
            "0 (Không có)"
        }

        val aqi = "Chưa có mạng"
        val hourlyList = mutableListOf<HourlySlot>()
        for (h in 0 until 24) {
            val futureH = (currentHour + h) % 24
            val futureNorm = (futureH - 5 + 24) % 24
            val futureCurve = sin((futureNorm / 24.0) * Math.PI)
            val hTemp = (profile.nightTempBase + (tempSwing * futureCurve).roundToInt() + microOffset).coerceIn(5, 45)
            val hIcon = if (futureH in 6..18) {
                if (h % 5 == 0 && profile.lat > 20) "⛅" else "☀️"
            } else {
                "🌙"
            }
            hourlyList.add(HourlySlot(String.format(Locale.US, "%02d:00", futureH), hIcon, "${hTemp}°C"))
        }

        val dayNames = arrayOf("Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy")
        val dayIcons = arrayOf("☀️", "⛅", "☀️", "🌤️", "☀️", "⛅", "☀️")
        val dailyList = mutableListOf<DailySlot>()
        val dayOfYear = cal.get(Calendar.DAY_OF_YEAR)

        for (d in 0 until 7) {
            val targetCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, d) }
            val dayName = if (d == 0) "Hôm nay" else dayNames[targetCal.get(Calendar.DAY_OF_WEEK) - 1]
            val dateStr = SimpleDateFormat("dd/MM", Locale("vi", "VN")).format(targetCal.time)
            val dayHash = abs((locationName + d).hashCode())
            val dayVariation = (dayHash % 3) - 1

            val minT = profile.nightTempBase + microOffset + dayVariation
            val maxT = profile.dayTempBase + microOffset + dayVariation
            val dIcon = dayIcons[(dayOfYear + d) % dayIcons.size]
            val dCond = when (dIcon) {
                "☀️" -> "Nắng đẹp, quang mây"
                "⛅" -> "Nhiều mây, dịu mát"
                "🌤️" -> "Nắng nhẹ, có mây thoảng"
                else -> "Mát mẻ, thoáng đãng"
            }
            dailyList.add(
                DailySlot(
                    dayName = dayName,
                    dateStr = dateStr,
                    icon = dIcon,
                    condition = dCond,
                    minTemp = minT,
                    maxTemp = maxT,
                    humidity = (humidity + (d % 3)).coerceIn(45, 90),
                    windSpeed = (windSpeed + (d % 2)).coerceIn(8, 30),
                    uvIndex = if (maxT >= 32) "8 (Rất cao)" else "5 (Trung bình)",
                    airQuality = aqi
                )
            )
        }

        return WeatherResult(
            fullLocation = locationName,
            currentTemp = currentTemp,
            tempDisplay = tempDisplay,
            condition = condition,
            icon = icon,
            humidity = humidity,
            windSpeed = windSpeed,
            uvIndex = uv,
            airQuality = aqi,
            hourlyForecast = hourlyList,
            dailyForecast = dailyList,
            isLiveData = false,
            sourceLabel = "Chờ đồng bộ dữ liệu thực tế...",
            updatedAtMillis = 0L,
            lat = profile.lat,
            lon = profile.lon
        )
    }

    /**
     * Đọc ngay bản ghi thời tiết THỰC TẾ đã lưu trong cache cho đúng địa điểm này.
     * Chỉ khi chưa có dữ liệu mạng nào được lưu cho khu vực này mới tạm hiển thị khung nền chờ đồng bộ.
     */
    fun getCachedOrInitialWeather(context: Context, locationName: String): WeatherResult {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val key = KEY_WEATHER_JSON_PREFIX + normalizeLocationKey(locationName)
        val rawJson = prefs.getString(key, null)
        if (!rawJson.isNullOrBlank()) {
            parseWeatherResultFromJson(rawJson)?.let { cached ->
                return cached
            }
        }
        return getLocalWeather(locationName)
    }

    /**
     * Kiểm tra xem cache của khu vực đã cũ (mặc định > 20 phút) hoặc chưa có dữ liệu thực tế hay chưa.
     */
    fun isWeatherCacheStale(
        context: Context,
        locationName: String,
        maxAgeMs: Long = 20 * 60_000L
    ): Boolean {
        val cached = getCachedOrInitialWeather(context, locationName)
        if (!cached.isLiveData || cached.updatedAtMillis <= 0L) return true
        return (System.currentTimeMillis() - cached.updatedAtMillis) >= maxAgeMs
    }

    /**
     * Giải mã tọa độ chính xác tới từng Xã/Phường/Quận/Huyện/Tỉnh bằng Google Android Geocoder
     * kết hợp Open-Meteo Geocoding API miễn phí.
     */
    private val exactLandmarkCoordinates: List<Pair<String, Pair<Double, Double>>> = listOf(
        // Quần đảo Trường Sa & Nhà giàn DK1 & Quần đảo Hoàng Sa
        "song tu tay" to (11.4292 to 114.3319),
        "sinh ton" to (9.8869 to 114.3292),
        "nam yet" to (10.1794 to 114.3653),
        "son ca" to (10.3767 to 114.4797),
        "phan vinh" to (8.9750 to 113.6989),
        "an bang" to (7.8906 to 112.9211),
        "tien nu" to (8.8556 to 114.6542),
        "co lin" to (9.7711 to 114.2569),
        "len dao" to (9.7783 to 114.3719),
        "da tay" to (8.8550 to 112.2083),
        "da dong" to (8.8267 to 112.5967),
        "da lat" to (8.6667 to 111.6667),
        "da lon" to (10.0625 to 113.8542),
        "thuyen chai" to (8.1667 to 113.3000),
        "toc tan" to (8.8083 to 113.9833),
        "nui le" to (8.7167 to 114.1833),
        "dk1" to (8.0200 to 110.5500),
        "truong sa" to (8.6442 to 111.9197),
        "phu lam" to (16.8353 to 112.3386),
        "linh con" to (16.6681 to 112.7319),
        "tri ton" to (15.7850 to 111.2036),
        "hoang sa" to (16.5322 to 111.6150),

        // Biển đảo Bắc - Trung - Nam
        "dao tran" to (21.2389 to 107.9672),
        "thanh lan" to (21.0156 to 107.8228),
        "co to" to (20.9708 to 107.7650),
        "quan lan" to (20.8806 to 107.5236),
        "minh chau" to (20.9225 to 107.5811),
        "ngoc vung" to (20.8167 to 107.3667),
        "cai chien" to (21.3189 to 107.7689),
        "vinh thuc" to (21.3833 to 107.9167),
        "tra co" to (21.4819 to 108.0369),
        "sa vi" to (21.4917 to 108.0672),
        "tuan chau" to (20.9311 to 106.9889),
        "bach long vi" to (20.1331 to 107.7289),
        "cat ba" to (20.7278 to 107.0481),
        "viet hai" to (20.7931 to 107.0394),
        "cat hai" to (20.8030 to 106.9420),
        "long chau" to (20.6231 to 107.1586),
        "hon dau" to (20.6681 to 106.8156),
        "con vanh" to (20.2667 to 106.5833),
        "con den" to (20.4719 to 106.6025),
        "hon me" to (19.3736 to 105.9250),
        "hon ne" to (19.9144 to 106.0086),
        "hon ngu" to (18.8033 to 105.7722),
        "hon mat" to (18.7950 to 105.9583),
        "vung chua" to (17.8861 to 106.4539),
        "con co" to (17.1592 to 107.3408),
        "son cha" to (16.2167 to 108.2042),
        "son tra" to (16.1206 to 108.2683),
        "cu lao cham" to (15.9558 to 108.5089),
        "tam hai" to (15.4750 to 108.6650),
        "ly son" to (15.3803 to 109.1156),
        "dao be" to (15.4281 to 109.0836),
        "cu lao xanh" to (13.6197 to 109.3497),
        "nhon chau" to (13.6197 to 109.3497),
        "ky co" to (13.8894 to 109.3036),
        "hon kho" to (13.7636 to 109.2994),
        "cu lao mai nha" to (13.2806 to 109.3278),
        "hon yen" to (13.2264 to 109.3189),
        "nhat tu son" to (13.4317 to 109.2611),
        "hon nua" to (12.8300 to 109.3944),
        "diep son" to (12.6908 to 109.2778),
        "mui doi" to (12.6483 to 109.4619),
        "binh ba" to (11.8419 to 109.2361),
        "binh hung" to (11.7844 to 109.2175),
        "binh lap" to (11.8156 to 109.2008),
        "hon tre" to (12.2125 to 109.2569),
        "hon mun" to (12.1678 to 109.3056),
        "vinh hy" to (11.7208 to 109.1972),
        "phu quy" to (10.5333 to 108.9500),
        "cu lao cau" to (11.2286 to 108.8286),
        "ke ga" to (10.6969 to 107.9917),
        "con dao" to (8.6833 to 106.6094),
        "long son" to (10.4539 to 107.0933),
        "thanh an" to (10.5256 to 106.9683),
        "cu lao dung" to (9.6167 to 106.1500),
        "phu quoc" to (10.2270 to 103.9632),
        "an thoi" to (10.0114 to 104.0133),
        "hon thom" to (9.9531 to 104.0172),
        "tho chau" to (9.2994 to 103.4836),
        "nam du" to (9.6833 to 104.3500),
        "hon son" to (9.8058 to 104.6331),
        "lai son" to (9.8058 to 104.6331),
        "hon nghe" to (10.0258 to 104.5586),
        "ba lua" to (10.1236 to 104.5250),
        "hai tac" to (10.2969 to 104.3167),
        "tien hai" to (10.2969 to 104.3167),
        "hon khoai" to (8.4317 to 104.8319),
        "hon chuoi" to (8.9489 to 104.5394),
        "hon da bac" to (9.1764 to 104.7989),
        "dat mui" to (8.6094 to 104.7250),

        // Vùng cao, Biên giới, Cửa khẩu & Đỉnh núi
        "lung cu" to (23.3639 to 105.3164),
        "dong van" to (23.2778 to 105.3631),
        "pho bang" to (23.2553 to 105.2389),
        "sung la" to (23.2261 to 105.2672),
        "ma pi leng" to (23.2356 to 105.4117),
        "meo vac" to (23.1628 to 105.4058),
        "xin cai" to (23.2683 to 105.4750),
        "son vi" to (23.2189 to 105.5419),
        "yen minh" to (23.1181 to 105.1436),
        "du gia" to (22.9278 to 105.2361),
        "quan ba" to (23.0631 to 104.9911),
        "hoang su phi" to (22.7408 to 104.6806),
        "ban phung" to (22.7350 to 104.5311),
        "chieu lau thi" to (22.6339 to 104.6339),
        "xin man" to (22.6836 to 104.4678),
        "suoi thau" to (22.6850 to 104.4328),
        "tay con linh" to (22.7986 to 104.8031),
        "pac bo" to (22.9775 to 106.0511),
        "ban gioc" to (22.8556 to 106.7225),
        "tra linh" to (22.8250 to 106.3250),
        "me pia" to (22.9056 to 105.6889),
        "phia oac" to (22.6167 to 105.8667),
        "sa pa" to (22.3364 to 103.8438),
        "fansipan" to (22.3033 to 103.7750),
        "o quy ho" to (22.3556 to 103.7675),
        "y ty" to (22.6258 to 103.6194),
        "lung po" to (22.6978 to 103.6922),
        "a mu sung" to (22.6978 to 103.6922),
        "ky quan san" to (22.5022 to 103.5881),
        "bac ha" to (22.5369 to 104.2908),
        "si ma cai" to (22.6917 to 104.2833),
        "muong khuong" to (22.6681 to 104.1200),
        "sin ho" to (22.3622 to 103.2494),
        "ka lang" to (22.6778 to 102.4778),
        "thu lum" to (22.7361 to 102.4639),
        "muong te" to (22.3789 to 102.8117),
        "phong tho" to (22.5447 to 103.3489),
        "dao san" to (22.6667 to 103.3167),
        "sin suoi ho" to (22.5417 to 103.4889),
        "pu ta leng" to (22.4233 to 103.5919),
        "si thau chai" to (22.3889 to 103.5750),
        "a pa chai" to (22.3853 to 102.1856),
        "sin thau" to (22.3853 to 102.1856),
        "muong nhe" to (22.1819 to 102.4567),
        "nam po" to (21.9500 to 102.7333),
        "tua chua" to (21.9964 to 103.3328),
        "pha din" to (21.5647 to 103.5169),
        "muong phang" to (21.4547 to 103.1489),
        "tay trang" to (21.2211 to 102.9056),
        "ta xua" to (21.2725 to 104.4553),
        "ngoc chien" to (21.5833 to 104.2667),
        "pha luong" to (20.6889 to 104.6361),
        "moc chau" to (20.8450 to 104.6406),
        "sop cop" to (20.9333 to 103.6000),
        "mu cang chai" to (21.8503 to 104.0869),
        "la pan tan" to (21.8250 to 104.1361),
        "khau pha" to (21.7519 to 104.2361),
        "tram tau" to (21.4669 to 104.3831),
        "ta chi nhu" to (21.5719 to 104.3556),
        "suoi giang" to (21.5950 to 104.5250),
        "tu le" to (21.7019 to 104.2861),
        "ba be" to (22.4167 to 105.6167),
        "pac nam" to (22.6167 to 105.6833),
        "na hang" to (22.3536 to 105.3881),
        "lam binh" to (22.4789 to 105.3022),
        "mau son" to (21.8486 to 106.9178),
        "huu nghi" to (21.9744 to 106.7128),
        "bac son" to (21.8944 to 106.3167),
        "dong lam" to (21.6639 to 106.3861),
        "binh lieu" to (21.5256 to 107.3944),
        "dong cao" to (21.3750 to 106.8583),
        "xuan son" to (21.1361 to 104.9500),
        "tam dao" to (21.4569 to 105.6442),
        "ba vi" to (21.0806 to 105.3672),
        "lung van" to (20.5583 to 105.1750),
        "hang kia" to (20.7361 to 104.8944),
        "mai chau" to (20.6606 to 105.0833),
        "pu luong" to (20.4494 to 105.1619),
        "muong lat" to (20.5256 to 104.6022),
        "ten tan" to (20.5694 to 104.5028),
        "na meo" to (20.2944 to 104.6278),
        "ky son" to (19.3944 to 104.1528),
        "nam can" to (19.4622 to 104.0931),
        "muong long" to (19.5139 to 104.3167),
        "pu mat" to (19.0167 to 104.8000),
        "cau treo" to (18.3833 to 105.1472),
        "phong nha" to (17.5906 to 106.2833),
        "son doong" to (17.4569 to 106.2875),
        "cha lo" to (17.6889 to 105.7639),
        "khe sanh" to (16.6267 to 106.7317),
        "lao bao" to (16.6186 to 106.5928),
        "huong phung" to (16.7361 to 106.5917),
        "la lay" to (16.3167 to 106.9917),
        "a luoi" to (16.2719 to 107.2325),
        "bach ma" to (16.1950 to 107.8558),
        "hai van" to (16.2000 to 108.1333),
        "ba na" to (15.9977 to 107.9881),
        "tay giang" to (15.8950 to 107.4569),
        "nam tra my" to (15.1500 to 108.1000),
        "ngoc linh" to (15.0725 to 107.9850),
        "mang den" to (14.5975 to 108.2917),
        "bo y" to (14.7008 to 107.5586),
        "chu dang ya" to (14.1139 to 108.0528),
        "kbang" to (14.1500 to 108.5833),
        "buon don" to (12.8894 to 107.7922),
        "ea sup" to (13.0833 to 107.8833),
        "ta dung" to (11.8556 to 107.9917),
        "langbiang" to (12.0469 to 108.4389),
        "da lat" to (11.9404 to 108.4583),
        "bao loc" to (11.5478 to 107.8075),
        "bu gia map" to (12.1556 to 107.1861),
        "ba den" to (11.3736 to 106.1744),
        "moc bai" to (11.0767 to 106.1756),
        "xa mat" to (11.6944 to 105.9861),
        "cat tien" to (11.4233 to 107.4286),
        "tra su" to (10.5764 to 105.0489),
        "nui cam" to (10.4958 to 105.0028)
    )

    suspend fun resolveExactCoordinates(context: Context, locationName: String): Pair<Double, Double> =
        withContext(Dispatchers.IO) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val normKey = normalizeLocationKey(locationName)
            val cachedCoord = prefs.getString(KEY_COORD_PREFIX + normKey, null)
            if (!cachedCoord.isNullOrBlank()) {
                val parts = cachedCoord.split(",")
                if (parts.size == 2) {
                    val lat = parts[0].toDoubleOrNull()
                    val lon = parts[1].toDoubleOrNull()
                    if (lat != null && lon != null && isInsideVietnam(lat, lon)) {
                        return@withContext lat to lon
                    }
                }
            }

            // 0. Ưu tiên khớp tức thì 0ms các đảo tiền tiêu, đỉnh núi, vùng sâu vùng xa đặc biệt
            val firstSegmentKey = normalizeLocationKey(locationName.substringBefore(","))
            for ((landmarkKey, coord) in exactLandmarkCoordinates) {
                if (firstSegmentKey.contains(landmarkKey) || normKey.contains(landmarkKey)) {
                    prefs.edit().putString(KEY_COORD_PREFIX + normKey, "${coord.first},${coord.second}").apply()
                    return@withContext coord
                }
            }

            val cleaned = locationName
                .replace("Thành phố / Tỉnh ", "", ignoreCase = true)
                .trim()
            val commaParts = cleaned.split(",").map { it.trim() }.filter { it.isNotBlank() }

            // Nếu chỉ là tên Tỉnh/Thành phố đơn lẻ -> dùng tọa độ chuẩn 0ms ngay lập tức
            if (commaParts.size <= 1) {
                val matchedProv = provinceProfiles.entries.firstOrNull { (provName, _) ->
                    val k = normalizeLocationKey(provName)
                    normKey == k || normKey == "tp $k" || normKey == "tinh $k" || normKey == "thanh pho $k"
                }?.value
                if (matchedProv != null) {
                    val coord = matchedProv.lat to matchedProv.lon
                    prefs.edit().putString(KEY_COORD_PREFIX + normKey, "${coord.first},${coord.second}").apply()
                    return@withContext coord
                }
            }

            val provinceHint = commaParts.lastOrNull().orEmpty()

            // 1. Open-Meteo Geocoding API (CDN siêu tốc ~150ms, hỗ trợ đối chiếu khớp Tỉnh/Huyện)
            val omQueries = buildList {
                for (p in commaParts.dropLast(if (commaParts.size >= 2) 1 else 0)) {
                    val stripped = p
                        .replace(Regex("\\(.*?\\)"), "")
                        .replace(
                            Regex(
                                "^(Phường|Xã|Thị trấn|Quận|Huyện|Huyện đảo|Thị xã|Thành phố|Tỉnh|Bản|Thôn|Ấp|Đảo|Quần đảo)\\s+",
                                RegexOption.IGNORE_CASE
                            ),
                            ""
                        )
                        .trim()
                    if (stripped.length >= 2) add(stripped)
                }
                if (cleaned.isNotBlank() && commaParts.size == 1) add(cleaned)
            }.distinct().take(2)

            for (q in omQueries) {
                val omGeo = queryOpenMeteoGeocoding(q, provinceHint)
                if (omGeo != null && isInsideVietnam(omGeo.first, omGeo.second)) {
                    prefs.edit().putString(KEY_COORD_PREFIX + normKey, "${omGeo.first},${omGeo.second}").apply()
                    return@withContext omGeo
                }
            }

            val candidateQueries = buildList {
                if (cleaned.isNotBlank()) add("$cleaned, Việt Nam")
                if (commaParts.size >= 3) {
                    add("${commaParts[1]}, ${commaParts.last()}, Việt Nam")
                }
            }.distinct().take(2)

            // 2. Google-backed Android Geocoder (timeout nhanh 1500ms để không bao giờ gây trễ widget)
            for (q in candidateQueries) {
                val geo = queryAndroidGeocoder(context, q)
                if (geo != null && isInsideVietnam(geo.first, geo.second)) {
                    prefs.edit().putString(KEY_COORD_PREFIX + normKey, "${geo.first},${geo.second}").apply()
                    return@withContext geo
                }
            }

            // 3. OpenStreetMap Nominatim Vietnam Geocoding (chính xác tới từng Thôn/Bản/Xã vùng sâu vùng xa)
            for (q in candidateQueries) {
                val nomGeo = queryNominatimCoordinates(q)
                if (nomGeo != null && isInsideVietnam(nomGeo.first, nomGeo.second)) {
                    prefs.edit().putString(KEY_COORD_PREFIX + normKey, "${nomGeo.first},${nomGeo.second}").apply()
                    return@withContext nomGeo
                }
            }

            // 4. Dự phòng tọa độ điểm đặc biệt / tỉnh gần nhất
            val fallback = resolveGeoProfile(locationName)
            fallback.lat to fallback.lon
        }

    private fun queryNominatimCoordinates(query: String): Pair<Double, Double>? {
        return try {
            val cleanQ = query.replace(Regex("\\(.*?\\)"), "").trim()
            val encoded = URLEncoder.encode(cleanQ, "UTF-8")
            val url = "https://nominatim.openstreetmap.org/search?q=$encoded&countrycodes=vn&format=json&limit=3&accept-language=vi"
            val body = httpGetString(url, timeoutMs = 1800, userAgent = "MagictuneWeather/6.9 (https://magictune.app)") ?: return null
            val arr = JSONArray(body)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val lat = obj.optString("lat", "").toDoubleOrNull()
                val lon = obj.optString("lon", "").toDoubleOrNull()
                if (lat != null && lon != null && isInsideVietnam(lat, lon)) {
                    return lat to lon
                }
            }
            null
        } catch (_: Throwable) {
            null
        }
    }

    private suspend fun queryAndroidGeocoder(context: Context, query: String): Pair<Double, Double>? {
        return try {
            if (!Geocoder.isPresent()) return null
            val geocoder = Geocoder(context, Locale("vi", "VN"))
            val addresses: List<Address>? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                withTimeoutOrNull(1500L) {
                    suspendCancellableCoroutine { cont ->
                        try {
                            geocoder.getFromLocationName(query, 3, object : Geocoder.GeocodeListener {
                                override fun onGeocode(results: MutableList<Address>) {
                                    if (cont.isActive) cont.resume(results)
                                }

                                override fun onError(errorMessage: String?) {
                                    if (cont.isActive) cont.resume(null)
                                }
                            })
                        } catch (_: Throwable) {
                            if (cont.isActive) cont.resume(null)
                        }
                    }
                }
            } else {
                withTimeoutOrNull(1500L) {
                    @Suppress("DEPRECATION")
                    geocoder.getFromLocationName(query, 3)
                }
            }

            addresses?.firstOrNull { addr ->
                val lat = addr.latitude
                val lon = addr.longitude
                isInsideVietnam(lat, lon)
            }?.let { it.latitude to it.longitude }
        } catch (_: Throwable) {
            null
        }
    }

    private fun queryOpenMeteoGeocoding(query: String, provinceHint: String = ""): Pair<Double, Double>? {
        return try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = "https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=10&language=vi&format=json"
            val body = httpGetString(url, timeoutMs = 2000) ?: return null
            val results = JSONObject(body).optJSONArray("results") ?: return null
            val normProv = normalizeLocationKey(
                provinceHint.replace(Regex("^(TP\\.|Thành phố|Tỉnh)\\s*", RegexOption.IGNORE_CASE), "")
            )
            var firstValidVn: Pair<Double, Double>? = null
            for (i in 0 until results.length()) {
                val obj = results.optJSONObject(i) ?: continue
                val cc = obj.optString("country_code", "")
                val lat = obj.optDouble("latitude", Double.NaN)
                val lon = obj.optDouble("longitude", Double.NaN)
                if (!lat.isNaN() && !lon.isNaN() && (cc.equals("VN", true) || isInsideVietnam(lat, lon)) && isInsideVietnam(lat, lon)) {
                    if (firstValidVn == null) {
                        firstValidVn = lat to lon
                    }
                    if (normProv.isNotBlank()) {
                        val admin1 = normalizeLocationKey(obj.optString("admin1", ""))
                        val admin2 = normalizeLocationKey(obj.optString("admin2", ""))
                        val name = normalizeLocationKey(obj.optString("name", ""))
                        if (admin1.contains(normProv) || normProv.contains(admin1.takeIf { it.length >= 4 } ?: "___") ||
                            admin2.contains(normProv) || name.contains(normProv)
                        ) {
                            return lat to lon
                        }
                    } else {
                        return lat to lon
                    }
                }
            }
            firstValidVn
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Truy vấn thời tiết THỜI GIAN THỰC đa nguồn độ chính xác cao:
     * 1. Open-Meteo High-Res Forecast (ECMWF IFS 9km + GFS + ICON + lượng mưa mm thực tế + mây %)
     *    kết hợp kiểm chứng chéo MET Norway (Yr.no) khi trạng thái mây/mưa ở ngưỡng giao thoa
     * 2. MET Norway (Yr.no) Locationforecast 2.0
     * 3. wttr.in
     *
     * Kết quả thực tế được lưu JSON đồng bộ ngay lập tức vào SharedPreferences để
     * App & Widget bên ngoài màn hình chính hiển thị chuẩn xác 100% tức thì.
     */
    suspend fun fetchLiveWeatherAsync(context: Context, locationName: String): WeatherResult =
        withContext(Dispatchers.IO) {
            val (lat, lon) = resolveExactCoordinates(context, locationName)

            val live = fetchFromOpenMeteo(locationName, lat, lon)
                ?: fetchFromMetNorway(locationName, lat, lon)
                ?: fetchFromWttrIn(locationName, lat, lon)

            if (live != null) {
                saveWeatherCache(context, locationName, live)
                return@withContext live
            }

            // Nếu ngoại tuyến hoàn toàn: ưu tiên bản cache thực tế trước đó của đúng khu vực này
            val cached = getCachedOrInitialWeather(context, locationName)
            if (cached.isLiveData) {
                val timeStr = SimpleDateFormat("HH:mm dd/MM", Locale("vi", "VN"))
                    .format(Date(cached.updatedAtMillis))
                return@withContext cached.copy(
                    sourceLabel = "Đã lưu lúc $timeStr (Ngoại tuyến)"
                )
            }

            cached
        }

    /**
     * Kiểm chứng chéo nhanh lượng mưa & trạng thái trời hiện tại từ MET Norway (Yr.no)
     * để tinh chỉnh độ chính xác nắng/mưa tại khu vực nhiệt đới Việt Nam.
     */
    private fun fetchMetNorwayInstantRainVerify(lat: Double, lon: Double): Pair<Boolean?, Double>? {
        return try {
            val latStr = String.format(Locale.US, "%.4f", lat)
            val lonStr = String.format(Locale.US, "%.4f", lon)
            val url = "https://api.met.no/weatherapi/locationforecast/2.0/compact?lat=$latStr&lon=$lonStr"
            val body = httpGetString(
                urlStr = url,
                timeoutMs = 1700,
                userAgent = "MagictuneWeather/6.9 (https://magictune.app)"
            ) ?: return null
            val series = JSONObject(body).optJSONObject("properties")?.optJSONArray("timeseries") ?: return null
            if (series.length() == 0) return null
            val utcFmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            val nowMs = System.currentTimeMillis()
            var startIdx = 0
            for (i in 0 until series.length()) {
                val entry = series.optJSONObject(i) ?: continue
                val tMs = try { utcFmt.parse(entry.optString("time", ""))?.time ?: 0L } catch (_: Throwable) { 0L }
                if (tMs >= nowMs - 30 * 60_000L) {
                    startIdx = i
                    break
                }
            }
            val curData = series.optJSONObject(startIdx)?.optJSONObject("data") ?: return null
            val next1h = curData.optJSONObject("next_1_hours")
            val sym = next1h?.optJSONObject("summary")?.optString("symbol_code", "")?.lowercase(Locale.US).orEmpty()
            val precipMm = next1h?.optJSONObject("details")?.optDouble("precipitation_amount", 0.0) ?: 0.0
            val isRainingInMet = sym.contains("rain") || sym.contains("thunder") || sym.contains("sleet") || precipMm >= 0.2
            val isClearInMet = sym.contains("clearsky") || sym.contains("fair")
            val rainFlag: Boolean? = when {
                isRainingInMet -> true
                isClearInMet && precipMm <= 0.0 -> false
                else -> null
            }
            rainFlag to precipMm
        } catch (_: Throwable) {
            null
        }
    }

    private fun fetchFromOpenMeteo(locationName: String, lat: Double, lon: Double): WeatherResult? {
        return try {
            val latStr = String.format(Locale.US, "%.4f", lat)
            val lonStr = String.format(Locale.US, "%.4f", lon)
            val forecastUrl =
                "https://api.open-meteo.com/v1/forecast?latitude=$latStr&longitude=$lonStr" +
                    "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,rain,showers,weather_code,cloud_cover,wind_speed_10m" +
                    "&hourly=temperature_2m,weather_code,is_day,precipitation_probability,precipitation,rain,showers,cloud_cover" +
                    "&daily=weather_code,temperature_2m_max,temperature_2m_min,uv_index_max,precipitation_probability_max,precipitation_sum" +
                    "&timezone=Asia%2FBangkok&forecast_days=7"

            val body = httpGetString(forecastUrl, timeoutMs = 3800) ?: return null
            val root = JSONObject(body)
            val currentObj = root.optJSONObject("current") ?: return null
            val hourlyObj = root.optJSONObject("hourly")
            val dailyObj = root.optJSONObject("daily")

            val liveTemp = currentObj.optDouble("temperature_2m", Double.NaN)
            if (liveTemp.isNaN()) return null
            val roundedTemp = liveTemp.roundToInt()
            val liveHumidity = currentObj.optDouble("relative_humidity_2m", 75.0).roundToInt().coerceIn(5, 100)
            val liveWind = currentObj.optDouble("wind_speed_10m", 10.0).roundToInt().coerceAtLeast(0)
            var liveCode = currentObj.optInt("weather_code", 0)
            val liveIsDay = currentObj.optInt("is_day", 1) == 1
            val currentCloudCover = currentObj.optDouble("cloud_cover", 35.0).roundToInt().coerceIn(0, 100)
            val currentPrecipMm = maxOf(
                currentObj.optDouble("precipitation", 0.0),
                currentObj.optDouble("rain", 0.0) + currentObj.optDouble("showers", 0.0)
            )

            // Khớp chính xác chỉ số giờ hiện tại theo chuỗi ISO Asia/Bangkok (yyyy-MM-dd'T'HH)
            val bangkokTz = TimeZone.getTimeZone("Asia/Bangkok")
            val hourPrefixFmt = SimpleDateFormat("yyyy-MM-dd'T'HH", Locale.US).apply { timeZone = bangkokTz }
            val currentHourPrefix = hourPrefixFmt.format(Date())

            var curHourRainProb = -1
            var nextHourRainProb = -1
            var curHourPrecipMm = 0.0

            val hourlySlots = mutableListOf<HourlySlot>()
            if (hourlyObj != null) {
                val times = hourlyObj.optJSONArray("time")
                val temps = hourlyObj.optJSONArray("temperature_2m")
                val codes = hourlyObj.optJSONArray("weather_code")
                val isDays = hourlyObj.optJSONArray("is_day")
                val precipProbs = hourlyObj.optJSONArray("precipitation_probability")
                val hourlyPrecips = hourlyObj.optJSONArray("precipitation")
                val hourlyClouds = hourlyObj.optJSONArray("cloud_cover")

                if (times != null && temps != null && times.length() > 0) {
                    var startIdx = -1
                    for (i in 0 until times.length()) {
                        val tStr = times.optString(i, "")
                        if (tStr.startsWith(currentHourPrefix)) {
                            startIdx = i
                            break
                        }
                    }
                    if (startIdx < 0) {
                        val cal = Calendar.getInstance(bangkokTz)
                        startIdx = cal.get(Calendar.HOUR_OF_DAY).coerceIn(0, times.length() - 1)
                    }

                    if (precipProbs != null && startIdx in 0 until precipProbs.length()) {
                        val p0 = precipProbs.optInt(startIdx, -1)
                        val p1 = if (startIdx + 1 < precipProbs.length()) precipProbs.optInt(startIdx + 1, p0) else p0
                        if (p0 in 0..100) curHourRainProb = p0
                        if (p1 in 0..100) nextHourRainProb = p1
                    }
                    if (hourlyPrecips != null && startIdx in 0 until hourlyPrecips.length()) {
                        curHourPrecipMm = hourlyPrecips.optDouble(startIdx, 0.0)
                    }

                    val endIdx = minOf(times.length(), startIdx + 24)
                    for (idx in startIdx until endIdx) {
                        val isoStr = times.optString(idx, "")
                        val hhmm = if (isoStr.length >= 16) isoStr.substring(11, 16) else {
                            String.format(Locale.US, "%02d:00", idx % 24)
                        }
                        val tVal = temps.optDouble(idx, liveTemp).roundToInt()
                        var cVal = codes?.optInt(idx, liveCode) ?: liveCode
                        val hProb = precipProbs?.optInt(idx, 20) ?: 20
                        val hMm = hourlyPrecips?.optDouble(idx, 0.0) ?: 0.0
                        val hCloud = hourlyClouds?.optInt(idx, currentCloudCover) ?: currentCloudCover
                        // Hiệu chỉnh mã thời tiết theo giờ dựa trên lượng mưa mm & xác suất mưa thực tế
                        if (cVal in 51..82 && hMm < 0.08 && hProb < 28) {
                            cVal = if (hCloud >= 75) 3 else if (hCloud >= 30) 2 else 1
                        } else if (cVal in 0..3 && (hMm >= 0.35 || hProb >= 78)) {
                            cVal = if (hMm >= 2.0) 63 else 80
                        }
                        val hHour = hhmm.substringBefore(":").toIntOrNull() ?: 12
                        val hIsDay = if (isDays != null && idx < isDays.length()) {
                            isDays.optInt(idx, 1) == 1
                        } else {
                            hHour in 6..17
                        }
                        val (hIcon, _) = decodeWmoWeather(cVal, hIsDay)
                        hourlySlots.add(HourlySlot(hhmm, hIcon, "${tVal}°C"))
                    }
                }
            }

            // Thuật toán Đa Tầng Kiểm Chứng Nắng / Mưa (Multi-Signal Sun & Rain Fusion):
            // Kết hợp: (1) Lượng mưa thực đo mm (currentPrecipMm + curHourPrecipMm),
            //          (2) Xác suất mưa giờ hiện tại & giờ kế tiếp,
            //          (3) Độ che phủ mây % (currentCloudCover) & Độ ẩm %,
            //          (4) Kiểm chứng chéo MET Norway (Yr.no) khi trạng thái giáp ranh (mây nhiều hoặc mưa nhỏ).
            val effectivePrecipMm = maxOf(currentPrecipMm, curHourPrecipMm * 0.7)
            val blendedHourProb = when {
                curHourRainProb in 0..100 && nextHourRainProb in 0..100 ->
                    ((curHourRainProb * 0.7) + (nextHourRainProb * 0.3)).roundToInt()
                curHourRainProb in 0..100 -> curHourRainProb
                else -> -1
            }

            val isBorderlineWeather = (liveCode in 51..82 && effectivePrecipMm < 0.25) ||
                (liveCode in 2..3 && (blendedHourProb >= 45 || liveHumidity >= 84))
            val metVerify = if (isBorderlineWeather) fetchMetNorwayInstantRainVerify(lat, lon) else null

            if (liveCode in 51..82) {
                // Nếu WMO báo mưa nhẹ nhưng thực đo 0.0mm, xác suất mưa giờ hiện tại thấp (<30%) hoặc MET Norway báo quang mây
                if (effectivePrecipMm < 0.08 && ((blendedHourProb in 0..28) || metVerify?.first == false)) {
                    liveCode = when {
                        currentCloudCover >= 80 -> 3
                        currentCloudCover >= 35 -> 2
                        else -> 1
                    }
                }
            } else if (liveCode in 0..3) {
                // Nếu WMO báo mây/nắng nhưng lượng mưa thực đo đang có mưa (>=0.25mm) hoặc cả xác suất mưa cao & MET Norway xác nhận đang mưa
                if (effectivePrecipMm >= 0.35 || (metVerify?.first == true && (metVerify.second >= 0.3 || blendedHourProb >= 55)) || blendedHourProb >= 82) {
                    liveCode = if (effectivePrecipMm >= 2.5) 63 else 80
                } else if (liveCode == 0 && currentCloudCover >= 55) {
                    liveCode = 2
                } else if (liveCode in 2..3 && currentCloudCover <= 22 && effectivePrecipMm <= 0.0 && (blendedHourProb in 0..20)) {
                    liveCode = 1
                }
            }

            val (codeIcon, codeDesc) = decodeWmoWeather(liveCode, liveIsDay)
            val liveDisplay = "$codeIcon ${roundedTemp}°C"

            var liveRainProb = if (blendedHourProb in 0..100) {
                blendedHourProb
            } else {
                estimateRainProbability(codeIcon, codeDesc, liveHumidity)
            }
            // Đồng bộ % mưa khớp chặt chẽ với trạng thái nắng/mưa thực tế sau kiểm chứng
            liveRainProb = when {
                liveCode >= 95 -> maxOf(liveRainProb, 85)
                liveCode in listOf(63, 65, 67, 81, 82) -> maxOf(liveRainProb, 75)
                liveCode in listOf(51, 53, 55, 61, 80) -> liveRainProb.coerceIn(50, 92)
                liveCode == 3 -> liveRainProb.coerceIn(18, 55)
                liveCode == 2 -> liveRainProb.coerceIn(10, 40)
                else -> liveRainProb.coerceIn(2, 22)
            }

            // Đo chất lượng không khí thực tế (timeout nhanh 1500ms để không làm chậm đồng bộ Widget)
            val aqiLabel = fetchOpenMeteoAirQuality(latStr, lonStr)

            // Dự báo 7 ngày từ Open-Meteo
            val dailySlots = mutableListOf<DailySlot>()
            var todayUvLabel = "5 (Trung bình)"
            if (dailyObj != null) {
                val dTimes = dailyObj.optJSONArray("time")
                val dCodes = dailyObj.optJSONArray("weather_code")
                val dMaxs = dailyObj.optJSONArray("temperature_2m_max")
                val dMins = dailyObj.optJSONArray("temperature_2m_min")
                val dUvs = dailyObj.optJSONArray("uv_index_max")
                val dPrecipMax = dailyObj.optJSONArray("precipitation_probability_max")
                val dPrecipSum = dailyObj.optJSONArray("precipitation_sum")
                val dayNames = arrayOf("Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Bảy", "Thứ Bảy")
                    .also { it[5] = "Thứ Sáu" }
                val isoDateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = bangkokTz }
                val viDateFmt = SimpleDateFormat("dd/MM", Locale("vi", "VN")).apply { timeZone = bangkokTz }

                if (dTimes != null && dMaxs != null && dMins != null) {
                    for (d in 0 until minOf(7, dTimes.length())) {
                        val rawDate = dTimes.optString(d, "")
                        val parsedDate = try { isoDateFmt.parse(rawDate) } catch (_: Throwable) { null }
                        val targetCal = Calendar.getInstance(bangkokTz).apply {
                            if (parsedDate != null) time = parsedDate else add(Calendar.DAY_OF_YEAR, d)
                        }
                        val dayName = if (d == 0) "Hôm nay" else dayNames[targetCal.get(Calendar.DAY_OF_WEEK) - 1]
                        val dateStr = viDateFmt.format(targetCal.time)
                        var code = if (d == 0) liveCode else (dCodes?.optInt(d, liveCode) ?: liveCode)
                        val dayMm = dPrecipSum?.optDouble(d, 0.0) ?: 0.0
                        val rawDayProb = dPrecipMax?.optInt(d, -1)?.takeIf { it in 0..100 }
                        if (d > 0 && code in 51..82 && dayMm < 0.6 && (rawDayProb != null && rawDayProb < 35)) {
                            code = 2
                        }
                        val (dIcon, dCond) = decodeWmoWeather(code, true)
                        val minT = dMins.optDouble(d, liveTemp - 4.0).roundToInt()
                        val maxT = dMaxs.optDouble(d, liveTemp + 2.0).roundToInt()
                        val uvDouble = dUvs?.optDouble(d, 5.0) ?: 5.0
                        val uvStr = formatUvIndex(uvDouble, liveIsDay || d > 0)
                        val dayRainProb = if (d == 0) {
                            liveRainProb
                        } else {
                            rawDayProb ?: estimateRainProbability(dIcon, dCond, liveHumidity)
                        }
                        if (d == 0) {
                            todayUvLabel = if (!liveIsDay) "0 (Ban đêm)" else uvStr
                        }

                        dailySlots.add(
                            DailySlot(
                                dayName = dayName,
                                dateStr = dateStr,
                                icon = dIcon,
                                condition = dCond,
                                minTemp = minT,
                                maxTemp = maxT,
                                humidity = liveHumidity,
                                windSpeed = liveWind,
                                uvIndex = uvStr,
                                airQuality = aqiLabel,
                                rainProbability = dayRainProb
                            )
                        )
                    }
                }
            }

            if (hourlySlots.isEmpty() || dailySlots.isEmpty()) return null

            WeatherResult(
                fullLocation = locationName,
                currentTemp = roundedTemp,
                tempDisplay = liveDisplay,
                condition = codeDesc,
                icon = codeIcon,
                humidity = liveHumidity,
                windSpeed = liveWind,
                uvIndex = todayUvLabel,
                airQuality = aqiLabel,
                hourlyForecast = hourlySlots,
                dailyForecast = dailySlots,
                isLiveData = true,
                sourceLabel = "Thực tế Đa Nguồn • Open-Meteo & MET",
                updatedAtMillis = System.currentTimeMillis(),
                lat = lat,
                lon = lon,
                rainProbability = liveRainProb
            )
        } catch (_: Throwable) {
            null
        }
    }

    private fun fetchOpenMeteoAirQuality(latStr: String, lonStr: String): String {
        return try {
            val aqUrl =
                "https://air-quality-api.open-meteo.com/v1/air-quality?latitude=$latStr&longitude=$lonStr" +
                    "&current=european_aqi&timezone=Asia%2FBangkok"
            val body = httpGetString(aqUrl, timeoutMs = 1500) ?: return "Ổn định (WMO)"
            val current = JSONObject(body).optJSONObject("current") ?: return "Ổn định (WMO)"
            val aqi = current.optInt("european_aqi", -1)
            if (aqi < 0) return "Ổn định (WMO)"
            val desc = when {
                aqi <= 20 -> "Rất tốt"
                aqi <= 40 -> "Tốt"
                aqi <= 60 -> "Trung bình"
                aqi <= 80 -> "Kém"
                else -> "Ô nhiễm"
            }
            "$desc (AQI: $aqi)"
        } catch (_: Throwable) {
            "Ổn định (WMO)"
        }
    }

    /**
     * Dự phòng 1: MET Norway (Yr.no Locationforecast 2.0 - miễn phí, chính xác toàn cầu)
     */
    private fun fetchFromMetNorway(locationName: String, lat: Double, lon: Double): WeatherResult? {
        return try {
            val latStr = String.format(Locale.US, "%.4f", lat)
            val lonStr = String.format(Locale.US, "%.4f", lon)
            val url = "https://api.met.no/weatherapi/locationforecast/2.0/compact?lat=$latStr&lon=$lonStr"
            val body = httpGetString(
                urlStr = url,
                timeoutMs = 4500,
                userAgent = "MagicTuneWeather/6.2 (https://magictune.app)"
            ) ?: return null

            val root = JSONObject(body)
            val props = root.optJSONObject("properties") ?: return null
            val series = props.optJSONArray("timeseries") ?: return null
            if (series.length() == 0) return null

            val utcFmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            val bangkokTz = TimeZone.getTimeZone("Asia/Bangkok")
            val hourFmt = SimpleDateFormat("HH:00", Locale.US).apply { timeZone = bangkokTz }
            val dateKeyFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = bangkokTz }
            val viDateFmt = SimpleDateFormat("dd/MM", Locale("vi", "VN")).apply { timeZone = bangkokTz }
            val nowMs = System.currentTimeMillis()

            var startIdx = 0
            for (i in 0 until series.length()) {
                val entry = series.optJSONObject(i) ?: continue
                val tMs = try { utcFmt.parse(entry.optString("time", ""))?.time ?: 0L } catch (_: Throwable) { 0L }
                if (tMs >= nowMs - 30 * 60_000L) {
                    startIdx = i
                    break
                }
            }

            val curEntry = series.optJSONObject(startIdx) ?: return null
            val curData = curEntry.optJSONObject("data") ?: return null
            val curInst = curData.optJSONObject("instant")?.optJSONObject("details") ?: return null
            val curTemp = curInst.optDouble("air_temperature", Double.NaN)
            if (curTemp.isNaN()) return null
            val roundedTemp = curTemp.roundToInt()
            val curHumidity = curInst.optDouble("relative_humidity", 75.0).roundToInt().coerceIn(5, 100)
            val curWindKmh = (curInst.optDouble("wind_speed", 3.0) * 3.6).roundToInt().coerceAtLeast(0)
            val curSym = curData.optJSONObject("next_1_hours")?.optJSONObject("summary")?.optString("symbol_code", "")
                ?: curData.optJSONObject("next_6_hours")?.optJSONObject("summary")?.optString("symbol_code", "")
                ?: "clearsky_day"
            val curHourLocal = Calendar.getInstance(bangkokTz).get(Calendar.HOUR_OF_DAY)
            val (curIcon, curDesc) = decodeMetSymbol(curSym, curHourLocal in 6..17)

            val hourlySlots = mutableListOf<HourlySlot>()
            val dailyBuckets = linkedMapOf<String, MutableList<Triple<Double, String, Date>>>()

            for (i in startIdx until series.length()) {
                val entry = series.optJSONObject(i) ?: continue
                val timeStr = entry.optString("time", "")
                val dt = try { utcFmt.parse(timeStr) } catch (_: Throwable) { null } ?: continue
                val data = entry.optJSONObject("data") ?: continue
                val details = data.optJSONObject("instant")?.optJSONObject("details") ?: continue
                val temp = details.optDouble("air_temperature", Double.NaN)
                if (temp.isNaN()) continue
                val sym = data.optJSONObject("next_1_hours")?.optJSONObject("summary")?.optString("symbol_code", "")
                    ?.takeIf { it.isNotBlank() }
                    ?: data.optJSONObject("next_6_hours")?.optJSONObject("summary")?.optString("symbol_code", "")
                    ?: curSym

                val localCal = Calendar.getInstance(bangkokTz).apply { time = dt }
                val localHour = localCal.get(Calendar.HOUR_OF_DAY)
                if (hourlySlots.size < 24) {
                    val (hIcon, _) = decodeMetSymbol(sym, localHour in 6..17)
                    hourlySlots.add(HourlySlot(hourFmt.format(dt), hIcon, "${temp.roundToInt()}°C"))
                }

                val dayKey = dateKeyFmt.format(dt)
                dailyBuckets.getOrPut(dayKey) { mutableListOf() }.add(Triple(temp, sym, dt))
            }

            val dayNames = arrayOf("Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy")
            val dailySlots = mutableListOf<DailySlot>()
            dailyBuckets.entries.take(7).forEachIndexed { idx, (_, items) ->
                val minT = items.minOf { it.first }.roundToInt()
                val maxT = items.maxOf { it.first }.roundToInt()
                val rep = items.getOrNull(items.size / 2) ?: items.first()
                val cal = Calendar.getInstance(bangkokTz).apply { time = rep.third }
                val dayName = if (idx == 0) "Hôm nay" else dayNames[cal.get(Calendar.DAY_OF_WEEK) - 1]
                val (dIcon, dDesc) = decodeMetSymbol(rep.second, true)
                dailySlots.add(
                    DailySlot(
                        dayName = dayName,
                        dateStr = viDateFmt.format(rep.third),
                        icon = dIcon,
                        condition = dDesc,
                        minTemp = minT,
                        maxTemp = maxT,
                        humidity = curHumidity,
                        windSpeed = curWindKmh,
                        uvIndex = if (maxT >= 32) "8 (Cao)" else "5 (Trung bình)",
                        airQuality = "Ổn định"
                    )
                )
            }

            if (hourlySlots.isEmpty() || dailySlots.isEmpty()) return null

            WeatherResult(
                fullLocation = locationName,
                currentTemp = roundedTemp,
                tempDisplay = "$curIcon ${roundedTemp}°C",
                condition = curDesc,
                icon = curIcon,
                humidity = curHumidity,
                windSpeed = curWindKmh,
                uvIndex = if (curHourLocal in 6..17) "6 (Cao)" else "0 (Ban đêm)",
                airQuality = "Ổn định",
                hourlyForecast = hourlySlots,
                dailyForecast = dailySlots,
                isLiveData = true,
                sourceLabel = "Thực tế • MET Norway",
                updatedAtMillis = System.currentTimeMillis(),
                lat = lat,
                lon = lon
            )
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Dự phòng 2: wttr.in JSON API
     */
    private fun fetchFromWttrIn(locationName: String, lat: Double, lon: Double): WeatherResult? {
        return try {
            val latStr = String.format(Locale.US, "%.4f", lat)
            val lonStr = String.format(Locale.US, "%.4f", lon)
            val url = "https://wttr.in/$latStr,$lonStr?format=j1&lang=vi"
            val body = httpGetString(url, timeoutMs = 4000) ?: return null
            val root = JSONObject(body)
            val curArr = root.optJSONArray("current_condition") ?: return null
            val cur = curArr.optJSONObject(0) ?: return null
            val tempC = cur.optString("temp_C", "").toIntOrNull() ?: return null
            val humidity = cur.optString("humidity", "75").toIntOrNull() ?: 75
            val wind = cur.optString("windspeedKmph", "12").toIntOrNull() ?: 12
            val wCode = cur.optString("weatherCode", "113").toIntOrNull() ?: 113
            val bangkokTz = TimeZone.getTimeZone("Asia/Bangkok")
            val curHour = Calendar.getInstance(bangkokTz).get(Calendar.HOUR_OF_DAY)
            val isDay = curHour in 6..17
            val (curIcon, curDesc) = decodeWwoCode(wCode, isDay)

            val weatherArr = root.optJSONArray("weather") ?: return null
            val dayNames = arrayOf("Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy")
            val isoDateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = bangkokTz }
            val viDateFmt = SimpleDateFormat("dd/MM", Locale("vi", "VN")).apply { timeZone = bangkokTz }

            val hourlySlots = mutableListOf<HourlySlot>()
            val dailySlots = mutableListOf<DailySlot>()

            for (d in 0 until weatherArr.length()) {
                val dObj = weatherArr.optJSONObject(d) ?: continue
                val minT = dObj.optString("mintempC", "$tempC").toIntOrNull() ?: tempC
                val maxT = dObj.optString("maxtempC", "$tempC").toIntOrNull() ?: tempC
                val uv = dObj.optString("uvIndex", "5").toDoubleOrNull() ?: 5.0
                val rawDate = dObj.optString("date", "")
                val dt = try { isoDateFmt.parse(rawDate) } catch (_: Throwable) { null }
                val cal = Calendar.getInstance(bangkokTz).apply {
                    if (dt != null) time = dt else add(Calendar.DAY_OF_YEAR, d)
                }
                val dayName = if (d == 0) "Hôm nay" else dayNames[cal.get(Calendar.DAY_OF_WEEK) - 1]
                val hArr = dObj.optJSONArray("hourly")

                var repCode = wCode
                if (hArr != null && hArr.length() > 0) {
                    val midObj = hArr.optJSONObject(hArr.length() / 2)
                    repCode = midObj?.optString("weatherCode", "$wCode")?.toIntOrNull() ?: wCode
                    if (hourlySlots.size < 24) {
                        for (h in 0 until hArr.length()) {
                            val hObj = hArr.optJSONObject(h) ?: continue
                            val timeInt = hObj.optString("time", "0").toIntOrNull() ?: 0
                            val hour = (timeInt / 100).coerceIn(0, 23)
                            if (d == 0 && hour < curHour) continue
                            val hTemp = hObj.optString("tempC", "$tempC").toIntOrNull() ?: tempC
                            val hCode = hObj.optString("weatherCode", "$wCode").toIntOrNull() ?: wCode
                            val (hIcon, _) = decodeWwoCode(hCode, hour in 6..17)
                            hourlySlots.add(HourlySlot(String.format(Locale.US, "%02d:00", hour), hIcon, "${hTemp}°C"))
                            if (hourlySlots.size >= 24) break
                        }
                    }
                }
                val (dIcon, dDesc) = decodeWwoCode(repCode, true)
                dailySlots.add(
                    DailySlot(
                        dayName = dayName,
                        dateStr = viDateFmt.format(cal.time),
                        icon = dIcon,
                        condition = dDesc,
                        minTemp = minT,
                        maxTemp = maxT,
                        humidity = humidity,
                        windSpeed = wind,
                        uvIndex = formatUvIndex(uv, true),
                        airQuality = "Ổn định"
                    )
                )
            }

            if (hourlySlots.isEmpty() || dailySlots.isEmpty()) return null

            WeatherResult(
                fullLocation = locationName,
                currentTemp = tempC,
                tempDisplay = "$curIcon ${tempC}°C",
                condition = curDesc,
                icon = curIcon,
                humidity = humidity,
                windSpeed = wind,
                uvIndex = formatUvIndex(cur.optString("uvIndex", "5").toDoubleOrNull() ?: 5.0, isDay),
                airQuality = "Ổn định",
                hourlyForecast = hourlySlots,
                dailyForecast = dailySlots,
                isLiveData = true,
                sourceLabel = "Thực tế • wttr.in",
                updatedAtMillis = System.currentTimeMillis(),
                lat = lat,
                lon = lon
            )
        } catch (_: Throwable) {
            null
        }
    }

    private fun httpGetString(
        urlStr: String,
        timeoutMs: Int = 4000,
        userAgent: String = "MagicTune-Weather/6.2"
    ): String? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                connectTimeout = timeoutMs
                readTimeout = timeoutMs
                requestMethod = "GET"
                setRequestProperty("User-Agent", userAgent)
                setRequestProperty("Accept", "application/json")
            }
            if (conn.responseCode == 200) {
                conn.inputStream.bufferedReader().use { it.readText() }
            } else {
                null
            }
        } catch (_: Throwable) {
            null
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }

    private fun saveWeatherCache(context: Context, locationName: String, result: WeatherResult) {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val jsonStr = serializeWeatherResult(result)
            val locKey = KEY_WEATHER_JSON_PREFIX + normalizeLocationKey(locationName)
            prefs.edit()
                .putString(locKey, jsonStr)
                .putString(KEY_CACHED_JSON, jsonStr)
                .putInt(KEY_CACHED_TEMP, result.currentTemp)
                .putString(KEY_CACHED_DESC, result.condition)
                .putString(KEY_CACHED_ICON, result.icon)
                .apply()
        } catch (_: Throwable) {}
    }

    private fun serializeWeatherResult(r: WeatherResult): String {
        val root = JSONObject().apply {
            put("fullLocation", r.fullLocation)
            put("currentTemp", r.currentTemp)
            put("tempDisplay", r.tempDisplay)
            put("condition", r.condition)
            put("icon", r.icon)
            put("humidity", r.humidity)
            put("windSpeed", r.windSpeed)
            put("uvIndex", r.uvIndex)
            put("airQuality", r.airQuality)
            put("isLiveData", r.isLiveData)
            put("sourceLabel", r.sourceLabel)
            put("updatedAtMillis", r.updatedAtMillis)
            put("lat", r.lat)
            put("lon", r.lon)
            put("rainProbability", r.rainProbability)

            val hArr = JSONArray()
            for (h in r.hourlyForecast) {
                hArr.put(
                    JSONObject().apply {
                        put("hourLabel", h.hourLabel)
                        put("icon", h.icon)
                        put("temp", h.temp)
                    }
                )
            }
            put("hourlyForecast", hArr)

            val dArr = JSONArray()
            for (d in r.dailyForecast) {
                dArr.put(
                    JSONObject().apply {
                        put("dayName", d.dayName)
                        put("dateStr", d.dateStr)
                        put("icon", d.icon)
                        put("condition", d.condition)
                        put("minTemp", d.minTemp)
                        put("maxTemp", d.maxTemp)
                        put("humidity", d.humidity)
                        put("windSpeed", d.windSpeed)
                        put("uvIndex", d.uvIndex)
                        put("airQuality", d.airQuality)
                        put("rainProbability", d.rainProbability)
                    }
                )
            }
            put("dailyForecast", dArr)
        }
        return root.toString()
    }

    private fun parseWeatherResultFromJson(jsonStr: String): WeatherResult? {
        return try {
            val root = JSONObject(jsonStr)
            val hArr = root.optJSONArray("hourlyForecast") ?: return null
            val dArr = root.optJSONArray("dailyForecast") ?: return null

            val hourly = buildList {
                for (i in 0 until hArr.length()) {
                    val o = hArr.optJSONObject(i) ?: continue
                    add(
                        HourlySlot(
                            hourLabel = o.optString("hourLabel", "--:00"),
                            icon = o.optString("icon", "☀️"),
                            temp = o.optString("temp", "--°C")
                        )
                    )
                }
            }
            val daily = buildList {
                for (i in 0 until dArr.length()) {
                    val o = dArr.optJSONObject(i) ?: continue
                    val dIcon = o.optString("icon", "☀️")
                    val dCond = o.optString("condition", "")
                    val dHum = o.optInt("humidity", 75)
                    add(
                        DailySlot(
                            dayName = o.optString("dayName", ""),
                            dateStr = o.optString("dateStr", ""),
                            icon = dIcon,
                            condition = dCond,
                            minTemp = o.optInt("minTemp", 20),
                            maxTemp = o.optInt("maxTemp", 30),
                            humidity = dHum,
                            windSpeed = o.optInt("windSpeed", 10),
                            uvIndex = o.optString("uvIndex", "5"),
                            airQuality = o.optString("airQuality", "Tốt"),
                            rainProbability = o.optInt("rainProbability", estimateRainProbability(dIcon, dCond, dHum))
                        )
                    )
                }
            }
            if (hourly.isEmpty() || daily.isEmpty()) return null

            val curIcon = root.optString("icon", "☀️")
            val curCond = root.optString("condition", "")
            val curHum = root.optInt("humidity", 75)
            WeatherResult(
                fullLocation = root.optString("fullLocation", ""),
                currentTemp = root.optInt("currentTemp", 26),
                tempDisplay = root.optString("tempDisplay", "☀️ 26°C"),
                condition = curCond,
                icon = curIcon,
                humidity = curHum,
                windSpeed = root.optInt("windSpeed", 10),
                uvIndex = root.optString("uvIndex", "5"),
                airQuality = root.optString("airQuality", "Tốt"),
                hourlyForecast = hourly,
                dailyForecast = daily,
                isLiveData = root.optBoolean("isLiveData", false),
                sourceLabel = root.optString("sourceLabel", "Đã lưu"),
                updatedAtMillis = root.optLong("updatedAtMillis", 0L),
                lat = root.optDouble("lat", 0.0),
                lon = root.optDouble("lon", 0.0),
                rainProbability = root.optInt("rainProbability", estimateRainProbability(curIcon, curCond, curHum))
            )
        } catch (_: Throwable) {
            null
        }
    }

    private fun formatUvIndex(uv: Double, isDay: Boolean): String {
        if (!isDay) return "0 (Ban đêm)"
        val r = uv.roundToInt().coerceAtLeast(0)
        return when {
            r <= 2 -> "$r (Thấp)"
            r <= 5 -> "$r (Trung bình)"
            r <= 7 -> "$r (Cao)"
            r <= 10 -> "$r (Rất cao)"
            else -> "$r (Cực đại)"
        }
    }

    private fun decodeWmoWeather(code: Int, isDay: Boolean): Pair<String, String> {
        return when (code) {
            0 -> (if (isDay) "☀️" else "🌙") to (if (isDay) "Trời quang, nắng đẹp" else "Đêm quang mây, thoáng đãng")
            1 -> (if (isDay) "🌤️" else "🌙") to (if (isDay) "Nắng ráo, ít mây" else "Đêm ít mây, dịu mát")
            2 -> (if (isDay) "⛅" else "☁️") to "Có mây rải rác, dịu mát"
            3 -> "☁️" to "Nhiều mây, mát mẻ"
            45, 48 -> "🌫️" to "Có sương mù"
            51, 53, 55, 56, 57 -> "🌧️" to "Mưa phùn nhẹ"
            61, 63, 66 -> "🌧️" to "Mưa rào nhẹ"
            65, 67 -> "🌧️" to "Mưa vừa đến mưa to"
            80, 81, 82 -> (if (isDay) "🌦️" else "🌧️") to "Mưa rào rải rác"
            95, 96, 99 -> "⛈️" to "Có mưa dông"
            else -> (if (isDay) "☀️" else "🌙") to (if (isDay) "Nắng đẹp, thoáng đãng" else "Đêm mát mẻ")
        }
    }

    private fun decodeMetSymbol(symbolCode: String, isDay: Boolean): Pair<String, String> {
        val s = symbolCode.lowercase()
        return when {
            s.contains("thunder") -> "⛈️" to "Có mưa dông"
            s.contains("heavyrain") -> "🌧️" to "Mưa to"
            s.contains("rainshowers") -> (if (isDay) "🌦️" else "🌧️") to "Mưa rào rải rác"
            s.contains("lightrain") -> "🌧️" to "Mưa nhẹ"
            s.contains("rain") || s.contains("sleet") -> "🌧️" to "Có mưa"
            s.contains("fog") -> "🌫️" to "Có sương mù"
            s.contains("cloudy") && !s.contains("partly") -> "☁️" to "Nhiều mây, mát mẻ"
            s.contains("partlycloudy") -> (if (isDay) "⛅" else "☁️") to "Có mây rải rác"
            s.contains("fair") -> (if (isDay) "🌤️" else "🌙") to (if (isDay) "Nắng ráo, ít mây" else "Đêm ít mây")
            s.contains("clearsky") -> (if (isDay) "☀️" else "🌙") to (if (isDay) "Trời quang, nắng đẹp" else "Đêm quang đãng")
            else -> (if (isDay) "☀️" else "🌙") to (if (isDay) "Nắng đẹp" else "Đêm mát")
        }
    }

    private fun decodeWwoCode(code: Int, isDay: Boolean): Pair<String, String> {
        return when (code) {
            113 -> (if (isDay) "☀️" else "🌙") to (if (isDay) "Trời quang, nắng đẹp" else "Đêm quang mây")
            116 -> (if (isDay) "⛅" else "☁️") to "Có mây rải rác"
            119, 122 -> "☁️" to "Nhiều mây, mát mẻ"
            143, 248, 260 -> "🌫️" to "Có sương mù"
            176, 263, 266, 293, 296, 353 -> "🌧️" to "Mưa nhẹ rải rác"
            299, 302, 305, 308, 356, 359 -> "🌧️" to "Mưa rào vừa đến to"
            200, 386, 389, 392, 395 -> "⛈️" to "Có mưa dông"
            else -> (if (isDay) "🌤️" else "🌙") to "Thời tiết ôn hòa"
        }
    }
}
