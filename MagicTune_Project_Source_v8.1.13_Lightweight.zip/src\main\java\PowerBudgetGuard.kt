package com.example.core.perf

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.SystemClock
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * PowerBudgetGuard (Bộ Giám Sát Trần Năng Lượng & Kill Switch Cứng):
 * Khống chế mức tiêu thụ điện năng của MagicTune dưới ngưỡng khắt khe < 50 mAh/giờ
 * trên viên pin 7200 mAh của Honor GT Pro và mọi dòng máy Android.
 *
 * Chiến lược 3 tầng bảo vệ tự động (Triple-Tier Hard Ceiling Guard):
 * - Tầng 1 (An toàn < 40 mAh/h): Hoạt động bình thường ở chế độ Smart Balanced.
 * - Tầng 2 (Cảnh báo 40 - 50 mAh/h): Bật Throttling: Giãn cooldown mạng dịch lên 10-15s,
 *   bỏ qua 50% khung hình OCR cuộn, giảm tần suất ticker để hạ nhiệt.
 * - Tầng 3 (Chạm trần >= 50 mAh/h): Kích hoạt KILL SWITCH khẩn cấp:
 *   Chuyển ngay sang ULTRA_LOW_POWER, dừng triệt để các vòng lặp hoạt ảnh,
 *   giải phóng ML Kit OCR khỏi RAM/GPU, ép True OLED Black #000000.
 */
object PowerBudgetGuard {

    private const val TAG = "PowerBudgetGuard"
    private const val PREFS_NAME = "magictune_power_budget_guard_prefs"

    const val MAX_HARD_BUDGET_MAH_PER_HOUR = 50.0  // Trần tối đa không được vượt qua
    const val WARNING_BUDGET_MAH_PER_HOUR = 40.0   // Ngưỡng cảnh báo bắt đầu tiết lưu
    const val SAFE_RELAX_MAH_PER_HOUR = 28.0       // Ngưỡng an toàn phục hồi trạng thái

    const val DEFAULT_DEVICE_BATTERY_CAPACITY_MAH = 7200.0 // Chuẩn pin Honor GT Pro

    @Volatile
    private var isThrottlingActive: Boolean = false

    @Volatile
    private var isKillSwitchActive: Boolean = false

    @Volatile
    private var lastRecordedDrainRateMah: Double = 18.5 // Mặc định an toàn lúc mới khởi động

    @Volatile
    private var lastSampleElapsedMs: Long = 0L

    @Volatile
    private var lastBatteryLevel: Int = -1

    private val guardScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    data class BudgetStatus(
        val drainRateMahPerHour: Double,
        val isThrottled: Boolean,
        val isKillSwitchEngaged: Boolean,
        val budgetHealthLabel: String,
        val safetyMarginMah: Double
    )

    fun isThrottleActive(): Boolean = isThrottlingActive

    fun isKillSwitchTriggered(): Boolean = isKillSwitchActive

    fun getLastRecordedDrainRate(): Double = lastRecordedDrainRateMah

    /**
     * Đo lường tiêu thụ điện năng thực tế qua BatteryManager và đánh giá ngân sách pin:
     */
    fun evaluateAndEnforceBudget(context: Context): BudgetStatus {
        val appCtx = context.applicationContext ?: context
        val bm = appCtx.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            ?: return BudgetStatus(lastRecordedDrainRateMah, isThrottlingActive, isKillSwitchActive, "Bình thường", MAX_HARD_BUDGET_MAH_PER_HOUR - lastRecordedDrainRateMah)

        val nowElapsed = SystemClock.elapsedRealtime()

        // 1. Đọc dòng điện tức thời (Microamps -> Milliamps)
        var instantMa = 0.0
        try {
            val microAmps = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
            if (microAmps != Int.MIN_VALUE && microAmps != 0) {
                // Trên một số thiết bị giá trị âm là đang xả, dương là sạc
                instantMa = kotlin.math.abs(microAmps) / 1000.0
            } else {
                val avgMicroAmps = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE)
                if (avgMicroAmps != Int.MIN_VALUE && avgMicroAmps != 0) {
                    instantMa = kotlin.math.abs(avgMicroAmps) / 1000.0
                }
            }
        } catch (_: Throwable) {}

        // 2. Đọc mức pin hiện tại để tính độ sụt áp theo cửa sổ thời gian
        val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val bIntent = appCtx.registerReceiver(null, ifilter)
        val level = bIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val isCharging = bIntent?.let {
            val status = it.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        } ?: false

        var calculatedDrainRate = lastRecordedDrainRateMah

        if (!isCharging && level in 0..100) {
            if (lastBatteryLevel != -1 && lastSampleElapsedMs > 0L) {
                val dtMs = nowElapsed - lastSampleElapsedMs
                if (dtMs >= 60_000L) { // Tối thiểu lấy mẫu 1 phút để tránh nhiễu
                    val deltaPct = (lastBatteryLevel - level).coerceAtLeast(0)
                    val dtHours = dtMs / 3_600_000.0
                    val rateFromDrop = (deltaPct.toDouble() / scale.toDouble()) * DEFAULT_DEVICE_BATTERY_CAPACITY_MAH / dtHours

                    calculatedDrainRate = if (instantMa in 5.0..800.0) {
                        // Lọc thông dải kết hợp giữa dòng tức thời và tốc độ sụt pin
                        (rateFromDrop * 0.4) + (instantMa * 0.6)
                    } else {
                        rateFromDrop
                    }.coerceIn(5.0, 300.0)
                }
            }
            lastBatteryLevel = level
            lastSampleElapsedMs = nowElapsed
        }

        lastRecordedDrainRateMah = calculatedDrainRate

        // 3. Cơ Chế Điều Phối Cắt Ngưỡng (Hard Cutoff Enforcement)
        if (calculatedDrainRate >= MAX_HARD_BUDGET_MAH_PER_HOUR) {
            // TẦNG 3: VƯỢT TRẦN 50 mAh/h -> KÍCH HOẠT KILL SWITCH CỨNG
            if (!isKillSwitchActive) {
                Log.w(TAG, "🚨 CẢNH BÁO: Dòng xả chạm trần ${calculatedDrainRate.toInt()} mAh/h (> 50 mAh/h). Kích hoạt Kill Switch!")
            }
            isKillSwitchActive = true
            isThrottlingActive = true

            // Chuyển Governor sang chế độ siêu tiết kiệm năng lượng
            guardScope.launch {
                try {
                    MagicTuneSelfPowerGovernor.setSelfPowerMode(appCtx, MagicTuneSelfPowerGovernor.SelfPowerMode.ULTRA_LOW_POWER)
                    ScreenPowerOptimizer.applyFullHonorDisplayOptimization(appCtx)
                    com.example.core.ocr.ScreenOcrEngine.releaseIdleResources()
                } catch (_: Throwable) {}
            }
        } else if (calculatedDrainRate >= WARNING_BUDGET_MAH_PER_HOUR) {
            // TẦNG 2: TIỆM CẬN TRẦN (40 - 50 mAh/h) -> BẬT TIẾT LƯU THROTTLE
            isThrottlingActive = true
            isKillSwitchActive = false
        } else if (calculatedDrainRate <= SAFE_RELAX_MAH_PER_HOUR) {
            // TẦNG 1: DƯỚI 28 mAh/h -> PHỤC HỒI HOÀN TOÀN BÌNH THƯỜNG
            isThrottlingActive = false
            isKillSwitchActive = false
        }

        val safetyMargin = (MAX_HARD_BUDGET_MAH_PER_HOUR - calculatedDrainRate).coerceAtLeast(0.0)
        val healthLabel = when {
            isKillSwitchActive -> "🚨 Chạm trần - Đang bật Kill Switch"
            isThrottlingActive -> "⚠️ Tiệm cận trần - Đang tiết lưu"
            calculatedDrainRate <= 25.0 -> "🟢 Xuất sắc (<25 mAh/h)"
            else -> "🌿 An toàn (<50 mAh/h)"
        }

        return BudgetStatus(
            drainRateMahPerHour = calculatedDrainRate,
            isThrottled = isThrottlingActive,
            isKillSwitchEngaged = isKillSwitchActive,
            budgetHealthLabel = healthLabel,
            safetyMarginMah = safetyMargin
        )
    }

    /**
     * Kiểm tra trạng thái pin có dưới 20% hay không để kích hoạt Ultra Low Power
     */
    fun isBatteryBelowEmergencyThreshold(context: Context): Boolean {
        return try {
            val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val bIntent = context.registerReceiver(null, ifilter)
            val level = bIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            level in 0..19
        } catch (_: Throwable) {
            false
        }
    }
}
