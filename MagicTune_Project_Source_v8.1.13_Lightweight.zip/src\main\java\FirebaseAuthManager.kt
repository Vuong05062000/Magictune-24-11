package com.example.core.auth

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.compose.runtime.Immutable
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.core.license.LicenseManager
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FieldPath
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.firestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield

object TimeFormatUtils {
    private val tlTimeFormat = ThreadLocal.withInitial { java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()) }
    private val tlDateFormat = ThreadLocal.withInitial { java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()) }
    private val tlDayMonthFormat = ThreadLocal.withInitial { java.text.SimpleDateFormat("dd/MM", java.util.Locale.getDefault()) }
    internal val tlCreatedAtFormat = ThreadLocal.withInitial { java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()) }
    internal val tlProAtFormat = ThreadLocal.withInitial { java.text.SimpleDateFormat("HH:mm:ss - dd/MM/yyyy", java.util.Locale.getDefault()) }
    internal val tlIntentTimeFormat = ThreadLocal.withInitial { java.text.SimpleDateFormat("HH:mm:ss dd/MM/yyyy", java.util.Locale.getDefault()) }
    internal val tlRestIsoUtcFormat = ThreadLocal.withInitial {
        java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }
    }

    /**
     * Định dạng thời gian online cuối theo ngày thực tế (Real-Calendar Date Comparison):
     * - Xác định chính xác ngày hôm nay (ngày, tháng, năm) theo múi giờ thiết bị hiện tại.
     * - Nếu cùng ngày lịch với ngày hôm nay:
     *   + Dưới 3 phút: "🟢 Vừa online tức thì"
     *   + Dưới 60 phút: "🟢 Online X phút trước"
     *   + Còn lại trong ngày: "🟡 Online lúc HH:mm hôm nay (dd/MM)"
     * - Nếu rơi vào ngày hôm qua (dù cách dưới 24h, ví dụ 23:00 hôm 29 và 08:00 hôm 30):
     *   + Hiển thị chính xác: "⚪ Hôm qua (dd/MM) lúc HH:mm" (tuyệt đối không bị nhầm là hôm nay)
     * - Nếu trước ngày hôm qua:
     *   + Hiển thị đầy đủ ngày/tháng/năm và giờ: "⚪ dd/MM/yyyy lúc HH:mm"
     */
    fun formatLastActive(timestamp: com.google.firebase.Timestamp?): String {
        val date = timestamp?.toDate() ?: return "Chưa rõ thời gian"
        val now = java.util.Date()

        val timeFormat = tlTimeFormat.get() ?: java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
        val dateFormat = tlDateFormat.get() ?: java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault())
        val dayMonthFormat = tlDayMonthFormat.get() ?: java.text.SimpleDateFormat("dd/MM", java.util.Locale.getDefault())

        val diffMillis = now.time - date.time
        val diffMinutes = (diffMillis / (60 * 1000)).coerceAtLeast(0)

        val calNow = java.util.Calendar.getInstance().apply { time = now }
        val calDate = java.util.Calendar.getInstance().apply { time = date }

        val isSameYear = calNow.get(java.util.Calendar.YEAR) == calDate.get(java.util.Calendar.YEAR)
        val isSameDay = isSameYear && calNow.get(java.util.Calendar.DAY_OF_YEAR) == calDate.get(java.util.Calendar.DAY_OF_YEAR)

        val calYesterday = java.util.Calendar.getInstance().apply {
            time = now
            add(java.util.Calendar.DAY_OF_YEAR, -1)
        }
        val isYesterday = calYesterday.get(java.util.Calendar.YEAR) == calDate.get(java.util.Calendar.YEAR) &&
            calYesterday.get(java.util.Calendar.DAY_OF_YEAR) == calDate.get(java.util.Calendar.DAY_OF_YEAR)

        return when {
            isSameDay && diffMinutes < 3 -> "🟢 Vừa online tức thì"
            isSameDay && diffMinutes < 60 -> "🟢 Online $diffMinutes phút trước"
            isSameDay -> "🟡 Online lúc ${timeFormat.format(date)} hôm nay (${dayMonthFormat.format(date)})"
            isYesterday -> "⚪ Hôm qua (${dayMonthFormat.format(date)}) lúc ${timeFormat.format(date)}"
            else -> "⚪ ${dateFormat.format(date)} lúc ${timeFormat.format(date)}"
        }
    }
}

@Immutable
@IgnoreExtraProperties
data class UserProfile(
    val userId: String = "",
    val email: String = "",
    val phoneNumber: String = "",
    val displayName: String = "",
    val role: String = "user", // "admin" hoặc "user"
    val isPro: Boolean = false,
    val isAccountPro: Boolean = false,
    val proTier: String = "FREE", // "ACCOUNT_PRO", "DEVICE_PRO", "FREE"
    val deviceId: String = "",
    val hardwareId: String = "",
    val activeDeviceId: String = "",
    val activeDeviceModel: String = "",
    val activeSessionToken: String = "",
    val licenseKey: String = "",
    val proActivatedSource: String = "",
    val bankTransCode: String = "",
    val revokedByAdmin: Boolean = false,
    val proActivatedAt: com.google.firebase.Timestamp? = null,
    val lastActive: com.google.firebase.Timestamp? = null,
    val createdAt: com.google.firebase.Timestamp? = null,
    val customGeminiKey: String = "",
    val customGroqKey: String = "",
    val customAiKeyRaw: String = "",
    val customAiKeyUpdatedAt: com.google.firebase.Timestamp? = null
) {
    fun hasPersonalAiKey(): Boolean {
        return customGeminiKey.isNotBlank() || customGroqKey.isNotBlank() || customAiKeyRaw.isNotBlank()
    }

    fun getPersonalGeminiKeysList(): List<String> {
        val src = "$customGeminiKey $customAiKeyRaw"
        return src.split(Regex("[\\s,;]+"))
            .map { it.trim() }
            .filter { it.startsWith("AIza") && it.length >= 16 }
            .distinct()
    }

    fun getPersonalGroqKeysList(): List<String> {
        val src = "$customGroqKey $customAiKeyRaw"
        return src.split(Regex("[\\s,;]+"))
            .map { it.trim() }
            .filter { (it.startsWith("gsk_") || (!it.startsWith("AIza") && it.length >= 20)) && it != "null" }
            .distinct()
    }

    fun getAllPersonalKeysCombined(): String {
        return (getPersonalGeminiKeysList() + getPersonalGroqKeysList()).distinct().joinToString(" ")
    }

    fun getLastActiveFormatted(): String = TimeFormatUtils.formatLastActive(lastActive)

    fun getCreatedAtFormatted(): String {
        val timestamp = createdAt ?: return "Mới tham gia"
        return (TimeFormatUtils.tlCreatedAtFormat.get() ?: java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault())).format(timestamp.toDate())
    }

    fun getProActivatedAtFormatted(): String {
        val ts = proActivatedAt ?: return ""
        return (TimeFormatUtils.tlProAtFormat.get() ?: java.text.SimpleDateFormat("HH:mm dd/MM/yyyy", java.util.Locale.getDefault())).format(ts.toDate())
    }

    fun getProSourceFormatted(): String {
        val src = proActivatedSource.trim()
        return when {
            src.startsWith("AI_AUTO_VISION_BILL:") -> "🤖 AI Duyệt Bill (${src.substringAfter("AI_AUTO_VISION_BILL:")})"
            src.contains("ADMIN_MANUAL_GRANT") -> "👑 Admin cấp trực tiếp"
            src.contains("ADMIN_KEY_GENERATED") -> "🔑 Admin tạo Key"
            src.contains("ADMIN_LOGIN") -> "👑 Đặc quyền Admin"
            src.isNotBlank() -> src
            bankTransCode.isNotBlank() -> "🏦 Mã GD: $bankTransCode"
            else -> "Chưa ghi nhận nguồn duyệt"
        }
    }
}

@Immutable
@IgnoreExtraProperties
data class DeviceRecord(
    val deviceId: String = "",
    val hardwareId: String = "",
    val model: String = "",
    val isPro: Boolean = false,
    val isAccountPro: Boolean = false,
    val upgradedToAccountPro: Boolean = false,
    val proTier: String = "FREE",
    val revokedByAdmin: Boolean = false,
    val ownerUid: String = "",
    val ownerEmail: String = "",
    val ownerName: String = "",
    val freeTrialUsed: Int = 0,
    val licenseKey: String = "",
    val approvedByAiReason: String = "",
    val bankTransCode: String = "",
    val lastActive: com.google.firebase.Timestamp? = null,
    val createdAt: com.google.firebase.Timestamp? = null,
    val proActivatedAt: com.google.firebase.Timestamp? = null,
    val customGeminiKey: String = "",
    val customGroqKey: String = "",
    val customAiKeyRaw: String = "",
    val customAiKeyUpdatedAt: com.google.firebase.Timestamp? = null
) {
    fun hasPersonalAiKey(): Boolean {
        return customGeminiKey.isNotBlank() || customGroqKey.isNotBlank() || customAiKeyRaw.isNotBlank()
    }

    fun getPersonalGeminiKeysList(): List<String> {
        val src = "$customGeminiKey $customAiKeyRaw"
        return src.split(Regex("[\\s,;]+"))
            .map { it.trim() }
            .filter { it.startsWith("AIza") && it.length >= 16 }
            .distinct()
    }

    fun getPersonalGroqKeysList(): List<String> {
        val src = "$customGroqKey $customAiKeyRaw"
        return src.split(Regex("[\\s,;]+"))
            .map { it.trim() }
            .filter { (it.startsWith("gsk_") || (!it.startsWith("AIza") && it.length >= 20)) && it != "null" }
            .distinct()
    }

    fun getAllPersonalKeysCombined(): String {
        return (getPersonalGeminiKeysList() + getPersonalGroqKeysList()).distinct().joinToString(" ")
    }

    fun getLastActiveFormatted(): String = TimeFormatUtils.formatLastActive(lastActive)

    fun getCreatedAtFormatted(): String {
        val timestamp = createdAt ?: return "Vừa thêm"
        return (TimeFormatUtils.tlCreatedAtFormat.get() ?: java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault())).format(timestamp.toDate())
    }

    fun getProActivatedAtFormatted(): String {
        val timestamp = proActivatedAt ?: return ""
        return (TimeFormatUtils.tlProAtFormat.get() ?: java.text.SimpleDateFormat("HH:mm dd/MM/yyyy", java.util.Locale.getDefault())).format(timestamp.toDate())
    }

    fun getProSourceFormatted(): String {
        val src = approvedByAiReason.trim()
        return when {
            src.startsWith("AI_AUTO_VISION_BILL:") -> "🤖 AI Duyệt Bill (${src.substringAfter("AI_AUTO_VISION_BILL:")})"
            src.contains("ADMIN_MANUAL_GRANT") -> "👑 Admin cấp trực tiếp"
            src.contains("ADMIN_KEY_GENERATED") -> "🔑 Admin tạo Key"
            src.contains("ADMIN_LOGIN") -> "👑 Đặc quyền Admin"
            src.isNotBlank() -> src
            bankTransCode.isNotBlank() -> "🏦 Mã GD: $bankTransCode"
            else -> "Chưa rõ nguồn duyệt"
        }
    }
}

@IgnoreExtraProperties
data class PaymentIntentRecord(
    val intentId: String = "",
    val deviceId: String = "",
    val model: String = "",
    val ownerEmail: String = "",
    val ownerName: String = "",
    val actionType: String = "",
    val details: String = "",
    val note: String = "",
    val isPro: Boolean = false,
    val timestamp: com.google.firebase.Timestamp? = null
) {
    fun getTimestampFormatted(): String {
        return try {
            val ts = timestamp ?: return "Vừa xong"
            (TimeFormatUtils.tlIntentTimeFormat.get() ?: java.text.SimpleDateFormat("HH:mm:ss dd/MM/yyyy", java.util.Locale.getDefault())).format(ts.toDate())
        } catch (_: Throwable) {
            "Vừa xong"
        }
    }
}

data class AdminListPage<T>(
    val items: List<T>,
    val hasMore: Boolean
)

object FirebaseAuthManager {

    private const val TAG = "FirebaseAuthManager"
    private val INITIAL_ADMIN_EMAIL: String
        get() = runCatching { com.example.BuildConfig.ADMIN_EMAIL }.getOrNull()?.ifBlank { null } ?: "vuongdhkmhn@gmail.com"
    private val INITIAL_ADMIN_EMAIL_ALT: String
        get() = runCatching { com.example.BuildConfig.ADMIN_EMAIL }.getOrNull()?.ifBlank { null } ?: "vuongdhkmhn@gmail.com"
    private val INITIAL_ADMIN_PHONE: String
        get() = runCatching { com.example.BuildConfig.ADMIN_PHONE }.getOrNull()?.ifBlank { null } ?: "0393368007"
    const val ACTION_SINGLE_DEVICE_KICKED = "com.example.core.auth.ACTION_SINGLE_DEVICE_KICKED"

    @androidx.compose.runtime.Immutable
    data class AuthSessionSnapshot(
        val isLoggedIn: Boolean = false,
        val uid: String = "",
        val email: String = "",
        val displayName: String = "",
        val role: String = "user",
        val isAdmin: Boolean = false,
        val isInitialized: Boolean = false
    )

    private const val KEY_CACHED_AUTH_LOGGED_IN = "cached_auth_logged_in"
    private const val KEY_CACHED_AUTH_UID = "cached_auth_uid"
    private const val KEY_CACHED_AUTH_EMAIL = "cached_auth_email"
    private const val KEY_CACHED_AUTH_NAME = "cached_auth_display_name"

    private val _authSessionFlow = MutableStateFlow(AuthSessionSnapshot())
    val authSessionFlow: StateFlow<AuthSessionSnapshot> = _authSessionFlow.asStateFlow()

    @Volatile
    private var centralAuthObserverRegistered: Boolean = false
    @Volatile
    private var cachedUserProfile: UserProfile? = null
    @Volatile
    private var cachedUserProfileUid: String = ""
    @Volatile
    private var lastSyncedUserProfileMs: Long = 0L
    @Volatile
    // Mốc thời gian khởi động app để chặn phát "null auth" trong cửa sổ Firebase Auth init (8 giây đầu)
    private var appStartTimeMs: Long = System.currentTimeMillis()

    private var singleDeviceListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var watchedUserId: String? = null
    private var authStateListenerInitialized = false
    @Volatile
    private var isSyncingProfileOnLogin: Boolean = false
    @Volatile
    private var lastLoginTimestampMs: Long = 0L
    @Volatile
    private var lastTokenRefreshMs: Long = 0L
    private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
    internal val adminSnapshotExecutor: java.util.concurrent.ExecutorService =
        java.util.concurrent.Executors.newSingleThreadExecutor { r ->
            Thread(r, "MagicTuneAdminSnapshotThread").apply { isDaemon = true }
        }

    private class AdminPageCursor {
        val mutex = Mutex()
        @Volatile var initialized: Boolean = false
        @Volatile var lastDocumentId: String? = null
        @Volatile var exhausted: Boolean = false
    }

    private const val ADMIN_LIST_PAGE_SIZE = 150L
    private val adminUsersPageCursor = AdminPageCursor()
    private val adminDevicesPageCursor = AdminPageCursor()
    private val adminProDevicesPageCursor = AdminPageCursor()

    /**
     * Khởi tạo trạng thái đăng nhập tức thì 0ms từ SharedPreferences khi mở app,
     * tránh việc UI chớp "Đăng Nhập" -> "Tài Khoản" hay phải chờ FirebaseAuth đọc đĩa ở Main Thread.
     */
    fun initAuthSessionFromCache(context: Context) {
        try {
            val appCtx = context.applicationContext ?: context
            val prefs = appCtx.getSharedPreferences("magictune_pro_prefs", Context.MODE_PRIVATE)
            val cachedUid = (prefs.getString(KEY_CACHED_AUTH_UID, "") ?: "").trim()
            val cachedEmail = (prefs.getString(KEY_CACHED_AUTH_EMAIL, null)
                ?: prefs.getString("current_user_email", "")
                ?: "").trim()
            val cachedName = (prefs.getString(KEY_CACHED_AUTH_NAME, "") ?: "").trim()
            val cachedRole = (prefs.getString("current_user_role", "user") ?: "user").trim()
            val hasExplicitFlag = prefs.contains(KEY_CACHED_AUTH_LOGGED_IN)
            val cachedLoggedIn = if (hasExplicitFlag) {
                prefs.getBoolean(KEY_CACHED_AUTH_LOGGED_IN, false) || cachedEmail.isNotBlank()
            } else {
                cachedUid.isNotBlank() || cachedEmail.isNotBlank()
            }
            val effectiveLoggedIn = cachedLoggedIn && (cachedUid.isNotBlank() || cachedEmail.isNotBlank())
            val adminByCache = effectiveLoggedIn && (
                cachedEmail.equals(INITIAL_ADMIN_EMAIL, ignoreCase = true) ||
                    cachedEmail.equals(INITIAL_ADMIN_EMAIL_ALT, ignoreCase = true) ||
                    cachedRole.equals("admin", ignoreCase = true) ||
                    LicenseManager.isCurrentUserAdmin(appCtx)
                )
            _authSessionFlow.value = AuthSessionSnapshot(
                isLoggedIn = effectiveLoggedIn,
                uid = if (effectiveLoggedIn) cachedUid else "",
                email = if (effectiveLoggedIn) cachedEmail else "",
                displayName = if (effectiveLoggedIn) cachedName else "",
                role = if (adminByCache) "admin" else cachedRole.ifBlank { "user" },
                isAdmin = adminByCache,
                isInitialized = true
            )
        } catch (_: Throwable) {}
    }

    /**
     * Đồng bộ tức thì trạng thái đăng nhập thực tế từ Firebase.auth.currentUser và bộ nhớ đệm vào authSessionFlow.
     * Đảm bảo Header Menu (Tài Khoản / Quản Trị / Terminal Shell) luôn khớp 100% với trang Tài Khoản.
     */
    fun refreshAuthSessionNow(context: Context): AuthSessionSnapshot {
        val appCtx = context.applicationContext ?: context
        try {
            ensureFirebaseInitialized(appCtx)
            val user = getCurrentUser()
            if (user != null) {
                persistAndEmitAuthSession(appCtx, user)
                return _authSessionFlow.value
            }
        } catch (_: Throwable) {}
        return _authSessionFlow.value
    }

    internal fun persistAndEmitAuthSession(context: Context, user: FirebaseUser?, explicitRole: String? = null) {
        try {
            val appCtx = context.applicationContext
            val prefs = appCtx.getSharedPreferences("magictune_pro_prefs", Context.MODE_PRIVATE)
            if (user != null && !user.isAnonymous) {
                val email = (user.email ?: "").trim()
                val name = (user.displayName ?: "").trim().ifBlank {
                    if (email.contains("@")) email.substringBefore("@") else "Thành Viên MagicTune"
                }
                val savedRole = (explicitRole ?: prefs.getString("current_user_role", "user") ?: "user").trim()
                val isAdmin = email.equals(INITIAL_ADMIN_EMAIL, ignoreCase = true) ||
                    email.equals(INITIAL_ADMIN_EMAIL_ALT, ignoreCase = true) ||
                    (user.phoneNumber ?: "").contains(INITIAL_ADMIN_PHONE) ||
                    savedRole.equals("admin", ignoreCase = true) ||
                    LicenseManager.isCurrentUserAdmin(appCtx)
                val roleToKeep = if (isAdmin) "admin" else savedRole.ifBlank { "user" }
                prefs.edit()
                    .putBoolean(KEY_CACHED_AUTH_LOGGED_IN, true)
                    .putString(KEY_CACHED_AUTH_UID, user.uid)
                    .putString(KEY_CACHED_AUTH_EMAIL, email)
                    .putString(KEY_CACHED_AUTH_NAME, name)
                    .putString("current_user_email", email)
                    .putString("current_user_role", roleToKeep)
                    .apply()
                _authSessionFlow.value = AuthSessionSnapshot(
                    isLoggedIn = true,
                    uid = user.uid,
                    email = email,
                    displayName = name,
                    role = roleToKeep,
                    isAdmin = isAdmin,
                    isInitialized = true
                )
            } else {
                // ⚠️ QUAN TRỌNG: Chỉ xoá phiên khi người dùng thực sự đăng xuất (signOut())
                // TUYỆT ĐỐI KHÔNG xoá phiên khi Firebase Auth đang tải token từ đĩa (1-3 giây sau khởi động)
                // Dấu hiệu: authStateFlow đang có email hợp lệ nhưng Firebase trả null tạm thời
                val currentSnapshot = _authSessionFlow.value
                val hasValidCachedSession = currentSnapshot.isLoggedIn && currentSnapshot.email.isNotBlank()
                val nowMs = System.currentTimeMillis()
                val isWithinStartupWindow = (nowMs - appStartTimeMs) < 8_000L  // 8 giây đầu khởi động
                
                if (hasValidCachedSession && isWithinStartupWindow) {
                    // Firebase Auth đang tải token từ đĩa - giữ nguyên trạng thái cache, 
                    // KHÔNG phát tín hiệu "đăng xuất" lên UI để tránh giật/flash màn hình
                    android.util.Log.d("FirebaseAuthManager", 
                        "⏳ Firebase Auth init window: giữ session cache (${currentSnapshot.email}) thay vì phát null")
                    return
                }
                
                prefs.edit()
                    .putBoolean(KEY_CACHED_AUTH_LOGGED_IN, false)
                    .remove(KEY_CACHED_AUTH_UID)
                    .remove(KEY_CACHED_AUTH_EMAIL)
                    .remove(KEY_CACHED_AUTH_NAME)
                    .apply()
                cachedUserProfile = null
                cachedUserProfileUid = ""
                lastSyncedUserProfileMs = 0L
                _authSessionFlow.value = AuthSessionSnapshot(
                    isLoggedIn = false,
                    isInitialized = true
                )
            }
        } catch (_: Throwable) {}
    }

    /**
     * Đăng ký DUY NHẤT 1 AuthStateListener trung tâm trên luồng nền IO để đồng bộ authSessionFlow
     * khi FirebaseAuth nạp xong token trên đĩa hoặc khi token thay đổi.
     */
    fun ensureCentralAuthStateObserver(context: Context) {
        val appCtx = context.applicationContext
        if (centralAuthObserverRegistered) return
        centralAuthObserverRegistered = true
        appStartTimeMs = System.currentTimeMillis()
        try {
            ensureFirebaseInitialized(appCtx)
            val current = try { Firebase.auth.currentUser } catch (_: Throwable) { null }
            if (current != null && !current.isAnonymous) {
                persistAndEmitAuthSession(appCtx, current)
            }
            Firebase.auth.addAuthStateListener { firebaseAuth ->
                val user = try { firebaseAuth.currentUser } catch (_: Throwable) { null }
                if (user != null && user.isAnonymous) {
                    try { firebaseAuth.signOut() } catch (_: Throwable) {}
                    persistAndEmitAuthSession(appCtx, null)
                } else {
                    persistAndEmitAuthSession(appCtx, user)
                }
            }
        } catch (_: Throwable) {
            centralAuthObserverRegistered = false
        }
    }

    /**
     * Làm mới token Firebase Auth ngầm trên luồng nền (không block UI).
     * Gọi khi app quay lại màn hình (onResume) sau > 30 phút nền để đảm bảo token không hết hạn.
     * Firebase Auth token có thời hạn 1 giờ — cần refresh chủ động để currentUser không bị null.
     */
    fun refreshFirebaseTokenSilentlyIfNeeded(context: Context) {
        val appCtx = context.applicationContext
        val nowMs = System.currentTimeMillis()
        // Chỉ refresh nếu đã > 30 phút kể từ lần refresh cuối
        if (nowMs - lastTokenRefreshMs < 30 * 60 * 1_000L) return
        lastTokenRefreshMs = nowMs
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                val user = try { Firebase.auth.currentUser } catch (_: Throwable) { null }
                if (user != null && !user.isAnonymous) {
                    // getIdToken(true) sẽ force-refresh token từ Firebase server nếu gần hết hạn
                    // Firebase tự cache token mới vào KeyStore, lần sau getCurrentUser() không bao giờ null
                    try {
                        kotlinx.coroutines.withTimeoutOrNull(8_000L) {
                            user.getIdToken(true).await()
                        }
                    } catch (_: Throwable) {
                        // Thử reload() nếu getIdToken fail (thường do mạng yếu)
                        try {
                            kotlinx.coroutines.withTimeoutOrNull(5_000L) {
                                user.reload().await()
                            }
                        } catch (_: Throwable) {}
                    }
                    // Sau khi refresh thành công, đồng bộ lại authSessionFlow
                    val refreshedUser = try { Firebase.auth.currentUser } catch (_: Throwable) { null }
                    if (refreshedUser != null && !refreshedUser.isAnonymous) {
                        persistAndEmitAuthSession(appCtx, refreshedUser)
                        android.util.Log.d("FirebaseAuthManager", "✅ Token refreshed silently for: ${refreshedUser.email}")
                    }
                } else {
                    // User null: thử init lại từ cache SharedPreferences
                    val prefs = appCtx.getSharedPreferences("magictune_pro_prefs", android.content.Context.MODE_PRIVATE)
                    val cachedEmail = (prefs.getString(KEY_CACHED_AUTH_EMAIL, "") ?: "").trim()
                    val cachedUid = (prefs.getString(KEY_CACHED_AUTH_UID, "") ?: "").trim()
                    if (cachedEmail.isNotBlank() && cachedUid.isNotBlank()) {
                        // Session vẫn còn trong prefs nhưng Firebase chưa load xong → phát lại từ cache
                        android.util.Log.d("FirebaseAuthManager", 
                            "⚡ Firebase user null but cache valid — restoring from SharedPreferences: $cachedEmail")
                        initAuthSessionFromCache(appCtx)
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    private fun extractSessionTimestampMs(token: String): Long {
        return token.substringAfterLast("_", "").toLongOrNull() ?: 0L
    }

    fun ensureFirebaseInitialized(context: Context) {
        try {
            val appCtx = context.applicationContext
            if (com.google.firebase.FirebaseApp.getApps(appCtx).isEmpty()) {
                val defaultApp = try {
                    com.google.firebase.FirebaseApp.initializeApp(appCtx)
                } catch (_: Throwable) { null }
if (defaultApp == null) {
                    // TUYỆT ĐỐI không hardcode Firebase API key/Application ID trong source code
                    // (chúng sẽ lộ trong APK giải mã). Dùng google-services.json (đã có) để Firebase
                    // tự cấu hình; chỉ fallback manual options khi không có config file.
                    val options = com.google.firebase.FirebaseOptions.Builder()
                        .setApplicationId("1:979840451154:android:9bc6d7866b29e90201558b")
                        .setProjectId("phn-mm-ha-n")
                        .setStorageBucket("phn-mm-ha-n.firebasestorage.app")
                        .build()
                    com.google.firebase.FirebaseApp.initializeApp(appCtx, options)
                }
            }
            try {
                if (Firebase.auth.currentUser?.isAnonymous == true) {
                    Firebase.auth.signOut()
                }
            } catch (_: Throwable) {}
        } catch (_: Throwable) {}
    }

    fun getAuth(): FirebaseAuth = Firebase.auth

    fun getDb(): FirebaseFirestore = Firebase.firestore

    /**
     * Khởi chạy bộ gác cổng "1 Tài Khoản - 1 Thiết Bị Duy Nhất" theo thời gian thực (Real-time Single-Device Session Guard):
     * - Khi người dùng đăng nhập tài khoản trên Thiết Bị Mới (Máy B), `activeDeviceId` và `activeSessionToken` trên Firestore `users/{uid}` sẽ đổi sang Máy B.
     * - Thiết Bị Cũ (Máy A) đang lắng nghe `users/{uid}` sẽ phát hiện tức thì `activeDeviceId != localDeviceId` với phiên mới hơn,
     *   tự động Đăng Xuất khỏi Máy A và thu hồi phiên Pro Tài Khoản trên Máy A ngay lập tức!
     */
    @Volatile
    private var isSessionGuardForegroundActive = false

    fun detachSingleDeviceListenerOnBackground() {
        isSessionGuardForegroundActive = false
        try {
            singleDeviceListener?.remove()
        } catch (_: Throwable) {}
        singleDeviceListener = null
        watchedUserId = null
    }

    fun startSingleDeviceSessionGuard(context: Context) {
        val appCtx = context.applicationContext
        ensureFirebaseInitialized(appCtx)
        isSessionGuardForegroundActive = true
        if (!authStateListenerInitialized) {
            authStateListenerInitialized = true
            try {
                Firebase.auth.addAuthStateListener { firebaseAuth ->
                    val current = firebaseAuth.currentUser
                    if (current != null && !current.isAnonymous && isSessionGuardForegroundActive) {
                        attachSingleDeviceListenerForUser(appCtx, current.uid)
                    } else {
                        singleDeviceListener?.remove()
                        singleDeviceListener = null
                        watchedUserId = null
                    }
                }
            } catch (_: Exception) {}
        }

        val currentUser = getCurrentUser()
        if (currentUser != null) {
            attachSingleDeviceListenerForUser(appCtx, currentUser.uid)
        }
    }

    private fun attachSingleDeviceListenerForUser(appCtx: Context, uid: String) {
        if (uid.isBlank()) return
        if (watchedUserId == uid && singleDeviceListener != null) return

        singleDeviceListener?.remove()
        watchedUserId = uid

        try {
            singleDeviceListener = getDb().collection("users").document(uid)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null || !snapshot.exists()) return@addSnapshotListener
                    if (snapshot.metadata.isFromCache) return@addSnapshotListener
                    if (isSyncingProfileOnLogin) return@addSnapshotListener
                    if (System.currentTimeMillis() - lastLoginTimestampMs < 15_000L) return@addSnapshotListener

                    val currentUser = getCurrentUser()
                    if (currentUser == null || currentUser.uid != uid) return@addSnapshotListener

                    val localDeviceId = LicenseManager.getDeviceId(appCtx).trim().uppercase()
                    val remoteActiveDeviceId = (snapshot.getString("activeDeviceId") ?: "").trim().uppercase()
                    val remoteDeviceModel = (snapshot.getString("activeDeviceModel") ?: "Thiết bị mới").trim()
                    val remoteSessionToken = (snapshot.getString("activeSessionToken") ?: "").trim()
                    val remoteRole = (snapshot.getString("role") ?: "").trim()
                    val remoteEmail = (snapshot.getString("email") ?: currentUser.email ?: "").trim()

                    // ĐẶC QUYỀN ADMIN: Tài khoản Admin tuyệt đối KHÔNG BAO GIỜ bị SingleDeviceSessionGuard tự động đá văng / đăng xuất
                    val isAdminUser = remoteEmail.equals(INITIAL_ADMIN_EMAIL, ignoreCase = true) ||
                        remoteEmail.equals(INITIAL_ADMIN_EMAIL_ALT, ignoreCase = true) ||
                        remoteRole.equals("admin", ignoreCase = true) ||
                        LicenseManager.isCurrentUserAdmin(appCtx)

                    if (isAdminUser) {
                        if (remoteEmail.isNotBlank()) {
                            LicenseManager.markLocalAdminVerified(appCtx, remoteEmail)
                        }
                        return@addSnapshotListener
                    }

                    val prefs = appCtx.getSharedPreferences("magictune_pro_prefs", Context.MODE_PRIVATE)
                    val localSessionToken = (prefs.getString(LicenseManager.KEY_ACTIVE_SESSION_TOKEN, "") ?: "").trim()

                    val isDifferentDevice = remoteActiveDeviceId.isNotBlank() &&
                            !LicenseManager.isDeviceIdMatchingCurrentDevice(appCtx, remoteActiveDeviceId)

                    val remoteTs = extractSessionTimestampMs(remoteSessionToken)
                    val localTs = extractSessionTimestampMs(localSessionToken)
                    val isNewerRemoteSession = remoteTs == 0L || localTs == 0L || remoteTs > localTs

                    val kickedByAnotherDevice = isDifferentDevice && isNewerRemoteSession

                    if (kickedByAnotherDevice) {
                        Log.w(TAG, "Phát hiện đăng nhập trên máy mới ($remoteActiveDeviceId - $remoteDeviceModel). Tự động đăng xuất máy cũ ($localDeviceId)!")
                        singleDeviceListener?.remove()
                        singleDeviceListener = null
                        watchedUserId = null

                        try {
                            Firebase.auth.signOut()
                        } catch (_: Exception) {}

                        prefs.edit()
                            .remove("current_user_role")
                            .remove("current_user_email")
                            .remove(LicenseManager.KEY_ACTIVE_SESSION_TOKEN)
                            .apply()
                        persistAndEmitAuthSession(appCtx, null)

                        // Thu hồi quyền Pro Tài Khoản trên máy cũ ngay lập tức khi đăng nhập sang máy khác
                        LicenseManager.revokeAccountProOnDeviceTransfer(appCtx)

                        try {
                            val credentialManager = CredentialManager.create(appCtx)
                            CoroutineScope(Dispatchers.IO).launch {
                                try {
                                    credentialManager.clearCredentialState(ClearCredentialStateRequest())
                                } catch (_: Exception) {}
                            }
                        } catch (_: Exception) {}

                        mainHandler.post {
                            try {
                                android.widget.Toast.makeText(
                                    appCtx,
                                    "⚠️ Tài khoản vừa đăng nhập trên máy mới ($remoteDeviceModel). Máy cũ đã tự động đăng xuất (Quy định 1 máy/tài khoản)!",
                                    android.widget.Toast.LENGTH_LONG
                                ).show()
                                appCtx.sendBroadcast(android.content.Intent(ACTION_SINGLE_DEVICE_KICKED).apply { setPackage(appCtx.packageName) })
                                appCtx.sendBroadcast(android.content.Intent(LicenseManager.ACTION_CONFIG_UPDATED).apply { setPackage(appCtx.packageName) })
                                appCtx.sendBroadcast(android.content.Intent(LicenseManager.ACTION_PRO_ACTIVATED).apply { setPackage(appCtx.packageName) })
                            } catch (_: Exception) {}
                        }
                        return@addSnapshotListener
                    }

                    // Nếu máy hiện tại đang là máy hợp lệ duy nhất và tài khoản có Pro trên Cloud -> Đồng bộ xuống máy ngay
                    val cloudAccountPro = snapshot.getBoolean("isAccountPro") == true ||
                            snapshot.getString("proTier") == "ACCOUNT_PRO"
                    val cloudDevicePro = !cloudAccountPro && (
                        snapshot.getBoolean("isPro") == true ||
                            snapshot.getString("proTier") == "DEVICE_PRO" ||
                            snapshot.getBoolean("magictunePro") == true
                        )
                    val cloudRevoked = snapshot.getBoolean("revokedByAdmin") == true

                    if (cloudRevoked && !LicenseManager.isCurrentUserAdmin(appCtx)) {
                        prefs.edit().remove(LicenseManager.KEY_LAST_NOTIFIED_PRO_APPROVED_TIER).apply()
                        LicenseManager.revokeAccountProOnDeviceTransfer(appCtx)
                    } else if (cloudAccountPro && !LicenseManager.isAccountProActivated(appCtx) && !LicenseManager.isAdminSimulateFreeMode(appCtx)) {
                        val originDevId = (snapshot.getString("deviceId") ?: "").trim().uppercase()
                        val isOriginalMachine = originDevId.isBlank() ||
                            LicenseManager.isDeviceIdMatchingCurrentDevice(appCtx, originDevId) ||
                            LicenseManager.hasOwnDevicePermanentKey(appCtx)
                        LicenseManager.activateAccountPro(
                            appCtx,
                            if (isOriginalMachine) "CLOUD_ACCOUNT_PRO_SYNC" else "SESSION_BORROWED_ACCOUNT_PRO",
                            syncToCloud = false,
                            isBorrowedFromAccountLogin = !isOriginalMachine
                        )
                        LicenseManager.notifyProApprovedIfNeeded(
                            context = appCtx,
                            isAccountPro = true,
                            targetEmail = remoteEmail,
                            deviceId = localDeviceId
                        )
                    } else if (cloudDevicePro && !LicenseManager.isProActivated(appCtx) && !LicenseManager.isAdminSimulateFreeMode(appCtx)) {
                        val originDevId = (snapshot.getString("deviceId") ?: "").trim().uppercase()
                        val actDevId = (snapshot.getString("activeDeviceId") ?: "").trim().uppercase()
                        val matchesThisDevice = originDevId.isBlank() ||
                            LicenseManager.isDeviceIdMatchingCurrentDevice(appCtx, originDevId) ||
                            LicenseManager.isDeviceIdMatchingCurrentDevice(appCtx, actDevId)
                        if (matchesThisDevice) {
                            LicenseManager.applyCloudUserDevicePro(
                                context = appCtx,
                                email = remoteEmail,
                                role = remoteRole
                            )
                        }
                    } else if (!cloudAccountPro && LicenseManager.isAccountProActivated(appCtx)) {
                        // Người dùng đã bị Admin hạ cấp từ ACCOUNT_PRO về DEVICE_PRO hoặc FREE
                        val isStillPro = snapshot.getBoolean("isPro") == true || snapshot.getString("proTier") == "DEVICE_PRO"
                        if (isStillPro) {
                            prefs.edit()
                                .putBoolean(LicenseManager.KEY_ACCOUNT_PRO_ACTIVATED, false)
                                .putBoolean(LicenseManager.KEY_UPGRADED_TO_ACCOUNT_PRO, false)
                                .putBoolean(LicenseManager.KEY_BORROWED_ACCOUNT_PRO_SESSION, false)
                                .putBoolean(LicenseManager.KEY_PRO_ACTIVATED, true)
                                .apply()
                            LicenseManager.writeProIntegritySeal(appCtx, isPro = true, isAccPro = false)
                        } else {
                            prefs.edit().remove(LicenseManager.KEY_LAST_NOTIFIED_PRO_APPROVED_TIER).apply()
                            LicenseManager.revokeAccountProOnDeviceTransfer(appCtx)
                        }
                        LicenseManager.notifyProAndConfigStateChanged(appCtx)
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi khởi tạo SingleDeviceSessionGuard: ${e.message}")
        }
    }

    /**
     * Đọc trường Timestamp an toàn tuyệt đối (Không bao giờ văng lỗi "Field '...' is not a com.google.firebase.Timestamp"
     * kể cả khi dữ liệu cũ trên Firestore lưu dưới dạng số Long/Number, Date hoặc String).
     */
    fun safeGetTimestamp(
        doc: com.google.firebase.firestore.DocumentSnapshot,
        field: String
    ): com.google.firebase.Timestamp? {
        if (!doc.exists()) return null
        return try {
            when (val raw = doc.get(field)) {
                is com.google.firebase.Timestamp -> raw
                is Number -> {
                    val v = raw.toLong()
                    val millis = if (v in 1..9_999_999_999L) v * 1000L else v
                    if (millis > 0L) com.google.firebase.Timestamp(java.util.Date(millis)) else null
                }
                is java.util.Date -> com.google.firebase.Timestamp(raw)
                is String -> {
                    val v = raw.trim().toLongOrNull()
                    if (v != null && v > 0L) {
                        val millis = if (v in 1..9_999_999_999L) v * 1000L else v
                        com.google.firebase.Timestamp(java.util.Date(millis))
                    } else null
                }
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Ghi nhớ email quen thuộc đã dùng trên thiết bị này để gợi ý đăng nhập nhanh
     */
    fun rememberFamiliarEmail(context: Context, email: String) {
        val clean = email.trim().lowercase()
        if (clean.isBlank() || !clean.contains("@") || clean.contains(" ")) return
        try {
            val prefs = context.getSharedPreferences("magictune_pro_prefs", Context.MODE_PRIVATE)
            val existingCsv = prefs.getString("familiar_emails_csv", "") ?: ""
            val list = existingCsv.split(",")
                .map { it.trim().lowercase() }
                .filter { it.isNotBlank() && it.contains("@") }
                .toMutableList()
            list.remove(clean)
            list.add(0, clean)
            val updatedCsv = list.take(5).joinToString(",")
            prefs.edit()
                .putString("familiar_emails_csv", updatedCsv)
                .putString("last_familiar_email", clean)
                .apply()
        } catch (_: Exception) {}
    }

    /**
     * Lấy danh sách email quen thuộc đã lưu cục bộ trên máy
     */
    fun getLocalFamiliarEmails(context: Context): List<String> {
        return try {
            val prefs = context.getSharedPreferences("magictune_pro_prefs", Context.MODE_PRIVATE)
            val result = mutableListOf<String>()
            val lastEmail = prefs.getString("last_familiar_email", "")?.trim()?.lowercase() ?: ""
            val currentEmail = prefs.getString("current_user_email", "")?.trim()?.lowercase() ?: ""
            val csv = prefs.getString("familiar_emails_csv", "") ?: ""
            if (lastEmail.contains("@")) result.add(lastEmail)
            if (currentEmail.contains("@") && !result.contains(currentEmail)) result.add(currentEmail)
            csv.split(",").map { it.trim().lowercase() }.forEach { item ->
                if (item.contains("@") && !result.contains(item)) {
                    result.add(item)
                }
            }
            result
        } catch (_: Exception) {
            emptyList()
        }
    }

    /**
     * Phát hiện thiết bị quen thuộc (từ Cầu nối REST Firestore + SDK devices/pro_devices/users + Settings.Secure + bộ nhớ máy)
     * và trả về danh sách email gợi ý ngay cả khi vừa gỡ app cài lại và chưa đăng nhập.
     */
    suspend fun fetchFamiliarDeviceEmails(context: Context): Pair<Boolean, List<String>> = withContext(Dispatchers.IO) {
        val emails = getLocalFamiliarEmails(context).toMutableList()
        val deviceId = LicenseManager.getDeviceId(context).trim().uppercase()
        val prefs = context.getSharedPreferences("magictune_pro_prefs", Context.MODE_PRIVATE)
        var isFamiliarDevice = emails.isNotEmpty() ||
            prefs.getBoolean("is_familiar_device_recognized", false) ||
            LicenseManager.isProActivated(context)

        try {
            val (restFamiliar, restEmails) = LicenseManager.fetchFamiliarDeviceInfoFromCloud(context)
            if (restFamiliar) isFamiliarDevice = true
            for (em in restEmails) {
                val clean = em.trim().lowercase()
                if (clean.contains("@") && !clean.contains(" ")) {
                    if (!emails.contains(clean)) emails.add(clean)
                    rememberFamiliarEmail(context, clean)
                }
            }
        } catch (_: Exception) {}

        try {
            // 1. Kiểm tra trong bảng devices/{deviceId} qua SDK
            val deviceDoc = getDb().collection("devices").document(deviceId).get().await()
            if (deviceDoc.exists()) {
                isFamiliarDevice = true
                val ownerEmail = (deviceDoc.getString("ownerEmail") ?: "").trim().lowercase()
                if (ownerEmail.contains("@") && !ownerEmail.contains(" ") && !ownerEmail.startsWith("ẩn danh")) {
                    emails.remove(ownerEmail)
                    emails.add(0, ownerEmail)
                    rememberFamiliarEmail(context, ownerEmail)
                }
            }
        } catch (_: Exception) {}

        try {
            // 2. Kiểm tra mục tiêu trong bảng users theo deviceId / activeDeviceId
            val cleanId = deviceId.trim().uppercase()
            val normTarget = LicenseManager.normalizeDeviceIdForMatch(cleanId)
            val primaryHw = LicenseManager.getPrimaryHwId(context)
            val candidateIds = listOf(primaryHw, "MT-$primaryHw", cleanId, normTarget, "MT-$normTarget").filter { it.isNotBlank() }.distinct()
            if (candidateIds.isNotEmpty()) {
                val byDev = try {
                    getDb().collection("users").whereIn("deviceId", candidateIds).limit(5).get().await()
                } catch (_: Exception) { null }
                val byAct = try {
                    getDb().collection("users").whereIn("activeDeviceId", candidateIds).limit(5).get().await()
                } catch (_: Exception) { null }
                val docs = (byDev?.documents.orEmpty() + byAct?.documents.orEmpty())
                for (doc in docs) {
                    isFamiliarDevice = true
                    val uEmail = (doc.getString("email") ?: "").trim().lowercase()
                    if (uEmail.contains("@") && !uEmail.contains(" ")) {
                        if (!emails.contains(uEmail)) {
                            emails.add(uEmail)
                        }
                        rememberFamiliarEmail(context, uEmail)
                    }
                }
            }
        } catch (_: Exception) {}

        Pair(isFamiliarDevice, emails.distinct())
    }

    /**
     * Lấy User hiện tại đang đăng nhập (Loại trừ hoàn toàn phiên Anonymous để không làm giả trạng thái đã đăng nhập)
     */
    fun getCurrentUser(): FirebaseUser? {
        return try {
            val u = Firebase.auth.currentUser
            if (u != null && u.isAnonymous) {
                try { Firebase.auth.signOut() } catch (_: Exception) {}
                null
            } else {
                if (u != null) {
                    val curSnap = _authSessionFlow.value
                    val email = (u.email ?: "").trim()
                    val isEmailAdmin = email.equals(INITIAL_ADMIN_EMAIL, ignoreCase = true) ||
                        email.equals(INITIAL_ADMIN_EMAIL_ALT, ignoreCase = true) ||
                        (u.phoneNumber ?: "").contains(INITIAL_ADMIN_PHONE)
                    if (!curSnap.isLoggedIn || curSnap.uid != u.uid || (isEmailAdmin && !curSnap.isAdmin)) {
                        val name = (u.displayName ?: "").trim().ifBlank {
                            if (email.contains("@")) email.substringBefore("@") else curSnap.displayName.ifBlank { "Thành Viên MagicTune" }
                        }
                        val nextAdmin = curSnap.isAdmin || isEmailAdmin
                        _authSessionFlow.value = AuthSessionSnapshot(
                            isLoggedIn = true,
                            uid = u.uid,
                            email = email.ifBlank { curSnap.email },
                            displayName = name,
                            role = if (nextAdmin) "admin" else curSnap.role.ifBlank { "user" },
                            isAdmin = nextAdmin,
                            isInitialized = true
                        )
                    }
                }
                u
            }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Kiểm tra xem user hiện tại có phải là Admin hay không (Ưu tiên Fast-Pass 0ns từ LicenseManager trước để không bao giờ nghẽn IPC)
     */
    fun isCurrentAdmin(context: Context? = null, profile: UserProfile? = null): Boolean {
        if (context != null && LicenseManager.isCurrentUserAdmin(context)) {
            return true
        }
        val role = (profile?.role ?: "").trim()
        if (role.equals("admin", ignoreCase = true)) {
            val pEmail = profile?.email?.trim().orEmpty()
            if (context != null && pEmail.isNotBlank()) {
                LicenseManager.markLocalAdminVerified(context, pEmail)
            }
            return true
        }
        val u = try { getCurrentUser() } catch (_: Exception) { null }
        val email = (u?.email ?: profile?.email ?: "").trim()
        val phone = (u?.phoneNumber ?: profile?.phoneNumber ?: "").trim()

        if (email.equals(INITIAL_ADMIN_EMAIL, ignoreCase = true) ||
            email.equals(INITIAL_ADMIN_EMAIL_ALT, ignoreCase = true) ||
            (phone.isNotBlank() && phone.contains(INITIAL_ADMIN_PHONE))
        ) {
            if (context != null && email.isNotBlank()) {
                LicenseManager.markLocalAdminVerified(context, email)
            }
            return true
        }

        if (context != null) {
            val prefs = context.getSharedPreferences("magictune_pro_prefs", Context.MODE_PRIVATE)
            val savedRole = (prefs.getString("current_user_role", "") ?: "").trim()
            val savedEmail = (prefs.getString("current_user_email", "") ?: "").trim()
            if (savedEmail.equals(INITIAL_ADMIN_EMAIL, ignoreCase = true) ||
                savedEmail.equals(INITIAL_ADMIN_EMAIL_ALT, ignoreCase = true) ||
                (savedEmail.isNotBlank() && savedRole.equals("admin", ignoreCase = true))
            ) {
                LicenseManager.markLocalAdminVerified(context, savedEmail.ifBlank { INITIAL_ADMIN_EMAIL })
                return true
            }
        }
        return false
    }

    /**
     * Đồng bộ hồ sơ người dùng lên Firestore ngay sau khi đăng nhập thành công (Chạy 100% trên Dispatchers.IO).
     * Đồng thời ghi nhận `activeDeviceId` và `activeSessionToken` của máy mới lên `users/{uid}`
     * để kích hoạt cơ chế tự động đăng xuất trên máy cũ (1 tài khoản chỉ đăng nhập 1 máy tại 1 thời điểm).
     */
    suspend fun syncUserProfile(context: Context, force: Boolean = false): UserProfile = withContext(Dispatchers.IO) {
        val user = getCurrentUser() ?: throw IllegalStateException("Chưa đăng nhập Firebase!")
        val nowMs = System.currentTimeMillis()
        val cached = cachedUserProfile
        if (!force && cached != null && cachedUserProfileUid == user.uid && (nowMs - lastSyncedUserProfileMs) < 120_000L) {
            persistAndEmitAuthSession(context, user, cached.role)
            return@withContext cached
        }
        isSyncingProfileOnLogin = true
        lastLoginTimestampMs = nowMs
        try {
            val uid = user.uid
            val email = (user.email ?: "").trim()
            val phone = (user.phoneNumber ?: "").trim()
            val name = user.displayName ?: if (email.isNotBlank()) email.substringBefore("@") else "Người dùng Magictune_Tool"
            val deviceId = LicenseManager.getDeviceId(context).trim().uppercase()
            val deviceModel = "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}"

            // Tạo mã phiên đăng nhập mới cho thiết bị này NGAY LẬP TỨC trước khi đọc/ghi Firestore
            // để SingleDeviceSessionGuard không bao giờ đá nhầm máy vừa mới đăng nhập!
            val newSessionToken = "${deviceId}_${System.currentTimeMillis()}"
            val prefs = context.getSharedPreferences("magictune_pro_prefs", Context.MODE_PRIVATE)
            prefs.edit()
                .putString("current_user_email", email)
                .putString(LicenseManager.KEY_ACTIVE_SESSION_TOKEN, newSessionToken)
                .apply()

            val docRef = getDb().collection("users").document(uid)
            val snap = try {
                kotlinx.coroutines.withTimeoutOrNull(3500L) {
                    docRef.get().await()
                }
            } catch (e: Exception) {
                Log.w(TAG, "Không thể đọc users/$uid trên Firestore, dùng dữ liệu cục bộ: ${e.message}")
                null
            }

            val existingRole = try { snap?.getString("role") } catch (_: Exception) { null } ?: "user"
            val cloudRevoked = try { snap?.getBoolean("revokedByAdmin") == true } catch (_: Exception) { false }
            val cloudPro = try { if (cloudRevoked) false else snap?.getBoolean("isPro") } catch (_: Exception) { null }
            val cloudAccountPro = try {
                if (cloudRevoked) false
                else (snap?.getBoolean("isAccountPro") == true) || (snap?.getString("proTier") == "ACCOUNT_PRO")
            } catch (_: Exception) { false }
            val previousBoundDeviceId = try {
                (snap?.getString("deviceId") ?: "").trim().uppercase()
            } catch (_: Exception) { "" }
            val previousActiveDeviceId = try {
                (snap?.getString("activeDeviceId") ?: "").trim().uppercase()
            } catch (_: Exception) { "" }

            val isAdminAccount = email.equals(INITIAL_ADMIN_EMAIL, ignoreCase = true) ||
                    email.equals(INITIAL_ADMIN_EMAIL_ALT, ignoreCase = true) ||
                    (phone.isNotBlank() && phone.contains(INITIAL_ADMIN_PHONE)) ||
                    existingRole == "admin"

            // Nếu tài khoản này đã bị Admin hạ cấp / thu hồi Pro (`revokedByAdmin == true`), lập tức thu hồi trên máy
            if (cloudRevoked && !isAdminAccount) {
                prefs.edit()
                    .putBoolean("revoked_by_admin", true)
                    .putBoolean("is_pro_activated", false)
                    .putBoolean("is_account_pro_activated", false)
                    .putBoolean("upgraded_to_account_pro", false)
                    .remove("activated_license_key")
                    .apply()
                LicenseManager.revokeAccountProOnDeviceTransfer(context)
            }

            val alreadyLocalPro = LicenseManager.isProActivated(context)
            val cloudDeviceRecognized = if (cloudRevoked && !isAdminAccount) {
                false
            } else if (alreadyLocalPro || isAdminAccount || cloudAccountPro) {
                alreadyLocalPro
            } else {
                try {
                    kotlinx.coroutines.withTimeoutOrNull(4000L) {
                        LicenseManager.checkDeviceRecognizedProInCloud(context, forceRefresh = false)
                    } ?: false
                } catch (_: Exception) {
                    false
                }
            }

            val isCurrentDeviceOnlyPro = LicenseManager.isDeviceProOnly(context) ||
                (prefs.getString(LicenseManager.KEY_ACTIVATED_LICENSE, "") ?: "").startsWith("PRO8-", ignoreCase = true) ||
                (prefs.getString(LicenseManager.KEY_ACTIVATED_LICENSE, "") ?: "").startsWith("PRO-", ignoreCase = true)
            val currentDeviceKey = (prefs.getString(LicenseManager.KEY_ACTIVATED_LICENSE, "") ?: "").trim()
            val hasRealAccountProKey = currentDeviceKey.startsWith("TKPR-", ignoreCase = true)

            // CHỐT CHẶN BẢO MẬT: Người dùng đăng nhập lên máy có sẵn Pro Thiết Bị (hoặc mượn máy)
            // TUYỆT ĐỐI KHÔNG BAO GIỜ được tự động nâng cấp tài khoản của họ lên Pro Tài Khoản!
            // Pro Tài Khoản CHỈ ĐƯỢC PHÉP gán khi:
            // 1. Tài khoản đó đã là Admin (isAdminAccount)
            // 2. Tài khoản đó trên Cloud ĐÃ CÓ Pro Tài Khoản từ trước (cloudAccountPro) do đã thanh toán >= 95k hoặc nâng cấp >= 50k
            // 3. Máy hiện tại thực sự sở hữu mã Key Pro Tài Khoản `TKPR-...` và đang có trạng thái chờ gán tài khoản hợp lệ.
            val localAccountPro = if (cloudRevoked && !isAdminAccount) {
                false
            } else if (isCurrentDeviceOnlyPro) {
                false
            } else {
                hasRealAccountProKey && (LicenseManager.isAccountProActivated(context) || LicenseManager.hasPendingAccountProBind(context))
            }

            // Tiêu thụ cờ chờ gán Account Pro ngay để không bị gán lặp lại cho các tài khoản đăng nhập sau
            if (LicenseManager.hasPendingAccountProBind(context)) {
                prefs.edit().putBoolean(LicenseManager.KEY_PENDING_ACCOUNT_PRO_BIND, false).apply()
            }

            val localDevicePro = if (cloudRevoked && !isAdminAccount) false else (cloudDeviceRecognized || LicenseManager.isProActivated(context))
            val isAccountProToSave = isAdminAccount || cloudAccountPro || localAccountPro

            val normCurrent = LicenseManager.normalizeDeviceIdForMatch(deviceId)
            val isSameOriginalProDevice = cloudPro == true && (
                (previousBoundDeviceId.isNotBlank() && LicenseManager.isDeviceIdMatchingCurrentDevice(context, previousBoundDeviceId)) ||
                    (previousActiveDeviceId.isNotBlank() && LicenseManager.isDeviceIdMatchingCurrentDevice(context, previousActiveDeviceId)) ||
                    (previousBoundDeviceId.isNotBlank() && LicenseManager.normalizeDeviceIdForMatch(previousBoundDeviceId) == normCurrent) ||
                    (previousActiveDeviceId.isNotBlank() && LicenseManager.normalizeDeviceIdForMatch(previousActiveDeviceId) == normCurrent)
                )
            val isProOnThisDevice = isAccountProToSave || localDevicePro || isSameOriginalProDevice
            val isProToSaveInUserDoc = isAccountProToSave || (cloudPro == true) || localDevicePro
            val proTierToSave = when {
                isAccountProToSave -> "ACCOUNT_PRO"
                isProToSaveInUserDoc -> "DEVICE_PRO"
                else -> "FREE"
            }

            val roleToSave = if (isAdminAccount) "admin" else existingRole

            prefs.edit()
                .putString("current_user_role", roleToSave)
                .putString("current_user_email", email)
                .putString(LicenseManager.KEY_ACTIVE_SESSION_TOKEN, newSessionToken)
                .apply()
            if (isAdminAccount && email.isNotBlank()) {
                LicenseManager.markLocalAdminVerified(context, email)
            }
            rememberFamiliarEmail(context, email)

            val existingCreatedAt = if (snap != null) safeGetTimestamp(snap, "createdAt") else null
            val existingProActivatedAt = if (snap != null) {
                safeGetTimestamp(snap, "proActivatedAt") ?: safeGetTimestamp(snap, "accountProActivatedAt")
            } else null
            val existingProSource = try {
                snap?.getString("proActivatedSource")?.takeIf { it.isNotBlank() }
                    ?: snap?.getString("approvedByAiReason").orEmpty()
            } catch (_: Exception) { "" }
            val hwId = LicenseManager.getHardwareId()

            val isOriginalOwnerDevice = (alreadyLocalPro && LicenseManager.hasOwnDevicePermanentKey(context)) ||
                previousBoundDeviceId.isBlank() ||
                LicenseManager.isDeviceIdMatchingCurrentDevice(context, previousBoundDeviceId) ||
                (LicenseManager.normalizeDeviceIdForMatch(previousBoundDeviceId) == normCurrent)

            val profileData = mutableMapOf<String, Any>(
                "userId" to uid,
                "email" to email,
                "phoneNumber" to phone,
                "displayName" to name,
                "role" to roleToSave,
                "isPro" to isProToSaveInUserDoc,
                "isAccountPro" to isAccountProToSave,
                "proTier" to proTierToSave,
                // Giữ nguyên deviceId của máy gốc đầu tiên đã mua Pro để chỉ máy gốc mới sở hữu Key vĩnh viễn
                "deviceId" to if (previousBoundDeviceId.isNotBlank()) previousBoundDeviceId else deviceId,
                "hardwareId" to hwId,
                "activeDeviceId" to deviceId,
                "activeDeviceModel" to deviceModel,
                "activeSessionToken" to newSessionToken,
                "lastActive" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (isProToSaveInUserDoc && existingProActivatedAt == null) {
                profileData["proActivatedAt"] = FieldValue.serverTimestamp()
                profileData["proActivatedMs"] = System.currentTimeMillis()
            }
            if (snap == null || !snap.exists() || snap.get("createdAt") !is com.google.firebase.Timestamp) {
                profileData["createdAt"] = existingCreatedAt ?: FieldValue.serverTimestamp()
            }

            try {
                kotlinx.coroutines.withTimeoutOrNull(3500L) {
                    docRef.set(profileData, SetOptions.merge()).await()
                }
                // Nếu tài khoản có Pro Tài Khoản đăng nhập sang thiết bị mới -> Thu hồi trạng thái Pro trên thiết bị cũ trong bảng `devices` (1 máy/lần),
                // nhưng TUYỆT ĐỐI KHÔNG ghi đè thu hồi nếu thiết bị cũ đang giữ bản quyền PRO THIẾT BỊ (DEVICE_PRO) vĩnh viễn!
                if (isAccountProToSave && previousActiveDeviceId.isNotBlank() &&
                    !LicenseManager.isDeviceIdMatchingCurrentDevice(context, previousActiveDeviceId) &&
                    !LicenseManager.isDeviceIdMatchingCurrentDevice(context, previousBoundDeviceId)
                ) {
                    val prevDocRef = getDb().collection("devices").document(previousActiveDeviceId)
                    val prevSnap = try {
                        kotlinx.coroutines.withTimeoutOrNull(2500L) { prevDocRef.get().await() }
                    } catch (_: Exception) { null }
                    if (prevSnap != null && prevSnap.exists()) {
                        val prevSource = prevSnap.getString("proActivatedSource").orEmpty()
                        val prevTier = prevSnap.getString("proTier").orEmpty()
                        val prevLicenseKey = prevSnap.getString("licenseKey").orEmpty()
                        val prevHasPermanentDeviceKey = prevLicenseKey.startsWith("PRO-", ignoreCase = true)
                        val prevIsDeviceProPermanent = prevSnap.getBoolean("isPro") == true &&
                            (prevHasPermanentDeviceKey ||
                                (prevSnap.getBoolean("isAccountPro") != true &&
                                    (prevTier == "DEVICE_PRO" || !prevSource.contains("BORROWED", ignoreCase = true))))
                        if (!prevIsDeviceProPermanent) {
                            prevDocRef.set(
                                mapOf(
                                    "isPro" to false,
                                    "isAccountPro" to false,
                                    "licenseKey" to "",
                                    "updatedAt" to FieldValue.serverTimestamp()
                                ),
                                SetOptions.merge()
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Không thể ghi hồ sơ users/$uid lên Firestore: ${e.message}")
            }

            if (isAdminAccount) {
                if (!LicenseManager.isAccountProActivated(context) || !LicenseManager.isProActivated(context)) {
                    LicenseManager.activateAccountPro(context, "ADMIN_LOGIN_AUTO_GRANT_PERMANENT", syncToCloud = true, isBorrowedFromAccountLogin = false)
                    LicenseManager.setProActivated(context, true, "ADMIN_LOGIN_AUTO_GRANT_PERMANENT", syncToCloud = true)
                }
                LicenseManager.syncDeviceProToCloud(context)
            } else if (isAccountProToSave) {
                if (isOriginalOwnerDevice) {
                    LicenseManager.activateAccountPro(context, "FIREBASE_ACCOUNT_PRO_LOGIN", syncToCloud = true, isBorrowedFromAccountLogin = false)
                    LicenseManager.syncDeviceProToCloud(context)
                } else {
                    // Máy phụ/máy mới đăng nhập Tài Khoản Pro: Được mở khóa Pro khi đang đăng nhập, nhưng KHÔNG cấp Key vĩnh viễn cho máy phụ
                    LicenseManager.activateAccountPro(context, "SESSION_BORROWED_ACCOUNT_PRO", syncToCloud = true, isBorrowedFromAccountLogin = true)
                    LicenseManager.syncDevicePresenceToCloud(context)
                }
            } else if (isProOnThisDevice) {
                LicenseManager.setProActivated(context, true, "FIREBASE_DEVICE_PRO_SYNC", syncToCloud = true)
                LicenseManager.syncDeviceProToCloud(context)
            } else {
                LicenseManager.deactivateAccountProOnLogout(context)
                LicenseManager.syncDevicePresenceToCloud(context)
            }

            // Chỉ đồng bộ Cloud bổ sung nếu chưa có Pro (tránh thừa khi đã xác nhận Pro)
            if (!isProOnThisDevice) {
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        LicenseManager.checkDeviceRecognizedProInCloud(context.applicationContext, forceRefresh = false)
                    } catch (_: Exception) {}
                }
            }

            val resultProfile = UserProfile(
                userId = uid,
                email = email,
                phoneNumber = phone,
                displayName = name,
                role = roleToSave,
                isPro = isProOnThisDevice,
                isAccountPro = isAccountProToSave,
                proTier = proTierToSave,
                deviceId = deviceId,
                hardwareId = hwId,
                activeDeviceId = deviceId,
                activeDeviceModel = deviceModel,
                activeSessionToken = newSessionToken,
                proActivatedSource = existingProSource,
                revokedByAdmin = cloudRevoked && !isAdminAccount,
                proActivatedAt = existingProActivatedAt ?: if (isProOnThisDevice) com.google.firebase.Timestamp.now() else null,
                lastActive = com.google.firebase.Timestamp.now(),
                createdAt = existingCreatedAt ?: com.google.firebase.Timestamp.now()
            )
            cachedUserProfile = resultProfile
            cachedUserProfileUid = uid
            lastSyncedUserProfileMs = System.currentTimeMillis()
            persistAndEmitAuthSession(context, user, roleToSave)
            resultProfile
        } finally {
            isSyncingProfileOnLogin = false
            startSingleDeviceSessionGuard(context)
        }
    }

    @Volatile
    private var lastUserHeartbeatMs: Long = 0L

    /**
     * Đồng bộ heartbeat có giới hạn cho tài khoản và thiết bị; bỏ qua khi mạng chưa xác thực để tránh hàng đợi offline.
     */
    fun updateUserHeartbeat(context: Context, force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!hasValidatedCloudNetwork(context)) return // Không để Firestore xếp mutation heartbeat vô hạn khi offline.
        val minInterval = if (force) 30_000L else 30 * 60_000L
        if (now - lastUserHeartbeatMs < minInterval) return
        lastUserHeartbeatMs = now

        val appCtx = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
                val db = try { getDb() } catch (_: Exception) { null }
                val timestamp = com.google.firebase.Timestamp.now()

                // 1. Cập nhật lastActive cho document tài khoản `users/$uid`
                if (user != null && user.uid.isNotBlank() && db != null) {
                    db.collection("users").document(user.uid).set(
                        mapOf(
                            "lastActive" to timestamp,
                            "updatedAt" to timestamp
                        ),
                        SetOptions.merge()
                    )
                }

                // Đồng bộ document thiết bị tại LicenseManager để tránh xếp cùng lúc hai mutation giống nhau.
                LicenseManager.syncDevicePresenceToCloud(appCtx, force = force)
            } catch (e: Exception) {
                Log.w(TAG, "Lỗi updateUserHeartbeat: ${e.message}")
            }
        }
    }

    private fun hasValidatedCloudNetwork(context: Context): Boolean {
        return try {
            val manager = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager
                ?: return false
            val network = manager.activeNetwork ?: return false
            val caps = manager.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (_: Throwable) { false }
    }

    private fun safeParseRestTimestamp(raw: Any?): com.google.firebase.Timestamp? {
        if (raw == null) return null
        return try {
            when (raw) {
                is com.google.firebase.Timestamp -> raw
                is java.util.Date -> com.google.firebase.Timestamp(raw)
                is Number -> {
                    val v = raw.toLong()
                    val millis = if (v in 1..9_999_999_999L) v * 1000L else v
                    if (millis > 0L) com.google.firebase.Timestamp(java.util.Date(millis)) else null
                }
                is String -> {
                    val s = raw.trim()
                    val numeric = s.toLongOrNull()
                    if (numeric != null && numeric > 0L) {
                        val millis = if (numeric in 1..9_999_999_999L) numeric * 1000L else numeric
                        com.google.firebase.Timestamp(java.util.Date(millis))
                    } else {
                        val cleanIso = s.substringBefore(".").removeSuffix("Z")
                        val parsed = TimeFormatUtils.tlRestIsoUtcFormat.get()?.parse(cleanIso)
                        if (parsed != null) com.google.firebase.Timestamp(parsed) else null
                    }
                }
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    internal fun parseUsersFromMaps(rawDocs: List<Map<String, Any>>): List<UserProfile> {
        return try {
            rawDocs.mapNotNull { m ->
                try {
                    val docId = (m["__id"] as? String).orEmpty()
                    val lastAct = safeParseRestTimestamp(m["lastActive"]) ?: safeParseRestTimestamp(m["updatedAt"])
                    val created = safeParseRestTimestamp(m["createdAt"])
                    val proAt = safeParseRestTimestamp(m["proActivatedAt"])
                        ?: safeParseRestTimestamp(m["accountProActivatedAt"])
                        ?: safeParseRestTimestamp(m["proActivatedMs"])
                    val uRevoked = (m["revokedByAdmin"] as? Boolean) == true
                    val uKey = ((m["licenseKey"] as? String) ?: "").trim()
                    val devId = (m["deviceId"] as? String).orEmpty()
                    val proSrc = ((m["proActivatedSource"] as? String)?.takeIf { it.isNotBlank() }
                        ?: (m["approvedByAiReason"] as? String).orEmpty()).trim()
                    val uRole = (m["role"] as? String) ?: "user"
                    val uEmail = (m["email"] as? String).orEmpty()
                    val isAdm = uRole == "admin" ||
                        uEmail.equals(INITIAL_ADMIN_EMAIL, ignoreCase = true) ||
                        uEmail.equals(INITIAL_ADMIN_EMAIL_ALT, ignoreCase = true)
                    val isExplicitDevKey = uKey.startsWith("PRO8-", ignoreCase = true) || uKey.startsWith("PRO-", ignoreCase = true)
                    val hasExplicitAccProof = uKey.startsWith("TKPR-", ignoreCase = true) ||
                        proSrc.contains("ADMIN_MANUAL_GRANT_ACCOUNT_PRO", ignoreCase = true)
                    val isAccPro = !uRevoked && (isAdm || hasExplicitAccProof || (((m["isAccountPro"] as? Boolean == true) || ((m["proTier"] as? String) == "ACCOUNT_PRO")) && !isExplicitDevKey))
                    val rawPro = !uRevoked && ((m["isPro"] as? Boolean == true) || isAccPro)
                    val rawCustomAi = ((m["customAiKeyRaw"] as? String) ?: (m["userCustomAiKeys"] as? String).orEmpty()).trim()
                    val rawCustomGemini = ((m["customGeminiKey"] as? String) ?: (m["userGeminiKey"] as? String).orEmpty()).trim()
                    val rawCustomGroq = ((m["customGroqKey"] as? String) ?: (m["userGroqKey"] as? String).orEmpty()).trim()
                    val customKeyTs = safeParseRestTimestamp(m["customAiKeyUpdatedAt"]) ?: safeParseRestTimestamp(m["customAiKeyUpdatedMs"])
                    UserProfile(
                        userId = (m["userId"] as? String)?.takeIf { it.isNotBlank() } ?: docId,
                        email = (m["email"] as? String).orEmpty(),
                        phoneNumber = (m["phoneNumber"] as? String).orEmpty(),
                        displayName = (m["displayName"] as? String)?.takeIf { it.isNotBlank() } ?: "Chưa đặt tên",
                        role = (m["role"] as? String)?.takeIf { it.isNotBlank() } ?: "user",
                        isPro = rawPro,
                        isAccountPro = isAccPro,
                        proTier = if (uRevoked) "FREE" else ((m["proTier"] as? String)?.takeIf { it.isNotBlank() }
                            ?: if (isAccPro) "ACCOUNT_PRO" else if (rawPro) "DEVICE_PRO" else "FREE"),
                        deviceId = devId,
                        hardwareId = (m["hardwareId"] as? String).orEmpty(),
                        activeDeviceId = (m["activeDeviceId"] as? String)?.takeIf { it.isNotBlank() } ?: devId,
                        activeDeviceModel = (m["activeDeviceModel"] as? String).orEmpty(),
                        activeSessionToken = (m["activeSessionToken"] as? String).orEmpty(),
                        licenseKey = (m["licenseKey"] as? String).orEmpty().trim(),
                        proActivatedSource = proSrc,
                        bankTransCode = (m["bankTransCode"] as? String).orEmpty().trim(),
                        revokedByAdmin = uRevoked,
                        proActivatedAt = proAt,
                        lastActive = lastAct,
                        createdAt = created,
                        customGeminiKey = rawCustomGemini,
                        customGroqKey = rawCustomGroq,
                        customAiKeyRaw = rawCustomAi,
                        customAiKeyUpdatedAt = customKeyTs
                    )
                } catch (_: Throwable) {
                    null
                }
            }.sortedWith(
                compareByDescending<UserProfile> { it.isPro }
                    .thenByDescending { it.proActivatedAt?.toDate()?.time ?: it.lastActive?.toDate()?.time ?: it.createdAt?.toDate()?.time ?: 0L }
            )
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun getOfflineUsersCached(context: Context): List<UserProfile> {
        return parseUsersFromMaps(LicenseManager.getCachedAdminCollectionMapsInstant(context, "users"))
    }

    suspend fun fetchAllUsersViaRest(context: Context, forceRefresh: Boolean = false): List<UserProfile> = withContext(Dispatchers.IO) {
        val rawDocs = LicenseManager.fetchAdminCollectionMapsViaRest(context, "users", 100, forceRefresh = forceRefresh, maxPages = 2)
        parseUsersFromMaps(rawDocs)
    }

    internal fun parseDevicesFromMaps(rawDocs: List<Map<String, Any>>): List<DeviceRecord> {
        return try {
            rawDocs.mapNotNull { m ->
                try {
                    val docId = (m["__id"] as? String).orEmpty()
                    val ts = safeParseRestTimestamp(m["lastActive"]) ?: safeParseRestTimestamp(m["updatedAt"])
                    val created = safeParseRestTimestamp(m["createdAt"])
                    val proAt = safeParseRestTimestamp(m["proActivatedAt"]) ?: safeParseRestTimestamp(m["proActivatedMs"])
                    val dKey = (m["licenseKey"] as? String).orEmpty().trim()
                    val dReason = (m["approvedByAiReason"] as? String).orEmpty().trim()
                    val dTrans = (m["bankTransCode"] as? String).orEmpty().trim()
                    val dRevoked = (m["revokedByAdmin"] as? Boolean) ?: false
                    val dUpgraded = !dRevoked && ((m["upgradedToAccountPro"] as? Boolean) ?: false)
                    val dAccPro = !dRevoked && ((m["isAccountPro"] as? Boolean == true) || ((m["proTier"] as? String) == "ACCOUNT_PRO"))
                    val effectivePro = !dRevoked && (
                        (m["isPro"] as? Boolean == true) ||
                            dAccPro ||
                            dUpgraded ||
                            dKey.length >= 12
                        )
                    val effTier = if (dRevoked) "FREE" else ((m["proTier"] as? String)?.takeIf { it.isNotBlank() }
                        ?: if (dAccPro) "ACCOUNT_PRO" else if (effectivePro) "DEVICE_PRO" else "FREE")
                    val rawDevCustomAi = ((m["customAiKeyRaw"] as? String) ?: (m["userCustomAiKeys"] as? String).orEmpty()).trim()
                    val rawDevCustomGemini = ((m["customGeminiKey"] as? String) ?: (m["userGeminiKey"] as? String).orEmpty()).trim()
                    val rawDevCustomGroq = ((m["customGroqKey"] as? String) ?: (m["userGroqKey"] as? String).orEmpty()).trim()
                    val devCustomKeyTs = safeParseRestTimestamp(m["customAiKeyUpdatedAt"]) ?: safeParseRestTimestamp(m["customAiKeyUpdatedMs"])
                    DeviceRecord(
                        deviceId = (m["deviceId"] as? String)?.takeIf { it.isNotBlank() } ?: docId,
                        hardwareId = (m["hardwareId"] as? String).orEmpty(),
                        model = (m["model"] as? String)?.takeIf { it.isNotBlank() } ?: "Thiết bị Android",
                        isPro = effectivePro,
                        isAccountPro = dAccPro,
                        upgradedToAccountPro = dUpgraded,
                        proTier = effTier,
                        revokedByAdmin = dRevoked,
                        ownerUid = (m["ownerUid"] as? String).orEmpty(),
                        ownerEmail = (m["ownerEmail"] as? String)?.takeIf { it.isNotBlank() } ?: "👤 Khách vãng lai (Chưa đăng nhập)",
                        ownerName = (m["ownerName"] as? String)?.takeIf { it.isNotBlank() } ?: "Khách vãng lai",
                        freeTrialUsed = (m["freeTrialUsed"] as? Number)?.toInt() ?: 0,
                        licenseKey = dKey,
                        approvedByAiReason = dReason,
                        bankTransCode = dTrans,
                        lastActive = ts,
                        createdAt = created,
                        proActivatedAt = proAt,
                        customGeminiKey = rawDevCustomGemini,
                        customGroqKey = rawDevCustomGroq,
                        customAiKeyRaw = rawDevCustomAi,
                        customAiKeyUpdatedAt = devCustomKeyTs
                    )
                } catch (_: Throwable) {
                    null
                }
            }.sortedWith(
                compareByDescending<DeviceRecord> { it.isPro }
                    .thenByDescending {
                        it.proActivatedAt?.toDate()?.time
                            ?: it.lastActive?.toDate()?.time
                            ?: it.createdAt?.toDate()?.time
                            ?: 0L
                    }
            )
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun getOfflineDevicesCached(context: Context): List<DeviceRecord> {
        return parseDevicesFromMaps(LicenseManager.getCachedAdminCollectionMapsInstant(context, "devices"))
    }

    suspend fun fetchAllDevicesViaRest(context: Context, forceRefresh: Boolean = false): List<DeviceRecord> = withContext(Dispatchers.IO) {
        val rawDocs = LicenseManager.fetchAdminCollectionMapsViaRest(context, "devices", 100, forceRefresh = forceRefresh, maxPages = 2)
        val rawProDocs = LicenseManager.fetchAdminCollectionMapsViaRest(context, "pro_devices", 80, forceRefresh = forceRefresh, maxPages = 1)
        parseDevicesFromMaps(rawDocs + rawProDocs)
    }

    internal fun parsePaymentIntentsFromMaps(rawDocs: List<Map<String, Any>>): List<PaymentIntentRecord> {
        return try {
            val parsed = rawDocs.mapNotNull { m ->
                try {
                    val docId = (m["__id"] as? String).orEmpty()
                    val rawDeviceId = (m["deviceId"] as? String).orEmpty().trim().ifBlank {
                        docId.substringBefore("_").trim()
                    }
                    val normId = LicenseManager.normalizeDeviceIdForMatch(rawDeviceId)
                    val canonicalDeviceId = if (normId.isNotBlank()) "MT-$normId" else rawDeviceId
                    PaymentIntentRecord(
                        intentId = docId,
                        deviceId = canonicalDeviceId,
                        model = (m["model"] as? String).orEmpty(),
                        ownerEmail = (m["ownerEmail"] as? String).orEmpty(),
                        ownerName = (m["ownerName"] as? String).orEmpty(),
                        actionType = (m["actionType"] as? String).orEmpty(),
                        details = (m["details"] as? String).orEmpty(),
                        note = (m["note"] as? String).orEmpty(),
                        isPro = (m["isPro"] as? Boolean) ?: false,
                        timestamp = safeParseRestTimestamp(m["timestamp"])
                    )
                } catch (_: Throwable) {
                    null
                }
            }
            parsed.groupBy { rec ->
                LicenseManager.normalizeDeviceIdForMatch(rec.deviceId).ifBlank {
                    "${rec.ownerEmail.trim().lowercase()}_${rec.model.trim().lowercase()}"
                }
            }.mapNotNull { (_, list) ->
                list.sortedWith(
                    compareByDescending<PaymentIntentRecord> { it.actionType == "CLICKED_I_PAID" }
                        .thenByDescending { it.timestamp?.toDate()?.time ?: 0L }
                ).firstOrNull()
            }
                .filter { !it.isPro }
                .sortedByDescending { it.timestamp?.toDate()?.time ?: 0L }
                .take(100)
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun getOfflinePaymentIntentsCached(context: Context): List<PaymentIntentRecord> {
        return parsePaymentIntentsFromMaps(LicenseManager.getCachedAdminCollectionMapsInstant(context, "payment_intents"))
    }

    suspend fun fetchPaymentIntentsViaRest(context: Context, forceRefresh: Boolean = false): List<PaymentIntentRecord> = withContext(Dispatchers.IO) {
        val rawDocs = LicenseManager.fetchAdminCollectionMapsViaRest(context, "payment_intents", 150, forceRefresh = forceRefresh, maxPages = 1)
        parsePaymentIntentsFromMaps(rawDocs)
    }

    internal fun parseHonorAppsFromMaps(rawDocs: List<Map<String, Any>>): List<com.example.data.HonorAppItem> {
        return try {
            rawDocs.mapNotNull { m ->
                try {
                    val docId = (m["__id"] as? String).orEmpty()
                    com.example.data.HonorAppItem(
                        id = (m["id"] as? String)?.takeIf { it.isNotBlank() } ?: docId,
                        name = (m["name"] as? String).orEmpty(),
                        description = (m["description"] as? String).orEmpty(),
                        downloadUrl = (m["downloadUrl"] as? String).orEmpty(),
                        category = (m["category"] as? String)?.takeIf { it.isNotBlank() } ?: "Tiện Ích",
                        version = (m["version"] as? String)?.takeIf { it.isNotBlank() } ?: "1.0",
                        author = (m["author"] as? String)?.takeIf { it.isNotBlank() } ?: "Admin VXM",
                        isProOnly = (m["isProOnly"] as? Boolean) ?: false,
                        iconName = (m["iconName"] as? String)?.takeIf { it.isNotBlank() } ?: "apps",
                        status = (m["status"] as? String)?.takeIf { it.isNotBlank() } ?: "APPROVED",
                        contributorEmail = (m["contributorEmail"] as? String).orEmpty(),
                        createdAt = (m["createdAt"] as? Number)?.toLong()
                            ?: safeParseRestTimestamp(m["createdAt"])?.toDate()?.time
                            ?: 0L
                    )
                } catch (_: Throwable) {
                    null
                }
            }.sortedByDescending { it.createdAt }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun getOfflineHonorAppsCached(context: Context): List<com.example.data.HonorAppItem> {
        return parseHonorAppsFromMaps(LicenseManager.getCachedAdminCollectionMapsInstant(context, "honor_apps"))
    }

    suspend fun fetchHonorAppsViaRest(context: Context, forceRefresh: Boolean = false): List<com.example.data.HonorAppItem> = withContext(Dispatchers.IO) {
        val rawDocs = LicenseManager.fetchAdminCollectionMapsViaRest(context, "honor_apps", 120, forceRefresh = forceRefresh, maxPages = 1)
        parseHonorAppsFromMaps(rawDocs)
    }

    private suspend fun fetchNextAdminCollectionPage(
        collectionName: String,
        cursor: AdminPageCursor,
        pageSize: Long = ADMIN_LIST_PAGE_SIZE
    ): Pair<List<Map<String, Any>>, Boolean> = cursor.mutex.withLock {
        if (cursor.exhausted) return@withLock emptyList<Map<String, Any>>() to false
        val baseQuery = getDb().collection(collectionName).orderBy(FieldPath.documentId())
        val query = if (cursor.initialized) {
            val lastId = cursor.lastDocumentId
            if (lastId.isNullOrBlank()) {
                cursor.exhausted = true
                return@withLock emptyList<Map<String, Any>>() to false
            }
            baseQuery.startAfter(lastId)
        } else {
            baseQuery
        }
        val snapshot = query.limit(pageSize).get().await()
        val docs = snapshot.documents
        cursor.initialized = true
        if (docs.isNotEmpty()) cursor.lastDocumentId = docs.last().id
        cursor.exhausted = docs.size < pageSize
        val rawDocs = docs.map { doc ->
            doc.data.orEmpty().toMutableMap().apply { put("__id", doc.id) }
        }
        rawDocs to !cursor.exhausted
    }

    suspend fun fetchNextUsersPage(): AdminListPage<UserProfile> = withContext(Dispatchers.IO) {
        val (rawDocs, hasMore) = fetchNextAdminCollectionPage("users", adminUsersPageCursor)
        AdminListPage(parseUsersFromMaps(rawDocs), hasMore)
    }

    suspend fun fetchNextDevicesPage(): AdminListPage<DeviceRecord> = withContext(Dispatchers.IO) {
        // Keep a combined button press bounded to 150 documents across both device collections.
        val (deviceDocs, devicesHaveMore) = fetchNextAdminCollectionPage("devices", adminDevicesPageCursor, pageSize = 100L)
        val (proDeviceDocs, proDevicesHaveMore) = fetchNextAdminCollectionPage("pro_devices", adminProDevicesPageCursor, pageSize = 50L)
        AdminListPage(parseDevicesFromMaps(deviceDocs + proDeviceDocs), devicesHaveMore || proDevicesHaveMore)
    }

    /**
     * Lắng nghe danh sách TẤT CẢ Người Dùng dành cho ADMIN (Chạy hoàn toàn trên Background Executor để 0ms lag UI)
     */
    fun observeAllUsers(context: Context? = null): Flow<List<UserProfile>> = callbackFlow {
        var parseJob: kotlinx.coroutines.Job? = null
        val listener = getDb().collection("users")
            .orderBy(FieldPath.documentId())
            .limit(ADMIN_LIST_PAGE_SIZE)
            .addSnapshotListener(adminSnapshotExecutor) { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Cảnh báo lắng nghe danh sách users: ${error.message}")
                    if (context != null) {
                        val appCtx = context.applicationContext
                        parseJob?.cancel()
                        parseJob = launch(Dispatchers.IO) {
                            val fallback = fetchAllUsersViaRest(appCtx)
                            if (fallback.isNotEmpty()) {
                                trySend(fallback)
                            }
                        }
                    }
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val docs = snapshot.documents
                    if (!adminUsersPageCursor.initialized) {
                        adminUsersPageCursor.lastDocumentId = docs.lastOrNull()?.id
                        adminUsersPageCursor.initialized = true
                        adminUsersPageCursor.exhausted = docs.size < ADMIN_LIST_PAGE_SIZE
                    }
                    parseJob?.cancel()
                    parseJob = launch(Dispatchers.Default) {
                        try {
                            var processedCount = 0
                            val list = docs.mapNotNull { doc ->
                                if ((++processedCount and 31) == 0) yield()
                                try {
                                    val lastAct = safeGetTimestamp(doc, "lastActive") ?: safeGetTimestamp(doc, "updatedAt")
                                    val created = safeGetTimestamp(doc, "createdAt")
                                    val proAt = safeGetTimestamp(doc, "proActivatedAt")
                                        ?: safeGetTimestamp(doc, "accountProActivatedAt")
                                        ?: (doc.getLong("proActivatedMs")?.takeIf { it > 0L }?.let { com.google.firebase.Timestamp(java.util.Date(it)) })
                                    val uRevoked = doc.getBoolean("revokedByAdmin") == true
                                    val uKey = (doc.getString("licenseKey") ?: "").trim()
                                    val proSrc = (doc.getString("proActivatedSource")?.takeIf { it.isNotBlank() }
                                        ?: doc.getString("approvedByAiReason").orEmpty()).trim()
                                    val uRole = doc.getString("role") ?: "user"
                                    val uEmail = doc.getString("email") ?: ""
                                    val isAdm = uRole == "admin" ||
                                        uEmail.equals(INITIAL_ADMIN_EMAIL, ignoreCase = true) ||
                                        uEmail.equals(INITIAL_ADMIN_EMAIL_ALT, ignoreCase = true)
                                    val isExplicitDevKey = uKey.startsWith("PRO8-", ignoreCase = true) || uKey.startsWith("PRO-", ignoreCase = true)
                                    val hasExplicitAccProof = uKey.startsWith("TKPR-", ignoreCase = true) ||
                                        proSrc.contains("ADMIN_MANUAL_GRANT_ACCOUNT_PRO", ignoreCase = true)
                                    val isAccPro = !uRevoked && (isAdm || hasExplicitAccProof || (((doc.getBoolean("isAccountPro") == true) || (doc.getString("proTier") == "ACCOUNT_PRO")) && !isExplicitDevKey))
                                    val rawPro = !uRevoked && ((doc.getBoolean("isPro") ?: false) || isAccPro)
                                    val rawCustomAi = (doc.getString("customAiKeyRaw") ?: doc.getString("userCustomAiKeys") ?: "").trim()
                                    val rawCustomGemini = (doc.getString("customGeminiKey") ?: doc.getString("userGeminiKey") ?: "").trim()
                                    val rawCustomGroq = (doc.getString("customGroqKey") ?: doc.getString("userGroqKey") ?: "").trim()
                                    val customKeyTs = safeGetTimestamp(doc, "customAiKeyUpdatedAt")
                                        ?: (doc.getLong("customAiKeyUpdatedMs")?.takeIf { it > 0L }?.let { com.google.firebase.Timestamp(java.util.Date(it)) })
                                    UserProfile(
                                        userId = doc.getString("userId") ?: doc.id,
                                        email = doc.getString("email") ?: "",
                                        phoneNumber = doc.getString("phoneNumber") ?: "",
                                        displayName = doc.getString("displayName") ?: "Chưa đặt tên",
                                        role = doc.getString("role") ?: "user",
                                        isPro = rawPro,
                                        isAccountPro = isAccPro,
                                        proTier = if (uRevoked) "FREE" else (doc.getString("proTier") ?: if (isAccPro) "ACCOUNT_PRO" else if (rawPro) "DEVICE_PRO" else "FREE"),
                                        deviceId = doc.getString("deviceId") ?: "",
                                        hardwareId = doc.getString("hardwareId") ?: "",
                                        activeDeviceId = doc.getString("activeDeviceId") ?: (doc.getString("deviceId") ?: ""),
                                        activeDeviceModel = doc.getString("activeDeviceModel") ?: "",
                                        activeSessionToken = doc.getString("activeSessionToken") ?: "",
                                        licenseKey = (doc.getString("licenseKey") ?: "").trim(),
                                        proActivatedSource = proSrc,
                                        bankTransCode = (doc.getString("bankTransCode") ?: "").trim(),
                                        revokedByAdmin = uRevoked,
                                        proActivatedAt = proAt,
                                        lastActive = lastAct,
                                        createdAt = created,
                                        customGeminiKey = rawCustomGemini,
                                        customGroqKey = rawCustomGroq,
                                        customAiKeyRaw = rawCustomAi,
                                        customAiKeyUpdatedAt = customKeyTs
                                    )
                                } catch (_: Throwable) { null }
                            }.sortedWith(
                                compareByDescending<UserProfile> { it.isPro }
                                    .thenByDescending { it.proActivatedAt?.toDate()?.time ?: it.lastActive?.toDate()?.time ?: it.createdAt?.toDate()?.time ?: 0L }
                            )
                            trySend(list)
                        } catch (_: Throwable) {}
                    }
                }
            }
        awaitClose {
            parseJob?.cancel()
            listener.remove()
        }
    }.flowOn(Dispatchers.Default).distinctUntilChanged().conflate()

    /**
     * Lắng nghe danh sách TẤT CẢ Thiết Bị dành cho ADMIN (Chạy hoàn toàn trên Background Executor để 0ms lag UI)
     */
    fun observeAllDevices(context: Context? = null): Flow<List<DeviceRecord>> = callbackFlow {
        var parseJob: kotlinx.coroutines.Job? = null
        val listener = getDb().collection("devices")
            .orderBy(FieldPath.documentId())
            .limit(ADMIN_LIST_PAGE_SIZE)
            .addSnapshotListener(adminSnapshotExecutor) { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Cảnh báo lắng nghe danh sách devices: ${error.message}")
                    if (context != null) {
                        val appCtx = context.applicationContext
                        parseJob?.cancel()
                        parseJob = launch(Dispatchers.IO) {
                            val fallback = fetchAllDevicesViaRest(appCtx)
                            if (fallback.isNotEmpty()) {
                                trySend(fallback)
                            }
                        }
                    }
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val docs = snapshot.documents
                    if (!adminDevicesPageCursor.initialized) {
                        adminDevicesPageCursor.lastDocumentId = docs.lastOrNull()?.id
                        adminDevicesPageCursor.initialized = true
                        adminDevicesPageCursor.exhausted = docs.size < ADMIN_LIST_PAGE_SIZE
                    }
                    parseJob?.cancel()
                    parseJob = launch(Dispatchers.Default) {
                        try {
                            var processedCount = 0
                            val list = docs.mapNotNull { doc ->
                                if ((++processedCount and 31) == 0) yield()
                                try {
                                    val ts = safeGetTimestamp(doc, "lastActive") ?: safeGetTimestamp(doc, "updatedAt")
                                    val created = safeGetTimestamp(doc, "createdAt")
                                    val proAt = safeGetTimestamp(doc, "proActivatedAt")
                                        ?: (doc.getLong("proActivatedMs")?.takeIf { it > 0L }?.let { com.google.firebase.Timestamp(java.util.Date(it)) })
                                    val dKey = (doc.getString("licenseKey") ?: "").trim()
                                    val dReason = (doc.getString("approvedByAiReason") ?: "").trim()
                                    val dTrans = (doc.getString("bankTransCode") ?: "").trim()
                                    val dRevoked = doc.getBoolean("revokedByAdmin") ?: false
                                    val dUpgraded = !dRevoked && (doc.getBoolean("upgradedToAccountPro") ?: false)
                                    val dAccPro = !dRevoked && ((doc.getBoolean("isAccountPro") ?: false) || (doc.getString("proTier") == "ACCOUNT_PRO"))
                                    val effectivePro = !dRevoked && (
                                        (doc.getBoolean("isPro") ?: false) ||
                                            dAccPro ||
                                            dUpgraded ||
                                            dKey.length >= 12
                                        )
                                    val rawDevCustomAi = (doc.getString("customAiKeyRaw") ?: doc.getString("userCustomAiKeys") ?: "").trim()
                                    val rawDevCustomGemini = (doc.getString("customGeminiKey") ?: doc.getString("userGeminiKey") ?: "").trim()
                                    val rawDevCustomGroq = (doc.getString("customGroqKey") ?: doc.getString("userGroqKey") ?: "").trim()
                                    val devCustomKeyTs = safeGetTimestamp(doc, "customAiKeyUpdatedAt")
                                        ?: (doc.getLong("customAiKeyUpdatedMs")?.takeIf { it > 0L }?.let { com.google.firebase.Timestamp(java.util.Date(it)) })
                                    DeviceRecord(
                                        deviceId = doc.getString("deviceId") ?: doc.id,
                                        hardwareId = doc.getString("hardwareId") ?: "",
                                        model = doc.getString("model") ?: "Thiết bị Android",
                                        isPro = effectivePro,
                                        isAccountPro = dAccPro,
                                        upgradedToAccountPro = dUpgraded,
                                        proTier = if (dRevoked) "FREE" else ((doc.getString("proTier")?.takeIf { it.isNotBlank() })
                                            ?: if (dAccPro) "ACCOUNT_PRO" else if (effectivePro) "DEVICE_PRO" else "FREE"),
                                        revokedByAdmin = dRevoked,
                                        ownerUid = doc.getString("ownerUid") ?: "",
                                        ownerEmail = doc.getString("ownerEmail") ?: "👤 Khách vãng lai (Chưa đăng nhập)",
                                        ownerName = doc.getString("ownerName") ?: "Khách vãng lai",
                                        freeTrialUsed = (doc.get("freeTrialUsed") as? Number)?.toInt() ?: 0,
                                        licenseKey = dKey,
                                        approvedByAiReason = dReason,
                                        bankTransCode = dTrans,
                                        lastActive = ts,
                                        createdAt = created,
                                        proActivatedAt = proAt,
                                        customGeminiKey = rawDevCustomGemini,
                                        customGroqKey = rawDevCustomGroq,
                                        customAiKeyRaw = rawDevCustomAi,
                                        customAiKeyUpdatedAt = devCustomKeyTs
                                    )
                                } catch (_: Throwable) { null }
                            }.sortedWith(
                                compareByDescending<DeviceRecord> { it.isPro }
                                    .thenByDescending {
                                        it.proActivatedAt?.toDate()?.time
                                            ?: it.lastActive?.toDate()?.time
                                            ?: it.createdAt?.toDate()?.time
                                            ?: 0L
                                    }
                            )
                            trySend(list)
                        } catch (_: Throwable) {}
                    }
                }
            }
        awaitClose {
            parseJob?.cancel()
            listener.remove()
        }
    }.flowOn(Dispatchers.Default).distinctUntilChanged().conflate()

    /**
     * Lắng nghe danh sách ý định thanh toán / hoạt động khách hàng dành cho ADMIN (Kênh Kép: REST + Realtime SDK)
     */
    fun observePaymentIntents(context: Context? = null): Flow<List<PaymentIntentRecord>> = callbackFlow {
        val db = getDb()
        var parseJob: kotlinx.coroutines.Job? = null
        val listener = db.collection("payment_intents")
            .limit(50)
            .addSnapshotListener(adminSnapshotExecutor) { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Cảnh báo lắng nghe danh sách payment_intents: ${error.message}")
                    if (context != null) {
                        val appCtx = context.applicationContext
                        parseJob?.cancel()
                        parseJob = launch(Dispatchers.IO) {
                            val fallback = fetchPaymentIntentsViaRest(appCtx)
                            if (fallback.isNotEmpty()) {
                                trySend(fallback)
                            }
                        }
                    }
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val docs = snapshot.documents
                    parseJob?.cancel()
                    parseJob = launch(Dispatchers.Default) {
                        try {
                            val rawDocs = docs.mapNotNull { doc ->
                                try {
                                    val rawDeviceId = (doc.getString("deviceId") ?: "").trim().ifBlank {
                                        doc.id.substringBefore("_").trim()
                                    }
                                    val normId = LicenseManager.normalizeDeviceIdForMatch(rawDeviceId)
                                    val canonicalDeviceId = if (normId.isNotBlank()) "MT-$normId" else rawDeviceId
                                    val record = PaymentIntentRecord(
                                        intentId = doc.id,
                                        deviceId = canonicalDeviceId,
                                        model = doc.getString("model") ?: "",
                                        ownerEmail = doc.getString("ownerEmail") ?: "",
                                        ownerName = doc.getString("ownerName") ?: "",
                                        actionType = doc.getString("actionType") ?: "",
                                        details = doc.getString("details") ?: "",
                                        isPro = doc.getBoolean("isPro") ?: false,
                                        timestamp = safeGetTimestamp(doc, "timestamp")
                                    )
                                    Pair(doc, record)
                                } catch (_: Throwable) { null }
                            }

                            val grouped = rawDocs.groupBy { (_, rec) ->
                                LicenseManager.normalizeDeviceIdForMatch(rec.deviceId).ifBlank {
                                    "${rec.ownerEmail.trim().lowercase()}_${rec.model.trim().lowercase()}"
                                }
                            }

                            val deduplicated = mutableListOf<PaymentIntentRecord>()

                            for ((_, docPairs) in grouped) {
                                val sorted = docPairs.sortedWith(
                                    compareByDescending<Pair<com.google.firebase.firestore.DocumentSnapshot, PaymentIntentRecord>> {
                                        it.second.actionType == "CLICKED_I_PAID"
                                    }.thenByDescending {
                                        it.second.timestamp?.toDate()?.time ?: 0L
                                    }
                                )
                                val keeper = sorted.firstOrNull()?.second ?: continue
                                if (!keeper.isPro) {
                                    deduplicated.add(keeper)
                                }
                            }

                            val finalSorted = deduplicated
                                .sortedByDescending { it.timestamp?.toDate()?.time ?: 0L }
                                .take(100)
                            trySend(finalSorted)
                        } catch (_: Throwable) {}
                    }
                }
            }
        awaitClose {
            parseJob?.cancel()
            listener.remove()
        }
    }.flowOn(Dispatchers.Default).distinctUntilChanged().conflate()

    /**
     * Lắng nghe danh sách ỨNG DỤNG TRONG KHO (Kênh Kép: REST + Realtime SDK)
     */
    fun observeHonorApps(context: Context? = null): Flow<List<com.example.data.HonorAppItem>> = callbackFlow {
        var parseJob: kotlinx.coroutines.Job? = null
        val listener = getDb().collection("honor_apps")
            .limit(50)
            .addSnapshotListener(adminSnapshotExecutor) { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Cảnh báo lắng nghe danh sách honor_apps: ${error.message}")
                    if (context != null) {
                        val appCtx = context.applicationContext
                        parseJob?.cancel()
                        parseJob = launch(Dispatchers.IO) {
                            val fallback = fetchHonorAppsViaRest(appCtx)
                            if (fallback.isNotEmpty()) {
                                trySend(fallback)
                            }
                        }
                    }
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val docs = snapshot.documents
                    parseJob?.cancel()
                    parseJob = launch(Dispatchers.Default) {
                        try {
                            var processedCount = 0
                            val list = docs.mapNotNull { doc ->
                                if ((++processedCount and 31) == 0) yield()
                                try {
                                    com.example.data.HonorAppItem(
                                        id = doc.id,
                                        name = doc.getString("name") ?: "",
                                        description = doc.getString("description") ?: "",
                                        downloadUrl = doc.getString("downloadUrl") ?: "",
                                        category = doc.getString("category") ?: "Tiện Ích",
                                        version = doc.getString("version") ?: "1.0",
                                        author = doc.getString("author") ?: "Admin VXM",
                                        isProOnly = doc.getBoolean("isProOnly") ?: false,
                                        iconName = doc.getString("iconName") ?: "apps",
                                        status = doc.getString("status") ?: "APPROVED",
                                        contributorEmail = doc.getString("contributorEmail") ?: "",
                                        createdAt = (doc.get("createdAt") as? Number)?.toLong()
                                            ?: safeGetTimestamp(doc, "createdAt")?.toDate()?.time
                                            ?: 0L
                                    )
                                } catch (_: Throwable) { null }
                            }.sortedByDescending { it.createdAt }
                            trySend(list)
                        } catch (_: Throwable) {}
                    }
                }
            }
        awaitClose {
            parseJob?.cancel()
            listener.remove()
        }
    }.flowOn(Dispatchers.Default).distinctUntilChanged().conflate()

    /**
     * ADMIN: Thêm hoặc Cập nhật ứng dụng vào Kho App (Main-safe withContext(Dispatchers.IO))
     */
    suspend fun saveHonorApp(app: com.example.data.HonorAppItem) = withContext(Dispatchers.IO) {
        kotlinx.coroutines.withTimeoutOrNull(12_000L) {
            val collection = getDb().collection("honor_apps")
            val docRef = if (app.id.isNotBlank()) collection.document(app.id) else collection.document()
            val data = mapOf(
                "id" to docRef.id,
                "name" to app.name.trim(),
                "description" to app.description.trim(),
                "downloadUrl" to app.downloadUrl.trim(),
                "category" to app.category.trim(),
                "version" to app.version.trim(),
                "author" to app.author.trim(),
                "isProOnly" to app.isProOnly,
                "iconName" to app.iconName.trim(),
                "status" to app.status,
                "contributorEmail" to app.contributorEmail,
                "updatedAt" to FieldValue.serverTimestamp(),
                "createdAt" to (if (app.createdAt > 0) app.createdAt else System.currentTimeMillis())
            )
            docRef.set(data, SetOptions.merge()).await()
        }
    }

    /**
     * NGƯỜI DÙNG: Đóng góp ứng dụng vào Kho App (Cần Admin duyệt) (Main-safe withContext(Dispatchers.IO))
     */
    suspend fun contributeHonorApp(app: com.example.data.HonorAppItem) = withContext(Dispatchers.IO) {
        kotlinx.coroutines.withTimeoutOrNull(12_000L) {
            val collection = getDb().collection("honor_apps")
            val docRef = collection.document()
            val data = mapOf(
                "id" to docRef.id,
                "name" to app.name.trim(),
                "description" to app.description.trim(),
                "downloadUrl" to app.downloadUrl.trim(),
                "category" to app.category.trim(),
                "version" to app.version.trim(),
                "author" to app.author.trim(),
                "isProOnly" to app.isProOnly,
                "iconName" to app.iconName.trim(),
                "status" to "PENDING",
                "contributorEmail" to (getCurrentUser()?.email ?: ""),
                "createdAt" to System.currentTimeMillis()
            )
            docRef.set(data).await()
        }
    }

    /**
     * ADMIN: Duyệt hoặc Từ chối ứng dụng (Main-safe withContext(Dispatchers.IO))
     */
    suspend fun updateHonorAppStatus(appId: String, newStatus: String) = withContext(Dispatchers.IO) {
        kotlinx.coroutines.withTimeoutOrNull(10_000L) {
            getDb().collection("honor_apps").document(appId)
                .update("status", newStatus)
                .await()
        }
    }

    /**
     * ADMIN: Xóa ứng dụng khỏi Kho App (Main-safe withContext(Dispatchers.IO))
     */
    suspend fun deleteHonorApp(appId: String) = withContext(Dispatchers.IO) {
        if (appId.isNotBlank()) {
            kotlinx.coroutines.withTimeoutOrNull(10_000L) {
                getDb().collection("honor_apps").document(appId).delete().await()
            }
        }
    }

    /**
     * ADMIN: Nâng cấp một tài khoản bất kỳ lên làm ADMIN (Main-safe withContext(Dispatchers.IO))
     */
    suspend fun upgradeUserToAdmin(targetUserId: String) = withContext(Dispatchers.IO) {
        kotlinx.coroutines.withTimeoutOrNull(10_000L) {
            getDb().collection("users").document(targetUserId)
                .update(
                    mapOf(
                        "role" to "admin",
                        "isPro" to true,
                        "isAccountPro" to true,
                        "proTier" to "ACCOUNT_PRO",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
        }
    }

    /**
     * ADMIN: Kích hoạt / Hủy bản PRO TÀI KHOẢN (Account Pro - Đổi máy tự do, 1 máy hoạt động) cho một tài khoản (Main-safe withContext(Dispatchers.IO))
     */
    suspend fun toggleUserProStatus(targetUserId: String, isPro: Boolean, deviceId: String = "") = withContext(Dispatchers.IO) {
        kotlinx.coroutines.withTimeoutOrNull(15_000L) {
            val resolvedDeviceId = if (deviceId.isNotBlank()) {
                deviceId
            } else {
                try {
                    val doc = getDb().collection("users").document(targetUserId).get().await()
                    doc.getString("activeDeviceId") ?: doc.getString("deviceId") ?: ""
                } catch (_: Exception) { "" }
            }

            if (!isPro) {
                val userEmail = try {
                    getDb().collection("users").document(targetUserId).get().await().getString("email") ?: ""
                } catch (_: Exception) { "" }
                LicenseManager.adminRevokeProCompletely(
                    userId = targetUserId,
                    deviceId = resolvedDeviceId,
                    ownerEmail = userEmail
                )
                return@withTimeoutOrNull
            }

            val userEmail = try {
                getDb().collection("users").document(targetUserId).get().await().getString("email") ?: ""
            } catch (_: Exception) { "" }

            LicenseManager.adminGrantTierForUserOrDevice(
                userId = targetUserId,
                deviceId = resolvedDeviceId,
                ownerEmail = userEmail,
                grantAccountPro = true
            )

            val userMap = mutableMapOf<String, Any>(
                "appId" to "magictune",
                "product" to "MAGICTUNE_PRO",
                "magictunePro" to true,
                "magictuneTier" to "ACCOUNT_PRO",
                "isPro" to true,
                "isAccountPro" to true,
                "proTier" to "ACCOUNT_PRO",
                "proActivatedSource" to "ADMIN_MANUAL_GRANT_ACCOUNT_PRO",
                "approvedByAiReason" to "ADMIN_MANUAL_GRANT_ACCOUNT_PRO",
                "proActivatedAt" to FieldValue.serverTimestamp(),
                "proActivatedMs" to System.currentTimeMillis(),
                "revokedByAdmin" to false,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            getDb().collection("users").document(targetUserId).set(userMap, SetOptions.merge()).await()

            if (resolvedDeviceId.isNotBlank()) {
                val cleanId = resolvedDeviceId.trim().uppercase()
                val devMap = mutableMapOf<String, Any>(
                    "deviceId" to cleanId,
                    "appId" to "magictune",
                    "product" to "MAGICTUNE_PRO",
                    "magictunePro" to true,
                    "isPro" to true,
                    "isAccountPro" to true,
                    "upgradedToAccountPro" to true,
                    "proTier" to "ACCOUNT_PRO",
                    "revokedByAdmin" to false,
                    "approvedByAiReason" to "ADMIN_MANUAL_GRANT_ACCOUNT_PRO",
                    "licenseKey" to LicenseManager.generateAccountProLicenseKeyForDevice(cleanId),
                    "proActivatedAt" to FieldValue.serverTimestamp(),
                    "proActivatedMs" to System.currentTimeMillis(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                getDb().collection("devices").document(cleanId).set(devMap, SetOptions.merge()).await()
                val normId = LicenseManager.normalizeDeviceIdForMatch(cleanId)
                if (normId.isNotBlank() && normId != cleanId) {
                    getDb().collection("devices").document(normId).set(devMap, SetOptions.merge())
                }
            }
        }
    }

    /**
     * ADMIN: Cấp Pro cho một thiết bị có kiểm tra xem thiết bị đó đã tồn tại (đã cài app/đồng bộ) trên hệ thống chưa.
     * Ném ngoại lệ nếu thiết bị không tồn tại, ngăn chặn việc admin nhập nhầm ID ảo (Main-safe withContext(Dispatchers.IO)).
     */
    suspend fun verifyAndToggleDeviceProStatus(deviceId: String, isPro: Boolean): Boolean = withContext(Dispatchers.IO) {
        if (deviceId.isBlank()) throw IllegalArgumentException("Device ID không được để trống!")
        val cleanId = deviceId.trim().uppercase()
        val normId = LicenseManager.normalizeDeviceIdForMatch(cleanId)
        val docRef = getDb().collection("devices").document(cleanId)
        val snapshot = kotlinx.coroutines.withTimeoutOrNull(8_000L) { docRef.get().await() }

        val existsInDevices = if (snapshot != null && snapshot.exists()) {
            true
        } else {
            val allDevs = try {
                kotlinx.coroutines.withTimeoutOrNull(8_000L) { getDb().collection("devices").get().await() }
            } catch (_: Exception) { null }
            allDevs?.documents?.any {
                LicenseManager.normalizeDeviceIdForMatch(it.getString("deviceId") ?: it.id) == normId
            } == true
        }

        if (isPro && !existsInDevices) {
            throw IllegalStateException("Không tìm thấy thiết bị '$cleanId' trên hệ thống! Thiết bị này chưa cài đặt ứng dụng hoặc chưa đồng bộ dữ liệu, không thể kích hoạt Pro.")
        }

        if (!isPro) {
            LicenseManager.adminRevokeProCompletely(deviceId = cleanId)
            return@withContext true
        }

        val updateMap = mutableMapOf<String, Any>(
            "deviceId" to cleanId,
            "appId" to "magictune",
            "product" to "MAGICTUNE_PRO",
            "magictunePro" to true,
            "isPro" to true,
            "revokedByAdmin" to false,
            "approvedByAiReason" to "ADMIN_MANUAL_GRANT_DEVICE_PRO",
            "licenseKey" to LicenseManager.generateLicenseKeyForDevice(cleanId),
            "proActivatedAt" to FieldValue.serverTimestamp(),
            "proActivatedMs" to System.currentTimeMillis(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        kotlinx.coroutines.withTimeoutOrNull(10_000L) {
            docRef.set(updateMap, SetOptions.merge()).await()
            if (normId.isNotBlank() && normId != cleanId) {
                getDb().collection("devices").document(normId).set(updateMap, SetOptions.merge())
            }
        }
        true
    }

    /**
     * ADMIN: Cấp Pro hoặc GỠ QUYỀN PRO trực tiếp trên một thiết bị bất kỳ (Kể cả thiết bị ẩn danh)
     * Đồng thời đồng bộ sang bảng `users` và vô hiệu hóa toàn bộ lịch sử AI / khôi phục nếu hạ cấp (Main-safe withContext(Dispatchers.IO)).
     */
    suspend fun toggleDeviceProStatus(
        deviceId: String,
        isPro: Boolean,
        context: Context? = null,
        userId: String = "",
        ownerEmail: String = ""
    ) = withContext(Dispatchers.IO) {
        if (deviceId.isBlank()) return@withContext
        val cleanId = deviceId.trim().uppercase()
        if (!isPro) {
            LicenseManager.adminRevokeProCompletely(
                context = context,
                userId = userId,
                deviceId = cleanId,
                ownerEmail = ownerEmail
            )
            return@withContext
        }
        val normId = LicenseManager.normalizeDeviceIdForMatch(cleanId)
        val docRef = getDb().collection("devices").document(cleanId)
        val updateMap = mutableMapOf<String, Any>(
            "deviceId" to cleanId,
            "appId" to "magictune",
            "product" to "MAGICTUNE_PRO",
            "magictunePro" to true,
            "isPro" to true,
            "revokedByAdmin" to false,
            "approvedByAiReason" to "ADMIN_MANUAL_GRANT_DEVICE_PRO",
            "licenseKey" to LicenseManager.generateLicenseKeyForDevice(cleanId),
            "proActivatedAt" to FieldValue.serverTimestamp(),
            "proActivatedMs" to System.currentTimeMillis(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        kotlinx.coroutines.withTimeoutOrNull(10_000L) {
            docRef.set(updateMap, SetOptions.merge()).await()
            if (normId.isNotBlank() && normId != cleanId) {
                getDb().collection("devices").document(normId).set(updateMap, SetOptions.merge())
            }
        }

        try {
            val allUsers = kotlinx.coroutines.withTimeoutOrNull(8_000L) { getDb().collection("users").get().await() }
            if (allUsers != null) {
                for (uDoc in allUsers.documents) {
                    val uAct = LicenseManager.normalizeDeviceIdForMatch(uDoc.getString("activeDeviceId") ?: "")
                    val uDev = LicenseManager.normalizeDeviceIdForMatch(uDoc.getString("deviceId") ?: "")
                    if (normId.isNotBlank() && (uAct == normId || uDev == normId)) {
                        uDoc.reference.set(
                            mapOf(
                                "isPro" to true,
                                "proActivatedSource" to "ADMIN_MANUAL_GRANT_DEVICE_PRO",
                                "proActivatedAt" to FieldValue.serverTimestamp(),
                                "proActivatedMs" to System.currentTimeMillis(),
                                "revokedByAdmin" to false,
                                "updatedAt" to FieldValue.serverTimestamp()
                            ),
                            SetOptions.merge()
                        )
                    }
                }
            }
        } catch (_: Exception) {}
    }

    /**
     * Đăng xuất Firebase Auth & Credential Manager an toàn trên Main Thread (Chống đơ/trắng màn hình)
     * Đồng thời thu hồi phiên Pro Tài Khoản trên thiết bị vừa đăng xuất để tài khoản có thể đăng nhập sang máy khác.
     */
    fun signOut(context: Context, credentialManager: CredentialManager, scope: CoroutineScope, onComplete: () -> Unit) {
        try {
            singleDeviceListener?.remove()
            singleDeviceListener = null
            watchedUserId = null
            Firebase.auth.signOut()
            val prefs = context.getSharedPreferences("magictune_pro_prefs", Context.MODE_PRIVATE)
            prefs.edit()
                .remove("current_user_role")
                .remove("current_user_email")
                .remove(LicenseManager.KEY_ACTIVE_SESSION_TOKEN)
                .apply()
            persistAndEmitAuthSession(context, null)
            LicenseManager.clearLocalAdminSession(context)
            LicenseManager.deactivateAccountProOnLogout(context)
            LicenseManager.syncDevicePresenceToCloud(context)
        } catch (_: Exception) {}

        scope.launch(Dispatchers.IO) {
            try {
                credentialManager.clearCredentialState(ClearCredentialStateRequest())
            } catch (e: Exception) {
                Log.e(TAG, "Lỗi xóa CredentialState", e)
            } finally {
                withContext(Dispatchers.Main) {
                    onComplete()
                }
            }
        }
    }

    /**
     * Đăng nhập tương tác bằng Google Sign-In via Credential Manager
     */
    fun signInWithGoogle(
        context: Context,
        credentialManager: CredentialManager,
        scope: CoroutineScope,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        ensureFirebaseInitialized(context)
        val clientId = try {
            val resId = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
            if (resId != 0) context.getString(resId) else ""
        } catch (e: Exception) {
            ""
        }
        if (clientId.isBlank()) {
            onError("Chưa cấu hình Web Client ID cho Google Sign-In!")
            return
        }

        val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
        val request = GetCredentialRequest.Builder().addCredentialOption(signInOption).build()

        scope.launch {
            try {
                lastLoginTimestampMs = System.currentTimeMillis()
                val result = credentialManager.getCredential(context, request)
                val credential = result.credential
                if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                    val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                    Firebase.auth.signInWithCredential(authCredential).await()
                    try {
                        syncUserProfile(context)
                    } catch (e: Exception) {
                        Log.w(TAG, "syncUserProfile sau Google Sign-In gặp lỗi: ${e.message}")
                    }
                    LicenseManager.notifyProAndConfigStateChanged(context)
                    onSuccess()
                } else {
                    onError("Loại xác thực Google không phù hợp!")
                }
            } catch (e: GetCredentialCancellationException) {
                Log.w(TAG, "Đăng nhập Google bị hủy: ${e.message}")
                onError("Đã hủy thao tác đăng nhập Google!")
            } catch (e: androidx.credentials.exceptions.NoCredentialException) {
                Log.w(TAG, "Không tìm thấy tài khoản Google khả dụng: ${e.message}")
                onError("Chưa có tài khoản Google trên máy. Vui lòng thêm hoặc bật tài khoản Google trong Cài đặt rồi thử lại!")
            } catch (e: Exception) {
                Log.e(TAG, "Đăng nhập Google thất bại", e)
                onError(translateAuthError(e))
            }
        }
    }

    /**
     * Dịch toàn bộ thông báo lỗi từ FirebaseAuth sang Tiếng Việt chuẩn xác, thân thiện (100% Tiếng Việt)
     */
    fun translateAuthError(e: Throwable?): String {
        if (e == null) return "Vui lòng kiểm tra lại thông tin Email và Mật khẩu!"
        val msg = e.message ?: ""
        val lower = msg.lowercase()
        return when {
            lower.contains("invalid-credential") || lower.contains("wrong-password") || lower.contains("invalid_login_credentials") || lower.contains("password is invalid") ->
                "Email hoặc Mật khẩu không chính xác. Nếu bạn chưa có tài khoản, vui lòng chọn 'Chưa có tài khoản? Đăng ký mới'!"
            lower.contains("user-not-found") || lower.contains("no user record") ->
                "Tài khoản Email này chưa được đăng ký trong hệ thống. Vui lòng chọn 'Đăng ký mới' phía trên!"
            lower.contains("email-already-in-use") || lower.contains("email-already-exists") || lower.contains("already in use") ->
                "Địa chỉ Email này đã được sử dụng. Vui lòng bấm 'Đăng nhập ngay' hoặc sử dụng tính năng 'Quên mật khẩu'!"
            lower.contains("invalid-email") || lower.contains("badly formatted") || lower.contains("formatted") ->
                "Địa chỉ Email không đúng định dạng chuẩn (ví dụ: user@gmail.com)!"
            lower.contains("weak-password") || lower.contains("at least 6 characters") ->
                "Mật khẩu quá ngắn. Vui lòng đặt mật khẩu từ 6 ký tự trở lên!"
            lower.contains("user-disabled") || lower.contains("disabled") ->
                "Tài khoản này đã bị tạm khóa bởi quản trị viên hệ thống."
            lower.contains("too-many-requests") || lower.contains("blocked all requests") ->
                "Bạn đã thử nhập sai quá nhiều lần. Vui lòng chờ 1-2 phút rồi thử lại để bảo mật tài khoản!"
            lower.contains("network") || lower.contains("timeout") || lower.contains("connection") || lower.contains("unreachable") ->
                "Lỗi kết nối mạng. Vui lòng kiểm tra kết nối Wi-Fi hoặc 4G/5G trên thiết bị!"
            lower.contains("recent-login-required") || lower.contains("requires-recent-login") ->
                "Vì lý do bảo mật, bạn cần đăng nhập lại trước khi thực hiện thao tác này!"
            lower.contains("operation-not-allowed") ->
                "Phương thức đăng nhập này chưa được kích hoạt trên hệ thống."
            lower.contains("no credentials available") || lower.contains("canceled") || lower.contains("cancelled") ->
                "Thao tác đăng nhập đã bị hủy hoặc chưa chọn tài khoản!"
            else ->
                "Đăng nhập thất bại. Vui lòng kiểm tra địa chỉ Email, Mật khẩu và kết nối mạng!"
        }
    }

    suspend fun signInWithEmail(email: String, pass: String): FirebaseUser = withContext(Dispatchers.IO) {
        val cleanEmail = email.replace(Regex("\\s+"), "").lowercase()
        lastLoginTimestampMs = System.currentTimeMillis()
        try {
            val res = Firebase.auth.signInWithEmailAndPassword(cleanEmail, pass).await()
            return@withContext res.user ?: throw IllegalStateException("Đăng nhập bằng Email thất bại!")
        } catch (e: Exception) {
            if (pass.trim() != pass && pass.trim().isNotEmpty()) {
                val resRetry = Firebase.auth.signInWithEmailAndPassword(cleanEmail, pass.trim()).await()
                return@withContext resRetry.user ?: throw e
            }
            throw e
        }
    }

    /**
     * Đăng ký tài khoản mới bằng Email & Mật khẩu
     */
    suspend fun signUpWithEmail(email: String, pass: String, name: String): FirebaseUser = withContext(Dispatchers.IO) {
        val cleanEmail = email.replace(Regex("\\s+"), "").lowercase()
        lastLoginTimestampMs = System.currentTimeMillis()
        val user = try {
            val res = Firebase.auth.createUserWithEmailAndPassword(cleanEmail, pass).await()
            res.user ?: throw IllegalStateException("Tạo tài khoản thất bại!")
        } catch (e: Exception) {
            val lower = (e.message ?: "").lowercase()
            if (lower.contains("email-already-in-use") || lower.contains("email-already-exists")) {
                // Nếu người dùng đã có tài khoản nhưng bấm nhầm nút Đăng ký và nhập đúng mật khẩu -> Tự động Đăng nhập luôn!
                try {
                    return@withContext signInWithEmail(cleanEmail, pass)
                } catch (_: Exception) {
                    throw e
                }
            }
            throw e
        }
        if (name.isNotBlank()) {
            try {
                val req = com.google.firebase.auth.userProfileChangeRequest {
                    this.displayName = name.trim()
                }
                user.updateProfile(req).await()
            } catch (_: Exception) {}
        }
        return@withContext user
    }

    /**
     * Gửi email khôi phục mật khẩu (Quên mật khẩu)
     */
    suspend fun sendPasswordResetEmail(email: String) = withContext(Dispatchers.IO) {
        val cleanEmail = email.replace(Regex("\\s+"), "").lowercase()
        Firebase.auth.sendPasswordResetEmail(cleanEmail).await()
        Unit
    }
}
