package com.example.core.printer

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfRenderer
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.roundToInt

enum class ConnectionType {
    WIFI_LAN,
    BLUETOOTH
}

enum class PrintSourceMode {
    FILE_OR_SHARED,
    CUSTOM_RECEIPT,
    TEST_SAMPLE
}

data class PairedBluetoothPrinter(
    val name: String,
    val address: String,
    val isLikelyPrinter: Boolean
)

data class CustomReceiptData(
    val shopName: String = "CỬA HÀNG MAGICTUNE PRO",
    val shopHotline: String = "SĐT / Zalo: 0988.888.888",
    val customerInfo: String = "Khách lẻ / Giao hàng nhanh",
    val itemsContent: String = "1x Dịch vụ Tinh chỉnh Honor MagicOS\n1x Cài đặt Full Thông báo & Google\n1x Tối ưu Màn hình 120Hz/144Hz",
    val codAmount: String = "0 VNĐ (ĐÃ THANH TOÁN)",
    val footerNote: String = "Cảm ơn Quý khách! Hẹn gặp lại!",
    val showFrameBox: Boolean = true
)

data class PrinterConfig(
    val connectionType: ConnectionType = ConnectionType.WIFI_LAN,
    val ip: String = "192.168.1.200",
    val port: Int = 9100,
    val bluetoothAddress: String = "",
    val bluetoothName: String = "",
    val paperWidthDots: Int = 576, // 576 dots (K80 - 80mm), 512 dots (K76/K80 hẹp), 384 dots (K57/K58 - 58mm)
    val autoCut: Boolean = true,
    val densityLevel: Int = 3, // 1: Nhạt, 2: Vừa, 3: Đậm chuẩn QR (mặc định), 4: Đậm tăng cường, 5: Cực đậm
    val boldFontDilation: Boolean = false, // Làm dày nét chữ thông minh (+1 dot) & Bảo vệ 100% mã vạch/QR
    val autoTrimBottom: Boolean = true, // Tự động cắt khoảng trắng thừa cuối hóa đơn/đơn hàng
    val openCashDrawer: Boolean = false, // Kích mở ngăn kéo đựng tiền thu ngân (RJ11)
    val feedLinesAfterPrint: Int = 2,
    val marginLeftDots: Int = 0,
    val marginRightDots: Int = 0,
    val copiesCount: Int = 1
)

object EscPosThermalPrinter {

    private const val PREFS_NAME = "magictune_printer_prefs"

    // Standard SPP UUID for Bluetooth Serial Printers
    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    fun loadSavedConfig(context: Context): PrinterConfig {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val connStr = prefs.getString("connection_type", ConnectionType.WIFI_LAN.name) ?: ConnectionType.WIFI_LAN.name
        val connType = try {
            ConnectionType.valueOf(connStr)
        } catch (_: Exception) {
            ConnectionType.WIFI_LAN
        }
        return PrinterConfig(
            connectionType = connType,
            ip = prefs.getString("printer_ip", "192.168.1.200") ?: "192.168.1.200",
            port = prefs.getInt("printer_port", 9100),
            bluetoothAddress = prefs.getString("bt_address", "") ?: "",
            bluetoothName = prefs.getString("bt_name", "") ?: "",
            paperWidthDots = prefs.getInt("paper_width_dots", 576),
            autoCut = prefs.getBoolean("auto_cut", true),
            densityLevel = prefs.getInt("density_level", 3).coerceIn(1, 5),
            boldFontDilation = prefs.getBoolean("bold_dilation", false),
            autoTrimBottom = prefs.getBoolean("auto_trim_bottom", true),
            openCashDrawer = prefs.getBoolean("open_cash_drawer", false),
            feedLinesAfterPrint = prefs.getInt("feed_lines", 2).coerceIn(0, 8),
            marginLeftDots = prefs.getInt("margin_left_dots", 0).coerceIn(0, 80),
            marginRightDots = prefs.getInt("margin_right_dots", 0).coerceIn(0, 80),
            copiesCount = prefs.getInt("copies_count", 1).coerceIn(1, 10)
        )
    }

    fun saveConfig(context: Context, config: PrinterConfig) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().apply {
            putString("connection_type", config.connectionType.name)
            putString("printer_ip", config.ip.trim())
            putInt("printer_port", config.port)
            putString("bt_address", config.bluetoothAddress)
            putString("bt_name", config.bluetoothName)
            putInt("paper_width_dots", config.paperWidthDots)
            putBoolean("auto_cut", config.autoCut)
            putInt("density_level", config.densityLevel.coerceIn(1, 5))
            putBoolean("bold_dilation", config.boldFontDilation)
            putBoolean("auto_trim_bottom", config.autoTrimBottom)
            putBoolean("open_cash_drawer", config.openCashDrawer)
            putInt("feed_lines", config.feedLinesAfterPrint.coerceIn(0, 8))
            putInt("margin_left_dots", config.marginLeftDots.coerceIn(0, 80))
            putInt("margin_right_dots", config.marginRightDots.coerceIn(0, 80))
            putInt("copies_count", config.copiesCount.coerceIn(1, 10))
            apply()
        }
    }

    fun getSavedIpHistory(context: Context): List<String> {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString("saved_ip_history", "192.168.1.200,192.168.1.199") ?: ""
        return raw.split(",").map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(6)
    }

    fun addIpToHistory(context: Context, ip: String) {
        val clean = normalizeIpv4Address(ip)
        if (clean.isBlank()) return
        val current = getSavedIpHistory(context).toMutableList()
        current.remove(clean)
        current.add(0, clean)
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString("saved_ip_history", current.take(6).joinToString(","))
            .apply()
    }

    fun loadCustomReceiptData(context: Context): CustomReceiptData {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return CustomReceiptData(
            shopName = prefs.getString("custom_shop_name", "CỬA HÀNG MAGICTUNE PRO") ?: "CỬA HÀNG MAGICTUNE PRO",
            shopHotline = prefs.getString("custom_shop_hotline", "SĐT / Zalo: 0988.888.888") ?: "SĐT / Zalo: 0988.888.888",
            customerInfo = prefs.getString("custom_customer_info", "Khách lẻ / Giao hàng nhanh") ?: "Khách lẻ / Giao hàng nhanh",
            itemsContent = prefs.getString(
                "custom_items_content",
                "1x Tinh chỉnh Honor MagicOS Toàn Diện\n1x Mở khóa 100% Thông báo Zalo/FB\n1x Khóa màn hình 120Hz/144Hz mượt"
            ) ?: "",
            codAmount = prefs.getString("custom_cod_amount", "0 VNĐ (ĐÃ THANH TOÁN)") ?: "0 VNĐ (ĐÃ THANH TOÁN)",
            footerNote = prefs.getString("custom_footer_note", "Cảm ơn Quý khách! Hẹn gặp lại!") ?: "Cảm ơn Quý khách! Hẹn gặp lại!",
            showFrameBox = prefs.getBoolean("custom_show_frame", true)
        )
    }

    fun saveCustomReceiptData(context: Context, data: CustomReceiptData) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().apply {
            putString("custom_shop_name", data.shopName)
            putString("custom_shop_hotline", data.shopHotline)
            putString("custom_customer_info", data.customerInfo)
            putString("custom_items_content", data.itemsContent)
            putString("custom_cod_amount", data.codAmount)
            putString("custom_footer_note", data.footerNote)
            putBoolean("custom_show_frame", data.showFrameBox)
            apply()
        }
    }

    private fun getBluetoothAdapter(context: Context? = null): BluetoothAdapter? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && context != null) {
            val bm = context.getSystemService(android.bluetooth.BluetoothManager::class.java)
            bm?.adapter
        } else {
            @Suppress("DEPRECATION")
            BluetoothAdapter.getDefaultAdapter()
        }
    }

    fun hasBluetoothPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    @SuppressLint("MissingPermission")
    fun getPairedBluetoothPrinters(context: Context): List<PairedBluetoothPrinter> {
        if (!hasBluetoothPermission(context)) return emptyList()
        val adapter = getBluetoothAdapter(context) ?: return emptyList()
        val bonded = try {
            adapter.bondedDevices ?: emptySet()
        } catch (_: Exception) {
            emptySet()
        }
        val printerKeywords = listOf(
            "print", "pos", "mtp", "rpp", "xp-", "xprinter", "gprinter",
            "hprt", "zy-", "k80", "k58", "k57", "bt-", "spp", "thermal", "bill"
        )
        return bonded.map { dev ->
            val devName = try {
                dev.name?.takeIf { it.isNotBlank() } ?: "Thiết bị Bluetooth (${dev.address.takeLast(5)})"
            } catch (_: Exception) {
                "Thiết bị Bluetooth (${dev.address.takeLast(5)})"
            }
            val majorClass = try {
                dev.bluetoothClass?.majorDeviceClass ?: 0
            } catch (_: Exception) {
                0
            }
            val isImaging = majorClass == BluetoothClass.Device.Major.IMAGING
            val matchesKeyword = printerKeywords.any { kw -> devName.lowercase().contains(kw) }
            PairedBluetoothPrinter(
                name = devName,
                address = dev.address,
                isLikelyPrinter = isImaging || matchesKeyword
            )
        }.sortedWith(compareByDescending<PairedBluetoothPrinter> { it.isLikelyPrinter }.thenBy { it.name })
    }

    /**
     * Lấy địa chỉ IPv4 Wi-Fi hiện tại của điện thoại để người dùng dễ đối chiếu dải mạng với máy in
     */
    fun getPhoneWifiIpAddress(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (iface.isUp && !iface.isLoopback && (iface.name.contains("wlan", true) || iface.name.contains("eth", true))) {
                    val addrs = iface.inetAddresses
                    while (addrs.hasMoreElements()) {
                        val a = addrs.nextElement()
                        if (a is java.net.Inet4Address && !a.isLoopbackAddress) {
                            return a.hostAddress ?: "Chưa rõ"
                        }
                    }
                }
            }
        } catch (_: Exception) {}
        return "Chưa kết nối Wi-Fi"
    }

    /**
     * Tạo hóa đơn mẫu chuẩn thương mại để test ngay lập tức mà không cần phải tìm ảnh bên ngoài
     */
    fun createSampleReceiptBitmap(paperWidthDots: Int): Bitmap {
        val width = paperWidthDots.coerceAtLeast(384)
        val isK80 = width >= 500
        val height = if (isK80) 560 else 510
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)

        val paint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
        }

        val pad = 18f
        val nowStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())

        // Viền khung ngoài chuẩn phiếu vận đơn thương mại
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        canvas.drawRoundRect(RectF(8f, 8f, width - 8f, height - 12f), 12f, 12f, paint)
        paint.style = Paint.Style.FILL

        // Header
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = if (isK80) 30f else 22f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("MAGICTUNE THERMAL PRO", width / 2f, 52f, paint)

        paint.textSize = if (isK80) 20f else 15f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("BẢN IN KIỂM TRA ĐẦU NHIỆT & ĐỘ NÉT", width / 2f, 84f, paint)

        paint.strokeWidth = 2f
        canvas.drawLine(pad, 102f, width - pad, 102f, paint)

        // Thông tin kỹ thuật
        paint.textAlign = Paint.Align.LEFT
        paint.textSize = if (isK80) 20f else 15f
        val khogiay = when {
            width >= 576 -> "K80 Chuẩn (80mm - 576 dots)"
            width >= 512 -> "K80/K76 (76mm - 512 dots)"
            else -> "K57/K58 (58mm - 384 dots)"
        }
        canvas.drawText("• Khổ giấy: $khogiay", pad, 136f, paint)
        canvas.drawText("• Thời gian: $nowStr", pad, 166f, paint)
        canvas.drawText("• Giao thức: ESC/POS Raster GS v 0", pad, 196f, paint)

        canvas.drawLine(pad, 214f, width - pad, 214f, paint)

        // Danh mục kiểm tra nét chữ
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = if (isK80) 22f else 16f
        canvas.drawText("1. Đơn hàng Shopee / TikTok Shop   [OK]", pad, 250f, paint)
        canvas.drawText("2. Tiếng Việt có dấu rõ nét 100%   [OK]", pad, 284f, paint)
        canvas.drawText("3. Bảo vệ khoảng trắng Mã Vạch/QR [OK]", pad, 318f, paint)

        canvas.drawLine(pad, 338f, width - pad, 338f, paint)

        // Vẽ mã vạch 1D mô phỏng để kiểm tra độ tách vạch của đầu nhiệt
        val barcodeTop = 356f
        val barcodeBottom = 426f
        val barAreaWidth = width - (pad * 2) - 40f
        var curX = pad + 20f
        val barPattern = intArrayOf(4, 2, 6, 3, 2, 4, 8, 2, 3, 5, 2, 4, 6, 2, 3, 4, 2, 6, 3, 3, 5, 2, 4, 2, 6, 3, 2, 4)
        var isBlackBar = true
        for (wUnit in barPattern) {
            val bw = wUnit * (if (isK80) 3.2f else 2.0f)
            if (curX + bw > pad + 20f + barAreaWidth) break
            if (isBlackBar) {
                canvas.drawRect(curX, barcodeTop, curX + bw, barcodeBottom, paint)
            }
            curX += bw
            isBlackBar = !isBlackBar
        }

        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        paint.textSize = if (isK80) 19f else 14f
        canvas.drawText("MT-88992026-VN", width / 2f, 452f, paint)

        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = if (isK80) 22f else 17f
        canvas.drawText("TRẠNG THÁI: SẴN SÀNG IN THƯƠNG MẠI", width / 2f, 492f, paint)

        if (isK80) {
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            paint.textSize = 17f
            canvas.drawText("Cảm ơn bạn đã sử dụng MagicTune Tool!", width / 2f, 526f, paint)
        }

        return bmp
    }

    /**
     * Tạo Bitmap Hóa đơn / Phiếu giao hàng tùy chỉnh do người dùng tự nhập
     */
    fun createCustomReceiptBitmap(paperWidthDots: Int, data: CustomReceiptData): Bitmap {
        val width = paperWidthDots.coerceAtLeast(384)
        val isK80 = width >= 500
        val pad = 20f
        val contentWidth = width - pad * 2

        val titleSize = if (isK80) 29f else 21f
        val subSize = if (isK80) 20f else 15f
        val bodySize = if (isK80) 22f else 16f
        val codSize = if (isK80) 26f else 19f

        val textPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = bodySize
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }

        // Tách dòng thông minh cho phần nội dung mặt hàng
        val wrappedLines = mutableListOf<String>()
        val rawLines = data.itemsContent.lines().filter { it.isNotBlank() }
        for (line in rawLines) {
            var current = ""
            for (word in line.split(" ")) {
                val candidate = if (current.isEmpty()) word else "$current $word"
                if (textPaint.measureText(candidate) <= contentWidth - 12f) {
                    current = candidate
                } else {
                    if (current.isNotEmpty()) wrappedLines.add(current)
                    current = word
                }
            }
            if (current.isNotEmpty()) wrappedLines.add(current)
        }
        if (wrappedLines.isEmpty()) {
            wrappedLines.add("(Chưa nhập nội dung đơn hàng)")
        }

        val lineSpacing = if (isK80) 34f else 26f
        val totalHeight = (360f + wrappedLines.size * lineSpacing).roundToInt().coerceAtLeast(420)

        val bmp = Bitmap.createBitmap(width, totalHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)

        val paint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
        }

        if (data.showFrameBox) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f
            canvas.drawRoundRect(RectF(8f, 8f, width - 8f, totalHeight - 10f), 12f, 12f, paint)
            paint.style = Paint.Style.FILL
        }

        var y = 48f
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = titleSize
        canvas.drawText(data.shopName.ifBlank { "PHIẾU GIAO HÀNG / HÓA ĐƠN" }, width / 2f, y, paint)

        if (data.shopHotline.isNotBlank()) {
            y += if (isK80) 30f else 24f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            paint.textSize = subSize
            canvas.drawText(data.shopHotline, width / 2f, y, paint)
        }

        y += 18f
        paint.strokeWidth = 2f
        canvas.drawLine(pad, y, width - pad, y, paint)

        val nowStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
        y += if (isK80) 30f else 24f
        paint.textAlign = Paint.Align.LEFT
        paint.textSize = subSize
        canvas.drawText("Ngày in: $nowStr", pad, y, paint)

        if (data.customerInfo.isNotBlank()) {
            y += if (isK80) 28f else 22f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("KH: ${data.customerInfo}", pad, y, paint)
        }

        y += 16f
        canvas.drawLine(pad, y, width - pad, y, paint)

        // Danh sách mặt hàng
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = bodySize
        for (itemLine in wrappedLines) {
            y += lineSpacing
            canvas.drawText(itemLine, pad, y, paint)
        }

        y += 18f
        canvas.drawLine(pad, y, width - pad, y, paint)

        // Tổng thu COD
        if (data.codAmount.isNotBlank()) {
            y += if (isK80) 36f else 28f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = codSize
            canvas.drawText("THU HỘ / TỔNG: ${data.codAmount}", pad, y, paint)
        }

        // Lời cảm ơn
        if (data.footerNote.isNotBlank()) {
            y += if (isK80) 38f else 30f
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
            paint.textSize = subSize
            canvas.drawText(data.footerNote, width / 2f, y, paint)
        }

        return bmp
    }

    /**
     * Chuẩn hóa IPv4 loại bỏ số 0 ở đầu mỗi octet (VD: "192.168.001.087" -> "192.168.1.87").
     */
    fun normalizeIpv4Address(rawIp: String): String {
        val clean = rawIp.trim()
        val parts = clean.split(".")
        if (parts.size == 4 && parts.all { it.isNotEmpty() && it.all { char -> char.isDigit() } }) {
            val normalizedParts = parts.mapNotNull { it.toIntOrNull()?.toString() }
            if (normalizedParts.size == 4) {
                return normalizedParts.joinToString(".")
            }
        }
        return clean
    }

    /**
     * Tạo Socket kết nối trực tiếp qua giao diện mạng Wi-Fi thực (Hardware Wi-Fi Interface).
     */
    fun openRobustSocket(ip: String, port: Int, timeoutMs: Int = 4500, context: Context? = null): Socket {
        val cleanIp = normalizeIpv4Address(ip)
        val targetAddress = InetSocketAddress(cleanIp, port)

        // Cách 1: Trói buộc socket trực tiếp vào Network Wi-Fi / Ethernet của Android (Network.bindSocket)
        if (context != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                if (cm != null) {
                    val allNetworks = cm.allNetworks
                    for (network in allNetworks) {
                        val caps = cm.getNetworkCapabilities(network)
                        if (caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))) {
                            var socket: Socket? = null
                            try {
                                socket = network.socketFactory.createSocket()
                                socket.tcpNoDelay = true
                                socket.keepAlive = true
                                socket.connect(targetAddress, timeoutMs)
                                return socket
                            } catch (_: Exception) {
                                try { socket?.close() } catch (_: Exception) {}
                            }
                        }
                    }
                }
            } catch (_: Exception) {}
        }

        // Cách 2: Bind Socket vào địa chỉ IP cục bộ thuộc mạng Wi-Fi
        var wifiBoundSocket: Socket? = null
        try {
            var localWifiAddress: InetAddress? = null
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (iface.isUp && !iface.isLoopback && (iface.name.contains("wlan", true) || iface.name.contains("eth", true))) {
                    val addrs = iface.inetAddresses
                    while (addrs.hasMoreElements()) {
                        val a = addrs.nextElement()
                        if (a is java.net.Inet4Address && !a.isLoopbackAddress) {
                            localWifiAddress = a
                            break
                        }
                    }
                }
                if (localWifiAddress != null) break
            }

            wifiBoundSocket = Socket().apply {
                tcpNoDelay = true
                keepAlive = true
                soTimeout = timeoutMs
            }
            if (localWifiAddress != null) {
                try {
                    wifiBoundSocket.bind(InetSocketAddress(localWifiAddress, 0))
                } catch (_: Exception) {}
            }
            wifiBoundSocket.connect(targetAddress, timeoutMs)
            return wifiBoundSocket
        } catch (_: Exception) {
            try { wifiBoundSocket?.close() } catch (_: Exception) {}
            val fallbackSocket = Socket().apply {
                tcpNoDelay = true
                soTimeout = timeoutMs
            }
            try {
                fallbackSocket.connect(targetAddress, timeoutMs)
                return fallbackSocket
            } catch (e: Exception) {
                try { fallbackSocket.close() } catch (_: Exception) {}
                throw e
            }
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun testConnection(config: PrinterConfig, context: Context? = null): Result<String> = withContext(Dispatchers.IO) {
        if (config.connectionType == ConnectionType.BLUETOOTH) {
            if (config.bluetoothAddress.isBlank()) {
                return@withContext Result.failure(Exception("Chưa chọn máy in Bluetooth nào. Hãy chọn 1 thiết bị Bluetooth bên dưới."))
            }
            var btSocket: android.bluetooth.BluetoothSocket? = null
            try {
                val btAdapter = getBluetoothAdapter(context)
                    ?: return@withContext Result.failure(Exception("Điện thoại không hỗ trợ Bluetooth"))
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && context != null &&
                    context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) !=
                    android.content.pm.PackageManager.PERMISSION_GRANTED
                ) {
                    return@withContext Result.failure(Exception("Chưa cấp quyền kết nối Bluetooth (BLUETOOTH_CONNECT). Hãy bấm nút 'Quét Thiết Bị Bluetooth' để cấp quyền."))
                }
                val dev = btAdapter.getRemoteDevice(config.bluetoothAddress)
                btSocket = dev.createRfcommSocketToServiceRecord(SPP_UUID)
                btSocket.connect()
                if (context != null) saveConfig(context, config)
                Result.success("🟢 Kết nối Bluetooth tới [${dev.name ?: dev.address}] THÀNH CÔNG!")
            } catch (e: Exception) {
                Result.failure(Exception("Không thể kết nối Bluetooth tới máy in: ${e.localizedMessage ?: e.message}"))
            } finally {
                try { btSocket?.close() } catch (_: Exception) {}
            }
        } else {
            val rawIp = config.ip.trim()
            val cleanIp = normalizeIpv4Address(rawIp)
            val port = config.port
            if (cleanIp.isBlank()) {
                return@withContext Result.failure(Exception("Địa chỉ IP máy in không được để trống."))
            }
            var socket: Socket? = null
            try {
                socket = openRobustSocket(cleanIp, port, 4000, context)
                if (context != null) {
                    saveConfig(context, config.copy(ip = cleanIp))
                    addIpToHistory(context, cleanIp)
                }
                val normalizedInfo = if (cleanIp != rawIp) " (Đã chuẩn hóa từ $rawIp -> $cleanIp)" else ""
                Result.success("🟢 Kết nối Wi-Fi/LAN tới [$cleanIp:$port]$normalizedInfo THÀNH CÔNG!")
            } catch (e: Exception) {
                val altPorts = listOf(9100, 9101, 9102, 80, 515, 4000).filter { it != port }
                var altFoundPort: Int? = null
                for (altP in altPorts) {
                    var testSock: Socket? = null
                    try {
                        testSock = openRobustSocket(cleanIp, altP, 1200, context)
                        altFoundPort = altP
                        break
                    } catch (_: Exception) {
                    } finally {
                        try { testSock?.close() } catch (_: Exception) {}
                    }
                }

                if (altFoundPort != null) {
                    Result.success("🟡 TÌM THẤY MÁY IN tại $cleanIp nhưng đang mở ở CỔNG $altFoundPort (thay vì $port). Hãy đổi cổng sang $altFoundPort!")
                } else {
                    val msg = e.localizedMessage ?: e.message.orEmpty()
                    val hint = when {
                        msg.contains("EHOSTUNREACH", true) || msg.contains("No route to host", true) ->
                            "Lỗi EHOSTUNREACH: Không tìm thấy máy in tại $cleanIp! Hãy kiểm tra điện thoại và máy in đã cùng mạng Wi-Fi chưa."
                        msg.contains("ECONNREFUSED", true) || msg.contains("Connection refused", true) ->
                            "Lỗi ECONNREFUSED: IP $cleanIp phản hồi nhưng Cổng $port bị đóng (Mặc định máy in nhiệt K80 là 9100)."
                        msg.contains("timeout", true) ->
                            "Hết thời gian chờ (Timeout) tới $cleanIp:$port. Hãy kiểm tra nguồn máy in hoặc bấm 'Quét IP Wi-Fi' để tìm đúng IP."
                        else -> "Lỗi kết nối Wi-Fi [$cleanIp:$port]: $msg"
                    }
                    Result.failure(Exception(hint))
                }
            } finally {
                try { socket?.close() } catch (_: Exception) {}
            }
        }
    }

    /**
     * Gửi lệnh điều khiển phần cứng trực tiếp (Cắt giấy, Đẩy giấy, Mở ngăn kéo tiền)
     */
    @SuppressLint("MissingPermission")
    suspend fun sendHardwareActionCommand(
        config: PrinterConfig,
        commandBytes: ByteArray,
        actionLabel: String,
        context: Context? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        var socket: Socket? = null
        var btSocket: BluetoothSocket? = null
        try {
            val out: OutputStream = if (config.connectionType == ConnectionType.BLUETOOTH) {
                if (config.bluetoothAddress.isBlank()) {
                    return@withContext Result.failure(Exception("Chưa chọn máy in Bluetooth."))
                }
                val btAdapter = getBluetoothAdapter(context)
                    ?: return@withContext Result.failure(Exception("Không hỗ trợ Bluetooth"))
                val device: BluetoothDevice = btAdapter.getRemoteDevice(config.bluetoothAddress)
                btSocket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                btSocket.connect()
                btSocket.outputStream
            } else {
                socket = openRobustSocket(config.ip, config.port, 4000, context)
                socket.getOutputStream()
            }
            out.write(byteArrayOf(0x1B, 0x40)) // ESC @ init
            out.write(commandBytes)
            out.flush()
            delay(80)
            Result.success("✅ Đã thực thi lệnh: $actionLabel")
        } catch (e: Exception) {
            Result.failure(Exception("Không thể gửi lệnh '$actionLabel': ${e.localizedMessage ?: e.message}"))
        } finally {
            try { socket?.close() } catch (_: Exception) {}
            try { btSocket?.close() } catch (_: Exception) {}
        }
    }

    /**
     * Tự động quét toàn bộ dải mạng Wi-Fi nội bộ (Subnet Discovery 1..254 theo batch nhanh) để tìm IP máy in cổng 9100
     */
    suspend fun discoverLocalPrinters(defaultPort: Int = 9100, context: Context? = null): List<String> = withContext(Dispatchers.IO) {
        val foundIps = mutableListOf<String>()
        try {
            var localSubnetPrefix: String? = null
            var myHostIp = ""
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (iface.isUp && !iface.isLoopback && (iface.name.contains("wlan", true) || iface.name.contains("eth", true))) {
                    val addrs = iface.inetAddresses
                    while (addrs.hasMoreElements()) {
                        val addr = addrs.nextElement()
                        val host = addr.hostAddress.orEmpty()
                        if (host.matches(Regex("^192\\.168\\.\\d+\\.\\d+$")) ||
                            host.matches(Regex("^10\\.\\d+\\.\\d+\\.\\d+$")) ||
                            host.matches(Regex("^172\\.(1[6-9]|2\\d|3[0-1])\\.\\d+\\.\\d+$"))
                        ) {
                            myHostIp = host
                            val lastDot = host.lastIndexOf('.')
                            if (lastDot > 0) {
                                localSubnetPrefix = host.substring(0, lastDot + 1)
                                break
                            }
                        }
                    }
                }
                if (localSubnetPrefix != null) break
            }

            val prefix = localSubnetPrefix ?: "192.168.1."
            // Ưu tiên quét đợt 1 các IP mặc định phổ biến nhất của máy in nhiệt Xprinter/Gprinter/HPRT/Zywell
            val priorityHosts = listOf(
                "${prefix}200", "${prefix}199", "${prefix}100", "${prefix}87", "${prefix}88",
                "${prefix}250", "${prefix}251", "${prefix}150", "${prefix}123", "${prefix}50",
                "${prefix}10", "${prefix}20", "${prefix}30", "${prefix}60", "${prefix}90"
            )
            val allRemainingHosts = (2..254).map { "${prefix}$it" }
                .filter { it !in priorityHosts && it != myHostIp }

            // Quét nhanh đợt 1 (Priority IPs)
            val priorityJobs = priorityHosts.filter { it != myHostIp }.map { host ->
                async {
                    try {
                        val socket = openRobustSocket(host, defaultPort, 380, context)
                        socket.close()
                        host
                    } catch (_: Exception) {
                        null
                    }
                }
            }
            foundIps.addAll(priorityJobs.awaitAll().filterNotNull())

            // Nếu chưa thấy hoặc quét mở rộng toàn dải mạng theo từng cụm 45 IP
            if (foundIps.isEmpty()) {
                // Limit concurrent socket probes to reduce CPU/network bursts on the phone.
                // Keep the full subnet coverage, but probe it in smaller groups.
                for (batch in allRemainingHosts.chunked(16)) {
                    val jobs = batch.map { host ->
                        async {
                            try {
                                val socket = openRobustSocket(host, defaultPort, 320, context)
                                socket.close()
                                host
                            } catch (_: Exception) {
                                null
                            }
                        }
                    }
                    val batchFound = jobs.awaitAll().filterNotNull()
                    foundIps.addAll(batchFound)
                    if (foundIps.isNotEmpty()) break
                }
            }
            if (context != null) {
                foundIps.forEach { addIpToHistory(context, it) }
            }
        } catch (_: Exception) {}
        return@withContext foundIps.distinct()
    }

    /**
     * Tự động cắt bỏ phần khoảng trắng thừa dưới đáy hóa đơn/vận đơn (Auto Trim Bottom White Margin)
     */
    fun trimBottomWhiteMargin(bitmap: Bitmap, thresholdLuminance: Int = 245): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        val rowPixels = IntArray(width)
        var lastContentY = height - 1

        for (y in height - 1 downTo 0) {
            bitmap.getPixels(rowPixels, 0, width, 0, y, width, 1)
            var hasDarkPixel = false
            for (x in 0 until width) {
                val pixel = rowPixels[x]
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                val lum = (r * 0.299 + g * 0.587 + b * 0.114).toInt()
                if (lum < thresholdLuminance) {
                    hasDarkPixel = true
                    break
                }
            }
            if (hasDarkPixel) {
                lastContentY = (y + 10).coerceAtMost(height)
                break
            }
        }

        return if (lastContentY < height && lastContentY > 24) {
            Bitmap.createBitmap(bitmap, 0, 0, width, lastContentY)
        } else {
            bitmap
        }
    }

    fun createPreviewBitmap(
        sourceBitmap: Bitmap,
        paperWidthDots: Int,
        marginLeftDots: Int,
        marginRightDots: Int,
        boldFontDilation: Boolean = false,
        densityLevel: Int = 3,
        autoTrimBottom: Boolean = true,
        maxHeightPx: Int = Int.MAX_VALUE
    ): Bitmap {
        val totalWidth = paperWidthDots.coerceAtLeast(384)
        val leftMargin = marginLeftDots.coerceIn(0, totalWidth / 3)
        val rightMargin = marginRightDots.coerceIn(0, totalWidth / 3)
        val printableWidth = (totalWidth - leftMargin - rightMargin).coerceAtLeast(120)

        val scaleFactor = printableWidth.toFloat() / sourceBitmap.width.toFloat().coerceAtLeast(1f)
        val rawTargetHeight = (sourceBitmap.height * scaleFactor).roundToInt().coerceAtLeast(1)
        val targetHeight = rawTargetHeight.coerceAtMost(maxHeightPx.coerceAtLeast(1))
        val srcCropHeight = if (rawTargetHeight > targetHeight) {
            (targetHeight / scaleFactor).roundToInt().coerceIn(1, sourceBitmap.height)
        } else {
            sourceBitmap.height
        }

        val fullPageBitmap = Bitmap.createBitmap(totalWidth, targetHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(fullPageBitmap)
        canvas.drawColor(Color.WHITE)
        val srcRect = android.graphics.Rect(0, 0, sourceBitmap.width, srcCropHeight)
        val dstRect = android.graphics.Rect(leftMargin, 0, leftMargin + printableWidth, targetHeight)
        canvas.drawBitmap(sourceBitmap, srcRect, dstRect, Paint(Paint.FILTER_BITMAP_FLAG))

        val trimmed = if (autoTrimBottom) {
            trimBottomWhiteMargin(fullPageBitmap)
        } else {
            fullPageBitmap
        }

        // Luôn hiển thị mô phỏng ngưỡng đen trắng thực tế theo Density Level & Bold Dilation để người dùng nhìn thấy chính xác bản in ra giấy
        return try {
            val w = trimmed.width
            val h = trimmed.height
            val pixels = IntArray(w * h)
            trimmed.getPixels(pixels, 0, w, 0, 0, w, h)
            val threshold = when (densityLevel) {
                1 -> 115
                2 -> 132
                3 -> 148
                4 -> 162
                5 -> 175
                else -> 148
            }
            val blackMatrix = BooleanArray(w * h)
            for (y in 0 until h) {
                val offset = y * w
                for (x in 0 until w) {
                    val p = pixels[offset + x]
                    val r = (p shr 16) and 0xFF
                    val g = (p shr 8) and 0xFF
                    val b = p and 0xFF
                    val lum = (r * 0.299 + g * 0.587 + b * 0.114).toInt()
                    if (lum < threshold) {
                        blackMatrix[offset + x] = true
                    }
                }
            }
            val outPixels = IntArray(w * h)
            for (y in 0 until h) {
                val offset = y * w
                for (x in 0 until w) {
                    var isBlack = blackMatrix[offset + x]
                    if (!isBlack && boldFontDilation && x > 0) {
                        val prevIsBlack = blackMatrix[offset + (x - 1)]
                        val isBarcodeOrQrArea = (x + 4 < w) && (
                            (blackMatrix[offset + x + 1] && !blackMatrix[offset + x + 2]) ||
                                (blackMatrix[offset + x + 2] && !blackMatrix[offset + x + 3])
                            )
                        val nextIsWhite1 = (x + 1 < w) && !blackMatrix[offset + (x + 1)]
                        val nextIsWhite2 = (x + 2 < w) && !blackMatrix[offset + (x + 2)]
                        val nextIsWhite3 = (x + 3 < w) && !blackMatrix[offset + (x + 3)]
                        if (prevIsBlack && !isBarcodeOrQrArea && nextIsWhite1 && nextIsWhite2 && nextIsWhite3) {
                            isBlack = true
                        }
                    }
                    outPixels[offset + x] = if (isBlack) Color.BLACK else Color.WHITE
                }
            }
            val resultBmp = Bitmap.createBitmap(outPixels, w, h, Bitmap.Config.ARGB_8888)
            if (trimmed != fullPageBitmap) trimmed.recycle()
            resultBmp
        } catch (_: Exception) {
            trimmed
        }
    }

    /**
     * Chuyển đổi Bitmap ảnh hoặc trang PDF sang lệnh in nhiệt ESC/POS (Raster Bit Image GS v 0)
     * Hỗ trợ in nhiều bản (copiesCount), tự động cắt giấy từng bản và mở ngăn kéo đựng tiền.
     */
    @SuppressLint("MissingPermission")
    suspend fun printBitmapToEscPos(
        bitmap: Bitmap,
        config: PrinterConfig,
        context: Context? = null,
        onProgress: ((String) -> Unit)? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        var socket: Socket? = null
        var btSocket: BluetoothSocket? = null
        val outputStream: OutputStream?

        try {
            if (context != null) {
                saveConfig(context, config)
            }
            if (config.connectionType == ConnectionType.BLUETOOTH) {
                if (config.bluetoothAddress.isBlank()) {
                    return@withContext Result.failure(Exception("Chưa chọn thiết bị máy in Bluetooth"))
                }
                val btAdapter = getBluetoothAdapter(context)
                    ?: return@withContext Result.failure(Exception("Điện thoại không hỗ trợ Bluetooth"))
                val device: BluetoothDevice = btAdapter.getRemoteDevice(config.bluetoothAddress)
                btSocket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                btSocket.connect()
                outputStream = btSocket.outputStream
            } else {
                val cleanIp = normalizeIpv4Address(config.ip)
                socket = openRobustSocket(cleanIp, config.port, 5500, context)
                if (context != null) addIpToHistory(context, cleanIp)
                outputStream = socket.getOutputStream()
            }

            val out = outputStream ?: return@withContext Result.failure(Exception("Không thể mở luồng dữ liệu tới máy in"))
            val totalCopies = config.copiesCount.coerceIn(1, 10)

            // Kích mở ngăn kéo đựng tiền thu ngân RJ11 nếu được bật (ESC p m t1 t2)
            if (config.openCashDrawer) {
                try {
                    out.write(byteArrayOf(0x1B, 0x70, 0x00, 0x19, 0xFA.toByte()))
                    out.flush()
                } catch (_: Exception) {}
            }

            for (copyIndex in 1..totalCopies) {
                if (totalCopies > 1) {
                    onProgress?.invoke("🖨️ Đang in bản $copyIndex / $totalCopies...")
                }
                sendSingleBitmapPageToStream(out, bitmap, config)
                if (copyIndex < totalCopies) {
                    delay(180)
                }
            }

            val destName = if (config.connectionType == ConnectionType.BLUETOOTH) {
                "Bluetooth [${config.bluetoothName.ifBlank { config.bluetoothAddress }}]"
            } else {
                "Wi-Fi [${normalizeIpv4Address(config.ip)}:${config.port}]"
            }
            val copyNote = if (totalCopies > 1) " ($totalCopies bản)" else ""
            Result.success("✅ Đã in thành công$copyNote ra máy in $destName!")
        } catch (e: Exception) {
            Result.failure(Exception("Lỗi in (${e.localizedMessage ?: e.message})"))
        } finally {
            try { socket?.close() } catch (_: Exception) {}
            try { btSocket?.close() } catch (_: Exception) {}
        }
    }

    /**
     * In toàn bộ các trang của file PDF nhiều trang (VD: 10-50 đơn hàng Shopee/TikTok trong 1 file PDF)
     */
    @SuppressLint("MissingPermission")
    suspend fun printAllPdfPagesToEscPos(
        context: Context,
        pdfUri: Uri,
        config: PrinterConfig,
        onProgress: ((String) -> Unit)? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        var socket: Socket? = null
        var btSocket: BluetoothSocket? = null
        try {
            saveConfig(context, config)
            val pageCount = getPdfPageCount(context, pdfUri)
            if (pageCount <= 0) {
                return@withContext Result.failure(Exception("Không thể đọc số trang của tệp PDF này."))
            }

            val out: OutputStream = if (config.connectionType == ConnectionType.BLUETOOTH) {
                if (config.bluetoothAddress.isBlank()) {
                    return@withContext Result.failure(Exception("Chưa chọn máy in Bluetooth"))
                }
                val btAdapter = getBluetoothAdapter(context)
                    ?: return@withContext Result.failure(Exception("Không hỗ trợ Bluetooth"))
                val device = btAdapter.getRemoteDevice(config.bluetoothAddress)
                btSocket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                btSocket.connect()
                btSocket.outputStream
            } else {
                val cleanIp = normalizeIpv4Address(config.ip)
                socket = openRobustSocket(cleanIp, config.port, 5500, context)
                addIpToHistory(context, cleanIp)
                socket.getOutputStream()
            }

            val totalCopies = config.copiesCount.coerceIn(1, 10)
            var printedCount = 0

            for (pageIdx in 0 until pageCount) {
                onProgress?.invoke("🖨️ Đang kết xuất & in trang PDF ${pageIdx + 1} / $pageCount...")
                val rawPageBmp = renderPdfPageToBitmap(context, pdfUri, pageIdx, config.paperWidthDots)
                    ?: continue
                val processedBmp = createPreviewBitmap(
                    sourceBitmap = rawPageBmp,
                    paperWidthDots = config.paperWidthDots,
                    marginLeftDots = config.marginLeftDots,
                    marginRightDots = config.marginRightDots,
                    boldFontDilation = config.boldFontDilation,
                    densityLevel = config.densityLevel,
                    autoTrimBottom = config.autoTrimBottom
                )
                if (rawPageBmp != processedBmp && !rawPageBmp.isRecycled) {
                    rawPageBmp.recycle()
                }
                for (c in 1..totalCopies) {
                    sendSingleBitmapPageToStream(out, processedBmp, config)
                    printedCount++
                    delay(140)
                }
                if (!processedBmp.isRecycled) {
                    processedBmp.recycle()
                }
                delay(160)
            }

            Result.success("✅ Đã in hoàn tất toàn bộ $pageCount trang PDF ($printedCount phiếu)!")
        } catch (e: Exception) {
            Result.failure(Exception("Lỗi khi in chuỗi trang PDF: ${e.localizedMessage ?: e.message}"))
        } finally {
            try { socket?.close() } catch (_: Exception) {}
            try { btSocket?.close() } catch (_: Exception) {}
        }
    }

    private suspend fun sendSingleBitmapPageToStream(
        out: OutputStream,
        bitmap: Bitmap,
        config: PrinterConfig
    ) {
        // 1. Khởi tạo máy in (ESC @) để xóa sạch dữ liệu đệm cũ
        out.write(byteArrayOf(0x1B, 0x40))
        out.flush()
        delay(25)

        // Thiết lập thông số đốt nóng phần cứng an toàn theo chuẩn ESC/POS (Hardware Heating Duration)
        try {
            val heatDots: Byte = 7
            val heatTime: Byte = when (config.densityLevel) {
                1 -> 60.toByte()
                2 -> 80.toByte()
                3 -> 100.toByte()
                4 -> 118.toByte()
                else -> 127.toByte()
            }
            val heatInterval: Byte = 2.toByte()
            out.write(byteArrayOf(0x1B, 0x37, heatDots, heatTime, heatInterval))
            out.flush()
        } catch (_: Exception) {}

        val totalWidth = config.paperWidthDots
        val fullPageBitmap = if (bitmap.width == totalWidth) {
            bitmap
        } else {
            createPreviewBitmap(
                sourceBitmap = bitmap,
                paperWidthDots = totalWidth,
                marginLeftDots = config.marginLeftDots,
                marginRightDots = config.marginRightDots,
                boldFontDilation = config.boldFontDilation,
                densityLevel = config.densityLevel,
                autoTrimBottom = config.autoTrimBottom
            )
        }
        val targetHeight = fullPageBitmap.height

        // 3. In theo từng dải nhỏ (Chunked Raster GS v 0) kèm pacing delay để không làm tràn bộ đệm máy in
        val maxChunkHeight = if (config.connectionType == ConnectionType.BLUETOOTH) 80 else 160
        val chunkDelayMs = if (config.connectionType == ConnectionType.BLUETOOTH) 25L else 12L
        var currentY = 0
        while (currentY < targetHeight) {
            val chunkH = (targetHeight - currentY).coerceAtMost(maxChunkHeight)
            val chunkBitmap = Bitmap.createBitmap(fullPageBitmap, 0, currentY, fullPageBitmap.width, chunkH)
            val rasterChunk = convertBitmapToRasterEscPos(chunkBitmap, config.densityLevel, config.boldFontDilation)
            chunkBitmap.recycle()
            out.write(rasterChunk)
            out.flush()
            delay(chunkDelayMs)
            currentY += chunkH
        }
        if (!fullPageBitmap.isRecycled && fullPageBitmap != bitmap) {
            fullPageBitmap.recycle()
        }

        // 4. Cuộn giấy ra theo số dòng cấu hình (ESC d n)
        val feedLines = config.feedLinesAfterPrint.coerceIn(0, 10).toByte()
        if (feedLines > 0) {
            out.write(byteArrayOf(0x1B, 0x64, feedLines))
        }

        // 5. Cắt giấy tự động nếu được bật (GS V 66 0)
        if (config.autoCut) {
            out.write(byteArrayOf(0x1D, 0x56, 0x42, 0x00))
        }

        out.flush()
    }

    /**
     * Đếm tổng số trang của file PDF
     */
    fun getPdfPageCount(context: Context, pdfUri: Uri): Int {
        return try {
            val pfd: ParcelFileDescriptor? = context.contentResolver.openFileDescriptor(pdfUri, "r")
            pfd?.use { descriptor ->
                val renderer = PdfRenderer(descriptor)
                val count = renderer.pageCount
                renderer.close()
                count
            } ?: 0
        } catch (_: Exception) {
            0
        }
    }

    /**
     * Đọc 1 trang bất kỳ (pageIndex) của file PDF sang Bitmap độ phân giải cao để in
     */
    fun renderPdfPageToBitmap(context: Context, pdfUri: Uri, pageIndex: Int = 0, targetWidth: Int = 576): Bitmap? {
        return try {
            val pfd: ParcelFileDescriptor? = context.contentResolver.openFileDescriptor(pdfUri, "r")
            pfd?.use { descriptor ->
                val renderer = PdfRenderer(descriptor)
                if (renderer.pageCount > 0) {
                    val safeIdx = pageIndex.coerceIn(0, renderer.pageCount - 1)
                    val page = renderer.openPage(safeIdx)
                    val aspectRatio = page.height.toFloat() / page.width.toFloat()
                    val renderWidth = targetWidth.coerceAtLeast(576)
                    val targetHeight = (renderWidth * aspectRatio).roundToInt().coerceAtLeast(1)
                    val bitmap = Bitmap.createBitmap(renderWidth, targetHeight, Bitmap.Config.ARGB_8888)
                    val canvas = Canvas(bitmap)
                    canvas.drawColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                    page.close()
                    renderer.close()
                    bitmap
                } else {
                    renderer.close()
                    null
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    fun renderPdfFirstPageToBitmap(context: Context, pdfUri: Uri, targetWidth: Int = 576): Bitmap? {
        return renderPdfPageToBitmap(context, pdfUri, 0, targetWidth)
    }

    /**
     * Thuật toán biến đổi Bitmap ảnh sang dữ liệu Raster ESC/POS Monochrome chuẩn K80/K57
     */
    private fun convertBitmapToRasterEscPos(bitmap: Bitmap, densityLevel: Int, boldDilation: Boolean = false): ByteArray {
        val width = bitmap.width
        val height = bitmap.height
        val widthBytes = (width + 7) / 8

        val out = ByteArrayOutputStream()

        // Lệnh GS v 0 m xL xH yL yH
        val m: Byte = 0
        val xL = (widthBytes and 0xFF).toByte()
        val xH = ((widthBytes shr 8) and 0xFF).toByte()
        val yL = (height and 0xFF).toByte()
        val yH = ((height shr 8) and 0xFF).toByte()

        out.write(byteArrayOf(0x1D, 0x76, 0x30, m, xL, xH, yL, yH))

        // Tinh chỉnh ngưỡng quang độ (Luminance Threshold) chuẩn quốc tế cho máy in nhiệt:
        val threshold = when (densityLevel) {
            1 -> 115 // Nhạt / Tiết kiệm nhiệt
            2 -> 132 // Vừa (Cân bằng trung tính)
            3 -> 148 // Đậm chuẩn nét hóa đơn & QR (Mặc định tối ưu nhất)
            4 -> 162 // Đậm tăng cường cho giấy nhiệt mờ
            5 -> 175 // Đậm tối đa an toàn (Bảo vệ kẽ hở QR)
            else -> 148
        }

        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        val blackMatrix = BooleanArray(width * height)
        for (y in 0 until height) {
            val rowOffset = y * width
            for (x in 0 until width) {
                val pixel = pixels[rowOffset + x]
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                val luminance = (r * 0.299 + g * 0.587 + b * 0.114).toInt()
                if (luminance < threshold) {
                    blackMatrix[rowOffset + x] = true
                }
            }
        }

        for (y in 0 until height) {
            val rowOffset = y * width
            for (xByte in 0 until widthBytes) {
                var byteVal = 0
                for (bit in 0 until 8) {
                    val x = xByte * 8 + bit
                    if (x < width) {
                        var isBlack = blackMatrix[rowOffset + x]
                        if (!isBlack && boldDilation && x > 0) {
                            val prevIsBlack = blackMatrix[rowOffset + (x - 1)]
                            val isBarcodeOrQrArea = (x + 4 < width) && (
                                (blackMatrix[rowOffset + x + 1] && !blackMatrix[rowOffset + x + 2]) ||
                                    (blackMatrix[rowOffset + x + 2] && !blackMatrix[rowOffset + x + 3])
                                )
                            val nextIsWhite1 = (x + 1 < width) && !blackMatrix[rowOffset + (x + 1)]
                            val nextIsWhite2 = (x + 2 < width) && !blackMatrix[rowOffset + (x + 2)]
                            val nextIsWhite3 = (x + 3 < width) && !blackMatrix[rowOffset + (x + 3)]

                            if (prevIsBlack && !isBarcodeOrQrArea && nextIsWhite1 && nextIsWhite2 && nextIsWhite3) {
                                isBlack = true
                            }
                        }
                        if (isBlack) {
                            byteVal = byteVal or (0x80 shr bit)
                        }
                    }
                }
                out.write(byteVal)
            }
        }

        return out.toByteArray()
    }
}
