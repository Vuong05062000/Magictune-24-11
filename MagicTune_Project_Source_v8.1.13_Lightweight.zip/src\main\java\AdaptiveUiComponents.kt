package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ButtonElevation
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.layout
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.ceil
import kotlin.math.max

private class ButtonMeasureState(
    var baseSingleLineHeightPx: Int = 0,
    var verticalPaddingPx: Int = 0
)

private fun detectWrappedLineCount(contentHeightDp: Float): Int {
    return when {
        contentHeightDp <= 22.5f -> 1
        contentHeightDp <= 38.0f -> 2
        contentHeightDp <= 54.5f -> 3
        else -> max(4, ceil((contentHeightDp - 2f) / 16.0f).toInt())
    }
}

/**
 * Helper layout inside Button / OutlinedButton that inspects the measured vertical height
 * of the button's inner Row content.
 * - 1 line -> 1x base height
 * - 2 lines -> 2x base height (gấp đôi độ cao)
 * - 3 lines -> 3x base height (gấp 3 độ cao)
 * - N lines -> Nx base height (gấp N độ cao)
 */
@Composable
private fun AdaptiveMultiLineButtonContent(
    measureState: ButtonMeasureState,
    content: @Composable RowScope.() -> Unit
) {
    Layout(
        content = {
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
                content = content
            )
        }
    ) { measurables, constraints ->
        val looseConstraints = constraints.copy(
            minWidth = 0,
            minHeight = 0,
            maxHeight = Constraints.Infinity
        )
        val firstMeasurable = measurables.firstOrNull()
            ?: return@Layout layout(constraints.minWidth, constraints.minHeight) {}
        val placeable = firstMeasurable.measure(looseConstraints)
        val rowHeightDp = placeable.height.toDp().value
        val detectedLines = detectWrappedLineCount(rowHeightDp)

        val defaultSingleLinePx = 40.dp.roundToPx()
        val rawBasePx = if (measureState.baseSingleLineHeightPx > 0) {
            measureState.baseSingleLineHeightPx
        } else {
            defaultSingleLinePx
        }

        val effectiveBaseSingleLinePx = if (detectedLines == 1) {
            rawBasePx
        } else {
            rawBasePx.coerceIn(34.dp.roundToPx(), 44.dp.roundToPx())
        }

        val targetTotalButtonHeightPx = effectiveBaseSingleLinePx * detectedLines
        val targetInnerHeightPx = (targetTotalButtonHeightPx - measureState.verticalPaddingPx)
            .coerceAtLeast(placeable.height)

        val finalWidth = max(constraints.minWidth, placeable.width)
        val finalHeight = max(
            constraints.minHeight,
            max(placeable.height, targetInnerHeightPx)
        ).coerceAtMost(
            if (constraints.hasBoundedHeight) constraints.maxHeight else Int.MAX_VALUE
        )

        layout(finalWidth, finalHeight) {
            val x = (finalWidth - placeable.width) / 2
            val y = (finalHeight - placeable.height) / 2
            placeable.placeRelative(x.coerceAtLeast(0), y.coerceAtLeast(0))
        }
    }
}

private fun Modifier.adaptiveButtonOuterMeasure(
    measureState: ButtonMeasureState,
    contentPadding: PaddingValues
): Modifier = this.layout { measurable, constraints ->
    val topPad = contentPadding.calculateTopPadding().roundToPx()
    val bottomPad = contentPadding.calculateBottomPadding().roundToPx()
    measureState.verticalPaddingPx = (topPad + bottomPad).coerceAtLeast(0)

    val requestedBasePx = when {
        constraints.minHeight > 0 -> constraints.minHeight
        constraints.hasBoundedHeight && constraints.maxHeight < 100.dp.roundToPx() -> constraints.maxHeight
        else -> 40.dp.roundToPx()
    }
    measureState.baseSingleLineHeightPx = requestedBasePx

    // Unbound maxHeight so multi-line buttons can always grow 2x, 3x, Nx and report full height to parent Card/Row/Column
    val childConstraints = constraints.copy(
        minHeight = requestedBasePx,
        maxHeight = Constraints.Infinity
    )
    val placeable = measurable.measure(childConstraints)
    layout(placeable.width, placeable.height) {
        placeable.placeRelative(0, 0)
    }
}

/**
 * Modifier for custom Box/Surface/Row clickable tiles so they also scale cleanly
 * when their text wraps to multiple lines and expand their parent Card height.
 */
fun Modifier.adaptiveMultiLineBoxHeight(
    baseSingleLineHeight: Dp = 44.dp
): Modifier = this.layout { measurable, constraints ->
    val placeable = measurable.measure(
        constraints.copy(
            minHeight = 0,
            maxHeight = Constraints.Infinity
        )
    )
    val contentHeightDp = placeable.height.toDp().value
    val detectedLines = when {
        contentHeightDp <= (baseSingleLineHeight.value + 4f) -> 1
        contentHeightDp <= (baseSingleLineHeight.value * 1.75f) -> 2
        contentHeightDp <= (baseSingleLineHeight.value * 2.5f) -> 3
        else -> max(4, ceil(contentHeightDp / (baseSingleLineHeight.value * 0.75f)).toInt())
    }
    val targetHeightPx = if (detectedLines == 1) {
        baseSingleLineHeight.roundToPx()
    } else {
        (baseSingleLineHeight * detectedLines).roundToPx()
    }
    val finalHeight = max(placeable.height, targetHeightPx)
    layout(placeable.width, finalHeight) {
        val y = (finalHeight - placeable.height) / 2
        placeable.placeRelative(0, y.coerceAtLeast(0))
    }
}

@Composable
fun Button(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    shape: Shape = ButtonDefaults.shape,
    colors: ButtonColors = ButtonDefaults.buttonColors(),
    elevation: ButtonElevation? = ButtonDefaults.buttonElevation(),
    border: BorderStroke? = null,
    contentPadding: PaddingValues = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
    interactionSource: MutableInteractionSource? = null,
    content: @Composable RowScope.() -> Unit
) {
    val measureState = remember { ButtonMeasureState() }
    androidx.compose.material3.Button(
        onClick = onClick,
        modifier = modifier.adaptiveButtonOuterMeasure(measureState, contentPadding),
        enabled = enabled,
        shape = shape,
        colors = colors,
        elevation = elevation,
        border = border,
        contentPadding = contentPadding,
        interactionSource = interactionSource
    ) {
        AdaptiveMultiLineButtonContent(
            measureState = measureState,
            content = content
        )
    }
}

@Composable
fun OutlinedButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    shape: Shape = ButtonDefaults.outlinedShape,
    colors: ButtonColors = ButtonDefaults.outlinedButtonColors(),
    elevation: ButtonElevation? = null,
    border: BorderStroke? = ButtonDefaults.outlinedButtonBorder(enabled),
    contentPadding: PaddingValues = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
    interactionSource: MutableInteractionSource? = null,
    content: @Composable RowScope.() -> Unit
) {
    val measureState = remember { ButtonMeasureState() }
    androidx.compose.material3.OutlinedButton(
        onClick = onClick,
        modifier = modifier.adaptiveButtonOuterMeasure(measureState, contentPadding),
        enabled = enabled,
        shape = shape,
        colors = colors,
        elevation = elevation,
        border = border,
        contentPadding = contentPadding,
        interactionSource = interactionSource
    ) {
        AdaptiveMultiLineButtonContent(
            measureState = measureState,
            content = content
        )
    }
}
