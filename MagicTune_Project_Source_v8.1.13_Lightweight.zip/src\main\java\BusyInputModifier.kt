package com.example.ui.components

import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput

/** Prevents overlapping screen actions from cancelling or racing an active ADB task. */
internal fun Modifier.blockInputWhileBusy(isBusy: Boolean): Modifier =
    if (!isBusy) this else pointerInput(isBusy) {
        awaitPointerEventScope {
            while (true) {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                event.changes.forEach { it.consume() }
            }
        }
    }
