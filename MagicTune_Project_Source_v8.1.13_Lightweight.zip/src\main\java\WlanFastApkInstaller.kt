package com.example.core.installer

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.core.shell.ShellEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * Bộ Cài Đặt APK Siêu Tốc Qua Gỡ Lỗi WLAN / Shizuku / Direct ADB (WlanFastApkInstaller).
 *
 * Tính năng:
 * 1. Nhận Uri tệp tin APK được người dùng chọn từ Bộ chọn tệp (File Picker).
 * 2. Lưu tạm vào bộ nhớ cache riêng của app.
 * 3. Nếu đã bật Gỡ Lỗi WLAN / Shizuku: Cài đặt siêu tốc (< 1 giây) không cần bấm xác nhận qua lệnh:
 *    `cat <path> | pm install -r -t -d -g -S <size>` hoặc `pm install -r -t -d -g <temp_file>`.
 * 4. Ngay khi cài xong:
 *    - Phân tích `packageName` của file APK vừa cài qua PackageManager.
 *    - Tìm Activity Launcher chính của app và khởi chạy trực tiếp ra màn hình chính điện thoại ngay lập tức!
 *    - Đưa thiết bị về Màn hình chính (`HOME`) nếu cần để hiển thị icon ứng dụng mới cài.
 * 5. Nếu chưa kết nối Gỡ Lỗi WLAN: Tự động mở bộ cài đặt chuẩn của Android qua FileProvider.
 */
object WlanFastApkInstaller {

    sealed class InstallResult {
        data class Success(val packageName: String, val appLabel: String) : InstallResult()
        data class FallbackStandardInstall(val message: String) : InstallResult()
        data class Error(val error: String) : InstallResult()
    }

    suspend fun installApkFromUri(context: Context, apkUri: Uri, onProgress: (String) -> Unit = {}): InstallResult = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext
        try {
            onProgress("⏳ Đang chuẩn bị tệp APK...")
            val resolver = appCtx.contentResolver

            // 1. Sao chép tệp tin APK vào thư mục tạm cache (ưu tiên externalCacheDir để shell UID 2000 đọc không cần world-readable)
            val baseCache = appCtx.externalCacheDir ?: appCtx.cacheDir
            val cacheDir = File(baseCache, "fast_installer").apply {
                if (!exists()) mkdirs()
                else listFiles()?.forEach { old -> try { old.delete() } catch (_: Throwable) {} }
            }
            val tempApkFile = File(cacheDir, "install_target_${System.currentTimeMillis()}.apk")

            resolver.openInputStream(apkUri)?.use { input ->
                FileOutputStream(tempApkFile).use { output ->
                    input.copyTo(output)
                    output.flush()
                }
            } ?: return@withContext InstallResult.Error("Không thể đọc tệp APK đã chọn.")

            if (!tempApkFile.exists() || tempApkFile.length() < 1024L) {
                try { tempApkFile.delete() } catch (_: Throwable) {}
                return@withContext InstallResult.Error("Tệp APK không hợp lệ hoặc dung lượng quá nhỏ.")
            }

            // 2. Phân tích gói ứng dụng (Tương thích API 33 - Android 17 PackageInfoFlags)
            val pm = appCtx.packageManager
            val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageArchiveInfo(tempApkFile.absolutePath, android.content.pm.PackageManager.PackageInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageArchiveInfo(tempApkFile.absolutePath, 0)
            }
            val packageName = pkgInfo?.packageName ?: ""
            val appLabel = if (pkgInfo != null) {
                try {
                    val appInfo = pkgInfo.applicationInfo
                    if (appInfo != null) {
                        appInfo.sourceDir = tempApkFile.absolutePath
                        appInfo.publicSourceDir = tempApkFile.absolutePath
                        pm.getApplicationLabel(appInfo).toString()
                    } else {
                        packageName
                    }
                } catch (_: Throwable) {
                    packageName
                }
            } else "Ứng dụng"

            // 3. Kiểm tra kết nối WLAN ADB / Shizuku
            val shell = ShellEngine.getInstance(appCtx)
            val isAdbReady = shell.state.value.isAdbReady

            if (isAdbReady) {
                onProgress("⚡ Đang cài đặt siêu tốc qua Gỡ lỗi WLAN (MagicOS 10/11 • Android 17)...")
                val apkPath = tempApkFile.absolutePath
                val fileSize = tempApkFile.length()

                // Cài đặt với các cờ: -r (reinstall), -t (test), -d (allow downgrade), -g (grant all permissions)
                // Bổ sung --bypass-low-target-sdk-block để cài mượt mọi APK cũ trên Android 15/16/17 & MagicOS 10/11
                val installCmd = "pm install --bypass-low-target-sdk-block -r -t -d -g '$apkPath' 2>/dev/null || pm install -r -t -d -g '$apkPath' 2>/dev/null || cat '$apkPath' | pm install --bypass-low-target-sdk-block -r -t -d -g -S $fileSize 2>/dev/null || cat '$apkPath' | pm install -r -t -d -g -S $fileSize"
                val res = shell.execute(installCmd)
                val out = (res.output + " " + res.error).trim()

                if (out.contains("Success", ignoreCase = true) || (packageName.isNotBlank() && isPackageInstalled(appCtx, packageName))) {
                    onProgress("🚀 Đã cài đặt xong! Đang hiển thị lên màn hình...")
                    // Khởi chạy ứng dụng và đưa ra màn hình chính ngay lập tức
                    launchInstalledApp(appCtx, packageName)

                    // Dọn dẹp file tạm
                    try { tempApkFile.delete() } catch (_: Throwable) {}

                    return@withContext InstallResult.Success(packageName, appLabel)
                } else {
                    // Nếu lỗi do quyền shell, fallback về bộ cài chuẩn
                    onProgress("⚠️ Lỗi shell, chuyển sang bộ cài mặc định...")
                    launchStandardInstaller(appCtx, tempApkFile)
                    return@withContext InstallResult.FallbackStandardInstall("Đang mở trình cài đặt mặc định: $out")
                }
            } else {
                onProgress("📱 Đang mở trình cài đặt Android...")
                launchStandardInstaller(appCtx, tempApkFile)
                return@withContext InstallResult.FallbackStandardInstall("Vui lòng xác nhận cài đặt trên màn hình.")
            }
        } catch (e: Throwable) {
            InstallResult.Error("Lỗi cài đặt: ${e.message}")
        }
    }

    private fun isPackageInstalled(context: Context, pkg: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(pkg, 0)
            true
        } catch (_: Throwable) {
            false
        }
    }

    private fun launchInstalledApp(context: Context, packageName: String) {
        if (packageName.isBlank()) return
        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            try {
                context.startActivity(launchIntent)
            } catch (_: Throwable) {}
        } else {
            // Đưa về màn hình chính để người dùng thấy icon app vừa cài
            val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            try {
                context.startActivity(homeIntent)
            } catch (_: Throwable) {}
        }
    }

    private fun launchStandardInstaller(context: Context, apkFile: File) {
        try {
            val authority = "${context.packageName}.fileprovider"
            val contentUri = FileProvider.getUriForFile(context, authority, apkFile)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(contentUri, "application/vnd.android.package-archive")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
            }
            context.startActivity(intent)
        } catch (e: Throwable) {
            val appCtx = context.applicationContext ?: context
            val errMsg = "Không thể mở tệp cài đặt: ${e.message}"
            if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
                try { Toast.makeText(appCtx, errMsg, Toast.LENGTH_LONG).show() } catch (_: Throwable) {}
            } else {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    try { Toast.makeText(appCtx, errMsg, Toast.LENGTH_LONG).show() } catch (_: Throwable) {}
                }
            }
        }
    }
}
