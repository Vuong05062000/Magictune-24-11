package com.example.core.keyboard

import android.content.Context

/**
 * Bộ gõ Tiếng Việt chuẩn Telex toàn diện (100% quy tắc âm vị học Tiếng Việt)
 * Dùng chung cho cả Bàn phím hệ thống MagicTune (IME) và Bàn phím MAGIC LIVE.
 *
 * Hỗ trợ đầy đủ:
 * - Phụ âm đ/Đ: dd -> đ, hoặc gõ d ở cuối âm tiết bắt đầu bằng d (vd: dang+d -> đang, duoc+d -> được).
 * - Nguyên âm mũ: aa -> â, ee -> ê, oo -> ô (kể cả gõ muộn sau phụ âm cuối: tien+e -> tiên, muon+o -> muôn, tuan+a -> tuân, khuay+a -> khuây).
 * - Nguyên âm móc/trăng (w):
 *   + aw -> ă (nam+w -> năm, hoac+w -> hoặc, quan+w -> quăn)
 *   + ow -> ơ (mo+w -> mơ, hoc+w -> hơc, quo+w -> quơ)
 *   + uw -> ư (tu+w -> tư, nhu+w -> như)
 *   + Cụm uo + w -> ươ (hỗ trợ cả 3 kiểu gõ: duowcj, duwowcj, duocwj -> được; nguowif, nguwowif, nguoiwf -> người; huowng, huwowng -> hương; ruou+w -> rượu; buou+w -> bướu).
 *   + Cụm ua + w -> ưa (giua+w -> giưa, mua+w -> mưa, chua+w -> chưa, xua+w -> xưa; riêng qua+w -> quă để gõ quăn/quắt).
 *   + Gõ tốc ký phụ âm + w -> ư (nhw -> như, thw -> thư, trw -> trư, chw -> chư, khw -> khư, phw -> phư, ngw -> ngư, tw -> tư, cw -> cư, lw -> lư...).
 * - Dấu thanh Telex: s (sắc), f (huyền), r (hỏi), x (ngã), j (nặng), z (xóa dấu thanh).
 * - Tự động định vị và dịch chuyển dấu thanh chuẩn xác khi gõ thêm nguyên âm/phụ âm cuối (ngã+i -> ngãi, hòa+n -> hoàn, củ+a -> của, tự+a -> tựa, đựo+c -> được, ngườ+i -> người).
 * - Cơ chế gõ lặp phím (double-tap) để hoàn tác dấu/mũ khi gõ từ tiếng Anh (vd: as+s -> as, aa+a -> aa, uw+w -> uw, tw+w -> tw).
 */
object VietnameseInputEngine {

    private val vowelTable = arrayOf(
        charArrayOf('a', 'á', 'à', 'ả', 'ã', 'ạ'),
        charArrayOf('ă', 'ắ', 'ằ', 'ẳ', 'ẵ', 'ặ'),
        charArrayOf('â', 'ấ', 'ầ', 'ẩ', 'ẫ', 'ậ'),
        charArrayOf('e', 'é', 'è', 'ẻ', 'ẽ', 'ẹ'),
        charArrayOf('ê', 'ế', 'ề', 'ể', 'ễ', 'ệ'),
        charArrayOf('i', 'í', 'ì', 'ỉ', 'ĩ', 'ị'),
        charArrayOf('o', 'ó', 'ò', 'ỏ', 'õ', 'ọ'),
        charArrayOf('ô', 'ố', 'ồ', 'ổ', 'ỗ', 'ộ'),
        charArrayOf('ơ', 'ớ', 'ờ', 'ở', 'ỡ', 'ợ'),
        charArrayOf('u', 'ú', 'ù', 'ủ', 'ũ', 'ụ'),
        charArrayOf('ư', 'ứ', 'ừ', 'ử', 'ữ', 'ự'),
        charArrayOf('y', 'ý', 'ỳ', 'ỷ', 'ỹ', 'ỵ')
    )

    private val validShorthandWConsonants = setOf(
        "b", "c", "ch", "d", "đ", "g", "gh", "gi", "h", "k", "kh",
        "l", "m", "n", "ng", "ngh", "nh", "p", "ph", "r", "s",
        "t", "th", "tr", "v", "x"
    )

    /**
     * Nhận diện thông minh xem con trỏ hiện tại có đang nằm trong một đường link (URL), tên miền (domain)
     * hoặc địa chỉ Email hay không (vd: vuong@gmail.com, aistudio.google.com, https://..., www....).
     * Khi phát hiện đang gõ nối tiếp sau dấu chấm '.', '@', '/', ':', '_', '-' của một chuỗi không có khoảng trắng,
     * bộ gõ sẽ tự động giữ nguyên ký tự gốc để viết link và email mượt mà tuyệt đối mà không cần tắt chế độ VN.
     */
    private fun isLikelyUrlOrEmailContext(prefix: String, word: String): Boolean {
        var tokenStart = prefix.length
        while (tokenStart > 0 && !prefix[tokenStart - 1].isWhitespace()) {
            tokenStart--
        }
        val nonSpacePrefix = prefix.substring(tokenStart)
        val fullTokenLower = (nonSpacePrefix + word).lowercase()

        if (fullTokenLower.startsWith("http://") ||
            fullTokenLower.startsWith("https://") ||
            fullTokenLower.startsWith("www.") ||
            fullTokenLower.contains("://") ||
            fullTokenLower.contains("@")
        ) {
            return true
        }

        if (nonSpacePrefix.isNotEmpty()) {
            val lastPrefixChar = nonSpacePrefix.last()
            // Chỉ nhận diện tên miền / đường dẫn / email khi phần trước dấu '.' là chuỗi ASCII không dấu (vd: google.com, aistudio.google),
            // hoặc chuỗi có '://', '@' — tránh trường hợp gõ nhầm dấu '.' sau từ Tiếng Việt (vd: cải.thiện) bị tắt bộ gõ.
            if (lastPrefixChar == '.' && nonSpacePrefix.length >= 3) {
                val beforeDot = nonSpacePrefix.dropLast(1)
                val isAsciiDomainLike = beforeDot.any { it.isLetterOrDigit() } &&
                    beforeDot.all { (it in 'a'..'z') || (it in 'A'..'Z') || (it in '0'..'9') || it == '-' || it == '_' || it == '.' }
                if (isAsciiDomainLike) {
                    return true
                }
            }
        }
        return false
    }

    private val validMultiOnsets = setOf(
        "ch", "gh", "gi", "kh", "ng", "ngh", "nh", "ph", "qu", "th", "tr"
    )

    private val foreignSingleOnsets = setOf('f', 'j', 'w', 'z')

    private val validVietnameseCodas = setOf(
        "", "c", "ch", "m", "n", "ng", "nh", "p", "t"
    )

    private val rawStateLock = Any()
    private var lastFullOutput: String = ""
    private var lastWordOutput: String = ""
    private var lastWordRaw: String = ""

    private fun hasForeignOnsetOrCluster(word: String): Boolean {
        if (word.isEmpty()) return false
        val firstLower = getBaseVowel(word[0]).lowercaseChar()
        if (firstLower in foreignSingleOnsets) return true
        var idx = 0
        val onset = StringBuilder()
        while (idx < word.length && !isViVowel(word[idx])) {
            onset.append(word[idx].lowercaseChar())
            idx++
        }
        if (onset.length >= 2) {
            if (onset.toString() !in validMultiOnsets) {
                return true
            }
        }
        return false
    }

    private fun hasVietnameseDiacritic(word: String): Boolean {
        for (ch in word) {
            if (ch == 'đ' || ch == 'Đ') return true
            val gt = getVowelGroupAndTone(ch) ?: continue
            if (gt.second > 0) return true
            val base = vowelTable[gt.first][0]
            if (base == 'ă' || base == 'â' || base == 'ê' || base == 'ô' || base == 'ơ' || base == 'ư') {
                return true
            }
        }
        return false
    }

    private fun isInvalidModifiedVowelPair(b1: Char, b2: Char, prevBase: Char?): Boolean {
        return when (b1) {
            'ă' -> true
            'â' -> b2 != 'u' && b2 != 'y'
            'ê' -> b2 != 'u'
            'ô' -> b2 != 'i'
            'ơ' -> b2 != 'i' && !(b2 == 'u' && prevBase == 'ư')
            'ư' -> b2 !in charArrayOf('a', 'i', 'o', 'ơ', 'u')
            else -> false
        }
    }

    private fun isInvalidVietnameseSyllable(word: String): Boolean {
        if (word.isEmpty()) return false
        if (hasForeignOnsetOrCluster(word)) return true

        val chars = word.toCharArray()
        val searchStart = getVowelSearchStart(chars)
        var firstVowelIdx = -1
        for (idx in searchStart until chars.size) {
            if (isViVowel(chars[idx])) {
                firstVowelIdx = idx
                break
            }
        }
        if (firstVowelIdx == -1) return false

        var i = firstVowelIdx
        while (i < chars.size && isViVowel(chars[i])) {
            if (i > firstVowelIdx) {
                val prevBase = if (i - 2 >= firstVowelIdx) getBaseVowel(chars[i - 2]).lowercaseChar() else null
                val b1 = getBaseVowel(chars[i - 1]).lowercaseChar()
                val b2 = getBaseVowel(chars[i]).lowercaseChar()
                if (isInvalidModifiedVowelPair(b1, b2, prevBase)) {
                    return true
                }
            }
            i++
        }

        for (k in i until chars.size) {
            if (isViVowel(chars[k])) {
                return true
            }
        }

        val coda = word.substring(i).lowercase()
        return coda !in validVietnameseCodas
    }

    private fun recordTelexOutput(resultText: String, newRawWord: String?): String {
        var ws = resultText.length
        while (ws > 0 && resultText[ws - 1].isLetter()) {
            ws--
        }
        val resultWord = resultText.substring(ws)
        synchronized(rawStateLock) {
            lastFullOutput = resultText
            lastWordOutput = resultWord
            lastWordRaw = if (resultWord.isEmpty()) "" else (newRawWord ?: resultWord)
        }
        return resultText
    }

    fun isViVowel(ch: Char): Boolean {
        val lower = ch.lowercaseChar()
        for (row in vowelTable) {
            if (lower in row) return true
        }
        return false
    }

    fun getVowelGroupAndTone(ch: Char): Pair<Int, Int>? {
        val lower = ch.lowercaseChar()
        for (g in vowelTable.indices) {
            val t = vowelTable[g].indexOf(lower)
            if (t != -1) return g to t
        }
        return null
    }

    fun getBaseVowel(ch: Char): Char {
        val gt = getVowelGroupAndTone(ch) ?: return ch
        val base = vowelTable[gt.first][0]
        return if (ch.isUpperCase()) base.uppercaseChar() else base
    }

    fun getToneIndex(ch: Char): Int {
        return getVowelGroupAndTone(ch)?.second ?: 0
    }

    fun applyToneToVowel(ch: Char, tone: Int): Char {
        val gt = getVowelGroupAndTone(ch) ?: return ch
        val res = vowelTable[gt.first][tone.coerceIn(0, 5)]
        return if (ch.isUpperCase()) res.uppercaseChar() else res
    }

    fun changeVowelBasePreserveTone(ch: Char, newBaseLower: Char): Char {
        val isUpper = ch.isUpperCase()
        val tone = getToneIndex(ch)
        val targetGroup = vowelTable.indexOfFirst { it[0] == newBaseLower }
        if (targetGroup == -1) return ch
        val res = vowelTable[targetGroup][tone]
        return if (isUpper) res.uppercaseChar() else res
    }

    /**
     * Xác định vị trí bắt đầu tính nguyên âm trong âm tiết (bỏ qua 'u' trong 'qu' và 'i' trong 'gi' khi sau nó còn nguyên âm khác).
     */
    private fun getVowelSearchStart(wordChars: CharArray): Int {
        if (wordChars.size > 2) {
            val c0 = getBaseVowel(wordChars[0]).lowercaseChar()
            val c1 = getBaseVowel(wordChars[1]).lowercaseChar()
            if (((c0 == 'q' && c1 == 'u') || (c0 == 'g' && c1 == 'i')) &&
                wordChars.drop(2).any { isViVowel(it) }
            ) {
                return 2
            }
        }
        return 0
    }

    /**
     * Chuẩn hóa cụm ưo / uơ -> ươ khi âm tiết có phụ âm cuối, bán nguyên âm cuối (i, u),
     * hoặc khi người dùng bấm dấu thanh; đồng thời chuyển 'ưa' + phụ âm cuối -> 'uă' + phụ âm cuối (vd: tưan -> tuăn).
     */
    private fun normalizeUoCluster(word: String, forceOpenUo: Boolean = false): String {
        val chars = word.toCharArray()
        val searchStart = getVowelSearchStart(chars)
        for (i in searchStart until chars.size - 1) {
            val b1 = getBaseVowel(chars[i]).lowercaseChar()
            val b2 = getBaseVowel(chars[i + 1]).lowercaseChar()
            val hasTrailingChars = (i + 2) < chars.size
            // Nếu là uơ (bất kỳ vị trí nào) hoặc ưo (khi sau đó đã có chữ cái cuối như c, n, ng, i, u, m, p, t hoặc khi đặt dấu thanh)
            if (b1 == 'u' && b2 == 'ơ') {
                chars[i] = changeVowelBasePreserveTone(chars[i], 'ư')
            } else if (b1 == 'ư' && b2 == 'o' && (hasTrailingChars || forceOpenUo)) {
                chars[i + 1] = changeVowelBasePreserveTone(chars[i + 1], 'ơ')
            } else if (b1 == 'ư' && b2 == 'a' && hasTrailingChars) {
                // Trong Tiếng Việt 'ưa' không bao giờ đi kèm phụ âm cuối; nếu có phụ âm cuối (như n, t, c, m, p) thì chuyển thành 'uă'
                val t1 = getToneIndex(chars[i])
                val t2 = getToneIndex(chars[i + 1])
                val combinedTone = if (t1 > 0) t1 else t2
                chars[i] = changeVowelBasePreserveTone(getBaseVowel(chars[i]), 'u')
                chars[i + 1] = applyToneToVowel(changeVowelBasePreserveTone(getBaseVowel(chars[i + 1]), 'ă'), combinedTone)
            }
        }
        return String(chars)
    }

    /**
     * Tìm vị trí nguyên âm chuẩn xác để đặt dấu thanh trong từ Tiếng Việt:
     * 1. Nếu có 1 nguyên âm -> đặt vào chính nó (vd: cá, gì, gìn, quý, quỳnh).
     * 2. Nếu có cụm 'ươ' (được, trường, người, mười, rượu, bướu, nước, hướng) -> luôn đặt vào 'ơ'.
     * 3. Nếu có nguyên âm mang dấu phụ (ă, â, ê, ô, ơ, ư) -> đặt vào nguyên âm đó (tiến, muốn, hoặc, tuần, giữa, tựa, khuấy, chuyện).
     * 4. Nếu có 3 nguyên âm (oai, oay, uya, iêu, yêu, uôi...) -> đặt vào nguyên âm giữa (ngoài, xoáy, khuya).
     * 5. Nếu có 2 nguyên âm:
     *    - Có phụ âm cuối (hoàn, toán, nhanh, hoàng, oanh, huynh) -> đặt vào nguyên âm thứ 2.
     *    - Không có phụ âm cuối (ngãi, của, giải, chào, ngày, hỏi, mùa, mũi, hòa, khỏe, thủy) -> đặt vào nguyên âm thứ 1.
     */
    /**
     * Tìm vị trí nguyên âm chuẩn xác 100% để đặt dấu thanh theo quy tắc âm vị học Tiếng Việt chính tả:
     * 1. Bất kỳ nguyên âm nào mang dấu phụ mũ / trăng / móc (ê, ô, ơ, ă, â) -> Bắt buộc là ÂM CHÍNH của âm tiết (chuyển, thuyền, tuyển, duyệt, tiến, muốn, hoặc, tuần, khuấy, người, trường).
     * 2. Cụm 'ươ' / 'ưo' / 'uơ' (được, trường, người, mười, rượu, bướu, nước, hướng) -> dấu luôn nằm ở chữ 'ơ'/'o'.
     * 3. Cụm 'uye' / 'uyê' (chuyen, thuyen, khuyen, tuyen, duyen, xuyen, quyen, khuyet, duyet...) -> âm chính là 'e' / 'ê'.
     * 4. Các nguyên âm 'ư' đơn lẻ có móc đi kèm nguyên âm khác (gửi, ngửi, cừu, hưu, giửa, chữa, lứa) -> dấu thuộc về 'ư'.
     * 5. Cụm 3 nguyên âm khác (oai, oay, uai, uay, uya...) -> dấu luôn đặt ở nguyên âm giữa (ngoài, xoáy, khuya).
     * 6. Cụm 2 nguyên âm:
     *    - Có phụ âm cuối (hoàn, toán, nhanh, hoàng, oanh, huynh, quỳnh) -> đặt vào nguyên âm thứ 2.
     *    - Không có phụ âm cuối (hòa, khỏe, thủy, quỳ, của, mía, mùa, chào, máy) -> phân định theo chuẩn mở.
     */
    fun findTargetVowelIndexInWord(word: String): Int {
        val chars = word.toCharArray()
        val searchStart = getVowelSearchStart(chars)
        val vowelIndices = mutableListOf<Int>()
        for (i in searchStart until chars.size) {
            if (isViVowel(chars[i])) {
                vowelIndices.add(i)
            }
        }
        if (vowelIndices.isEmpty()) return -1
        if (vowelIndices.size == 1) return vowelIndices[0]

        // 1. Ưu tiên 1: Bất kỳ nguyên âm nào mang dấu phụ MŨ / MÓC / TRĂNG (ê, ô, ơ, ă, â)
        // Luôn luôn là ÂM CHÍNH của âm tiết (vd: chuyển, thuyền, tuyển, duyệt, tiến, muốn, hoặc, tuần, khuấy, người, trường, rượu)
        val specialBases = setOf('ê', 'ô', 'ơ', 'ă', 'â')
        for (idx in vowelIndices) {
            val b = getBaseVowel(chars[idx]).lowercaseChar()
            if (b in specialBases) {
                return idx
            }
        }

        // 2. Cụm 'ươ' / 'ưo' / 'uơ': dấu luôn nằm ở chữ 'ơ'/'o' thứ 2 (được, trường, người, mười, rượu, bướu, nước, hướng)
        for (k in 0 until vowelIndices.size - 1) {
            val idx1 = vowelIndices[k]
            val idx2 = vowelIndices[k + 1]
            if (idx2 == idx1 + 1) {
                val b1 = getBaseVowel(chars[idx1]).lowercaseChar()
                val b2 = getBaseVowel(chars[idx2]).lowercaseChar()
                if ((b1 == 'ư' && (b2 == 'ơ' || b2 == 'o')) || (b1 == 'u' && b2 == 'ơ')) {
                    return idx2
                }
            }
        }

        // 3. Cụm 'uye' / 'uyê' (chuyen, thuyen, khuyen, tuyen, duyen, xuyen, quyen, khuyet, duyet...) -> âm chính là 'e' / 'ê'
        for (k in 0 until vowelIndices.size - 2) {
            val idx1 = vowelIndices[k]
            val idx2 = vowelIndices[k + 1]
            val idx3 = vowelIndices[k + 2]
            if (idx2 == idx1 + 1 && idx3 == idx2 + 1) {
                val b1 = getBaseVowel(chars[idx1]).lowercaseChar()
                val b2 = getBaseVowel(chars[idx2]).lowercaseChar()
                val b3 = getBaseVowel(chars[idx3]).lowercaseChar()
                if (b1 == 'u' && b2 == 'y' && (b3 == 'e' || b3 == 'ê')) {
                    return idx3
                }
            }
        }

        // 4. Các nguyên âm 'ư' đơn lẻ có mũ/móc đi kèm nguyên âm khác (vd: gửi, ngửi, cừu, hưu, giửa, chữa, lứa)
        val uHornIndices = vowelIndices.filter { getBaseVowel(chars[it]).lowercaseChar() == 'ư' }
        if (uHornIndices.isNotEmpty()) {
            return uHornIndices.first()
        }

        // 5. Cụm 3 nguyên âm khác (oai, oay, uai, uay, uya...) -> dấu luôn đặt ở nguyên âm giữa (ngoài, xoáy, khuya)
        if (vowelIndices.size >= 3) {
            return vowelIndices[1]
        }

        // 6. Cụm 2 nguyên âm
        if (vowelIndices.size == 2) {
            val idx1 = vowelIndices[0]
            val idx2 = vowelIndices[1]
            val b1 = getBaseVowel(chars[idx1]).lowercaseChar()
            val b2 = getBaseVowel(chars[idx2]).lowercaseChar()
            val hasFinalConsonant = idx2 < chars.size - 1

            // 6.1. Nếu có phụ âm cuối (hoàn, toán, hoạch, oanh, uyên, muốn, tiền, luân, chuẩn, xuân, huyết, quỳnh, huynh):
            // Âm chính là nguyên âm thứ 2
            if (hasFinalConsonant) {
                return idx2
            }

            // 6.2. Không có phụ âm cuối (âm tiết mở):
            // - Các cụm oa, oe, uy (hòa, khóe, thủy, quỳ, hủy): dấu đặt ở nguyên âm thứ 2
            if ((b1 == 'o' && (b2 == 'a' || b2 == 'e')) || (b1 == 'u' && b2 == 'y')) {
                return idx2
            }

            // - Các nguyên âm đôi ia, ya, ua, ưa (mía, tía, mùa, của, chúa, chưa, sửa, lửa): dấu đặt ở nguyên âm thứ 1
            if ((b1 == 'i' || b1 == 'y' || b1 == 'u' || b1 == 'ư') && b2 == 'a') {
                return idx1
            }

            // - Các vần mở có bán nguyên âm cuối thông thường (ai, oi, ui, ay, au, ao, eo, iu): dấu đặt ở nguyên âm thứ 1
            return idx1
        }

        return vowelIndices[0]
    }

    /**
     * Tự động định vị lại dấu thanh trong từ khi cấu trúc âm tiết thay đổi
     * (vd: ngã + i -> ngãi, hòa + n -> hoàn, củ + a -> của, gì + a -> già, đựo + c -> được).
     */
    private fun repositionToneInWord(word: String, forceOpenUo: Boolean = false): String {
        val normalized = normalizeUoCluster(word, forceOpenUo)
        val chars = normalized.toCharArray()
        var existingTone = 0
        for (i in chars.indices) {
            val t = getToneIndex(chars[i])
            if (t > 0) {
                existingTone = t
                break
            }
        }
        if (existingTone == 0) return normalized

        val targetIdx = findTargetVowelIndexInWord(normalized)
        if (targetIdx == -1) return normalized

        for (i in chars.indices) {
            if (isViVowel(chars[i])) {
                chars[i] = getBaseVowel(chars[i])
            }
        }
        chars[targetIdx] = applyToneToVowel(chars[targetIdx], existingTone)
        return String(chars)
    }

    /**
     * Xử lý phím gõ mới theo chuẩn Telex.
     * Trả về chuỗi văn bản mới sau khi áp dụng quy tắc Tiếng Việt.
     */
    fun applyTelex(currentText: String, typedKey: String): String {
        if (typedKey.length != 1) return recordTelexOutput(currentText + typedKey, null)
        val keyChar = typedKey[0]
        if (!keyChar.isLetter()) {
            return recordTelexOutput(currentText + typedKey, "")
        }
        val lowerKey = keyChar.lowercaseChar()

        // Tách từ (âm tiết) cuối cùng đang gõ ở ngay trước con trỏ
        var wordStart = currentText.length
        while (wordStart > 0 && currentText[wordStart - 1].isLetter()) {
            wordStart--
        }
        val prefix = currentText.substring(0, wordStart)
        val word = currentText.substring(wordStart)

        val trackedRawPrefix: String? = synchronized(rawStateLock) {
            if (currentText == lastFullOutput && word == lastWordOutput) lastWordRaw else null
        }
        val rawCandidate = (trackedRawPrefix ?: word) + typedKey

        // Tự động giữ nguyên ký tự gốc nếu người dùng đang gõ link URL, tên miền (.com, .vn) hoặc địa chỉ Email
        if (isLikelyUrlOrEmailContext(prefix, word)) {
            return recordTelexOutput(currentText + typedKey, rawCandidate)
        }

        // Trường hợp bắt đầu từ mới: giữ nguyên 'w'/'W' để gõ tiếng Anh (wifi, widget, web, win, wlan...) mượt 100% không bao giờ bị nhảy 'ưwi'.
        // (Nếu người dùng muốn gõ 'ừ/ứ/ử/ữ/ự' bằng tốc ký 'wf/ws/wr/wx/wj' hoặc 'uw' -> xử lý ở bước 3 & bước 5 bên dưới)
        if (word.isEmpty()) {
            return recordTelexOutput(currentText + typedKey, rawCandidate)
        }

        // Nếu bắt đầu bằng 'w'/'W' và gõ phím dấu thanh (s, f, r, x, j) -> chuyển tốc ký thành ứ, ừ, ử, ữ, ự
        if (word.length == 1 && (word[0] == 'w' || word[0] == 'W') && lowerKey in setOf('s', 'f', 'r', 'x', 'j')) {
            val toneIdx = when (lowerKey) {
                's' -> 1
                'f' -> 2
                'r' -> 3
                'x' -> 4
                else -> 5
            }
            val uBase = if (word[0].isUpperCase()) 'Ư' else 'ư'
            val tonedU = applyToneToVowel(uBase, toneIdx)
            return recordTelexOutput(prefix + tonedU, rawCandidate)
        }

        // Nếu bắt đầu bằng "wo"/"wu" mà bấm thêm 'w' (vd: wow -> ươ, wuw -> ưu)
        if (word.length == 2 && (word[0] == 'w' || word[0] == 'W') && lowerKey == 'w') {
            val secondLower = word[1].lowercaseChar()
            if (secondLower == 'o' || secondLower == 'u') {
                val uFirst = if (word[0].isUpperCase()) 'Ư' else 'ư'
                val secondChar = if (secondLower == 'o') {
                    if (word[1].isUpperCase()) 'Ơ' else 'ơ'
                } else {
                    word[1]
                }
                return recordTelexOutput(prefix + uFirst + secondChar, rawCandidate)
            }
        }

        // Nếu bắt đầu từ bằng 'ư'/'Ư' mà phím tiếp theo là i, e, h, l, r -> khôi phục về 'w'/'W' để gõ từ tiếng Anh (wifi, widget, web, what, when, write)
        if (word.length == 1 && (word[0] == 'ư' || word[0] == 'Ư') && lowerKey in setOf('i', 'e', 'h', 'l', 'r')) {
            val wChar = if (word[0].isUpperCase()) "W" else "w"
            return recordTelexOutput(prefix + wChar + typedKey, rawCandidate)
        }

        // Nếu âm tiết hiện tại không hợp lệ trong Tiếng Việt (từ tiếng Anh/ngoại lai), không áp dụng quy tắc Telex nữa và khôi phục nguyên gốc nếu đã lỡ bỏ dấu
        if (isInvalidVietnameseSyllable(word)) {
            if (hasVietnameseDiacritic(word)) {
                return recordTelexOutput(prefix + rawCandidate, rawCandidate)
            }
            if (trackedRawPrefix != null && trackedRawPrefix != word && word.last().lowercaseChar() != lowerKey) {
                return recordTelexOutput(prefix + rawCandidate, rawCandidate)
            }
            return recordTelexOutput(currentText + typedKey, rawCandidate)
        }

        val lastChar = word.last()

        // 1. Quy tắc d + d -> đ (hoặc gõ d ở cuối âm tiết bắt đầu bằng d: dang+d -> đang, duoc+d -> được)
        if (lowerKey == 'd') {
            if (lastChar == 'd' || lastChar == 'D') {
                // Nếu trước đó đã hoàn tác dd (vd: word kết thúc bằng "dd"), không biến lại thành đ nữa
                if (word.length >= 2 && (word[word.length - 2] == 'd' || word[word.length - 2] == 'D')) {
                    return recordTelexOutput(currentText + typedKey, rawCandidate)
                }
                val replacement = if (lastChar.isUpperCase()) "Đ" else "đ"
                return recordTelexOutput(prefix + word.dropLast(1) + replacement, rawCandidate)
            }
            if (lastChar == 'đ' || lastChar == 'Đ') {
                val reverted = if (lastChar.isUpperCase()) "D" else "d"
                return recordTelexOutput(prefix + word.dropLast(1) + reverted + typedKey, rawCandidate)
            }
            val firstChar = word.first()
            val validInternalVietnameseChars = setOf('c', 'h', 'm', 'n', 'g', 'p', 't')
            if ((firstChar == 'd' || firstChar == 'D') &&
                word.length in 2..7 &&
                word.drop(1).any { isViVowel(it) } &&
                word.drop(1).all { isViVowel(it) || it.lowercaseChar() in validInternalVietnameseChars }
            ) {
                if (word.length >= 2 && (word[1] == 'd' || word[1] == 'D')) {
                    return recordTelexOutput(currentText + typedKey, rawCandidate)
                }
                val replacement = if (firstChar.isUpperCase()) 'Đ' else 'đ'
                return recordTelexOutput(prefix + replacement + word.substring(1), rawCandidate)
            }
            if ((firstChar == 'đ' || firstChar == 'Đ') && word.length in 2..7) {
                val reverted = if (firstChar.isUpperCase()) 'D' else 'd'
                return recordTelexOutput(prefix + reverted + word.substring(1) + typedKey, rawCandidate)
            }
        }

        // 2. Quy tắc mũ: aa -> â, ee -> ê, oo -> ô (kể cả chuyển ă + a -> â, ơ + o -> ô)
        if (lowerKey == 'a' || lowerKey == 'e' || lowerKey == 'o') {
            val targetBase = lowerKey
            val hatBase = when (lowerKey) {
                'a' -> 'â'
                'e' -> 'ê'
                else -> 'ô'
            }
            val chars = word.toCharArray()
            val searchStart = getVowelSearchStart(chars)

            // Nếu người dùng đã hoàn tác mũ trước đó (vd: gõ 3 chữ o liên tiếp 'xooo' -> 'xoo'), không tự đóng mũ lại
            if (chars.size >= 2) {
                val lastB = getBaseVowel(chars.last()).lowercaseChar()
                val prevB = getBaseVowel(chars[chars.size - 2]).lowercaseChar()
                if (lastB == targetBase && prevB == targetBase) {
                    return recordTelexOutput(currentText + typedKey, rawCandidate)
                }
            }

            // Nếu từ đang có cụm 'ươ' và người dùng gõ 'o' -> chuyển 'ươ' thành 'uô' (vd: mươn + o -> muôn)
            if (lowerKey == 'o') {
                for (i in searchStart until chars.size - 1) {
                    val b1 = getBaseVowel(chars[i]).lowercaseChar()
                    val b2 = getBaseVowel(chars[i + 1]).lowercaseChar()
                    if (b1 == 'ư' && (b2 == 'ơ' || b2 == 'o')) {
                        chars[i] = changeVowelBasePreserveTone(chars[i], 'u')
                        chars[i + 1] = changeVowelBasePreserveTone(chars[i + 1], 'ô')
                        return recordTelexOutput(prefix + repositionToneInWord(String(chars)), rawCandidate)
                    }
                }
            }

            for (i in chars.size - 1 downTo searchStart) {
                val b = getBaseVowel(chars[i]).lowercaseChar()
                if (b == targetBase || (targetBase == 'a' && b == 'ă') || (targetBase == 'o' && b == 'ơ')) {
                    // Tránh biến 'o' trong cụm 'oa', 'oe' thành 'ôa', 'ôe' (không tồn tại trong Tiếng Việt)
                    if (targetBase == 'o' && i + 1 < chars.size) {
                        val nextB = getBaseVowel(chars[i + 1]).lowercaseChar()
                        if (nextB == 'a' || nextB == 'ă' || nextB == 'e') continue
                    }
                    chars[i] = changeVowelBasePreserveTone(chars[i], hatBase)
                    return recordTelexOutput(prefix + repositionToneInWord(String(chars)), rawCandidate)
                } else if (b == hatBase) {
                    // Gõ lặp lần 2 (vd: aa + a -> aa, oo + o -> oo cho từ 'xoong', tiên + e -> tiene) -> hoàn tác về chữ thường + chữ vừa gõ
                    chars[i] = changeVowelBasePreserveTone(chars[i], targetBase)
                    return recordTelexOutput(prefix + String(chars) + typedKey, rawCandidate)
                }
            }
        }

        // 3. Quy tắc phím 'w': aw -> ă, ow -> ơ, uw -> ư, uo+w -> ươ, ua+w -> ưa, uu+w -> ưu, phụ âm+w -> ư
        if (lowerKey == 'w') {
            val chars = word.toCharArray()
            val searchStart = getVowelSearchStart(chars)

            // 3a. Nếu từ kết thúc bằng 'ư'/'Ư' và trước đó chỉ là phụ âm đầu (do gõ tốc ký w -> ư, nhw -> như, tw -> tư),
            // bấm 'w' lần nữa sẽ hoàn tác 'ư' -> 'w' (vd: w + w -> w, tw + w -> tw để gõ twin, two, wifi, web, www).
            val lastBase = getBaseVowel(chars.last()).lowercaseChar()
            if (lastBase == 'ư' && getToneIndex(chars.last()) == 0) {
                val beforeLast = word.dropLast(1).lowercase()
                if (beforeLast.isEmpty() || beforeLast in validShorthandWConsonants) {
                    val wChar = if (chars.last().isUpperCase()) 'W' else 'w'
                    chars[chars.size - 1] = wChar
                    return recordTelexOutput(prefix + String(chars), rawCandidate)
                }
            }

            // 3b. Kiểm tra cụm 'uo' / 'ưo' / 'uô' / 'ươ' trong từ (vd: duoc+w -> được, nguoi+w -> người, ruou+w -> rượu, buou+w -> bướu, duwow -> dươ)
            for (i in searchStart until chars.size - 1) {
                val b1 = getBaseVowel(chars[i]).lowercaseChar()
                val b2 = getBaseVowel(chars[i + 1]).lowercaseChar()
                if ((b1 == 'u' || b1 == 'ư') && (b2 == 'o' || b2 == 'ô' || b2 == 'ơ')) {
                    if (b1 == 'ư' && b2 == 'ơ') {
                        // Đã là 'ươ' rồi mà bấm 'w' thêm lần nữa -> hoàn tác về 'uo' + 'w'
                        chars[i] = changeVowelBasePreserveTone(chars[i], 'u')
                        chars[i + 1] = changeVowelBasePreserveTone(chars[i + 1], 'o')
                        return recordTelexOutput(prefix + String(chars) + typedKey, rawCandidate)
                    } else {
                        // Chuyển cả cụm (uo, uô, ưo, uơ) -> 'ươ'
                        chars[i] = changeVowelBasePreserveTone(chars[i], 'ư')
                        chars[i + 1] = changeVowelBasePreserveTone(chars[i + 1], 'ơ')
                        return recordTelexOutput(prefix + repositionToneInWord(String(chars), forceOpenUo = true), rawCandidate)
                    }
                }
            }

            // 3c. Kiểm tra cụm 'ua' / 'ưa' ở âm tiết mở (không có phụ âm cuối sau 'a': giua+w -> giưa, mua+w -> mưa, chua+w -> chưa)
            // Nếu sau 'a' có phụ âm cuối (như tuan+w -> tuăn, hoac+w -> hoặc, xoan+w -> xoăn) hoặc 'qua'+w -> rơi xuống bước 3d để thành 'ă'!
            for (i in searchStart until chars.size - 1) {
                val b1 = getBaseVowel(chars[i]).lowercaseChar()
                val b2 = getBaseVowel(chars[i + 1]).lowercaseChar()
                if ((b1 == 'u' || b1 == 'ư') && b2 == 'a' && i + 1 == chars.size - 1) {
                    if (b1 == 'ư') {
                        chars[i] = changeVowelBasePreserveTone(chars[i], 'u')
                        return recordTelexOutput(prefix + String(chars) + typedKey, rawCandidate)
                    } else {
                        chars[i] = changeVowelBasePreserveTone(chars[i], 'ư')
                        return recordTelexOutput(prefix + repositionToneInWord(String(chars)), rawCandidate)
                    }
                }
                // Cụm 'uu' / 'ưu' (vd: luu+w -> lưu, cuu+w -> cứu, huu+w -> hữu, muu+w -> mưu): móc đặt ở chữ 'u' đầu tiên
                if ((b1 == 'u' || b1 == 'ư') && b2 == 'u') {
                    if (b1 == 'ư') {
                        chars[i] = changeVowelBasePreserveTone(chars[i], 'u')
                        return recordTelexOutput(prefix + String(chars) + typedKey, rawCandidate)
                    } else {
                        chars[i] = changeVowelBasePreserveTone(chars[i], 'ư')
                        return recordTelexOutput(prefix + repositionToneInWord(String(chars)), rawCandidate)
                    }
                }
            }

            // 3d. Duyệt từ cuối từ về đầu để biến đổi nguyên âm đơn a/â -> ă, o/ô -> ơ, u -> ư (vd: nam+w -> năm, hoac+w -> hoặc, quan+w -> quăn, tuan+w -> tuăn, tu+w -> tư)
            for (i in chars.size - 1 downTo searchStart) {
                val b = getBaseVowel(chars[i]).lowercaseChar()
                if (b == 'u' && chars.size == 2 && chars[0].lowercaseChar() == 'q') {
                    // Không biến âm đệm 'u' trong âm đầu 'qu' thành 'qư'
                    continue
                }
                if (b == 'a' || b == 'â' || b == 'o' || b == 'ô' || b == 'u') {
                    val hornBase = when (b) {
                        'a', 'â' -> 'ă'
                        'o', 'ô' -> 'ơ'
                        else -> 'ư'
                    }
                    chars[i] = changeVowelBasePreserveTone(chars[i], hornBase)
                    return recordTelexOutput(prefix + repositionToneInWord(String(chars)), rawCandidate)
                } else if (b == 'ă' || b == 'ơ' || b == 'ư') {
                    val plainBase = when (b) {
                        'ă' -> 'a'
                        'ơ' -> 'o'
                        else -> 'u'
                    }
                    chars[i] = changeVowelBasePreserveTone(chars[i], plainBase)
                    return recordTelexOutput(prefix + String(chars) + typedKey, rawCandidate)
                }
            }

            // 3e. Gõ tốc ký phụ âm đầu + w -> ư (vd: nhw -> như, thw -> thư, trw -> trư, giw -> giư, tw -> tư, cw -> cư, lw -> lư)
            val lowerWord = word.lowercase()
            if (lowerWord in validShorthandWConsonants) {
                val uHorn = if (keyChar.isUpperCase() || (word.length >= 2 && word.all { it.isUpperCase() })) "Ư" else "ư"
                return recordTelexOutput(prefix + word + uHorn, rawCandidate)
            }

            return recordTelexOutput(currentText + typedKey, rawCandidate)
        }

        // 4. Phím 'z': Xóa dấu thanh trong từ (nếu từ đang có dấu sắc/huyền/hỏi/ngã/nặng)
        if (lowerKey == 'z') {
            val chars = word.toCharArray()
            var hadTone = false
            for (i in chars.indices) {
                if (getToneIndex(chars[i]) > 0) {
                    chars[i] = getBaseVowel(chars[i])
                    hadTone = true
                }
            }
            if (hadTone) {
                return recordTelexOutput(prefix + String(chars), rawCandidate)
            }
        }

        // 5. Bảng dấu thanh Telex: s (1: sắc), f (2: huyền), r (3: hỏi), x (4: ngã), j (5: nặng)
        val requestedTone = when (lowerKey) {
            's' -> 1
            'f' -> 2
            'r' -> 3
            'x' -> 4
            'j' -> 5
            else -> null
        }
        if (requestedTone != null) {
            val normalizedWord = normalizeUoCluster(word, forceOpenUo = true)
            val targetIdx = findTargetVowelIndexInWord(normalizedWord)
            if (targetIdx != -1) {
                val chars = normalizedWord.toCharArray()
                var currentWordTone = 0
                for (ch in chars) {
                    val t = getToneIndex(ch)
                    if (t > 0) {
                        currentWordTone = t
                        break
                    }
                }

                // Nếu từ không mang dấu nhưng ký tự cuối cùng đã trùng chính phím thanh điệu (sau khi hoàn tác, vd: "pas" + "s" -> "pass"), giữ nguyên không đóng lại dấu
                if (currentWordTone == 0 && word.last().lowercaseChar() == lowerKey) {
                    return recordTelexOutput(currentText + typedKey, rawCandidate)
                }

                // Nếu từ đã mang ĐÚNG dấu đó -> Hoàn tác về nguyên âm không dấu + thêm chữ cái vừa gõ
                if (currentWordTone == requestedTone) {
                    for (i in chars.indices) {
                        if (isViVowel(chars[i])) {
                            chars[i] = getBaseVowel(chars[i])
                        }
                    }
                    return recordTelexOutput(prefix + String(chars) + typedKey, rawCandidate)
                }

                // Xóa dấu cũ (nếu có) và đặt dấu mới vào đúng nguyên âm chuẩn chính tả
                for (i in chars.indices) {
                    if (isViVowel(chars[i])) {
                        chars[i] = getBaseVowel(chars[i])
                    }
                }
                chars[targetIdx] = applyToneToVowel(chars[targetIdx], requestedTone)
                return recordTelexOutput(prefix + String(chars), rawCandidate)
            }
        }

        // 6. Khi gõ thêm nguyên âm hoặc phụ âm vào từ đã có dấu hoặc cụm 'ưo' / 'ưa'
        // (vd: ngã + i -> ngãi, hòa + n -> hoàn, củ + a -> của, gì + a -> già, đựo + c -> được, ngườ + i -> người)
        val appendedWord = word + typedKey
        val forceUo = lowerKey != 'o'
        val repositioned = repositionToneInWord(appendedWord, forceOpenUo = forceUo)
        if (isInvalidVietnameseSyllable(repositioned)) {
            if (hasVietnameseDiacritic(word) || hasVietnameseDiacritic(repositioned)) {
                return recordTelexOutput(prefix + rawCandidate, rawCandidate)
            }
            return recordTelexOutput(currentText + typedKey, rawCandidate)
        }
        if (repositioned != appendedWord) {
            return recordTelexOutput(prefix + repositioned, rawCandidate)
        }

        return recordTelexOutput(currentText + typedKey, rawCandidate)
    }
}

/**
 * Kho biểu tượng cảm xúc (Emoji) phân theo danh mục kèm lưu trữ lịch sử dùng gần đây trên thiết bị.
 */
object MagicEmojiCatalog {
    private const val PREFS_NAME = "magic_emoji_prefs"
    private const val KEY_RECENT = "recent_emojis"
    private const val MAX_RECENT = 32

    data class EmojiCategory(
        val icon: String,
        val title: String,
        val emojis: List<String>
    )

    val categories = listOf(
        EmojiCategory(
            icon = "😀",
            title = "Cảm xúc",
            emojis = listOf(
                "😀", "😃", "😄", "😁", "😆", "😅", "🤣", "😂",
                "🙂", "🙃", "😉", "😊", "😇", "🥰", "😍", "🤩",
                "😘", "😗", "😚", "😙", "🥲", "😋", "😛", "😜",
                "🤪", "😝", "🤑", "🤗", "🤭", "🤫", "🤔", "🫡",
                "🤐", "🤨", "😐", "😑", "😶", "😏", "😒", "🙄",
                "😬", "😮‍💨", "🤥", "😌", "😔", "😪", "🤤", "😴",
                "😷", "🤒", "🤕", "🤢", "🤮", "🤧", "🥵", "🥶",
                "🥴", "😵", "🤯", "🤠", "🥳", "🥸", "😎", "🤓",
                "🧐", "😕", "😟", "🙁", "😮", "😯", "😲", "😳",
                "🥺", "🥹", "😦", "😧", "😨", "😰", "😥", "😢",
                "😭", "😱", "😖", "😣", "😞", "😓", "😩", "😫",
                "🥱", "😤", "😡", "😠", "🤬", "😈", "👿", "💀",
                "🫠", "🫣", "🫢", "🫥"
            )
        ),
        EmojiCategory(
            icon = "❤️",
            title = "Tim & Tay",
            emojis = listOf(
                "❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍",
                "🤎", "💔", "❤️‍🔥", "❤️‍🩹", "❣️", "💕", "💞", "💓",
                "💗", "💖", "💘", "💝", "💟", "👍", "👎", "👌",
                "🤌", "🤏", "✌️", "🤞", "🫰", "🤟", "🤘", "🤙",
                "👈", "👉", "👆", "👇", "☝️", "✋", "🤚", "🖐️",
                "🖖", "👋", "🤝", "🙏", "✍️", "💪", "🦾", "🫶",
                "👏", "🙌", "👐", "🤲", "🤜", "🤛", "✊", "👊",
                "🫡", "🙇", "🤦", "🤷", "🙆", "🙅", "🙋", "💃",
                "🫵", "🩷", "🩵", "🩶"
            )
        ),
        EmojiCategory(
            icon = "🎉",
            title = "Lễ hội",
            emojis = listOf(
                "🔥", "✨", "🌟", "⭐", "💫", "💥", "💢", "💯",
                "🎉", "🎊", "🎈", "🎂", "🎁", "🎀", "🏆", "🥇",
                "🥈", "🥉", "🏅", "🎖️", "👑", "💎", "💰", "💵",
                "🧧", "🏮", "🎆", "🎇", "🧨", "🪄", "🔮", "🧿",
                "🎵", "🎶", "🎤", "🎧", "🎸", "🎹", "🥁", "🎺",
                "📸", "📹", "🎬", "🎮", "🕹️", "🎲", "🎯", "🎳",
                "🪩", "🪙", "🪪", "🛟"
            )
        ),
        EmojiCategory(
            icon = "🐱",
            title = "Thiên nhiên",
            emojis = listOf(
                "🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼",
                "🐻‍❄️", "🐨", "🐯", "🦁", "🐮", "🐷", "🐸", "🐵",
                "🙈", "🙉", "🙊", "🐔", "🐧", "🐦", "🐤", "🦆",
                "🦅", "🦉", "🦇", "🐺", "🐗", "🐴", "🦄", "🐝",
                "🦋", "🐌", "🐞", "🐢", "🐍", "🦖", "🐙", "🐬",
                "🐳", "🦈", "🌸", "🌺", "🌻", "🌹", "🌷", "🌼",
                "🍀", "🌿", "🌱", "🌲", "🌳", "🌴", "🌵", "🌈",
                "☀️", "🌤️", "⛅", "🌧️", "⛈️", "❄️", "🌙", "⚡",
                "🪷", "🪻", "🦩", "🦭"
            )
        ),
        EmojiCategory(
            icon = "🍜",
            title = "Ẩm thực",
            emojis = listOf(
                "🍜", "🍲", "🍛", "🍣", "🍱", "🥟", "🍤", "🍙",
                "🍚", "🍘", "🍢", "🍡", "🍧", "🍨", "🍦", "🥧",
                "🧁", "🍰", "🎂", "🍮", "🍭", "🍬", "🍫", "🍿",
                "🍩", "🍪", "🍔", "🍟", "🍕", "🌭", "🥪", "🌮",
                "🌯", "🥗", "🥘", "🍝", "🥩", "🍗", "🍖", "🥖",
                "🥐", "🍎", "🍊", "🍋", "🍌", "🍉", "🍇", "🍓",
                "🍒", "🍑", "🥭", "🍍", "🥥", "🥝", "🥑", "☕",
                "🍵", "🧋", "🧃", "🥤", "🍺", "🍻", "🥂", "🍷"
            )
        ),
        EmojiCategory(
            icon = "✅",
            title = "Ký hiệu",
            emojis = listOf(
                "✅", "☑️", "✔️", "❌", "❎", "➕", "➖", "➗",
                "✖️", "❓", "❔", "❕", "❗", "‼️", "⁉️", "⭕",
                "🛑", "⛔", "📛", "🚫", "⚠️", "🔔", "🔕", "📢",
                "📣", "💡", "🔦", "🔒", "🔓", "🔑", "📌", "📍",
                "📎", "✂️", "📝", "📅", "📊", "📈", "📉", "📁",
                "🚀", "✈️", "🚗", "🏍️", "🚲", "🏠", "🏢", "🏥",
                "⏰", "⏳", "🔋", "🔌", "💻", "📱", "☎️", "🇻🇳"
            )
        )
    )

    fun getRecentEmojis(context: Context): List<String> {
        return try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val raw = prefs.getString(KEY_RECENT, "") ?: ""
            if (raw.isBlank()) {
                listOf("😂", "🤣", "❤️", "👍", "🙏", "😍", "🥰", "😭", "😊", "🔥", "✨", "🎉", "💯", "✅", "🤔", "😎")
            } else {
                raw.split("|").filter { it.isNotBlank() }
            }
        } catch (_: Throwable) {
            listOf("😂", "🤣", "❤️", "👍", "🙏", "😍", "🥰", "😭")
        }
    }

    fun recordEmojiUsed(context: Context, emoji: String) {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val current = getRecentEmojis(context).toMutableList()
            current.remove(emoji)
            current.add(0, emoji)
            val trimmed = current.take(MAX_RECENT)
            prefs.edit().putString(KEY_RECENT, trimmed.joinToString("|")).apply()
        } catch (_: Throwable) {}
    }
}
