package com.example.core.perf

import android.app.ActivityManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.StatFs
import android.util.Log
import androidx.compose.runtime.Immutable
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.PersistentCacheSettings
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.launch

@Immutable
data class MemoryStorageBudget(
    val totalRamMb: Int,
    val availableRamMb: Int,
    val freeRomMb: Long,
    val coilMemoryCachePercent: Double,
    val coilDiskCacheBytes: Long,
    val firestoreDiskCacheBytes: Long,
    val allowRgb565: Boolean,
    val appIconRamCacheSize: Int,
    val maxDiskCachedIcons: Int,
    val profileLabel: String
)

/**
 * Công cụ tối ưu hóa sử dụng tối đa RAM & ROM của điện thoại:
 * - Tự động mở rộng bộ nhớ đệm RAM (Coil, Icon Cache, App Snapshot, Tab Compose state)
 *   tùy theo dung lượng RAM thực của máy (lên đến 28% heap trên máy 8GB–16GB RAM).
 * - Tận dụng bộ nhớ trong ROM để lưu sẵn Cache Firestore (tối đa 128MB), Coil Disk Cache (tối đa 128MB),
 *   Icon ứng dụng PNG & JSON Snapshot cho màn hình Soi Ngầm, Kho App, Dọn App -> mở lại là 0ms không chờ quay!
 */
object DeviceMemoryStorageOptimizer {

    private const val TAG = "MemStorageOptimizer"
    private const val FAST_CACHE_DIR = "fast_cache"
    private const val ICONS_CACHE_DIR = "icons"

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    private val iconDiskWriterDispatcher = kotlinx.coroutines.Dispatchers.IO.limitedParallelism(1)
    private val iconDiskWriterScope = kotlinx.coroutines.CoroutineScope(
        kotlinx.coroutines.SupervisorJob() + iconDiskWriterDispatcher
    )
    private val pendingIconWrites = java.util.Collections.newSetFromMap(
        java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    )

    @Volatile
    private var cachedBudget: MemoryStorageBudget? = null

    @Volatile
    private var firestoreCacheConfigured = false

    fun computeBudget(context: Context): MemoryStorageBudget {
        cachedBudget?.let { return it }
        val appCtx = context.applicationContext ?: context
        val budget = try {
            val am = appCtx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am?.getMemoryInfo(mi)
            val totalRamMb = if (mi.totalMem > 0L) (mi.totalMem / (1024L * 1024L)).toInt() else 4096
            val availRamMb = if (mi.availMem > 0L) (mi.availMem / (1024L * 1024L)).toInt() else 1500
            val isLowRam = am?.isLowRamDevice == true || Build.VERSION.SDK_INT < Build.VERSION_CODES.O

            val freeRomMb = try {
                val stat = StatFs(appCtx.filesDir.absolutePath)
                stat.availableBytes / (1024L * 1024L)
            } catch (_: Throwable) {
                2048L
            }

            val ramTier = when {
                !isLowRam && totalRamMb >= 7000 -> "Siêu Mượt (${(totalRamMb + 512) / 1024}GB RAM)"
                !isLowRam && totalRamMb >= 4500 -> "Mượt Cao (${(totalRamMb + 512) / 1024}GB RAM)"
                !isLowRam && totalRamMb >= 3200 -> "Cân Bằng (${(totalRamMb + 512) / 1024}GB RAM)"
                else -> "Tiết Kiệm RAM"
            }

            val coilMemPercent = when {
                isLowRam || totalRamMb < 3200 -> 0.06
                totalRamMb >= 7000 -> 0.10
                totalRamMb >= 4500 -> 0.08
                else -> 0.07
            }

            val iconRamCount = when {
                isLowRam || totalRamMb < 3200 -> 24
                totalRamMb >= 7000 -> 48
                totalRamMb >= 4500 -> 40
                else -> 32
            }

            val coilDiskBytes = when {
                freeRomMb >= 4096L -> 64L * 1024L * 1024L
                freeRomMb >= 1024L -> 32L * 1024L * 1024L
                else -> 16L * 1024L * 1024L
            }

            val firestoreDiskBytes = when {
                freeRomMb >= 4096L -> 32L * 1024L * 1024L
                freeRomMb >= 1024L -> 24L * 1024L * 1024L
                else -> 16L * 1024L * 1024L
            }

            val maxDiskIcons = when {
                freeRomMb >= 2048L -> 320
                freeRomMb >= 512L -> 160
                else -> 60
            }

            MemoryStorageBudget(
                totalRamMb = totalRamMb,
                availableRamMb = availRamMb,
                freeRomMb = freeRomMb,
                coilMemoryCachePercent = coilMemPercent,
                coilDiskCacheBytes = coilDiskBytes,
                firestoreDiskCacheBytes = firestoreDiskBytes,
                allowRgb565 = isLowRam || totalRamMb < 3200,
                appIconRamCacheSize = iconRamCount,
                maxDiskCachedIcons = maxDiskIcons,
                profileLabel = ramTier
            )
        } catch (_: Throwable) {
            MemoryStorageBudget(
                totalRamMb = 4096,
                availableRamMb = 1500,
                freeRomMb = 2048L,
                coilMemoryCachePercent = 0.18,
                coilDiskCacheBytes = 64L * 1024L * 1024L,
                firestoreDiskCacheBytes = 32L * 1024L * 1024L,
                allowRgb565 = false,
                appIconRamCacheSize = 36,
                maxDiskCachedIcons = 120,
                profileLabel = "Tiêu Chuẩn"
            )
        }
        cachedBudget = budget
        return budget
    }

    /**
     * Giữ Persistent Disk Cache Firestore ở mức nhỏ để hạn chế tải bộ nhớ khi xử lý cache và mutation queue lớn.
     */
    fun configureFirestorePersistentCacheOnce(context: Context) {
        if (firestoreCacheConfigured) return
        synchronized(this) {
            if (firestoreCacheConfigured) return
            firestoreCacheConfigured = true
            try {
                val budget = computeBudget(context)
                val settings = FirebaseFirestoreSettings.Builder()
                    .setLocalCacheSettings(
                        PersistentCacheSettings.newBuilder()
                            .setSizeBytes(budget.firestoreDiskCacheBytes)
                            .build()
                    )
                    .build()
                FirebaseFirestore.getInstance().firestoreSettings = settings
                Log.d(
                    TAG,
                    "Firestore persistent ROM cache configured: ${budget.firestoreDiskCacheBytes / (1024 * 1024)}MB (${budget.profileLabel})"
                )
            } catch (t: Throwable) {
                // Nếu Firestore instance đã được cấu hình trước đó thì bỏ qua an toàn
                Log.d(TAG, "Firestore cache settings note: ${t.message}")
            }
        }
    }

    private fun getFastCacheDir(context: Context): File {
        val dir = File((context.applicationContext ?: context).filesDir, FAST_CACHE_DIR)
        if (!dir.exists()) {
            try { dir.mkdirs() } catch (_: Throwable) {}
        }
        return dir
    }

    private fun getIconsCacheDir(context: Context): File {
        val dir = File(getFastCacheDir(context), ICONS_CACHE_DIR)
        if (!dir.exists()) {
            try { dir.mkdirs() } catch (_: Throwable) {}
        }
        return dir
    }

    fun readFastSnapshotJson(context: Context, fileName: String): String? {
        return try {
            val file = File(getFastCacheDir(context), fileName)
            if (!file.exists() || !file.isFile || file.length() <= 0L || file.length() > 4 * 1024 * 1024L) {
                return null
            }
            file.readText(Charsets.UTF_8)
        } catch (_: Throwable) {
            null
        }
    }

    fun writeFastSnapshotJson(context: Context, fileName: String, content: String) {
        try {
            if (content.length > 4 * 1024 * 1024) return
            val dir = getFastCacheDir(context)
            val tmp = File(dir, "$fileName.tmp")
            val target = File(dir, fileName)
            tmp.writeText(content, Charsets.UTF_8)
            if (!tmp.renameTo(target)) {
                target.writeText(content, Charsets.UTF_8)
                try { tmp.delete() } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    private fun safeIconFileName(packageName: String): String {
        return packageName.replace(Regex("[^a-zA-Z0-9._-]"), "_") + ".png"
    }

    fun loadIconFromDisk(context: Context, packageName: String): Bitmap? {
        if (packageName.isBlank()) return null
        return try {
            val file = File(getIconsCacheDir(context), safeIconFileName(packageName))
            if (!file.exists() || file.length() <= 0L || file.length() > 512 * 1024L) return null
            val opts = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            BitmapFactory.decodeFile(file.absolutePath, opts)
        } catch (_: Throwable) {
            null
        }
    }

    fun saveIconBytesToDisk(context: Context, packageName: String, pngBytes: ByteArray) {
        if (packageName.isBlank() || pngBytes.isEmpty() || pngBytes.size > 512 * 1024) return
        val appCtx = context.applicationContext ?: context
        if (!pendingIconWrites.add(packageName)) return
        // Chỉ ghi mảng byte bất biến (.tmp -> rename) trên 1 luồng IO riêng: tuyệt đối không chạm chung đối tượng Bitmap với RenderThread/Skia
        iconDiskWriterScope.launch {
            try {
                val budget = computeBudget(appCtx)
                if (budget.freeRomMb < 120L) return@launch
                val dir = getIconsCacheDir(appCtx)
                val file = File(dir, safeIconFileName(packageName))
                if (file.exists() && file.length() > 0L) return@launch
                val tmp = File(dir, safeIconFileName(packageName) + ".tmp")
                FileOutputStream(tmp).use { out ->
                    out.write(pngBytes)
                }
                if (!tmp.renameTo(file)) {
                    try { tmp.delete() } catch (_: Throwable) {}
                }
            } catch (_: Throwable) {
            } finally {
                pendingIconWrites.remove(packageName)
            }
        }
    }

    fun saveIconToDisk(context: Context, packageName: String, bitmap: Bitmap) {
        if (packageName.isBlank() || bitmap.isRecycled) return
        val pngBytes = try {
            val baos = java.io.ByteArrayOutputStream(4096)
            if (bitmap.compress(Bitmap.CompressFormat.PNG, 88, baos)) {
                baos.toByteArray()
            } else {
                null
            }
        } catch (_: Throwable) {
            null
        } ?: return
        saveIconBytesToDisk(context, packageName, pngBytes)
    }

    /**
     * Làm nóng sẵn trên Dispatchers.IO sau khi khung hình đầu đã lên:
     * - Nạp Snapshot Soi Ngầm & số liệu Sáng màn / Tắt màn (µAh) từ ROM vào RAM
     * - Nạp trước biểu tượng PNG từ ROM vào AppIconMemoryCache
     * - Giới hạn dung lượng thư mục icons cache theo budget ROM
     */
    fun prewarmHotAppCaches(context: Context) {
        val appCtx = context.applicationContext ?: context
        val budget = computeBudget(appCtx)

        // 1. Nạp trước dữ liệu Pin (µAh), Tốc độ xả Sáng màn/Tắt màn, Soi App Ngầm & Danh sách Launcher Apps vào RAM (0ms khi mở Tab 7)
        try {
            val batt = com.example.core.widget.BatteryInfoReader.read(appCtx, lightweight = true)
            com.example.core.ai.AiPowerAutopilotManager.getDrainRateAnalytics(
                context = appCtx,
                lightweightRead = true,
                preloadedBattery = batt
            )
        } catch (_: Throwable) {}
        try {
            com.example.core.widget.BackgroundDrainInspector.hydrateCachedReport(appCtx)
            com.example.core.widget.GestureLauncherOverlay.peekOrHydrateInstalledApps(appCtx)
        } catch (_: Throwable) {}

        // 2. Làm nóng top icon PNG từ ROM vào RAM LruCache & cắt tỉa nếu quá giới hạn
        try {
            val dir = getIconsCacheDir(appCtx)
            val files = dir.listFiles()?.toList().orEmpty()
            if (files.size > budget.maxDiskCachedIcons) {
                files.sortedBy { it.lastModified() }
                    .take(files.size - budget.maxDiskCachedIcons)
                    .forEach { try { it.delete() } catch (_: Throwable) {} }
            }
            com.example.core.widget.AppIconMemoryCache.warmUpFromDisk(appCtx, limit = 16)
        } catch (_: Throwable) {}
    }
}
