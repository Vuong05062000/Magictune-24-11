package com.example.core.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Quản lý lưu trữ cục bộ lịch sử trò chuyện trên bảng Gemini (MagicLiveFloatingOverlay):
 * - Lưu trữ cục bộ trên máy trong 24 giờ.
 * - Giữ nguyên toàn bộ đoạn chat khi đóng/mở bảng trong ngày.
 * - Tự động làm mới khi sang ngày hôm sau hoặc khi quá 24 giờ.
 * - Làm mới tức thì khi người dùng bấm "➕ Phiên mới".
 */
object GeminiFloatingChatHistoryStore {

    private const val TAG = "GeminiChatHistoryStore"
    private const val SESSION_FILE_NAME = "gemini_floating_session_v1.json"
    private const val IMAGES_DIR_NAME = "gemini_session_images"
    private const val MAX_BUBBLES_TO_STORE = 40
    private const val SESSION_TTL_MS = 24L * 60L * 60L * 1000L // 24 giờ

    data class StoredBubble(
        val id: String,
        val isUser: Boolean,
        val text: String,
        val timestampLabel: String,
        val imageCaption: String? = null,
        val imageLocalPath: String? = null,
        val isPendingPlaceholder: Boolean = false
    )

    data class RestoredSession(
        val sessionId: String,
        val sessionStartMs: Long,
        val bubbles: List<StoredBubbleWithBitmap>,
        val conversationHistory: List<Pair<String, String>>
    )

    data class StoredBubbleWithBitmap(
        val id: String,
        val isUser: Boolean,
        val text: String,
        val timestampLabel: String,
        val imageBitmap: Bitmap? = null,
        val imageCaption: String? = null,
        val imageLocalPath: String? = null
    )

    private val lock = Any()

    private fun getTodayDateString(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    private fun getSessionImagesDir(context: Context): File {
        val dir = File(context.applicationContext.filesDir, IMAGES_DIR_NAME)
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /**
     * Kiểm tra xem phiên trò chuyện hiện tại đã lưu trên máy còn hợp lệ không:
     * - Chưa quá 24 giờ kể từ thời điểm bắt đầu phiên.
     * - Vẫn trong cùng ngày (theo yêu cầu: làm mới vào ngày hôm sau).
     */
    fun isSessionValid(context: Context): Boolean {
        synchronized(lock) {
            try {
                val file = File(context.applicationContext.filesDir, SESSION_FILE_NAME)
                if (!file.exists() || file.length() < 5L) return false

                val raw = file.readText(Charsets.UTF_8)
                val root = JSONObject(raw)

                val sessionDate = root.optString("sessionDate", "")
                val today = getTodayDateString()
                if (sessionDate != today) {
                    Log.d(TAG, "Session expired due to new day: saved=$sessionDate, today=$today")
                    return false
                }

                val startMs = root.optLong("sessionStartMs", 0L)
                val now = System.currentTimeMillis()
                if (startMs <= 0L || (now - startMs) >= SESSION_TTL_MS) {
                    Log.d(TAG, "Session expired due to 24h TTL: age=${(now - startMs) / 1000}s")
                    return false
                }

                return true
            } catch (e: Throwable) {
                Log.w(TAG, "Error checking session validity: ${e.message}")
                return false
            }
        }
    }

    /**
     * Lưu ảnh Bitmap vào thư mục lưu trữ cục bộ của phiên chat.
     */
    fun saveBubbleImageToCache(context: Context, bubbleId: String, bitmap: Bitmap): String? {
        return try {
            val dir = getSessionImagesDir(context)
            val file = File(dir, "gemini_img_${bubbleId}.png")
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 95, out)
            }
            file.absolutePath
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to cache bubble image: ${e.message}")
            null
        }
    }

    /**
     * Lưu toàn bộ bong bóng chat và ngữ cảnh hội thoại vào đĩa.
     */
    fun saveSession(
        context: Context,
        sessionId: String,
        sessionStartMs: Long,
        bubbles: List<StoredBubbleWithBitmap>,
        conversationHistory: List<Pair<String, String>>
    ) {
        synchronized(lock) {
            try {
                val appCtx = context.applicationContext
                val root = JSONObject()
                root.put("sessionId", sessionId)
                root.put("sessionStartMs", if (sessionStartMs > 0L) sessionStartMs else System.currentTimeMillis())
                root.put("sessionDate", getTodayDateString())
                root.put("lastActiveMs", System.currentTimeMillis())

                // 1. Lưu bubbles (chỉ lấy tối đa MAX_BUBBLES_TO_STORE tin nhắn gần nhất)
                val bubblesArr = JSONArray()
                val targetBubbles = bubbles.takeLast(MAX_BUBBLES_TO_STORE)
                for (b in targetBubbles) {
                    val bObj = JSONObject()
                    bObj.put("id", b.id)
                    bObj.put("isUser", b.isUser)
                    bObj.put("text", b.text)
                    bObj.put("timestampLabel", b.timestampLabel)
                    if (!b.imageCaption.isNullOrBlank()) {
                        bObj.put("imageCaption", b.imageCaption)
                    }

                    var localPath = b.imageLocalPath
                    if (localPath.isNullOrBlank() && b.imageBitmap != null && !b.imageBitmap.isRecycled) {
                        localPath = saveBubbleImageToCache(appCtx, b.id, b.imageBitmap)
                    }
                    if (!localPath.isNullOrBlank()) {
                        bObj.put("imageLocalPath", localPath)
                    }

                    bubblesArr.put(bObj)
                }
                root.put("bubbles", bubblesArr)

                // 2. Lưu conversationHistory
                val convArr = JSONArray()
                val targetHistory = conversationHistory.takeLast(30)
                for (pair in targetHistory) {
                    val cObj = JSONObject()
                    cObj.put("role", pair.first)
                    cObj.put("content", pair.second)
                    convArr.put(cObj)
                }
                root.put("conversationHistory", convArr)

                val file = File(appCtx.filesDir, SESSION_FILE_NAME)
                file.writeText(root.toString(), Charsets.UTF_8)
                Log.d(TAG, "Saved Gemini floating session (${targetBubbles.size} bubbles, ${targetHistory.size} turns)")
            } catch (e: Throwable) {
                Log.e(TAG, "Failed to save Gemini session: ${e.message}")
            }
        }
    }

    /**
     * Khôi phục phiên trò chuyện đã lưu nếu còn hợp lệ.
     */
    fun restoreSession(context: Context): RestoredSession? {
        synchronized(lock) {
            if (!isSessionValid(context)) {
                clearSession(context)
                return null
            }

            return try {
                val appCtx = context.applicationContext
                val file = File(appCtx.filesDir, SESSION_FILE_NAME)
                if (!file.exists()) return null

                val raw = file.readText(Charsets.UTF_8)
                val root = JSONObject(raw)
                val sessionId = root.optString("sessionId", UUID.randomUUID().toString().take(8))
                val sessionStartMs = root.optLong("sessionStartMs", System.currentTimeMillis())

                val bubblesArr = root.optJSONArray("bubbles") ?: JSONArray()
                val restoredBubbles = mutableListOf<StoredBubbleWithBitmap>()

                for (i in 0 until bubblesArr.length()) {
                    val bObj = bubblesArr.optJSONObject(i) ?: continue
                    val id = bObj.optString("id", UUID.randomUUID().toString().take(8))
                    val isUser = bObj.optBoolean("isUser", false)
                    val text = bObj.optString("text", "")
                    val time = bObj.optString("timestampLabel", "Vừa xong")
                    val caption = if (bObj.has("imageCaption")) bObj.optString("imageCaption") else null
                    val path = if (bObj.has("imageLocalPath")) bObj.optString("imageLocalPath") else null

                    var bmp: Bitmap? = null
                    if (!path.isNullOrBlank()) {
                        val imgFile = File(path)
                        if (imgFile.exists() && imgFile.canRead()) {
                            try {
                                bmp = BitmapFactory.decodeFile(imgFile.absolutePath)
                            } catch (_: Throwable) {}
                        }
                    }

                    restoredBubbles.add(
                        StoredBubbleWithBitmap(
                            id = id,
                            isUser = isUser,
                            text = text,
                            timestampLabel = time,
                            imageBitmap = bmp,
                            imageCaption = caption,
                            imageLocalPath = path
                        )
                    )
                }

                val convArr = root.optJSONArray("conversationHistory") ?: JSONArray()
                val restoredHistory = mutableListOf<Pair<String, String>>()
                for (i in 0 until convArr.length()) {
                    val cObj = convArr.optJSONObject(i) ?: continue
                    val role = cObj.optString("role", "user")
                    val content = cObj.optString("content", "")
                    if (content.isNotBlank()) {
                        restoredHistory.add(role to content)
                    }
                }

                if (restoredBubbles.isEmpty()) null
                else RestoredSession(
                    sessionId = sessionId,
                    sessionStartMs = sessionStartMs,
                    bubbles = restoredBubbles,
                    conversationHistory = restoredHistory
                )
            } catch (e: Throwable) {
                Log.e(TAG, "Failed to restore Gemini session: ${e.message}")
                null
            }
        }
    }

    /**
     * Xóa sạch phiên trò chuyện khi người dùng bấm "➕ Phiên mới" hoặc khi quá hạn.
     */
    fun clearSession(context: Context) {
        synchronized(lock) {
            try {
                val appCtx = context.applicationContext
                val file = File(appCtx.filesDir, SESSION_FILE_NAME)
                if (file.exists()) file.delete()

                val imgDir = File(appCtx.filesDir, IMAGES_DIR_NAME)
                if (imgDir.exists()) {
                    imgDir.listFiles()?.forEach { try { it.delete() } catch (_: Throwable) {} }
                }
                Log.d(TAG, "Cleared Gemini session file and cached images")
            } catch (e: Throwable) {
                Log.w(TAG, "Failed to clear session: ${e.message}")
            }
        }
    }
}
